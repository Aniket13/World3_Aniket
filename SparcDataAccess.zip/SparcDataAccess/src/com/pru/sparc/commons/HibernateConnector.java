package com.pru.sparc.commons;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
/**
 *
 * @author 
 */
public class HibernateConnector {

    private static HibernateConnector hib_con;
    private Configuration cfg;
    private SessionFactory sessionFactory;
	@SuppressWarnings("deprecation")
	private HibernateConnector() throws HibernateException {

		try{
			sessionFactory = new AnnotationConfiguration().
	                   configure().addPackage("com.pru.sparc.model").
	                   buildSessionFactory();
	      }catch (Exception ex) { 
	         System.err.println("Failed to create sessionFactory object." + ex);
	         throw new ExceptionInInitializerError(ex); 
	      }
          }

    public static synchronized HibernateConnector getInstance() throws HibernateException {
        if (hib_con == null) {
        	hib_con = new HibernateConnector();
        }

        return hib_con;
    }

    public Session getSession() throws HibernateException {
        Session session = sessionFactory.openSession();
        if (!session.isConnected()) {
            this.reconnect();
        }
        return session;
    }

	private void reconnect() throws HibernateException {
        this.sessionFactory = cfg.buildSessionFactory();
    }
}
