package com.pru.sparc.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;


@Entity
@Table(name ="QUOTE_RATE_OVERRIDE")
@ComponentScan(" com.pru.sparc.model")
public class RatingOverride {

	@Id
	@GeneratedValue
	@Column(name="OVERRIDE_ID")
	private int overrideId;
	@Column(name="FIELD_KEY")
	private String fieldKey;
	@Column(name="FIELD_VAL")
	private double fieldValue;
	@Column(name="FIELD_SEQ")
	private int fieldSeqno;
	@Column(name="GROUP_ID")
	private String groupId;
	@Column(name="OVERRIDE_ALLOWED")
	private String overrideAllowed;
	@Column(name="OVERRIDE_INDICATOR")
	private String overrideIndicator;
	@Column(name="OVERRIDE_VAL")
	private double overrideValue;
	@Column(name="UW_APPROVAL")
	private String uwApproval;
	@Column(name="APPROVING_UW")
	private String approvingUW;
	@Column(name="APPROVAL_DATE")
	private Date approvalDate;
	@Column(name="UW_EVALUATION")
	private String uwEvalulation;
	
	@ManyToOne
	@JoinColumn(name="RATE_ID")
	private RatingExhibits ratingExhibits;
	
	public int getOverrideId() {
		return overrideId;
	}

	public void setOverrideId(int overrideId) {
		this.overrideId = overrideId;
	}

	public String getFieldKey() {
		return fieldKey;
	}

	public void setFieldKey(String fieldKey) {
		this.fieldKey = fieldKey;
	}

	public double getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(double fieldValue) {
		this.fieldValue = fieldValue;
	}

	public int getFieldSeqno() {
		return fieldSeqno;
	}

	public void setFieldSeqno(int fieldSeqno) {
		this.fieldSeqno = fieldSeqno;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getOverrideAllowed() {
		return overrideAllowed;
	}

	public void setOverrideAllowed(String overrideAllowed) {
		this.overrideAllowed = overrideAllowed;
	}

	public double getOverrideValue() {
		return overrideValue;
	}

	public void setOverrideValue(double overrideValue) {
		this.overrideValue = overrideValue;
	}

	public String getUwApproval() {
		return uwApproval;
	}

	public void setUwApproval(String uwApproval) {
		this.uwApproval = uwApproval;
	}

	public String getApprovingUW() {
		return approvingUW;
	}

	public void setApprovingUW(String approvingUW) {
		this.approvingUW = approvingUW;
	}

	public Date getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	public String getUwEvalulation() {
		return uwEvalulation;
	}

	public void setUwEvalulation(String uwEvalulation) {
		this.uwEvalulation = uwEvalulation;
	}

	public RatingExhibits getRatingExhibits() {
		return ratingExhibits;
	}

	public void setRatingExhibits(RatingExhibits ratingExhibits) {
		this.ratingExhibits = ratingExhibits;
	}

	public String getOverrideIndicator() {
		return overrideIndicator;
	}

	public void setOverrideIndicator(String overrideIndicator) {
		this.overrideIndicator = overrideIndicator;
	}
}

