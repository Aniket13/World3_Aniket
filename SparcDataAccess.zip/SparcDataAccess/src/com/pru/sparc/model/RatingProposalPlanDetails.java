package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name = "QUOTE_RATE_PROPOSAL_PLAN_DETAILS")
@ComponentScan(" com.pru.sparc.model")
public class RatingProposalPlanDetails {
	
	@Id
	@GeneratedValue
	@Column(name="RATE_PROPOSAL_PLAN_ID")
	private int rateProposalPlanId;
	
	@Column(name="PROPOSAL_EXHIBIT_LIVES")
	private double proposalExhibitLives;
	
	@Column(name="PROPOSAL_EXHIBIT_VOLUME")
	private double proposalExhibitVolume;
	
	@Column(name="PROPOSAL_EXHIBIT_RATE")
	private double proposalExhibitRate;
	
	@Column(name="PROPOSAL_EXHIBIT_PREMIUM")
	private double proposalExhibitPremium;
	
	@Column(name="COMPOSITE_RATE")
	private double compositeRate;
	
	@Column(name="ESTIMATED_LIVES")
	private double estLivesForPlan;
	
	@Column(name="EST_LIVES_ALL_COMPOSITE_PLANS")
	private double estLivesAllCompositePlan;
	
	@Column(name="ESTIMATED_VOLUME")
	private double estVolumeForPlan;
	
	@Column(name="EST_VOLUME_ALL_COMPOSITE_PLANS")
	private double estVolumeAllCompositePlan;
	
	@Column(name="MONTHLY_RATES")
	private double monthlyRates;
	
	@Column(name="MANUAL_RATE")
	private double manualRate;
	
	@Column(name="MONTHLY_PREMIUM")
	private double monthlyPremiumForPlan;
	
	@Column(name="MONTHLY_PREMIUM_ALL_COMPOSITE_PLAN")
	private double monthlyPremiumAllCompositePlan;
	
	@Column(name="GROUP_ID")
	private String groupId;
	
	@OneToOne
	@JoinColumn(name="RATE_ID")
	private RatingExhibits ratingExhibits;

	public int getRateProposalPlanId() {
		return rateProposalPlanId;
	}

	public void setRateProposalPlanId(int rateProposalPlanId) {
		this.rateProposalPlanId = rateProposalPlanId;
	}

	public double getProposalExhibitLives() {
		return proposalExhibitLives;
	}

	public void setProposalExhibitLives(double proposalExhibitLives) {
		this.proposalExhibitLives = proposalExhibitLives;
	}

	public double getProposalExhibitVolume() {
		return proposalExhibitVolume;
	}

	public void setProposalExhibitVolume(double proposalExhibitVolume) {
		this.proposalExhibitVolume = proposalExhibitVolume;
	}

	public double getProposalExhibitRate() {
		return proposalExhibitRate;
	}

	public void setProposalExhibitRate(double proposalExhibitRate) {
		this.proposalExhibitRate = proposalExhibitRate;
	}

	public double getProposalExhibitPremium() {
		return proposalExhibitPremium;
	}

	public void setProposalExhibitPremium(double proposalExhibitPremium) {
		this.proposalExhibitPremium = proposalExhibitPremium;
	}

	public double getCompositeRate() {
		return compositeRate;
	}

	public void setCompositeRate(double compositeRate) {
		this.compositeRate = compositeRate;
	}

	public double getEstLivesForPlan() {
		return estLivesForPlan;
	}

	public void setEstLivesForPlan(double estLivesForPlan) {
		this.estLivesForPlan = estLivesForPlan;
	}

	public double getEstLivesAllCompositePlan() {
		return estLivesAllCompositePlan;
	}

	public void setEstLivesAllCompositePlan(double estLivesAllCompositePlan) {
		this.estLivesAllCompositePlan = estLivesAllCompositePlan;
	}

	public double getEstVolumeForPlan() {
		return estVolumeForPlan;
	}

	public void setEstVolumeForPlan(double estVolumeForPlan) {
		this.estVolumeForPlan = estVolumeForPlan;
	}

	public double getEstVolumeAllCompositePlan() {
		return estVolumeAllCompositePlan;
	}

	public void setEstVolumeAllCompositePlan(double estVolumeAllCompositePlan) {
		this.estVolumeAllCompositePlan = estVolumeAllCompositePlan;
	}

	public double getMonthlyRates() {
		return monthlyRates;
	}

	public void setMonthlyRates(double monthlyRates) {
		this.monthlyRates = monthlyRates;
	}

	public double getManualRate() {
		return manualRate;
	}

	public void setManualRate(double manualRate) {
		this.manualRate = manualRate;
	}

	public double getMonthlyPremiumForPlan() {
		return monthlyPremiumForPlan;
	}

	public void setMonthlyPremiumForPlan(double monthlyPremiumForPlan) {
		this.monthlyPremiumForPlan = monthlyPremiumForPlan;
	}

	public double getMonthlyPremiumAllCompositePlan() {
		return monthlyPremiumAllCompositePlan;
	}

	public void setMonthlyPremiumAllCompositePlan(
			double monthlyPremiumAllCompositePlan) {
		this.monthlyPremiumAllCompositePlan = monthlyPremiumAllCompositePlan;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public RatingExhibits getRatingExhibits() {
		return ratingExhibits;
	}

	public void setRatingExhibits(RatingExhibits ratingExhibits) {
		this.ratingExhibits = ratingExhibits;
	}
}
