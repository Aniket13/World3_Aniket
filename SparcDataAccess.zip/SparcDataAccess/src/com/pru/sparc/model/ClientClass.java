package com.pru.sparc.model;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name="CLIENT")
@ComponentScan(" com.pru.sparc.model")
public class ClientClass {
	@Id
	@GeneratedValue
	@Column(name="CLIENT_ID")
	private int clientId;
	@Column(name="CLIENT_NAME", length=100)
	private String clientName;
	@Column(name="PARENT_COMPANY", length=50)
	private String parentCompany;
	@Column(name="FULL_LEGAL_NAME", length=100)
	private String fullLegalName;
	@Column(name="DBA",length=20)
	private String dba;
	@Column(name="DBNO", length=10)
	private String dAndB;
	@Column(name="SIC_NO", length=20)
	private String sic;
	@Column(name="NATURE_BUSINESS", length=20)
	private String natureOfBusiness;
	@Column(name="CONTRACT_STATE", length=30)
	private String contractState;
	@Column(name="NON_ERISA", length=10)
	private String nonErisa;
	@Column(name="TIN_NO", length=20)
	private String tin;
	@Column(name="CONTACT_NAME", length=30)
	private String contactName;
	@Column(name="CONTACT_EMAIL", length=100)
	private String contactEmail;
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER, mappedBy="client")
	private List<AddressDetails> address;
	@Column(name="STATUS", length=20)
	private String status;
	@Column(name="CREATED_BY", length=30)
	private String createdBy;
	@Column(name="CREATED_DATE")
	private Date createdDate;
	@Column(name="UPDATED_BY", length=30)
	private String updatedBy;
	@Column(name="UPDATED_DATE")
	private Date updatedDate;
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="client")
	private Set<ProposalDetails> proposals;
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="client")
	private Set<CensusDetail> censusFiles;
	
	
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getParentCompany() {
		return parentCompany;
	}
	public String getSic() {
		return sic;
	}
	public void setSic(String sic) {
		this.sic = sic;
	}
	public List<AddressDetails> getAddress() {
		return address;
	}
	public void setAddress(List<AddressDetails> address) {
		this.address = address;
	}
	public void setParentCompany(String parentCompany) {
		this.parentCompany = parentCompany;
	}
	public String getFullLegalName() {
		return fullLegalName;
	}
	public void setFullLegalName(String fullLegalName) {
		this.fullLegalName = fullLegalName;
	}
	public String getDba() {
		return dba;
	}
	public void setDba(String dba) {
		this.dba = dba;
	}
	public String getdAndB() {
		return dAndB;
	}
	public void setdAndB(String dAndB) {
		this.dAndB = dAndB;
	}
	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}
	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}
	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public String getNonErisa() {
		return nonErisa;
	}
	public void setNonErisa(String nonErisa) {
		this.nonErisa = nonErisa;
	}
	public String getTin() {
		return tin;
	}
	public void setTin(String tin) {
		this.tin = tin;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public Set<ProposalDetails> getProposals() {
		return proposals;
	}
	public void setProposals(Set<ProposalDetails> proposals) {
		this.proposals = proposals;
	}
	public Set<CensusDetail> getCensusFiles() {
		return censusFiles;
	}
	public void setCensusFiles(Set<CensusDetail> censusFiles) {
		this.censusFiles = censusFiles;
	}
	
}
