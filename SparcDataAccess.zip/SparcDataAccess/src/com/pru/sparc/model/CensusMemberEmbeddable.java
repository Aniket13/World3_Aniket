package com.pru.sparc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Embeddable
public class CensusMemberEmbeddable implements Serializable {
	private static final long serialVersionUID = -1324374720968664690L;
	
	@Column(name = "CENSUS_MEMBER_ID", length = 100)
	private String censusMemberId;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "CENSUS_ID")
	private CensusDetail censusDetail;
	
	public String getCensusMemberId() {
		return censusMemberId;
	}
	public void setCensusMemberId(String censusMemberId) {
		this.censusMemberId = censusMemberId;
	}
	public CensusDetail getCensusDetail() {
		return censusDetail;
	}
	public void setCensusDetail(CensusDetail censusDetail) {
		this.censusDetail = censusDetail;
	}	
}
