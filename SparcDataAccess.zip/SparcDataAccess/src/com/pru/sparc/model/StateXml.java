package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;

@Entity
@Table(name="SPARC_STATE_DETAILS")
public class StateXml {
	
	@GeneratedValue
	@Column(name="STATEID")
	private int stateId;
	@EmbeddedId
	private StateXmlEmbeddable stateXmlEmbeddable;
	@Column(name="VERSION_STATUS", length=50)
	private String versionStatus;
	@Column(name="PROPOSAL_STATUS", length=50)
	private String proposalStatus;
	@Column(name="STATE_STATUS", length=20)
	private String stateStatus;
	@Column(name="PRE_COND", length=50)
	private String preCond;
	@Column(name="POST_COND", length=50)
	private String postCond;
	@Column(name="USER_ID", length=50)
	private String userId;
	@Column(name="CRT_DT", length=30)
	private String crtDt;
	@Column(name="MOD_USER", length=50)
	private String modUser;
	@Column(name="MOD_DT", length=30)
	private String modDt;
	
	public StateXml() {}
	
	public StateXml(int stateId, String versionStatus, String proposalStatus,
			String stateStatus, String preCond, String postCond, String userId,
			String crtDt, String modUser, String modDt
			) {
		super();
		this.stateId = stateId;
		this.versionStatus = versionStatus;
		this.proposalStatus = proposalStatus;
		this.stateStatus = stateStatus;
		this.preCond = preCond;
		this.postCond = postCond;
		this.userId = userId;
		this.crtDt = crtDt;
		this.modUser = modUser;
		this.modDt = modDt;
		
	}
	
	public StateXmlEmbeddable getStateXmlEmbeddable() {
		return stateXmlEmbeddable;
	}
	public void setStateXmlEmbeddable(StateXmlEmbeddable stateXmlEmbeddable) {
		this.stateXmlEmbeddable = stateXmlEmbeddable;
	}
	
	public String getStateStatus() {
		return stateStatus;
	}

	public void setStateStatus(String stateStatus) {
		this.stateStatus = stateStatus;
	}
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public String getVersionStatus() {
		return versionStatus;
	}
	public void setVersionStatus(String versionStatus) {
		this.versionStatus = versionStatus;
	}
	public String getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	public String getPreCond() {
		return preCond;
	}
	public void setPreCond(String preCond) {
		this.preCond = preCond;
	}
	public String getPostCond() {
		return postCond;
	}
	public void setPostCond(String postCond) {
		this.postCond = postCond;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCrtDt() {
		return crtDt;
	}
	public void setCrtDt(String crtDt) {
		this.crtDt = crtDt;
	}
	public String getModUser() {
		return modUser;
	}
	public void setModUser(String modUser) {
		this.modUser = modUser;
	}
	public String getModDt() {
		return modDt;
	}
	public void setModDt(String modDt) {
		this.modDt = modDt;
	}
	
	
}
