package com.pru.sparc.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name="PLAN")
@ComponentScan(" com.pru.sparc.model")
public class PlanDetailsClass {
	
	/*@EmbeddedId
    private PlanDetailsEmbadable planDetailsEmbadable;*/
	
	@Id
	@GeneratedValue
	@Column(name="PLAN_ID")
	private Integer planId;
	@Column(name="OVER_ID")
	private Integer overId;
	/*@Column(name="PLAN_SEQ")
	private Integer planSeq;*/
	@Column(name="PLAN_DESC")
	private String planDescription;
	@Column(name="PROD_CODE")
	private String productCode;
	@Column(name="EFF_DATE")
	private Date effectiveDate;
	@Column(name="CONTRACT_STATE")
	private String contractState;
	@Column(name="TYPE_OF_CASE")
	private String typeOfCase;
	@Column(name="PRUVALUE_EXCEP")
	private String pruValueException;
	@Column(name="FIELD_LVL_EXCEP")
	private String fieldLevelException;
	@Column(name="CONTRIB_ARNGMNT")
	private String contributionArrangement;
	@Column(name="OVERIDE_INDI")
	private String overrideIndicator;
	@Column(name="MIN_PARTI_PCT")
	private Float minParticipationPct;
	@Column(name="VOLAT_CAVEAT_PCT")
	private Float volatilityCaveatPct;
	@Column(name="COMPOSITE_RATING")
	private String compositeRating;
	@Column(name="AGE_BAND_RATING")
	private String ageBandedRating;
	@Column(name="RATE_GAURANTEE")
	private Integer rateGurantee;
	@Column(name="RATE_EXPRESSION")
	private String rateExpression;
	@Column(name="AMT_OF_INSURANCE")
	private String insuranceAmount;
	@Column(name="MAX_DOLLAR_AMT")
	private Double maxDollaramt;
	@Column(name="MIN_DOLLAR_AMT")
	private Double minDollarAmt;
	@Column(name="MULTI_OF_EARNINGS")
	private String multipleOfEarnings;
	@Column(name="ROUNDING_RULE")
	private String roundingRule;
	@Column(name="ROUNDING_OCCURS")
	private String roundingOccurs;
	@Column(name="AGE_RED_SCH")
	private String ageReductionSchedule;
	@Column(name="DISAB_PROVSN")
	private String disablityProvision;
	@Column(name="DURATION")
	private String duration;
	@Column(name="VOLUME_AMT")
	private String volumeAmounts;
	@Column(name="GUAR_ISSUE_LIMIT")
	private String guranteeIssueLimit;
	@Column(name="DOLLAR_AMT")
	private Double dollarAmount;
	@Column(name="LIV_BNF_OPT")
	private String livingBenefitOption;
	@Column(name="LBO_MAX")
	private Double lboMax;
	@Column(name="LBO_PCT")
	private Float lboPercent;
	@Column(name="LBO_LIFE_EXPECT")
	private String lboLifeExpectancy;
	@Column(name="COV_TERMI_RETIR")
	private String coverageTerminateAtRetirement;
	@Column(name="TRAVEL_ASSIST")
	private String travelAssistance;
	@Column(name="EARN_DEFN")
	private String earningDefiniton;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_ID")
	private ProductDetails product;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PROPOSAL_VERSION_ID")
	private QuotationDetails version;
	@Column(name="INCLUDE_BONUS")
	private String includeBonus;
	@Column(name="INCLUDE_COMMISSION")
	private String includeCommission;
	@Column(name="INCLUDE_OVERTIME")
	private String includeOvertime;
	@Column(name="MIN_HRS_REQ")
	private Double minHrsReqd ;
	@Column(name="INF_CRR_RATE")
	private Double infCrrRate;
	@Column(name="REN_CRR_RATE")
	private Double renCrrRate;
	@Column(name="DISPLAY_PLAN")
	private String displayPlan;
	@Column(name="ORIGINAL_PLAN_ID")
	private Integer originalPlanId;
	@Column(name="CASE_FLAT_AMT")
	private Double caseFlatAmt;
	
	//newly added fields
	@Column(name="EMPLOYEE_CONTRIB_TYPE")
	private String employeeContribType;
	@Column(name="EMPLOYEE_CONTRIB_FLAT_AMT")
	private Double employeeContribFlatAmt;
	@Column(name="EMPLOYEE_CONTRIB_PERCENT")
	private Double employeeContribPercent;
	@Column(name="MULTI_OF_EARNINGS_MAX_DOLLAR_AMT")
	private Double multiOfEarningsMaxDollarAmt;
	@Column(name="MULTI_OF_EARNINGS_MIN_DOLLAR_AMT")
	private Double multiOfEarningsMinDollarAmt;
	@Column(name="PREMIUM_CONTINUANCE_DETAILS")
	private String premiumContinuanceDetails;
	@Column(name="ENROLLMENT_ASSUMPTION_VARIATION")
	private String enrollmentAssumptionVariation;
	@Column(name="RATE_EXPRESSION_OTHER")
	private String rateExpressionOther;
	@Column(name="LBO_LIFE_EXPECTANCY_OTHER")
	private String lboLifeExpectancyOther;
	@Column(name="GRANDFATHERING_GROUP")
	private String grandfatheringGroup;
	@Column(name="FLAT_DOLLAR_AMOUNT")
	private Double flatDollarAmount;
	@Column(name="ROUNDING_RULE_ATTRIBUTE")
	private String roundingRuleAttribute;
	@Column(name="AGE_RED_SCHEDULE_ATTRIBUTE")
	private String ageRedScheduleAttribute;
	@Column(name="DURATION_ATTRIBUTE")
	private String durationAttribute;
	@Column(name="SUBPRODUCT_ATTRIBUTE")
	private String subProductAttribute;
	@Column(name="INCREMENTAL_DOLLAR_AMOUNT")
	private Double incrementalDollAramount;
	@Column(name="ENROLLMENT_ASSUMPTION")
	private String enrollmentAssumption;
	@Column(name="MULTINATIONAL_POOLING_VALUE")
	private String multinationalPoolingValue;
	@Column(name="EXPERIENCE_ARRANGEMENT")
	private String experienceArrangement;
	@Column(name="GUARANTEE_ISSUE_LMT_MULTI_OF_EARN")
	private String guaranteeIssueLmtMultiOfEarn;	
	@Column(name="GRANDFATHERING_TYPE")
	private String grandFatheringType;
	@Column(name="PRCT_BL_ACTIVE_AMT_MAX_DOLLAR_AMT")
	private Double prctBlActiveAmtMaxDollarAmt;
	@Column(name="PRCT_BL_ACTIVE_AMT_MIN_DOLLAR_AMT")
	private Double prctBlActiveAmtMinDollarAmt;
	@Column(name="PRCT_BL_ACTIVE_AMT")
	private Double prctBlActiveAmt;
	@Column(name="ELIMINATION_PERIOD")
	private String eliminationPeriod;
	@Column(name="QUALIFYING_AGE")
	private String qualifyingAge;
	@Column(name="TERMINATION_AGE")
	private String terminationAge;
	@Column(name="LBO_APPLIES_TO")
	private String lboAppliesTo;
	@Column(name="ORDER_OF_PRIORITY_LBO_CLAIM_PAYMENT")
	private String orderOfPriorityLboClaimPayment;
	@Column(name="OTHER_DURATION_AGE")
	private String otherDurationAge;
	@Column(name="SPECIFIC_EMPLOYEE_WAITING_PERIOD_DAYS")
	private Integer specificEmployeeWaitingPeriodDays;
	@Column(name="RETENTION_BASIS")
	private String retentionBasis;
	@Column(name="GUARANTEE_ISSUE")
	private String guaranteeIssue;
	@Column(name="MEDICAL_UNDERWRITING")
	private String medicalUnderwriting;
	@Column(name="BURIAL_EXPENSE_PAYMENT")
	private String burialExpensePayment;
	@Column(name="EMPLOYEE_WAITING_PERIOD_OPTION")
	private String employeeWaitingPeriodOption;
	@Column(name="BENEFICIARY_FIN_COUNSELING_SERVICE")
	private String beneficiaryFinCounselingService;
	@Column(name="EXISTING_EARNING_DEFINITION")
	private String existingEarningDefinition;
	@Column(name="MAX_DOLLAR_CAP")
	private Double maxDollarCap;
	
	@Column(name="BONUS_AVG_DOLLAR")
	private String bonusAvgDollar;
	@Column(name="COMMISSION_AVG_DOLLAR")
	private String commissionAvgDollar;
	@Column(name="OVERTIME_AVG_DOLLAR")
	private String overtimeAvgDollar;
	
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	public Integer getOverId() {
		return overId;
	}
	public void setOverId(Integer overId) {
		this.overId = overId;
	}
	public String getPlanDescription() {
		return planDescription;
	}
	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public String getTypeOfCase() {
		return typeOfCase;
	}
	public void setTypeOfCase(String typeOfCase) {
		this.typeOfCase = typeOfCase;
	}
	public String getPruValueException() {
		return pruValueException;
	}
	public void setPruValueException(String pruValueException) {
		this.pruValueException = pruValueException;
	}
	public String getFieldLevelException() {
		return fieldLevelException;
	}
	public void setFieldLevelException(String fieldLevelException) {
		this.fieldLevelException = fieldLevelException;
	}
	public String getContributionArrangement() {
		return contributionArrangement;
	}
	public void setContributionArrangement(String contributionArrangement) {
		this.contributionArrangement = contributionArrangement;
	}
	public String getOverrideIndicator() {
		return overrideIndicator;
	}
	public void setOverrideIndicator(String overrideIndicator) {
		this.overrideIndicator = overrideIndicator;
	}
	public Float getMinParticipationPct() {
		return minParticipationPct;
	}
	public void setMinParticipationPct(Float minParticipationPct) {
		this.minParticipationPct = minParticipationPct;
	}
	public Float getVolatilityCaveatPct() {
		return volatilityCaveatPct;
	}
	public void setVolatilityCaveatPct(Float volatilityCaveatPct) {
		this.volatilityCaveatPct = volatilityCaveatPct;
	}
	public String getCompositeRating() {
		return compositeRating;
	}
	public void setCompositeRating(String compositeRating) {
		this.compositeRating = compositeRating;
	}
	public String getAgeBandedRating() {
		return ageBandedRating;
	}
	public void setAgeBandedRating(String ageBandedRating) {
		this.ageBandedRating = ageBandedRating;
	}
	public Integer getRateGurantee() {
		return rateGurantee;
	}
	public void setRateGurantee(Integer rateGurantee) {
		this.rateGurantee = rateGurantee;
	}
	public String getRateExpression() {
		return rateExpression;
	}
	public void setRateExpression(String rateExpression) {
		this.rateExpression = rateExpression;
	}
	public String getInsuranceAmount() {
		return insuranceAmount;
	}
	public void setInsuranceAmount(String insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}
	public Double getMaxDollaramt() {
		return maxDollaramt;
	}
	public void setMaxDollaramt(Double maxDollaramt) {
		this.maxDollaramt = maxDollaramt;
	}
	public Double getMinDollarAmt() {
		return minDollarAmt;
	}
	public void setMinDollarAmt(Double minDollarAmt) {
		this.minDollarAmt = minDollarAmt;
	}
	public String getMultipleOfEarnings() {
		return multipleOfEarnings;
	}
	public void setMultipleOfEarnings(String multipleOfEarnings) {
		this.multipleOfEarnings = multipleOfEarnings;
	}
	public String getRoundingRule() {
		return roundingRule;
	}
	public void setRoundingRule(String roundingRule) {
		this.roundingRule = roundingRule;
	}
	public String getRoundingOccurs() {
		return roundingOccurs;
	}
	public void setRoundingOccurs(String roundingOccurs) {
		this.roundingOccurs = roundingOccurs;
	}
	public String getAgeReductionSchedule() {
		return ageReductionSchedule;
	}
	public void setAgeReductionSchedule(String ageReductionSchedule) {
		this.ageReductionSchedule = ageReductionSchedule;
	}
	public String getDisablityProvision() {
		return disablityProvision;
	}
	public void setDisablityProvision(String disablityProvision) {
		this.disablityProvision = disablityProvision;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getVolumeAmounts() {
		return volumeAmounts;
	}
	public void setVolumeAmounts(String volumeAmounts) {
		this.volumeAmounts = volumeAmounts;
	}
	public String getGuranteeIssueLimit() {
		return guranteeIssueLimit;
	}
	public void setGuranteeIssueLimit(String guranteeIssueLimit) {
		this.guranteeIssueLimit = guranteeIssueLimit;
	}
	public Double getDollarAmount() {
		return dollarAmount;
	}
	public void setDollarAmount(Double dollarAmount) {
		this.dollarAmount = dollarAmount;
	}
	public String getLivingBenefitOption() {
		return livingBenefitOption;
	}
	public void setLivingBenefitOption(String livingBenefitOption) {
		this.livingBenefitOption = livingBenefitOption;
	}
	public Double getLboMax() {
		return lboMax;
	}
	public void setLboMax(Double lboMax) {
		this.lboMax = lboMax;
	}
	public Float getLboPercent() {
		return lboPercent;
	}
	public void setLboPercent(Float lboPercent) {
		this.lboPercent = lboPercent;
	}
	public String getLboLifeExpectancy() {
		return lboLifeExpectancy;
	}
	public void setLboLifeExpectancy(String lboLifeExpectancy) {
		this.lboLifeExpectancy = lboLifeExpectancy;
	}
	public String getCoverageTerminateAtRetirement() {
		return coverageTerminateAtRetirement;
	}
	public void setCoverageTerminateAtRetirement(
			String coverageTerminateAtRetirement) {
		this.coverageTerminateAtRetirement = coverageTerminateAtRetirement;
	}
	public String getTravelAssistance() {
		return travelAssistance;
	}
	public void setTravelAssistance(String travelAssistance) {
		this.travelAssistance = travelAssistance;
	}
	public String getEarningDefiniton() {
		return earningDefiniton;
	}
	public void setEarningDefiniton(String earningDefiniton) {
		this.earningDefiniton = earningDefiniton;
	}
	public ProductDetails getProduct() {
		return product;
	}
	public void setProduct(ProductDetails product) {
		this.product = product;
	}
	public QuotationDetails getVersion() {
		return version;
	}
	public void setVersion(QuotationDetails version) {
		this.version = version;
	}
	public String getIncludeBonus() {
		return includeBonus;
	}
	public void setIncludeBonus(String includeBonus) {
		this.includeBonus = includeBonus;
	}
	public String getIncludeCommission() {
		return includeCommission;
	}
	public void setIncludeCommission(String includeCommission) {
		this.includeCommission = includeCommission;
	}
	public String getIncludeOvertime() {
		return includeOvertime;
	}
	public void setIncludeOvertime(String includeOvertime) {
		this.includeOvertime = includeOvertime;
	}
	public Double getMinHrsReqd() {
		return minHrsReqd;
	}
	public void setMinHrsReqd(Double minHrsReqd) {
		this.minHrsReqd = minHrsReqd;
	}
	public Double getInfCrrRate() {
		return infCrrRate;
	}
	public void setInfCrrRate(Double infCrrRate) {
		this.infCrrRate = infCrrRate;
	}
	public Double getRenCrrRate() {
		return renCrrRate;
	}
	public void setRenCrrRate(Double renCrrRate) {
		this.renCrrRate = renCrrRate;
	}
	public String getDisplayPlan() {
		return displayPlan;
	}
	public void setDisplayPlan(String displayPlan) {
		this.displayPlan = displayPlan;
	}
	public Integer getOriginalPlanId() {
		return originalPlanId;
	}
	public void setOriginalPlanId(Integer originalPlanId) {
		this.originalPlanId = originalPlanId;
	}
	public Double getCaseFlatAmt() {
		return caseFlatAmt;
	}
	public void setCaseFlatAmt(Double caseFlatAmt) {
		this.caseFlatAmt = caseFlatAmt;
	}
	public String getEmployeeContribType() {
		return employeeContribType;
	}
	public void setEmployeeContribType(String employeeContribType) {
		this.employeeContribType = employeeContribType;
	}
	public Double getEmployeeContribFlatAmt() {
		return employeeContribFlatAmt;
	}
	public void setEmployeeContribFlatAmt(Double employeeContribFlatAmt) {
		this.employeeContribFlatAmt = employeeContribFlatAmt;
	}
	public Double getEmployeeContribPercent() {
		return employeeContribPercent;
	}
	public void setEmployeeContribPercent(Double employeeContribPercent) {
		this.employeeContribPercent = employeeContribPercent;
	}
	public Double getMultiOfEarningsMaxDollarAmt() {
		return multiOfEarningsMaxDollarAmt;
	}
	public void setMultiOfEarningsMaxDollarAmt(Double multiOfEarningsMaxDollarAmt) {
		this.multiOfEarningsMaxDollarAmt = multiOfEarningsMaxDollarAmt;
	}
	public Double getMultiOfEarningsMinDollarAmt() {
		return multiOfEarningsMinDollarAmt;
	}
	public void setMultiOfEarningsMinDollarAmt(Double multiOfEarningsMinDollarAmt) {
		this.multiOfEarningsMinDollarAmt = multiOfEarningsMinDollarAmt;
	}
	public String getPremiumContinuanceDetails() {
		return premiumContinuanceDetails;
	}
	public void setPremiumContinuanceDetails(String premiumContinuanceDetails) {
		this.premiumContinuanceDetails = premiumContinuanceDetails;
	}
	public String getEnrollmentAssumptionVariation() {
		return enrollmentAssumptionVariation;
	}
	public void setEnrollmentAssumptionVariation(
			String enrollmentAssumptionVariation) {
		this.enrollmentAssumptionVariation = enrollmentAssumptionVariation;
	}
	public String getRateExpressionOther() {
		return rateExpressionOther;
	}
	public void setRateExpressionOther(String rateExpressionOther) {
		this.rateExpressionOther = rateExpressionOther;
	}
	public String getLboLifeExpectancyOther() {
		return lboLifeExpectancyOther;
	}
	public void setLboLifeExpectancyOther(String lboLifeExpectancyOther) {
		this.lboLifeExpectancyOther = lboLifeExpectancyOther;
	}
	public String getGrandfatheringGroup() {
		return grandfatheringGroup;
	}
	public void setGrandfatheringGroup(String grandfatheringGroup) {
		this.grandfatheringGroup = grandfatheringGroup;
	}
	public Double getFlatDollarAmount() {
		return flatDollarAmount;
	}
	public void setFlatDollarAmount(Double flatDollarAmount) {
		this.flatDollarAmount = flatDollarAmount;
	}
	public String getRoundingRuleAttribute() {
		return roundingRuleAttribute;
	}
	public void setRoundingRuleAttribute(String roundingRuleAttribute) {
		this.roundingRuleAttribute = roundingRuleAttribute;
	}
	public String getAgeRedScheduleAttribute() {
		return ageRedScheduleAttribute;
	}
	public void setAgeRedScheduleAttribute(String ageRedScheduleAttribute) {
		this.ageRedScheduleAttribute = ageRedScheduleAttribute;
	}
	public String getDurationAttribute() {
		return durationAttribute;
	}
	public void setDurationAttribute(String durationAttribute) {
		this.durationAttribute = durationAttribute;
	}
	public String getSubProductAttribute() {
		return subProductAttribute;
	}
	public void setSubProductAttribute(String subProductAttribute) {
		this.subProductAttribute = subProductAttribute;
	}
	public Double getIncrementalDollAramount() {
		return incrementalDollAramount;
	}
	public void setIncrementalDollAramount(Double incrementalDollAramount) {
		this.incrementalDollAramount = incrementalDollAramount;
	}
	public String getEnrollmentAssumption() {
		return enrollmentAssumption;
	}
	public void setEnrollmentAssumption(String enrollmentAssumption) {
		this.enrollmentAssumption = enrollmentAssumption;
	}
	public String getMultinationalPoolingValue() {
		return multinationalPoolingValue;
	}
	public void setMultinationalPoolingValue(String multinationalPoolingValue) {
		this.multinationalPoolingValue = multinationalPoolingValue;
	}
	public String getExperienceArrangement() {
		return experienceArrangement;
	}
	public void setExperienceArrangement(String experienceArrangement) {
		this.experienceArrangement = experienceArrangement;
	}
	public String getGuaranteeIssueLmtMultiOfEarn() {
		return guaranteeIssueLmtMultiOfEarn;
	}
	public void setGuaranteeIssueLmtMultiOfEarn(String guaranteeIssueLmtMultiOfEarn) {
		this.guaranteeIssueLmtMultiOfEarn = guaranteeIssueLmtMultiOfEarn;
	}
	public String getGrandFatheringType() {
		return grandFatheringType;
	}
	public void setGrandFatheringType(String grandFatheringType) {
		this.grandFatheringType = grandFatheringType;
	}
	public Double getPrctBlActiveAmtMaxDollarAmt() {
		return prctBlActiveAmtMaxDollarAmt;
	}
	public void setPrctBlActiveAmtMaxDollarAmt(Double prctBlActiveAmtMaxDollarAmt) {
		this.prctBlActiveAmtMaxDollarAmt = prctBlActiveAmtMaxDollarAmt;
	}
	public Double getPrctBlActiveAmtMinDollarAmt() {
		return prctBlActiveAmtMinDollarAmt;
	}
	public void setPrctBlActiveAmtMinDollarAmt(Double prctBlActiveAmtMinDollarAmt) {
		this.prctBlActiveAmtMinDollarAmt = prctBlActiveAmtMinDollarAmt;
	}
	public Double getPrctBlActiveAmt() {
		return prctBlActiveAmt;
	}
	public void setPrctBlActiveAmt(Double prctBlActiveAmt) {
		this.prctBlActiveAmt = prctBlActiveAmt;
	}
	public String getEliminationPeriod() {
		return eliminationPeriod;
	}
	public void setEliminationPeriod(String eliminationPeriod) {
		this.eliminationPeriod = eliminationPeriod;
	}
	public String getQualifyingAge() {
		return qualifyingAge;
	}
	public void setQualifyingAge(String qualifyingAge) {
		this.qualifyingAge = qualifyingAge;
	}
	public String getTerminationAge() {
		return terminationAge;
	}
	public void setTerminationAge(String terminationAge) {
		this.terminationAge = terminationAge;
	}
	public String getLboAppliesTo() {
		return lboAppliesTo;
	}
	public void setLboAppliesTo(String lboAppliesTo) {
		this.lboAppliesTo = lboAppliesTo;
	}
	public String getOrderOfPriorityLboClaimPayment() {
		return orderOfPriorityLboClaimPayment;
	}
	public void setOrderOfPriorityLboClaimPayment(
			String orderOfPriorityLboClaimPayment) {
		this.orderOfPriorityLboClaimPayment = orderOfPriorityLboClaimPayment;
	}
	public String getOtherDurationAge() {
		return otherDurationAge;
	}
	public void setOtherDurationAge(String otherDurationAge) {
		this.otherDurationAge = otherDurationAge;
	}
	public Integer getSpecificEmployeeWaitingPeriodDays() {
		return specificEmployeeWaitingPeriodDays;
	}
	public void setSpecificEmployeeWaitingPeriodDays(
			Integer specificEmployeeWaitingPeriodDays) {
		this.specificEmployeeWaitingPeriodDays = specificEmployeeWaitingPeriodDays;
	}
	public String getRetentionBasis() {
		return retentionBasis;
	}
	public void setRetentionBasis(String retentionBasis) {
		this.retentionBasis = retentionBasis;
	}
	public String getGuaranteeIssue() {
		return guaranteeIssue;
	}
	public void setGuaranteeIssue(String guaranteeIssue) {
		this.guaranteeIssue = guaranteeIssue;
	}
	public String getMedicalUnderwriting() {
		return medicalUnderwriting;
	}
	public void setMedicalUnderwriting(String medicalUnderwriting) {
		this.medicalUnderwriting = medicalUnderwriting;
	}
	public String getBurialExpensePayment() {
		return burialExpensePayment;
	}
	public void setBurialExpensePayment(String burialExpensePayment) {
		this.burialExpensePayment = burialExpensePayment;
	}
	public String getEmployeeWaitingPeriodOption() {
		return employeeWaitingPeriodOption;
	}
	public void setEmployeeWaitingPeriodOption(String employeeWaitingPeriodOption) {
		this.employeeWaitingPeriodOption = employeeWaitingPeriodOption;
	}
	public String getBeneficiaryFinCounselingService() {
		return beneficiaryFinCounselingService;
	}
	public void setBeneficiaryFinCounselingService(
			String beneficiaryFinCounselingService) {
		this.beneficiaryFinCounselingService = beneficiaryFinCounselingService;
	}
	public String getExistingEarningDefinition() {
		return existingEarningDefinition;
	}
	public void setExistingEarningDefinition(String existingEarningDefinition) {
		this.existingEarningDefinition = existingEarningDefinition;
	}
	public Double getMaxDollarCap() {
		return maxDollarCap;
	}
	public void setMaxDollarCap(Double maxDollarCap) {
		this.maxDollarCap = maxDollarCap;
	}
	public String getBonusAvgDollar() {
		return bonusAvgDollar;
	}
	public void setBonusAvgDollar(String bonusAvgDollar) {
		this.bonusAvgDollar = bonusAvgDollar;
	}
	public String getCommissionAvgDollar() {
		return commissionAvgDollar;
	}
	public void setCommissionAvgDollar(String commissionAvgDollar) {
		this.commissionAvgDollar = commissionAvgDollar;
	}
	public String getOvertimeAvgDollar() {
		return overtimeAvgDollar;
	}
	public void setOvertimeAvgDollar(String overtimeAvgDollar) {
		this.overtimeAvgDollar = overtimeAvgDollar;
	}
	
	

	
}
