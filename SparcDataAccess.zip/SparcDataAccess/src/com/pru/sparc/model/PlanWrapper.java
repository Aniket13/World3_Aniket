package com.pru.sparc.model;

import java.util.List;

public class PlanWrapper {
	private PlanDetailsClass planDetailsClass;
	private List<PlanEligibilityClass> planEligibilityClass;
	private ProposalBrokerDetails proposalBrokerDetails;
	private PlanDetailsClass overriddenDetails;
	public PlanDetailsClass getPlanDetailsClass() {
		return planDetailsClass;
	}
	public void setPlanDetailsClass(PlanDetailsClass plaDetailsClass) {
		this.planDetailsClass = plaDetailsClass;
	}
	public List<PlanEligibilityClass> getPlanEligibilityClass() {
		return planEligibilityClass;
	}
	public void setPlanEligibilityClass(
			List<PlanEligibilityClass> planEligibilityClass) {
		this.planEligibilityClass = planEligibilityClass;
	}
	public ProposalBrokerDetails getProposalBrokerDetails() {
		return proposalBrokerDetails;
	}
	public void setProposalBrokerDetails(ProposalBrokerDetails proposalBrokerDetails) {
		this.proposalBrokerDetails = proposalBrokerDetails;
	}
	public PlanDetailsClass getOverriddenDetails() {
		return overriddenDetails;
	}
	public void setOverriddenDetails(PlanDetailsClass overriddenDetails) {
		this.overriddenDetails = overriddenDetails;
	}
}
