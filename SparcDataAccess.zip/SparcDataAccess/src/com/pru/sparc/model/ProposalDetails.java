package com.pru.sparc.model;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;
@Entity
@Table(name ="PROPOSAL")
@ComponentScan(" com.pru.sparc.model")
public class ProposalDetails {
	@Id
	@Column(name="PROPOSAL_ID",length = 20)
	private String proposalId;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CLIENT_ID")
	private ClientClass client;
	
	@Column(name="STATUS",length = 50)
	private String proposalStatus;
	
	@OneToOne
	@JoinColumn(name="SALES_OFF_ID")
	private SalesOffice salesOffice;
	
	@Column(name="PROPOSAL_DESCRIPTION",length = 100)
	private String proposalDescription;
	
	@Column(name="CASE_EFFECTIVE_DATE")
	private Date caseEffectiveDt;
	
	@Column(name="PROPOSAL_CONTRACT_STATE",length = 100)
	private String contractState;
	
	//date of proposal received from client
	@Column(name="RECEIVED_FROM_CLIENT_DATE")
	private Date receivedFromClientDt;
	
	//date required for proposal to client
	@Column(name="DATE_REQUIRED")
	private Date dateRequired;
	
	//proposal sent date to client
	@Column(name="SENT_TO_CLIENT_DATE")
	private Date sentToClientDt;
	
	//date required for proposal to broker
	@Column(name="DATE_REQUIRED_BROKER")
	private Date dateRequiredBroker;
	
	@Column(name="TASK_OWNER",length = 30)
	private String taskowner;
	
	@Column(name="CONTROL_NUMBER",length = 40)
	private String controlNumber;
	
	@Column(name="MARKET_SEGMENT_IND",length = 20)
	private String marketSegmentInd;
	
	@Column(name="SMALL_BUSINESS_IND",length = 30)
	private String smallBusinessInd;
	
	@Column(name="FEDERAL_CONTRACT_CLIENT",length = 3)
	private String federalContractClient;
	
	@Column(name="STATE_CONTRACT_CLIENT",length = 3)
	private String stateContractClient;
	
	@Column(name="LOCAL_CONTRACT_CLIENT",length = 3)
	private String localContractClient;
	
	@Column(name="EXCHANGE_QUOTE",length = 3)
	private String exchangeQuote;
	
	@Column(name="MULTI_NATIONAL_POOLING",length = 3)
	private String multiNationalPooling;
	
	@Column(name="PROPOSAL_COMMENTS",length = 800)
	private String proposalComments;
	
	@OneToMany (cascade=CascadeType.ALL, mappedBy="proposal",fetch=FetchType.EAGER)
	private Set<QuotationDetails> quotes;

	@Column(name="CREATION_DATE",length = 20)
	private Date creationDate;
	
	@Column(name="MODIFIED_DATE",length = 20)
	private Date modifiedDate;
	
	@Column(name="CREATED_BY",length = 20)
	private String createdBy;
	
	@Column(name="MODIFIED_BY",length = 20)
	private String modifiedBy;
	
	public String getProposalId() {
		return proposalId;
	}

	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}

	public ClientClass getClient() {
		return client;
	}

	public void setClient(ClientClass client) {
		this.client = client;
	}

	public String getProposalStatus() {
		return proposalStatus;
	}

	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}

	public SalesOffice getSalesOffice() {
		return salesOffice;
	}

	public void setSalesOffice(SalesOffice salesOffice) {
		this.salesOffice = salesOffice;
	}

	public String getProposalDescription() {
		return proposalDescription;
	}

	public void setProposalDescription(String proposalDescription) {
		this.proposalDescription = proposalDescription;
	}

	public Date getCaseEffectiveDt() {
		return caseEffectiveDt;
	}

	public void setCaseEffectiveDt(Date caseEffectiveDt) {
		this.caseEffectiveDt = caseEffectiveDt;
	}

	public String getContractState() {
		return contractState;
	}

	public void setContractState(String contractState) {
		this.contractState = contractState;
	}

	public Date getReceivedFromClientDt() {
		return receivedFromClientDt;
	}

	public void setReceivedFromClientDt(Date receivedFromClientDt) {
		this.receivedFromClientDt = receivedFromClientDt;
	}

	public Date getDateRequired() {
		return dateRequired;
	}

	public void setDateRequired(Date dateRequired) {
		this.dateRequired = dateRequired;
	}

	public Date getSentToClientDt() {
		return sentToClientDt;
	}

	public void setSentToClientDt(Date sentToClientDt) {
		this.sentToClientDt = sentToClientDt;
	}

	public Date getDateRequiredBroker() {
		return dateRequiredBroker;
	}

	public void setDateRequiredBroker(Date dateRequiredBroker) {
		this.dateRequiredBroker = dateRequiredBroker;
	}

	public String getTaskowner() {
		return taskowner;
	}

	public void setTaskowner(String taskowner) {
		this.taskowner = taskowner;
	}

	public String getControlNumber() {
		return controlNumber;
	}

	public void setControlNumber(String controlNumber) {
		this.controlNumber = controlNumber;
	}

	public String getMarketSegmentInd() {
		return marketSegmentInd;
	}

	public void setMarketSegmentInd(String marketSegmentInd) {
		this.marketSegmentInd = marketSegmentInd;
	}

	public String getSmallBusinessInd() {
		return smallBusinessInd;
	}

	public void setSmallBusinessInd(String smallBusinessInd) {
		this.smallBusinessInd = smallBusinessInd;
	}

	public String getFederalContractClient() {
		return federalContractClient;
	}

	public void setFederalContractClient(String federalContractClient) {
		this.federalContractClient = federalContractClient;
	}

	public String getStateContractClient() {
		return stateContractClient;
	}

	public void setStateContractClient(String stateContractClient) {
		this.stateContractClient = stateContractClient;
	}

	public String getLocalContractClient() {
		return localContractClient;
	}

	public void setLocalContractClient(String localContractClient) {
		this.localContractClient = localContractClient;
	}

	public String getExchangeQuote() {
		return exchangeQuote;
	}

	public void setExchangeQuote(String exchangeQuote) {
		this.exchangeQuote = exchangeQuote;
	}

	public String getMultiNationalPooling() {
		return multiNationalPooling;
	}

	public void setMultiNationalPooling(String multiNationalPooling) {
		this.multiNationalPooling = multiNationalPooling;
	}

	public String getProposalComments() {
		return proposalComments;
	}

	public void setProposalComments(String proposalComments) {
		this.proposalComments = proposalComments;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Set<QuotationDetails> getQuotes() {
		return quotes;
	}

	public void setQuotes(Set<QuotationDetails> quotes) {
		this.quotes = quotes;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
}
