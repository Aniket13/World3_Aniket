package com.pru.sparc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Embeddable
public class CensusClassEmbadable implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1324374720968664690L;
	@Column(name="CLASS_ID", length=50)
	private String censusClsId;
	@ManyToOne(optional = false)
	@JoinColumn(name = "CENSUS_ID")
	private CensusDetail censusDetail;
	/*@OneToMany(mappedBy = "cenMemEmbadable.censusClassEmbadable", cascade = CascadeType.ALL, fetch=FetchType.LAZY)
    private List<CensusMemberDetailsEntity> censusMem;*/
	
	public String getCensusClsId() {
		return censusClsId;
	}
	public void setCensusClsId(String censusClsId) {
		this.censusClsId = censusClsId;
	}
	public CensusDetail getCensusDetail() {
		return censusDetail;
	}
	public void setCensusDetail(CensusDetail censusDetail) {
		this.censusDetail = censusDetail;
	}
	
}
