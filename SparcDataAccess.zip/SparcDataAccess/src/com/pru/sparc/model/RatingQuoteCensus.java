package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name ="QUOTE_RATE_CENSUS")
public class RatingQuoteCensus {

	@Id
	@GeneratedValue
	@Column(name="RATE_CENSUS_ID")
	private int rateCensusId;
	@Column(name="AGE_BRACKET")
	private String ageBracket;
	@Column(name="TOTAL_LIVES")
	private double totalLives;
	@Column(name="TOTAL_COVERED_VOLUME")
	private double totalCoveredVolume;
	@Column(name="COMPOSITE_MONTHLY_PREMIUM_STEP_RATE")
	private double monthlyPremiumStepRate;
	@Column(name="TABLE_I_RATE")
	private double tableIRate;
	@Column(name="CROSS_TABLE_I")
	private double crossTableI;
	@Column(name="FINAL_RATE")
	private double finalRate;
	
	@Column(name="GROUP_ID")
	private String groupId;
	
	@ManyToOne
	@JoinColumn(name="RATE_ID")
	private RatingExhibits ratingExhibits;

	public int getRateCensusId() {
		return rateCensusId;
	}

	public void setRateCensusId(int rateCensusId) {
		this.rateCensusId = rateCensusId;
	}

	public String getAgeBracket() {
		return ageBracket;
	}

	public void setAgeBracket(String ageBracket) {
		this.ageBracket = ageBracket;
	}

	public double getTotalLives() {
		return totalLives;
	}

	public void setTotalLives(double totalLives) {
		this.totalLives = totalLives;
	}

	public double getTotalCoveredVolume() {
		return totalCoveredVolume;
	}

	public void setTotalCoveredVolume(double totalCoveredVolume) {
		this.totalCoveredVolume = totalCoveredVolume;
	}

	public double getMonthlyPremiumStepRate() {
		return monthlyPremiumStepRate;
	}

	public void setMonthlyPremiumStepRate(double monthlyPremiumStepRate) {
		this.monthlyPremiumStepRate = monthlyPremiumStepRate;
	}

	public double getTableIRate() {
		return tableIRate;
	}

	public void setTableIRate(double tableIRate) {
		this.tableIRate = tableIRate;
	}

	public double getCrossTableI() {
		return crossTableI;
	}

	public void setCrossTableI(double crossTableI) {
		this.crossTableI = crossTableI;
	}

	public double getFinalRate() {
		return finalRate;
	}

	public void setFinalRate(double finalRate) {
		this.finalRate = finalRate;
	}

	public RatingExhibits getRatingExhibits() {
		return ratingExhibits;
	}

	public void setRatingExhibits(RatingExhibits ratingExhibits) {
		this.ratingExhibits = ratingExhibits;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
}
