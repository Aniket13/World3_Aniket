package com.pru.sparc.model;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Sales_Region")
public class SalesRegion {
	
	@Id
	@Column(name="REGION_ID" ,length=100)
	private String regionId;
	
	@Column(name="REGION_NAME",length=50)
	private String regName;
	
	@Column(name="Division",length=50)
	private String division;

	@OneToMany (mappedBy="salesRegion",fetch=FetchType.EAGER)
	private Set<SalesOffice> offices;
	
	public String getRegName() {
		return regName;
	}
	public void setRegName(String regName) {
		this.regName = regName;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	
	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	
	public Set<SalesOffice> getOffices() {
		return offices;
	}
	public void setOffices(Set<SalesOffice> offices) {
		this.offices = offices;
	}
}
