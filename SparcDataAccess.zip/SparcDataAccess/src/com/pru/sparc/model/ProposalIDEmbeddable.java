package com.pru.sparc.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Embeddable
public class ProposalIDEmbeddable implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name="PROPDATE",length = 20)
	@Temporal(TemporalType.DATE)
	private Date propDate;
	
	@Column(name="PROPSEQID")
	private int seqId;
	
	public Date getPropDate() {
		return propDate;
	}
	public void setPropDate(Date propDate) {
		this.propDate = propDate;
	}
	public int getSeqId() {
		return seqId;
	}
	public void setSeqId(int seqId) {
		this.seqId = seqId;
	}
}
