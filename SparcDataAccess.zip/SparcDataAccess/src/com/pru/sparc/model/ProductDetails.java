package com.pru.sparc.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class ProductDetails {
	@Id 
	@GeneratedValue
	@Column(name="PRODUCT_ID")
	private int productId;
	@Column(name="PRODUCT_DESCRIPTION",length = 100)
	private String productDescription;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	@OneToMany (cascade=CascadeType.ALL, mappedBy="product",fetch=FetchType.EAGER)
	private Set<PlanDetailsClass> plans;
}
