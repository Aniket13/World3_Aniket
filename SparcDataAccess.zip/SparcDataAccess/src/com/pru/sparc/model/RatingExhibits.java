package com.pru.sparc.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name = "QUOTE_RATE_MASTER")
@ComponentScan(" com.pru.sparc.model")
public class RatingExhibits {

	@Id
	@GeneratedValue
	@Column(name = "RATE_ID")
	private int rateId;
	@Column(name="OVER_ID")
	private String overId;
	//kept unidirectional many to one
	@ManyToOne(optional = false)
	@JoinColumn(name="PLAN_ID")
	@LazyCollection(LazyCollectionOption.FALSE)
	private PlanDetailsClass plan;

	@OneToMany(mappedBy = "ratingExhibits", cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<RatingAggregatedCensus> ratingAggregatedCensus;
	
	@OneToMany(mappedBy = "ratingExhibits", cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<RatingOverride> ratingOverride;
	
	@OneToOne(mappedBy = "ratingExhibits", cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private RatingProposalPlanDetails ratingProposalPlanDetails;
	
	@OneToMany(mappedBy = "ratingExhibits", cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<RatingQuoteCensus> ratingQuoteCensus;
	
	@OneToMany(mappedBy = "ratingExhibits", cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<RatingRuleResult> ratingRuleResult;

	public int getRateId() {
		return rateId;
	}

	public void setRateId(int rateId) {
		this.rateId = rateId;
	}

	public PlanDetailsClass getPlan() {
		return plan;
	}

	public void setPlan(PlanDetailsClass plan) {
		this.plan = plan;
	}

	public List<RatingAggregatedCensus> getRatingAggregatedCensus() {
		return ratingAggregatedCensus;
	}

	public void setRatingAggregatedCensus(
			List<RatingAggregatedCensus> ratingAggregatedCensus) {
		this.ratingAggregatedCensus = ratingAggregatedCensus;
	}

	public List<RatingOverride> getRatingOverride() {
		return ratingOverride;
	}

	public void setRatingOverride(List<RatingOverride> ratingOverride) {
		this.ratingOverride = ratingOverride;
	}

	public RatingProposalPlanDetails getRatingProposalPlanDetails() {
		return ratingProposalPlanDetails;
	}

	public void setRatingProposalPlanDetails(
			RatingProposalPlanDetails ratingProposalPlanDetails) {
		this.ratingProposalPlanDetails = ratingProposalPlanDetails;
	}

	public List<RatingQuoteCensus> getRatingQuoteCensus() {
		return ratingQuoteCensus;
	}

	public void setRatingQuoteCensus(List<RatingQuoteCensus> ratingQuoteCensus) {
		this.ratingQuoteCensus = ratingQuoteCensus;
	}

	public List<RatingRuleResult> getRatingRuleResult() {
		return ratingRuleResult;
	}

	public void setRatingRuleResult(List<RatingRuleResult> ratingRuleResult) {
		this.ratingRuleResult = ratingRuleResult;
	}

	public String getOverId() {
		return overId;
	}

	public void setOverId(String overId) {
		this.overId = overId;
	}
}
