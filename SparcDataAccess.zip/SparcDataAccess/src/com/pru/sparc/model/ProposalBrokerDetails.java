package com.pru.sparc.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name="Proposal_Broker")
@ComponentScan("com.pru.sparc.model")
public class ProposalBrokerDetails {
	@Id
	@GeneratedValue
	@Column(name="Prop_Broker_ID")
	private int proBrokerId;
	@Column(name="Proposal_Plan_ID", length=100)
	private String proPlanId;
	//Foreign key
	@ManyToOne (fetch= FetchType.EAGER)
	@JoinColumn(name = "BROKER_ID")
	private BrokerDetails brokerDetails;
	//Proposal/Plan indicator - value 1 for proposal and 0 for plan
	@Column(name="PROPOSAL_PLAN_IND")
	private int proposalPlanInd;
	//commission Details
	@Column(name="COMMISSION_SPLIT")
	private double commissionSplit;
	@Column(name="ARRANGEMENT" ,length=50)
	private String arrangement;
	@Column(name="FLAT_AMOUNT")
	private double flatAmount;
	@Column(name="FLAT_PERCENTAGE")
	private float flatPercentage;
	@Column(name="COMMISSION_PAID_TO" ,length=50)
	private String commPaidTo;
	@Column(name="ADVANCE_COMMISSION_OCCURS" ,length=50)
	private String advCommOccurs;
	@Column(name="ADVANCE_COMMISSION")
	private double advComm;
	@Column(name="ADVANCE_COMMISSION_FLAG")
	private String advanceCommissionFlag;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PROPOSAL_VERSION_ID")
	private QuotationDetails versionDetails;
	
	public int getProBrokerId() {
		return proBrokerId;
	}
	public void setProBrokerId(int proBrokerId) {
		this.proBrokerId = proBrokerId;
	}
	public String getProPlanId() {
		return proPlanId;
	}
	public void setProPlanId(String proPlanId) {
		this.proPlanId = proPlanId;
	}
	public BrokerDetails getBrokerDetails() {
		return brokerDetails;
	}
	public void setBrokerDetails(BrokerDetails brokerDetails) {
		this.brokerDetails = brokerDetails;
	}
	public double getCommissionSplit() {
		return commissionSplit;
	}
	public void setCommissionSplit(double commissionSplit) {
		this.commissionSplit = commissionSplit;
	}
	public String getArrangement() {
		return arrangement;
	}
	public void setArrangement(String arrangement) {
		this.arrangement = arrangement;
	}
	public double getFlatAmount() {
		return flatAmount;
	}
	public void setFlatAmount(double flatAmount) {
		this.flatAmount = flatAmount;
	}
	public float getFlatPercentage() {
		return flatPercentage;
	}
	public void setFlatPercentage(float flatPercentage) {
		this.flatPercentage = flatPercentage;
	}
	public String getCommPaidTo() {
		return commPaidTo;
	}
	public void setCommPaidTo(String commPaidTo) {
		this.commPaidTo = commPaidTo;
	}
	public String getAdvCommOccurs() {
		return advCommOccurs;
	}
	public void setAdvCommOccurs(String advCommOccurs) {
		this.advCommOccurs = advCommOccurs;
	}
	public double getAdvComm() {
		return advComm;
	}
	public void setAdvComm(double advComm) {
		this.advComm = advComm;
	}
	public int getProposalPlanInd() {
		return proposalPlanInd;
	}
	public void setProposalPlanInd(int proposalPlanInd) {
		this.proposalPlanInd = proposalPlanInd;
	}
	public String getAdvanceCommissionFlag() {
		return advanceCommissionFlag;
	}
	public void setAdvanceCommissionFlag(String advanceCommissionFlag) {
		this.advanceCommissionFlag = advanceCommissionFlag;
	}
	public QuotationDetails getVersionDetails() {
		return versionDetails;
	}
	public void setVersionDetails(QuotationDetails versionDetails) {
		this.versionDetails = versionDetails;
	}
}
