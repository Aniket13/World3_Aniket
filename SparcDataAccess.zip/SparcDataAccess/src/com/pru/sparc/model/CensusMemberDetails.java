package com.pru.sparc.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MEMBER")
public class CensusMemberDetails {
	
	/*@EmbeddedId
	private CensusMemberEmbeddable censusMemEmbadable;*/
	@Id
	@GeneratedValue
	@Column(name = "MEMBER_ID", length = 100)
	private int censusMemberId;
	@ManyToOne(optional = false)
	@JoinColumn(name = "CENSUS_ID")
	private CensusDetail censusDetail;
	@Column(name = "ADD_VOLUME", length = 50)
	private String addVolume;
	@Column(name = "AGE", length = 10)
	private String age;
	@Column(name = "BASIC_LIFE_VOLUME", length = 50)
	private String basicLifeVol;
	@Column(name = "BIRTH_DATE", length = 30)
	private Date birthDate;
	@Column(name = "CITY", length = 100)
	private String city;
	@Column(name = "DEP_DENTAL_CHILD_PART", length = 100)
	private String dentalChildPart;
	@Column(name = "DEP_PART", length = 100)
	private String dentalPart;
	@Column(name = "DEP_SPOUCE_PART", length = 100)
	private String dentalSpoucePart;
	@Column(name = "DGL_CHILD_VOLUME", length = 100)
	private String dglChildVolume;
	@Column(name = "DGL_SPOUCE_VOLUME", length = 100)
	private String dglSpouceVolume;
	@Column(name = "EMP_ID", length = 100)
	private String empID;
	@Column(name = "FIRST_NAME", length = 100)
	private String firstName;
	@Column(name = "GENDER", length = 100)
	private String gender;
	@Column(name = "GOVT_ID", length = 100)
	private String govtID;
	@Column(name = "HIRE_DATE", length = 100)
	private Date hireDate;
	@Column(name = "JOB_DESCRIPTION", length = 100)
	private String jobDescription;
	@Column(name = "LAST_NAME", length = 100)
	private String lastName;
	@Column(name = "OADD_VOLUME", length = 100)
	private String oAddVolume;
	@Column(name = "OCCUPATION_CODE", length = 100)
	private String occupationCode;
	@Column(name = "OGL_VOLUME", length = 100)
	private String oglVolume;
	@Column(name = "OPTIONAL_STD_PART", length = 100)
	private String optionalStdPart;
	@Column(name = "RESIDENCE_ZIP", length = 20)
	private String residenceZip;
	@Column(name = "SALARY", length = 20)
	private String salary;
	@Column(name = "STATE", length = 100)
	private String state;
	@Column(name = "ZIP_CODE", length = 20)
	private String zipCode;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CLASS_SEQ_ID")
	private CensusClass memberClass;
	@Column(name = "OGL_PART", length = 100)
	private String oglPart;
	@Column(name = "DGL_SPOUCE_PART", length = 100)
	private String dglSpoucePart;
	@Column(name = "DGL_CHILD_PART", length = 100)
	private String dglChildPart;
	@Column(name = "OPTIONAL_ADD_PART", length = 100)
	private String oAddPart;
	@Column(name = "OPTIONAL_LTD_PART", length = 100)
	private String optionalLtdPart;


	/*public CensusMemberEmbeddable getCensusMemEmbadable() {
		return censusMemEmbadable;
	}

	public void setCensusMemEmbadable(CensusMemberEmbeddable censusMemEmbadable) {
		this.censusMemEmbadable = censusMemEmbadable;
	}*/

	public int getCensusMemberId() {
		return censusMemberId;
	}

	public void setCensusMemberId(int censusMemberId) {
		this.censusMemberId = censusMemberId;
	}

	public CensusDetail getCensusDetail() {
		return censusDetail;
	}

	public void setCensusDetail(CensusDetail censusDetail) {
		this.censusDetail = censusDetail;
	}

	public String getoAddVolume() {
		return oAddVolume;
	}

	public void setoAddVolume(String oAddVolume) {
		this.oAddVolume = oAddVolume;
	}

	public String getoAddPart() {
		return oAddPart;
	}

	public void setoAddPart(String oAddPart) {
		this.oAddPart = oAddPart;
	}

	public String getAddVolume() {
		return addVolume;
	}

	public void setAddVolume(String addVolume) {
		this.addVolume = addVolume;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getBasicLifeVol() {
		return basicLifeVol;
	}

	public void setBasicLifeVol(String basicLifeVol) {
		this.basicLifeVol = basicLifeVol;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDentalChildPart() {
		return dentalChildPart;
	}

	public void setDentalChildPart(String dentalChildPart) {
		this.dentalChildPart = dentalChildPart;
	}

	public String getDentalPart() {
		return dentalPart;
	}

	public void setDentalPart(String dentalPart) {
		this.dentalPart = dentalPart;
	}

	public String getDentalSpoucePart() {
		return dentalSpoucePart;
	}

	public void setDentalSpoucePart(String dentalSpoucePart) {
		this.dentalSpoucePart = dentalSpoucePart;
	}

	public String getDglChildVolume() {
		return dglChildVolume;
	}

	public void setDglChildVolume(String dglChildVolume) {
		this.dglChildVolume = dglChildVolume;
	}

	public String getDglSpouceVolume() {
		return dglSpouceVolume;
	}

	public void setDglSpouceVolume(String dglSpouceVolume) {
		this.dglSpouceVolume = dglSpouceVolume;
	}

	public String getEmpID() {
		return empID;
	}

	public void setEmpID(String empID) {
		this.empID = empID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getGovtID() {
		return govtID;
	}

	public void setGovtID(String govtID) {
		this.govtID = govtID;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOaddVolume() {
		return oAddVolume;
	}

	public void setOaddVolume(String oaddVolume) {
		this.oAddVolume = oaddVolume;
	}

	public String getOccupationCode() {
		return occupationCode;
	}

	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	public String getOglVolume() {
		return oglVolume;
	}

	public void setOglVolume(String oglVolume) {
		this.oglVolume = oglVolume;
	}

	public String getOptionalStdPart() {
		return optionalStdPart;
	}

	public void setOptionalStdPart(String optionalStdPart) {
		this.optionalStdPart = optionalStdPart;
	}

	public String getResidenceZip() {
		return residenceZip;
	}

	public void setResidenceZip(String residenceZip) {
		this.residenceZip = residenceZip;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public CensusClass getMemberClass() {
		return memberClass;
	}

	public void setMemberClass(CensusClass memberClass) {
		this.memberClass = memberClass;
	}

	public String getOglPart() {
		return oglPart;
	}

	public void setOglPart(String oglPart) {
		this.oglPart = oglPart;
	}

	public String getDglSpoucePart() {
		return dglSpoucePart;
	}

	public void setDglSpoucePart(String dglSpoucePart) {
		this.dglSpoucePart = dglSpoucePart;
	}

	public String getDglChildPart() {
		return dglChildPart;
	}

	public void setDglChildPart(String dglChildPart) {
		this.dglChildPart = dglChildPart;
	}

	public String getOaddPart() {
		return oAddPart;
	}

	public void setOaddPart(String oaddPart) {
		this.oAddPart = oaddPart;
	}

	public String getOptionalLtdPart() {
		return optionalLtdPart;
	}

	public void setOptionalLtdPart(String optionalLtdPart) {
		this.optionalLtdPart = optionalLtdPart;
	}

}
