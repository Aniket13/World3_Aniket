package com.pru.sparc.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionOfElements;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
@Table(name="PROPOSAL_VERSION")
public class QuotationDetails {
	
	@Id 
	@GeneratedValue
	/*@Column(name="VERSION_SEQ")
	private int versionSequence;*/
	
	@Column(name="PROPOSAL_VERSION_ID")
	private int versionNumber;
	
	@Column(name="VERSION_DESCRIPTION",length = 100)
	private String versionDesc;
	
	@OneToOne
	@JoinColumn(name="CENSUSID")
	private CensusDetail census;
	
	@Column(name="BASIC_LIFE",length = 3)
	private String basicLife;
	
	@Column(name="LTD",length = 3)
	private String ltd;
	
	@Column(name="CONTACT_DOCUMENT_FORMAT",length = 20)
	private String contactDocFormat;
	
	@Column(name="BILL_DELIVERY_METHOD",length = 20)
	private String billDeliveryMethod;
	
	@Column(name="BILL_METHOD",length = 20)
	private String billMethod;
	
	@Column(name="ATP_VOUCHER_PROGRAM",length = 3)
	private String atpVoucerPgm;
	
	@Column(name="VERSION_STATUS",length = 50)
	private String versionStatus;
	
	@Column(name="COMMENT",length = 100)
	private String comment;
	
	@Column(name="LIFE_REASON",length = 50)
	private String lifeReason;
	
	@Column(name="DISABILITY_REASON",length = 50)
	private String disabilityReason;
	
	@Column(name="DENTAL_REASON",length = 50)
	private String dentalReason;
	
	@Column(name="RSM_NOTIFICATION_COMMENT",length = 100)
	private String rsmComment;
	
	@ManyToOne (fetch= FetchType.EAGER)
	@JoinColumn(name = "PROPOSAL_ID")
	private ProposalDetails proposal;

	@Column(name="CLONED_FROM_VERSION_ID",length = 100)
	private int clonedFrom;
	
	@CollectionOfElements
	@JoinTable (name = "PROPOSAL_VERSION_QUOTE_REASON",
	joinColumns = @JoinColumn(name = "PROPOSAL_VERSION_ID"))
	@LazyCollection(LazyCollectionOption.FALSE)
	private Collection<QuoteReasonLookup> quoteReasons = new ArrayList<QuoteReasonLookup>();
	
	/*@OneToMany
	@JoinTable(name="SPARC_PROPOSAL_VERSION_PLAN_MAP",joinColumns=@JoinColumn(name="VERSION_SEQ",unique=false),
				inverseJoinColumns=@JoinColumn(name="PLAN_SEQ",unique=false)
	)
	@LazyCollection(LazyCollectionOption.FALSE)
	private Collection<PlanDetailsClass> productPlans = new ArrayList<PlanDetailsClass>();*/
	
	@Column(name="CREATION_DATE",length = 20)
	private Date creationDate;
	
	@Column(name="MODIFIED_DATE",length = 20)
	private Date modifiedDate;
	
	@Column(name="CREATED_BY",length = 20)
	private String createdBy;
	
	@Column(name="MODIFIED_BY",length = 20)
	private String modifiedBy;
	
	@OneToMany (cascade=CascadeType.ALL, mappedBy="version",fetch=FetchType.EAGER)
	private Set<PlanDetailsClass> plans;

	/*public int getVersionSequence() {
		return versionSequence;
	}

	public void setVersionSequence(int versionSequence) {
		this.versionSequence = versionSequence;
	}*/

	public int getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	public String getVersionDesc() {
		return versionDesc;
	}

	public void setVersionDesc(String versionDesc) {
		this.versionDesc = versionDesc;
	}

	public CensusDetail getCensus() {
		return census;
	}

	public void setCensus(CensusDetail census) {
		this.census = census;
	}

	public String getBasicLife() {
		return basicLife;
	}

	public void setBasicLife(String basicLife) {
		this.basicLife = basicLife;
	}

	public String getLtd() {
		return ltd;
	}

	public void setLtd(String ltd) {
		this.ltd = ltd;
	}

	public String getContactDocFormat() {
		return contactDocFormat;
	}

	public void setContactDocFormat(String contactDocFormat) {
		this.contactDocFormat = contactDocFormat;
	}

	public String getBillDeliveryMethod() {
		return billDeliveryMethod;
	}

	public void setBillDeliveryMethod(String billDeliveryMethod) {
		this.billDeliveryMethod = billDeliveryMethod;
	}

	public String getBillMethod() {
		return billMethod;
	}

	public void setBillMethod(String billMethod) {
		this.billMethod = billMethod;
	}

	public String getAtpVoucerPgm() {
		return atpVoucerPgm;
	}

	public void setAtpVoucerPgm(String atpVoucerPgm) {
		this.atpVoucerPgm = atpVoucerPgm;
	}

	public String getVersionStatus() {
		return versionStatus;
	}

	public void setVersionStatus(String versionStatus) {
		this.versionStatus = versionStatus;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getLifeReason() {
		return lifeReason;
	}

	public void setLifeReason(String lifeReason) {
		this.lifeReason = lifeReason;
	}

	public String getDisabilityReason() {
		return disabilityReason;
	}

	public void setDisabilityReason(String disabilityReason) {
		this.disabilityReason = disabilityReason;
	}

	public String getDentalReason() {
		return dentalReason;
	}

	public void setDentalReason(String dentalReason) {
		this.dentalReason = dentalReason;
	}

	public String getRsmComment() {
		return rsmComment;
	}

	public void setRsmComment(String rsmComment) {
		this.rsmComment = rsmComment;
	}

	public ProposalDetails getProposal() {
		return proposal;
	}

	public void setProposal(ProposalDetails proposal) {
		this.proposal = proposal;
	}

	public int getClonedFrom() {
		return clonedFrom;
	}

	public void setClonedFrom(int clonedFrom) {
		this.clonedFrom = clonedFrom;
	}

	public Collection<QuoteReasonLookup> getQuoteReasons() {
		return quoteReasons;
	}

	public void setQuoteReasons(Collection<QuoteReasonLookup> quoteReasons) {
		this.quoteReasons = quoteReasons;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/*public Collection<PlanDetailsClass> getProductPlans() {
		return productPlans;
	}

	public void setProductPlans(Collection<PlanDetailsClass> productPlans) {
		this.productPlans = productPlans;
	}*/

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Set<PlanDetailsClass> getPlans() {
		return plans;
	}

	public void setPlans(Set<PlanDetailsClass> plans) {
		this.plans = plans;
	}
}
