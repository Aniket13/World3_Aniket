package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CENSUS_LIVE_ALLOCATION")
public class CensusLvsAlloc {
	@Id
	@GeneratedValue
	@Column(name="ALLOC_ID", length=50)
	private int censusAllocId;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "CENSUS_ID")
	private CensusDetail censusDetail;
	
	@Column(name="STATE", length=10)
	private String state;
	
	@Column(name="NO_OF_LIVE", length=10)
	private String noOfLives;
	
	@Column(name="ALLOCATION_FACTOR", length=10)
	private String allocationFactor;
	
	/*@Column(name="LIVEALLOCPERCN", length=10)
	private float allocPerc;*/
	
	/*@EmbeddedId
    private CensusAllocationEmbadable cenAllocEmbadable;*/
	
	public String getAllocationFactor() {
		return allocationFactor;
	}
	public void setAllocationFactor(String allocationFactor) {
		this.allocationFactor = allocationFactor;
	}
	
	public CensusLvsAlloc() {}
	public CensusLvsAlloc(String censusId, String cenState, String noOfLives,
			int allocPerc) {
		super();
		this.noOfLives = noOfLives;
		//this.allocPerc = allocPerc;
	}
	public String getNoOfLives() {
		return noOfLives;
	}
	public void setNoOfLives(String noOfLives) {
		this.noOfLives = noOfLives;
	}
	/*public float getAllocPerc() {
		return allocPerc;
	}
	public void setAllocPerc(float allocPerc) {
		this.allocPerc = allocPerc;
	}
	public CensusAllocationEmbadable getCenAllocEmbadable() {
		return cenAllocEmbadable;
	}
	public void setCenAllocEmbadable(CensusAllocationEmbadable cenAllocEmbadable) {
		this.cenAllocEmbadable = cenAllocEmbadable;
	}*/
	public int getCensusAllocId() {
		return censusAllocId;
	}
	public void setCensusAllocId(int censusAllocId) {
		this.censusAllocId = censusAllocId;
	}
	public CensusDetail getCensusDetail() {
		return censusDetail;
	}
	public void setCensusDetail(CensusDetail censusDetail) {
		this.censusDetail = censusDetail;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
