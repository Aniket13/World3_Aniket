package com.pru.sparc.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name="Broker_Detail")
@ComponentScan("com.pru.sparc.model")
public class BrokerDetails {
	
	@Id
	@GeneratedValue
	@Column(name="BROKER_ID")
	private int brokerId;
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="brokerDetails")
	private Set<ProposalBrokerDetails> proBrokerDet;
	
	@Column(name="BROKER_NAME", length=100)
	private String brokerName;
	
	@Column(name="PRODUCER_CONTRACT_ID", length=50)
	private String producerContractId;
	
	@Column(name="AGENCY_CODE", length=40)
	private String agencyCode;
	
	@Column(name="PRODUCER_RANKING", length=40)
	private String producerRanking;
	
	@Column(name="PRODUCER_TYPE", length=50)
	private String producerType;
	
	@Column(name="IS_ORGANIZATION", length=10)
	private String isOrganization;
	
	@Column(name="CREATION_DATE",length = 20)
	private Date creationDate;
	
	@Column(name="MODIFIED_DATE",length = 20)
	private Date modifiedDate;
	
	@Column(name="CREATED_BY",length = 20)
	private String createdBy;
	
	@Column(name="MODIFIED_BY",length = 20)
	private String modifiedBy;

	public int getBrokerId() {
		return brokerId;
	}

	public void setBrokerId(int brokerId) {
		this.brokerId = brokerId;
	}

	public Set<ProposalBrokerDetails> getProBrokerDet() {
		return proBrokerDet;
	}

	public void setProBrokerDet(Set<ProposalBrokerDetails> proBrokerDet) {
		this.proBrokerDet = proBrokerDet;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}
	public String getProducerContractId() {
		return producerContractId;
	}
	public void setProducerContractId(String producerContractId) {
		this.producerContractId = producerContractId;
	}
	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getProducerRanking() {
		return producerRanking;
	}

	public void setProducerRanking(String producerRanking) {
		this.producerRanking = producerRanking;
	}

	public String getProducerType() {
		return producerType;
	}

	public void setProducerType(String producerType) {
		this.producerType = producerType;
	}

	public String getIsOrganization() {
		return isOrganization;
	}

	public void setIsOrganization(String isOrganization) {
		this.isOrganization = isOrganization;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
}
