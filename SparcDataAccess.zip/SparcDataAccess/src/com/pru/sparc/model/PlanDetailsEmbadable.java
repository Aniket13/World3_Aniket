package com.pru.sparc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;

@Embeddable
public class PlanDetailsEmbadable implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8210936986391079910L;

	@GeneratedValue
	@Column(name="PLAN_ID")
	private int planId;
	
	@Column(name="OVER_ID")
	private int overId;

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public int getOverId() {
		return overId;
	}

	public void setOverId(int overId) {
		this.overId = overId;
	}
	
}
