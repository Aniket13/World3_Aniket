package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name ="SIC")
@ComponentScan(" com.pru.sparc.model")
public class SIC {
	@Id
	@Column(name="SIC_NUMBER")
	private String sicNumber;
	
	@Column(name="DESCRIPTION")
	private String description;

	public String getSicNumber() {
		return sicNumber;
	}

	public void setSicNumber(String sicNumber) {
		this.sicNumber = sicNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
