package com.pru.sparc.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name="ADDRESS")
@ComponentScan(" com.pru.sparc.model")
public class AddressDetails {
	@Id
	@GeneratedValue
	@Column(name="ADDRESS_ID")
	private int addressId;
	@Column(name="ADDRESS_1", length=50)
	private String address;
	@Column(name="ADDRESS_2", length=50)
	private String address2;
	@Column(name="CITY", length=50)
	private String city;
	@Column(name="COUNTRY", length=50)
	private String country;
	@Column(name="STATE", length=50)
	private String state;
	@Column(name="ZIP", length=10)
	private String zipcode;
	@Column(name="PHONE", length=20)
	private String phone;
	@Column(name="FAX", length=20)
	private String fax;
	@Column(name="STATUS")
	private String status;
	@Column(name="CREATED_BY", length=30)
	private String createdBy;
	@Column(name="CREATED_DATE")
	private Date createdDate;
	@Column(name="UPDATED_BY", length=30)
	private String updatedBy;
	@Column(name="UPDATED_DATE")
	private Date updatedDate;
	@Column(name="OTHER_COUNTRY", length=50)
	private String otherCountryVal;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CLIENT_ID")
	private ClientClass client;
	
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getOtherCountryVal() {
		return otherCountryVal;
	}
	public void setOtherCountryVal(String otherCountryVal) {
		this.otherCountryVal = otherCountryVal;
	}
	public ClientClass getClient() {
		return client;
	}
	public void setClient(ClientClass client) {
		this.client = client;
	}
}
