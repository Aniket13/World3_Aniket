package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name ="QUOTE_RATE_AGGREGATED_CENSUS")
public class RatingAggregatedCensus {
	
	@Id
	@GeneratedValue
	@Column(name="AGGREGATED_CENSUS_ID")
	private int aggregatedCensusId;
	
	@Column(name="AGE_BRACKET")
	private String ageBracket;
	
	@Column(name="GENDER")
	private String gender;
	
	@Column(name="STATUS")
	private String status;
	
	@Column(name="LIVES")
	private double lives;
	
	@Column(name="COVERED_VOLUME")
	private double coveredVolume;
	
	@Column(name="NON_POOLED_VOLUME")
	private double nonPooledVolume;
	
	@Column(name="POOLED_VOLUME")
	private double pooledVolume;
	
	@Column(name="NON_POOLED_MANUAL_RATE")
	private double nonPooledManualRate;
	
	@Column(name="POOLED_MANUAL_RATE")
	private double pooledManualRate;
	
	@Column(name="GROUP_ID")
	private String groupId;
	
	@ManyToOne
	@JoinColumn(name="RATE_ID")
	private RatingExhibits ratingExhibits;

	public int getAggregatedCensusId() {
		return aggregatedCensusId;
	}

	public void setAggregatedCensusId(int aggregatedCensusId) {
		this.aggregatedCensusId = aggregatedCensusId;
	}

	public String getAgeBracket() {
		return ageBracket;
	}

	public void setAgeBracket(String ageBracket) {
		this.ageBracket = ageBracket;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getLives() {
		return lives;
	}

	public void setLives(double lives) {
		this.lives = lives;
	}

	public double getCoveredVolume() {
		return coveredVolume;
	}

	public void setCoveredVolume(double coveredVolume) {
		this.coveredVolume = coveredVolume;
	}

	public double getNonPooledVolume() {
		return nonPooledVolume;
	}

	public void setNonPooledVolume(double nonPooledVolume) {
		this.nonPooledVolume = nonPooledVolume;
	}

	public double getPooledVolume() {
		return pooledVolume;
	}

	public void setPooledVolume(double pooledVolume) {
		this.pooledVolume = pooledVolume;
	}

	public double getNonPooledManualRate() {
		return nonPooledManualRate;
	}

	public void setNonPooledManualRate(double nonPooledManualRate) {
		this.nonPooledManualRate = nonPooledManualRate;
	}

	public double getPooledManualRate() {
		return pooledManualRate;
	}

	public void setPooledManualRate(double pooledManualRate) {
		this.pooledManualRate = pooledManualRate;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public RatingExhibits getRatingExhibits() {
		return ratingExhibits;
	}

	public void setRatingExhibits(RatingExhibits ratingExhibits) {
		this.ratingExhibits = ratingExhibits;
	}
}
