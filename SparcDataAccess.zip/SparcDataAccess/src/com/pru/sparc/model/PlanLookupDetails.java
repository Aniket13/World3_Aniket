package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name="PLANCONFIG_LOOKUP")
@ComponentScan(" com.pru.sparc.model")
public class PlanLookupDetails {
	@Id
	@GeneratedValue
	@Column(name="PLAN_LOOKUP_NO")
	private int lookupNo;
	@Column(name="LOOKUP_CATEGORY")
	private String lookupCategory;
	@Column(name="LOOKUP_KEY")
	private String lookupCode;
	@Column(name="LOOKUP_VALUE")
	private String lookupValue;
	@Column(name="ORDER_NO")
	private int lookupOrder;
	@Column(name="VISIBILITY_FLAG")
	private String visibilityFlag;
	
	public int getLookupNo() {
		return lookupNo;
	}
	public void setLookupNo(int lookupNo) {
		this.lookupNo = lookupNo;
	}
	public String getLookupCategory() {
		return lookupCategory;
	}
	public void setLookupCategory(String lookupCategory) {
		this.lookupCategory = lookupCategory;
	}
	public String getLookupCode() {
		return lookupCode;
	}
	public void setLookupCode(String lookupCode) {
		this.lookupCode = lookupCode;
	}
	public String getLookupValue() {
		return lookupValue;
	}
	public void setLookupValue(String lookupValue) {
		this.lookupValue = lookupValue;
	}
	public int getLookupOrder() {
		return lookupOrder;
	}
	public void setLookupOrder(int lookupOrder) {
		this.lookupOrder = lookupOrder;
	}
	public String getVisibilityFlag() {
		return visibilityFlag;
	}
	public void setVisibilityFlag(String visibilityFlag) {
		this.visibilityFlag = visibilityFlag;
	}
}
