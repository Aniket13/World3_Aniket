package com.pru.sparc.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;
@Entity
@Table(name="PLAN_ELIGIBILITY_CLASS")
@ComponentScan(" com.pru.sparc.model")
public class PlanEligibilityClass {
	@Id
	@GeneratedValue
	private int eligClassId;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PLAN_ID")
	private PlanDetailsClass planDetails;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CLASS_ID")
	private CensusClass censusClass;
	@Column(name="NO_OF_LIVES")
	private int noOfLives;
	@Column(name="CLASS_SELECTED")
	private String classSelected;
	public int getEligClassId() {
		return eligClassId;
	}
	public void setEligClassId(int eligClassId) {
		this.eligClassId = eligClassId;
	}
	public PlanDetailsClass getPlanDetails() {
		return planDetails;
	}
	public void setPlanDetails(PlanDetailsClass planDetails) {
		this.planDetails = planDetails;
	}
	public CensusClass getCensusClass() {
		return censusClass;
	}
	public void setCensusClass(CensusClass censusClass) {
		this.censusClass = censusClass;
	}
	public int getNoOfLives() {
		return noOfLives;
	}
	public void setNoOfLives(int noOfLives) {
		this.noOfLives = noOfLives;
	}
	public String getClassSelected() {
		return classSelected;
	}
	public void setClassSelected(String classSelected) {
		this.classSelected = classSelected;
	}
	
}
