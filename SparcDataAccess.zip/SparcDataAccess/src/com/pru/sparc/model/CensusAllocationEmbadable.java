package com.pru.sparc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Embeddable
public class CensusAllocationEmbadable implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1324374720968664690L;
	@Column(name="STATE_ID", length=50)
	private String censusAllocStateId;
	@ManyToOne(optional = false)
	@JoinColumn(name = "CENSUS_ID")
	private CensusDetail censusDetail;
	
	public String getCensusAllocStateId() {
		return censusAllocStateId;
	}
	public void setCensusAllocStateId(String censusAllocStateId) {
		this.censusAllocStateId = censusAllocStateId;
	}
	public CensusDetail getCensusDetail() {
		return censusDetail;
	}
	public void setCensusDetail(CensusDetail censusDetail) {
		this.censusDetail = censusDetail;
	}
	
	
}
