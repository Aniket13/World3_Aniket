package com.pru.sparc.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name ="PRUDENTIAL_CONTACT")
@ComponentScan(" com.pru.sparc.model")
public class PrudentialContactDetails {
	@Id
	@GeneratedValue
	@Column(name="PRUDENTIAL_CONTACT_ID")
	private int contactId;
	
	@Column(name="LDSM_NAME",length = 100)
	private String ldsmName;
	
	@Column(name="LDSM_ASSISTANT",length = 100)
	private String ldsmAssistant;
	
	@Column(name="LIFE_SPECIALIST",length = 100)
	private String lifeSpecialist;
	
	@Column(name="LIFE_SPECIALIST_ASSISTANT",length = 100)
	private String lifeSplAssistant;
	
	@Column(name="UNDERWRITER",length = 100)
	private String underwriter;
	
	@Column(name="RATE_CALC_TECHNICIAN",length = 100)
	private String rateCalcTechnician;
	
	@Column(name="ACCOUNT_MANAGER",length = 100)
	private String acctManager;
	
	@Column(name="MID_MARKET_ACCOUNT_MANAGER",length = 100)
	private String midMarketAcctManager;
	
	@Column(name="REGIONAL_ADMIN_DIRECTOR",length = 100)
	private String regionalAdminDir;
	
	@Column(name="ACCOUNT_EXECUTIVE",length = 100)
	private String acctExecutive;
	
	@Column(name="EXTERNAL_AGENT",length = 100)
	private String externalAgent;
	
	@Column(name="EXTERNAL_AGENT_OFFICE",length = 100)
	private String extAgentOffice;
	
	@Column(name="EXTERNAL_AGENT_PHONE",length = 100)
	private String extAgentPhone;
	
	@Column(name="CREATION_DATE",length = 20)
	private Date creationDate;
	
	@Column(name="MODIFIED_DATE",length = 20)
	private Date modifiedDate;
	
	@Column(name="CREATED_BY",length = 20)
	private String createdBy;
	
	@Column(name="MODIFIED_BY",length = 20)
	private String modifiedBy;
	
	@OneToOne
	@JoinColumn(name="PROPOSAL_ID")
	private ProposalDetails proposalDetails;

	public int getContactId() {
		return contactId;
	}

	public void setContactId(int contactId) {
		this.contactId = contactId;
	}

	public String getLdsmName() {
		return ldsmName;
	}

	public void setLdsmName(String ldsmName) {
		this.ldsmName = ldsmName;
	}

	public String getLdsmAssistant() {
		return ldsmAssistant;
	}

	public void setLdsmAssistant(String ldsmAssistant) {
		this.ldsmAssistant = ldsmAssistant;
	}

	public String getLifeSpecialist() {
		return lifeSpecialist;
	}

	public void setLifeSpecialist(String lifeSpecialist) {
		this.lifeSpecialist = lifeSpecialist;
	}

	public String getLifeSplAssistant() {
		return lifeSplAssistant;
	}

	public void setLifeSplAssistant(String lifeSplAssistant) {
		this.lifeSplAssistant = lifeSplAssistant;
	}

	public String getUnderwriter() {
		return underwriter;
	}

	public void setUnderwriter(String underwriter) {
		this.underwriter = underwriter;
	}

	public String getRateCalcTechnician() {
		return rateCalcTechnician;
	}

	public void setRateCalcTechnician(String rateCalcTechnician) {
		this.rateCalcTechnician = rateCalcTechnician;
	}

	public String getAcctManager() {
		return acctManager;
	}

	public void setAcctManager(String acctManager) {
		this.acctManager = acctManager;
	}

	public String getMidMarketAcctManager() {
		return midMarketAcctManager;
	}

	public void setMidMarketAcctManager(String midMarketAcctManager) {
		this.midMarketAcctManager = midMarketAcctManager;
	}

	public String getRegionalAdminDir() {
		return regionalAdminDir;
	}

	public void setRegionalAdminDir(String regionalAdminDir) {
		this.regionalAdminDir = regionalAdminDir;
	}

	public String getAcctExecutive() {
		return acctExecutive;
	}

	public void setAcctExecutive(String acctExecutive) {
		this.acctExecutive = acctExecutive;
	}

	public String getExternalAgent() {
		return externalAgent;
	}

	public void setExternalAgent(String externalAgent) {
		this.externalAgent = externalAgent;
	}

	public String getExtAgentOffice() {
		return extAgentOffice;
	}

	public void setExtAgentOffice(String extAgentOffice) {
		this.extAgentOffice = extAgentOffice;
	}

	public String getExtAgentPhone() {
		return extAgentPhone;
	}

	public void setExtAgentPhone(String extAgentPhone) {
		this.extAgentPhone = extAgentPhone;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public ProposalDetails getProposalDetails() {
		return proposalDetails;
	}

	public void setProposalDetails(ProposalDetails proposalDetails) {
		this.proposalDetails = proposalDetails;
	}
	
}
