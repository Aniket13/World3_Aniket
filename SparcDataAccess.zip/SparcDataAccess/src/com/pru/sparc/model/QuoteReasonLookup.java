package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;


@Embeddable
public class QuoteReasonLookup {
	
	@Column(name="DESCRIPTION",length=100)
	private String quoteDesc;
	
	public String getQuoteDesc() {
		return quoteDesc;
	}
	public void setQuoteDesc(String quoteDesc) {
		this.quoteDesc = quoteDesc;
	}
}
