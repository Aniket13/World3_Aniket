package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="Sales_Office")
public class SalesOffice {
	@Id
	@Column(name="SALES_OFF_ID" ,length=100)
	private String salesOfficeId;
	
	@Column(name="SALES_OFF_NAME",length=50)
	private String salesOffName;
	
	@ManyToOne (fetch= FetchType.EAGER)
	@JoinColumn(name = "REGION_ID")
	private SalesRegion salesRegion;

	public String getSalesOffName() {
		return salesOffName;
	}

	public void setSalesOffName(String salesOffName) {
		this.salesOffName = salesOffName;
	}

	public String getSalesOfficeId() {
		return salesOfficeId;
	}

	public void setSalesOfficeId(String salesOfficeId) {
		this.salesOfficeId = salesOfficeId;
	}
	public SalesRegion getSalesRegion() {
		return salesRegion;
	}

	public void setSalesRegion(SalesRegion salesRegion) {
		this.salesRegion = salesRegion;
	}
}
