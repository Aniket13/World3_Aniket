package com.pru.sparc.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="CENSUS_CLASS")
public class CensusClass {
	@Id
	@GeneratedValue
	@Column(name="CLASS_ID", length=50)
	private int censusClsId;
	@ManyToOne(optional = false, fetch=FetchType.EAGER)
	@JoinColumn(name = "CENSUS_ID")
	private CensusDetail censusDetail;
	@Column(name="DESCRIPTION", length=100)
	private String classDesc;
	@Column(name="EXEMPT", length=1)
	private String exempt;
	@Column(name="FULL_TIME", length=1)
	private String fullTime;
	@Column(name="MANAGEMENT", length=1)
	private String management;
	@Column(name="MEDICALLY_UNDERWRITTEN", length=1)
	private String medicallyUnd;
	@Column(name="SALARIED", length=1)
	private String salaried;
	@Column(name="SMOKER", length=1)
	private String smoker;
	@Column(name="RETIREE", length=1)
	private String retiree;
	@Column(name="GRANDFATHERED", length=1)
	private String grandFathered;
	
	/*@EmbeddedId
    private CensusClassEmbadable cenClsEmbadable;*/
	
	@Column(name="COLL_BARGIN", length=1)
	private String collBargain;
	
	@OneToMany(fetch=FetchType.LAZY, mappedBy="memberClass")
	private List<CensusMemberDetails> memberList;

	public String getClassDesc() {
		return classDesc;
	}

	public List<CensusMemberDetails> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<CensusMemberDetails> memberList) {
		this.memberList = memberList;
	}

	public void setClassDesc(String classDesc) {
		this.classDesc = classDesc;
	}

	public String getExempt() {
		return exempt;
	}

	public void setExempt(String exempt) {
		this.exempt = exempt;
	}

	public String getFullTime() {
		return fullTime;
	}

	public void setFullTime(String fullTime) {
		this.fullTime = fullTime;
	}

	public String getManagement() {
		return management;
	}

	public void setManagement(String management) {
		this.management = management;
	}

	public String getMedicallyUnd() {
		return medicallyUnd;
	}

	public void setMedicallyUnd(String medicallyUnd) {
		this.medicallyUnd = medicallyUnd;
	}

	public String getSalaried() {
		return salaried;
	}

	public void setSalaried(String salaried) {
		this.salaried = salaried;
	}

	public String getSmoker() {
		return smoker;
	}

	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}

	public String getRetiree() {
		return retiree;
	}

	public void setRetiree(String retiree) {
		this.retiree = retiree;
	}

	public String getGrandFathered() {
		return grandFathered;
	}

	public void setGrandFathered(String grandFathered) {
		this.grandFathered = grandFathered;
	}

	/*public CensusClassEmbadable getCenClsEmbadable() {
		return cenClsEmbadable;
	}

	public void setCenClsEmbadable(CensusClassEmbadable cenClsEmbadable) {
		this.cenClsEmbadable = cenClsEmbadable;
	}*/

	public String getCollBargain() {
		return collBargain;
	}

	public int getCensusClsId() {
		return censusClsId;
	}

	public void setCensusClsId(int censusClsId) {
		this.censusClsId = censusClsId;
	}

	public CensusDetail getCensusDetail() {
		return censusDetail;
	}

	public void setCensusDetail(CensusDetail censusDetail) {
		this.censusDetail = censusDetail;
	}

	public void setCollBargain(String collBargain) {
		this.collBargain = collBargain;
	}
}
