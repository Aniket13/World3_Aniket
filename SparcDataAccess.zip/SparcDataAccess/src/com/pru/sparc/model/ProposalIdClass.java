package com.pru.sparc.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.context.annotation.ComponentScan;

@Entity
@Table(name="proposalidseq")
@ComponentScan(" com.pru.sparc.model")
public class ProposalIdClass {
	@EmbeddedId
    private ProposalIDEmbeddable proposalIDEmbeddable;

	public ProposalIDEmbeddable getProposalIDEmbeddable() {
		return proposalIDEmbeddable;
	}

	public void setProposalIDEmbeddable(ProposalIDEmbeddable proposalIDEmbeddable) {
		this.proposalIDEmbeddable = proposalIDEmbeddable;
	}
	
	
}
