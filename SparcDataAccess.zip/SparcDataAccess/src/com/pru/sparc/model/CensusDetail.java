package com.pru.sparc.model;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="CENSUS_FILE")
public class CensusDetail {

	@Id
	@GeneratedValue
	@Column(name="CENSUS_ID", length=20)
	private int censusId;
	@Column(name="CENSUS_NAME", length=50)
	private String censusName;
	@Column(name="CENSUS_DATE", length=20)
	private Date censusDate;
	@Column(name="RECEIPT_DT", length=20)
	private Date receiptDate;
	@Column(name="TIME_RECV_DT", length=20)
	private String timeRecvDate;
	@Column(name="LAST_MOD_DT", length=30)
	private String lastModDate;
	@Column(name="TOTAL_LIVE", length=10)
	private int totalLives;
	@Column(name="CREATED_BY", length=20)
	private String createdBy;
	@Column(name="CONTAINS_SALARY", length=5)
	private String containsSalary;
	@Column(name="SALARY_AMOUNT", length=10)
	private double salaryAmount;
	@Column(name="NOTES", length=30)
	private String notes;
	@OneToMany(mappedBy = "censusDetail", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
    private Set<CensusClass> censusCls;
	@OneToMany(mappedBy = "censusDetail", cascade = CascadeType.ALL, fetch=FetchType.LAZY)
    private List<CensusLvsAlloc> censusAlloc;
	
	@OneToMany(mappedBy = "censusDetail", cascade = CascadeType.ALL, fetch=FetchType.LAZY)
    private List<CensusMemberDetails> censusMemberDetails;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CLIENT_ID")
	private ClientClass client;
	
	public int getCensusId() {
		return censusId;
	}

	public void setCensusId(int censusId) {
		this.censusId = censusId;
	}

	public String getCensusName() {
		return censusName;
	}

	public void setCensusName(String censusName) {
		this.censusName = censusName;
	}

	public Date getCensusDate() {
		return censusDate;
	}

	public void setCensusDate(Date censusDate) {
		this.censusDate = censusDate;
	}

	public Date getReceiptDate() {
		return receiptDate;
	}

	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}

	public String getTimeRecvDate() {
		return timeRecvDate;
	}

	public void setTimeRecvDate(String timeRecvDate) {
		this.timeRecvDate = timeRecvDate;
	}

	public String getLastModDate() {
		return lastModDate;
	}

	public void setLastModDate(String lastModDate) {
		this.lastModDate = lastModDate;
	}

	public int getTotalLives() {
		return totalLives;
	}

	public void setTotalLives(int totalLives) {
		this.totalLives = totalLives;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getContainsSalary() {
		return containsSalary;
	}

	public void setContainsSalary(String containsSalary) {
		this.containsSalary = containsSalary;
	}

	public double getSalaryAmount() {
		return salaryAmount;
	}

	public void setSalaryAmount(double salaryAmount) {
		this.salaryAmount = salaryAmount;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Set<CensusClass> getCensusCls() {
		return censusCls;
	}

	public void setCensusCls(Set<CensusClass> censusCls) {
		this.censusCls = censusCls;
	}

	public List<CensusLvsAlloc> getCensusAlloc() {
		return censusAlloc;
	}

	public void setCensusAlloc(List<CensusLvsAlloc> censusAlloc) {
		this.censusAlloc = censusAlloc;
	}

	public List<CensusMemberDetails> getCensusMemberDetails() {
		return censusMemberDetails;
	}

	public void setCensusMemberDetails(List<CensusMemberDetails> censusMemberDetails) {
		this.censusMemberDetails = censusMemberDetails;
	}
	public ClientClass getClient() {
		return client;
	}
	public void setClient(ClientClass client) {
		this.client = client;
	}
}
