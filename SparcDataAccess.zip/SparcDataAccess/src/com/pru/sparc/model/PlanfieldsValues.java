package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SPARC_PLAN_FIELD_LOOKUP")
public class PlanfieldsValues {

	@Column(name = "lkpcode")
	private String fieldName;
	@Column(name = "lkpvalues")
	private String fieldVal;
	@Id
	@GeneratedValue
	@Column(name = "LKPNUMBER")
	private int id;
	@Column(name = "LKPCATEGORY")
	private String fieldCat;
	@Column(name = "FIELDTYPE")
	private String fieldTyp;

	public PlanfieldsValues() {
	}

	public PlanfieldsValues(String fieldName, String fieldVal, int id,
			String fieldCat, String fieldTyp) {
		super();
		this.fieldName = fieldName;
		this.fieldVal = fieldVal;
		this.id = id;
		this.fieldCat = fieldCat;
		this.fieldTyp = fieldTyp;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldVal() {
		return fieldVal;
	}

	public void setFieldVal(String fieldVal) {
		this.fieldVal = fieldVal;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFieldCat() {
		return fieldCat;
	}

	public void setFieldCat(String fieldCat) {
		this.fieldCat = fieldCat;
	}

	public String getFieldTyp() {
		return fieldTyp;
	}

	public void setFieldTyp(String fieldTyp) {
		this.fieldTyp = fieldTyp;
	}

	@Override
	public String toString() {
		return "PlanfieldsValues [fieldName=" + fieldName + ", fieldVal="
				+ fieldVal + ", id=" + id + ", fieldCat=" + fieldCat
				+ ", fieldTyp=" + fieldTyp + "]";
	}

}
