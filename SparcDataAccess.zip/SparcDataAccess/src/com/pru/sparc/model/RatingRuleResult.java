package com.pru.sparc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name ="QUOTE_RATE_RULE_RESULT")
public class RatingRuleResult {

	@Id
	@GeneratedValue
	@Column(name="RATE_RULE_ID")
	private int rateRuleId;
	
	@Column(name="RULE_DESCRIPTION")
	private String ruleDesc;
	
	@Column(name="RULE_RESULT")
	private String ruleResult;
	
	@Column(name="GROUP_ID")
	private String groupId;
	
	@ManyToOne
	@JoinColumn(name="RATE_ID")
	private RatingExhibits ratingExhibits;

	public int getRateRuleId() {
		return rateRuleId;
	}

	public void setRateRuleId(int rateRuleId) {
		this.rateRuleId = rateRuleId;
	}

	public String getRuleDesc() {
		return ruleDesc;
	}

	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}

	public String getRuleResult() {
		return ruleResult;
	}

	public void setRuleResult(String ruleResult) {
		this.ruleResult = ruleResult;
	}

	public RatingExhibits getRatingExhibits() {
		return ratingExhibits;
	}

	public void setRatingExhibits(RatingExhibits ratingExhibits) {
		this.ratingExhibits = ratingExhibits;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
}
