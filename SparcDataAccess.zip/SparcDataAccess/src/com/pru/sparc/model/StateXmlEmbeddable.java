package com.pru.sparc.model;

import java.io.Serializable;
import javax.persistence.Column;

public class StateXmlEmbeddable implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name="CURR_STATE", length=50)
	private String currState;
	@Column(name="PROPOSAL_ID")
	private String proposalId;
	public String getCurrState() {
		return currState;
	}
	public void setCurrState(String currState) {
		this.currState = currState;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	

}
