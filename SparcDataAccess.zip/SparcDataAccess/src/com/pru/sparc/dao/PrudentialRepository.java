package com.pru.sparc.dao;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.PrudentialContactDetails;
import com.pru.sparc.model.SalesOffice;

public interface PrudentialRepository {
	public void savePrudentialContact(PrudentialContactDetails prudentialContactDetails);
	public SalesOffice getRegion(String salesOffId);
	public ProposalDetails getProposalById(String proposalId);
}
