package com.pru.sparc.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.RatingQuoteDAO;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.RatingExhibits;

@Repository
public class RatingQuoteDaoImpl implements RatingQuoteDAO {
	
	@Override
	public RatingExhibits saveRatingEngineResults(RatingExhibits ratingExhibitsRequestObject) {
		Session session = null;
		Transaction txn = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			txn = session.beginTransaction();
			session.saveOrUpdate(ratingExhibitsRequestObject);
			txn.commit();
			return ratingExhibitsRequestObject;
		
		} catch(Exception e){
			e.printStackTrace();
			txn.rollback();
			ratingExhibitsRequestObject = null;
			
		} finally{
			session.close();
		}
		return null;
	}

	@Override
	public RatingExhibits updateRatingEngineOverrides(RatingExhibits ratingExhibitsRequestObject) {
		Session session = null;
		Transaction txn = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			txn = session.beginTransaction();
			session.update(ratingExhibitsRequestObject);
			txn.commit();
			return ratingExhibitsRequestObject;
		
		} catch(Exception e){
			e.printStackTrace();
			txn.rollback();
			ratingExhibitsRequestObject = null;
			
		} finally{
			session.close();
		}
		return null;
	}
	

	@Override
	public RatingExhibits retrievePlanRatingEngineResults(int planId, int rateId) {
		Session session = null;
		RatingExhibits ratingExhibits = new RatingExhibits();
		try{
			session = HibernateConnector.getInstance().getSession();			
			Query query = session.createQuery("from RatingExhibits ratingEntity where ratingEntity.rateId = "+rateId);
			ratingExhibits = (RatingExhibits)query.uniqueResult();
			
		} catch(Exception e){
			e.printStackTrace();
			ratingExhibits = null;
		} finally{
			session.close();
		}
		return ratingExhibits;
	}


	@Override
	public String getVersionStatus(int versionNumber) {
		Session session = null;
		String versionStatus = null;
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("select versionStatus from QuotationDetails versionEntity where versionNumber = :versionNumber");
			query.setParameter("versionNumber", versionNumber);
			versionStatus = (String)query.uniqueResult();
		} catch(Exception e){
			e.printStackTrace();
			versionStatus = null;
		} finally{
			session.close();
		}
		return versionStatus;
	
	
	}


	public RatingExhibits getPlanRatingDetails(Integer planId, String isRateOverride) {
		Session session = null;
		RatingExhibits ratingExhibits = new RatingExhibits();
		try{
			session = HibernateConnector.getInstance().getSession();			
			Query query = session.createQuery("from RatingExhibits ratingEntity where ratingEntity.plan.planId = :planId and ratingEntity.overId=:isRateOverride");
			query.setParameter("planId", planId);
			query.setParameter("isRateOverride", isRateOverride);
			ratingExhibits = (RatingExhibits)query.uniqueResult();
			
		} catch(Exception e){
			e.printStackTrace();
			ratingExhibits = null;
		} finally{
			session.close();
		}
		return ratingExhibits;
	}


	@Override
	public int deleteRatingResults(RatingExhibits ratingEntity) {

		Session session = null;
		Transaction txn = null;
		int records = 0;
		try{
			session = HibernateConnector.getInstance().getSession();
			txn = session.beginTransaction();
			
			session.delete(ratingEntity);
			//Query query = session.createQuery("delete RatingExhibits ratingEntity where ratingEntity = :ratingEntity");
			//query.setParameter("ratingEntity", ratingEntity);
			//records = query.executeUpdate();
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return records;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RatingExhibits> getAllPlanRatingEngineResults(int planId) {
		Session session = null;
		List<RatingExhibits> ratingExhibits = new ArrayList<RatingExhibits>();
		try{
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("from RatingExhibits ratingEntity where ratingEntity.plan.planId = :planId");
			query.setParameter("planId", planId);
			ratingExhibits = (List<RatingExhibits>)query.list();
			
		} catch(Exception e){
			e.printStackTrace();
			ratingExhibits = null;
		} finally{
			session.close();
		}
		return ratingExhibits;
	}

	@Override
	public ProposalDetails getProposalDetails(String proposalId) {
		Session session = null;
		ProposalDetails proposalDetails = null;
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("from ProposalDetails proposalEntity where proposalEntity.proposalId = :proposalId");
			query.setParameter("proposalId", proposalId);
			proposalDetails = (ProposalDetails)query.uniqueResult();
		} catch(Exception e){
			e.printStackTrace();
			proposalDetails = null;
		} finally{
			session.close();
		}
		return proposalDetails;
	}

	@Override
	public void updateVersionStatus(int versionNumber, String versionStatus) {
		Session session = null;
		Transaction txn = null;
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			txn = session.beginTransaction();
			Query query = session.createQuery("update QuotationDetails set versionStatus = :versionStatus where versionNumber = :versionNumber");
			query.setParameter("versionStatus", versionStatus);
			query.setParameter("versionNumber", versionNumber);
			int result = query.executeUpdate();
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
		} finally{
			session.close();
		}
	}
}
