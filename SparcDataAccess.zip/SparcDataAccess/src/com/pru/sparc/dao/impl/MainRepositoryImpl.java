package com.pru.sparc.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.MainRepository;
import com.pru.sparc.model.LookupDetails;
import com.pru.sparc.model.PlanLookupDetails;

@Repository
public class MainRepositoryImpl implements MainRepository {
	
	/**
	 * Method to get the list of states from database
	 * @param censusStateLookupCategory
	 * @return List<LookupDetails>
	 */
	@Override
	public List<LookupDetails> getLookupList(LookupDetails lookupDetails)
			throws Exception {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from LookupDetails l where l.lookupCategory in("
			+lookupDetails.getLookupCategory()+") and l.lookupType like ('%"+lookupDetails.getLookupType()+"%') ORDER BY l.lookupValue ASC");
			
			@SuppressWarnings("unchecked")
			List<LookupDetails> lookupList = query.list();
			txn.commit();
			return lookupList;
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}
	
	/**
	 * Method to get the list of dropdown values for plan fields from database
	 * @param censusStateLookupCategory
	 * @return List<LookupDetails>
	 */
	@Override
	public List<PlanLookupDetails> getPlanLookupList()
			throws Exception {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from PlanLookupDetails");
			@SuppressWarnings("unchecked")
			List<PlanLookupDetails> lookupList = query.list();
			txn.commit();
			return lookupList;
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}
	
	@Override
	public LookupDetails getPlanContractState(String stateCode) throws Exception {
		LookupDetails lookupDetails = null;
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("from LookupDetails l where l.lookupCode = '"+stateCode+"' and l.lookupCategory = 'BASICINFORMSTATES'" );
			lookupDetails = (LookupDetails) query.uniqueResult();
		} catch(HibernateException e){
			e.printStackTrace();
			lookupDetails = null;
		} finally{
			session.close();
		}
		return lookupDetails;
	}
}
