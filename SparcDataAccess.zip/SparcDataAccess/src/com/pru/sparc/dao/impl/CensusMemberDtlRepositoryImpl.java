package com.pru.sparc.dao.impl;

import java.util.HashMap;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.CensusMemberDtlRepository;
import com.pru.sparc.drools.model.CensusConstants;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.StateConstants;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.CensusMemberDetails;

@Repository
public class CensusMemberDtlRepositoryImpl implements CensusMemberDtlRepository {	

	/**
	 * Census member details (edit census member details Screen)
	 * 
	 * @param CensusMemberDetails
	 */
	@Override
	public void updateCensusMember(CensusMemberDetails censusMemberDetails)
			throws Exception {

		Session session;
		Transaction transaction;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			session.update(censusMemberDetails);
			transaction.commit();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
	}

	/**
	 * To get all census member list
	 * 
	 * @param censusId
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CensusMemberDetails> getCensusMembers(int censusId) {

		Session session;
		Transaction transaction;
		List<CensusMemberDetails> memberDetailsEntyLst = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			Query query = session
					.createQuery("from CensusMemberDetails c where c.censusDetail.censusId='"
							+ censusId + "'");
			// query.setParameter("censusId", censusId);
			memberDetailsEntyLst = (List<CensusMemberDetails>) query.list();

			transaction.commit();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
		return memberDetailsEntyLst;
	}

	@Override
	public CensusClass getCensusMemberClass(int censusId, int censusClsId) {
		Session session;
		Transaction transaction;
		// memberClass="desc";
		CensusClass censusClass = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			Query query = session
					.createQuery("from CensusClass c where c.censusDetail.censusId='"
							+ censusId
							+ "' and c.censusClsId='"
							+ censusClsId
							+ "'");
			censusClass = (CensusClass) query.uniqueResult();
			transaction.commit();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			censusClass = null;
		}
		return censusClass;
	}

	@SuppressWarnings("unchecked")
	public List<HashMap<String, Object>> getCensusMembersForEachClass(
			List<Integer> classId) {

		Session session;
		Transaction transaction;
		List<HashMap<String, Object>> memberList = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			Query query = session
					.createQuery("select new Map(c.salary as "
							+ PersonConstants.PEOPLE_SALARY
							+ ",c.gender as "+ PersonConstants.PEOPLE_GENDER + ", c.age as "
							+ PersonConstants.PEOPLE_AGE
							+ ",c.state as "
							+ PersonConstants.PEOPLE_STATE
							+ ",c.basicLifeVol as "
							+ PersonConstants.PEOPLE_BASIC_AMT
							+ " ,c.memberClass.retiree as RetrireeStatus ) from CensusMemberDetails c where c.memberClass.censusClsId in (:classId)");

			query.setParameterList("classId", classId);
			// query.setParameter("censusId", censusId);
			memberList = (List<HashMap<String, Object>>) query.list();

			// memberList = (List<HashMap<String, Object>>)

			transaction.commit();

		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
		return memberList;
	}

	public List<HashMap<String, Object>> getDataListByMember() {
		Session session = null;
		Transaction transaction;

		List<HashMap<String, Object>> memberList = null;
		try {

			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			memberList = (List<HashMap<String, Object>>) session.createQuery(
					"select new Map(c.salary as "
							+ PersonConstants.PEOPLE_SALARY + ",c.gender as "
							+ PersonConstants.PEOPLE_GENDER + ", c.age as "
							+ PersonConstants.PEOPLE_AGE + ",c.state as "
							+ PersonConstants.PEOPLE_STATE
							+ ",c.basicLifeVol as "
							+ PersonConstants.PEOPLE_BASIC_AMT
							+ ") from CensusMemberDetails c").list();
			transaction.commit();
			// System.out.println("p---" + memberList.get(0));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return memberList;
	}
	
	@SuppressWarnings("unchecked")
	public HashMap<String, Object> getCensusDetails(
			int proposalVersionId) {

		Session session;
		Transaction transaction;
		HashMap<String, Object> censusDetails = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			Query query = session
					.createQuery("select new Map(c.containsSalary as "
							+ CensusConstants.SALARY_SET_FOR_ALL
							+ ",c.salaryAmount as "
							+ CensusConstants.SALARY_ESTIMATE													
							+ ") from QuotationDetails qd join qd.census c where qd.versionNumber= "+proposalVersionId);
			
			// query.setParameter("censusId", censusId);
			censusDetails = (HashMap<String, Object>) query.uniqueResult();

			// memberList = (List<HashMap<String, Object>>)

			transaction.commit();

		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
		return censusDetails;
	}


	@SuppressWarnings("unchecked")
	public List<HashMap<String, Object>> getStateDetails(int versionId) {

		Session session;
		Transaction transaction;
		List<HashMap<String, Object>> stateDetails = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			Query query = session
					.createQuery("select new Map(c.state as "
							+ StateConstants.STATE
							+ ",c.allocationFactor as "+ StateConstants.STATE_ALLOCATION_FACTOR 
							+ ") from QuotationDetails qv  join qv.census.censusAlloc c where qv.versionNumber="+versionId);

			//query.setParameterList("classId", classId);
			// query.setParameter("censusId", censusId);
			stateDetails = (List<HashMap<String, Object>>) query.list();

			// memberList = (List<HashMap<String, Object>>)

			transaction.commit();

		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
		return stateDetails;
	}
	
	

}
