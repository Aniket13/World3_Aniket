package com.pru.sparc.dao.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.PlanDetailsRepository;
import com.pru.sparc.drools.model.CommissionConstants;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.PlanEligibilityClass;
import com.pru.sparc.model.PlanWrapper;
import com.pru.sparc.model.ProductDetails;
//import com.pru.sparc.model.PlanIdSequence;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.QuotationDetails;

@Repository
public class PlanDetailsRepositoryImpl implements PlanDetailsRepository {

	@Override
	public PlanDetailsClass addPlanDetails(PlanDetailsClass planDetails) {
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.save(planDetails);
			// need to write code to insert planId and version id into
			// PROPOSAL_VERSION_PLAN_MAP table
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return planDetails;
	}

	@Override
	public PlanDetailsClass updatePlanDetails(PlanDetailsClass planDetails) {
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.update(planDetails);
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return planDetails;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PlanDetailsClass> getAllPlansForVersion(int versionId,
			String proposalId, int productId) {
		Session session = null;
		List<PlanDetailsClass> planDetails = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from com.pru.sparc.model.PlanDetailsClass p where p.overId = 0 and p.version.versionNumber = "+versionId
					+" and p.product.productId = "+productId+" and p.version.proposal.proposalId = '"+proposalId+"' and p.displayPlan = 'Y'");
			planDetails = (List<PlanDetailsClass>)query.list();
			// planDetails = (PlanDetails) session.get(PlanDetails.class,
			// planId);
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			planDetails = null;
		} finally {
			session.close();
		}
		return planDetails;
	}

	@Override
	public PlanDetailsClass getPlanDetails(int planId) {
		Session session = null;
		PlanDetailsClass planDetails = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createQuery("from com.pru.sparc.model.PlanDetailsClass p where p.planId = "
							+ planId + " and p.overId = 0");
			planDetails = (PlanDetailsClass) query.uniqueResult();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return planDetails;
	}

	@Override
	public PlanDetailsClass getOverriddenRecordForPlanId(int planId) {
		Session session = null;
		PlanDetailsClass planDetails = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createQuery("from com.pru.sparc.model.PlanDetailsClass p where p.originalPlanId = "
							+ planId + " and p.overId = 1");
			planDetails = (PlanDetailsClass) query.uniqueResult();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return planDetails;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PlanDetailsClass> getPlanDetailsByProposalVersionProductId(
			int versionNumber, int productId) {
		Session session = null;
		List<PlanDetailsClass> planDetailsList = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createQuery("from com.pru.sparc.model.PlanDetailsClass p where p.overId = 0 and p.product.productId = "
							+ productId
							+ " and p.version.versionNumber = "
							+ versionNumber);
			planDetailsList = (List<PlanDetailsClass>) query.list();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			planDetailsList = null;
		} finally {
			session.close();
		}
		return planDetailsList;
	}

	/*
	 * public static void main(String[] args) { PlanDetailsRepositoryImpl pRI =
	 * new PlanDetailsRepositoryImpl(); pRI.getOverriddenRecordForPlanId(1); }
	 */
	@Override
	public void saveEligibilityClasses(
			List<PlanEligibilityClass> planEligibilityClasses) {
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			for (PlanEligibilityClass planEligibilityClass : planEligibilityClasses) {
				session.save(planEligibilityClass);
			}
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@Override
	public void updateEligibilityClasses(
			List<PlanEligibilityClass> planEligibilityClasses) {
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			for (PlanEligibilityClass planEligibilityClass : planEligibilityClasses) {
				session.update(planEligibilityClass);
			}
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<PlanEligibilityClass> getEligibilityClasses(int planId) {
		List<PlanEligibilityClass> eligibilityClassList = null;
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createQuery("from com.pru.sparc.model.PlanEligibilityClass p where p.planDetails.planId = "
							+ planId);
			eligibilityClassList = (List<PlanEligibilityClass>) query.list();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			eligibilityClassList = null;
		} finally {
			session.close();
		}
		return eligibilityClassList;
	}

	@Override
	public void savePlanCommission(ProposalBrokerDetails proposalBroker) {
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.saveOrUpdate(proposalBroker);
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@Override
	public ProposalBrokerDetails getCommissionDetails(String planId,
			int brokerId) {
		ProposalBrokerDetails proposalBrokerDetails = null;
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createQuery("from com.pru.sparc.model.ProposalBrokerDetails p where p.proPlanId = '"
							+ planId
							+ "' and p.brokerDetails.brokerId = "
							+ brokerId);
			proposalBrokerDetails = (ProposalBrokerDetails) query
					.uniqueResult();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			proposalBrokerDetails = null;
		} finally {
			session.close();
		}
		return proposalBrokerDetails;
	}

	@Override
	public CensusClass getCensusClassById(int censusClassId) {
		Session session = null;
		CensusClass censusClass = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			censusClass = (CensusClass) session.get(CensusClass.class,
					censusClassId);
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			censusClass = null;
		} finally {
			session.close();
		}
		return censusClass;
	}

	@Override
	public int getCensusForPlan(int planID, int versionNumber) {
		Session session = null;
		int censusId = 0;
		try {
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("select c.censusId from PlanDetailsClass p join p.version v join v.census c "
							+ "where p.planId = "
							+ planID
							+ " and p.overId = 0"
							+ " and p.version.versionNumber = " + versionNumber);
			censusId = (Integer) query.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
			censusId = 0;
		} finally {
			session.close();
		}
		return censusId;
	}

	
	/*public static void main(String[] args) {
		PlanDetailsRepositoryImpl obj = new PlanDetailsRepositoryImpl();
		obj.getCensusForPlan(1,1);
	}*/
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CensusClass> getCensusClassesForPlan(int censusId) {
		Session session = null;
		List<CensusClass> classList = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createQuery("from com.pru.sparc.model.CensusClass c where c.censusDetail.censusId = "
							+ censusId);
			classList = query.list();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			classList = null;
		} finally {
			session.close();
		}
		return classList;
	}

	@Override
	public int getNoOfLivesPerClass(int censusId, int censusClsId) {
		Session session = null;
		int noOfLives = 0;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createSQLQuery("select count(*) from MEMBER m where m.CENSUS_ID = "
							+ censusId + " and m.CLASS_SEQ_ID = " + censusClsId);
			noOfLives =  ((BigInteger) query.uniqueResult()).intValue();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			noOfLives = 0;
		} finally {
			session.close();
		}
		return noOfLives;
	}
	
	/*
	 * @Override public long getPlanIdSequenceId(){ Session session = null; long
	 * planId = 0; try{ session = HibernateConnector.getInstance().getSession();
	 * Transaction txn = session.beginTransaction(); Query query =
	 * session.createQuery("from com.pru.sparc.model.PlanIDSequence"); planId =
	 * (Long) query.uniqueResult(); PlanIdSequence planIdSequence = new
	 * PlanIdSequence(); planIdSequence.setSeqId(planId+1);
	 * updatePlanSequenceId(planIdSequence); txn.commit(); }catch(Exception e){
	 * e.printStackTrace(); planId = 0; } finally{ session.close(); } return
	 * planId; }
	 * 
	 * private void updatePlanSequenceId(PlanIdSequence planIdSequence){ Session
	 * session = null; try{ session =
	 * HibernateConnector.getInstance().getSession(); Transaction txn =
	 * session.beginTransaction(); session.update(PlanIdSequence.class);
	 * txn.commit(); }catch(Exception e){ e.printStackTrace(); } finally{
	 * session.close(); } }
	 */

	@SuppressWarnings("unchecked")
	public List<HashMap<String, Object>> getDataListByPlan(int versionId) {
		Session session = null;
		Transaction transaction;
		List<HashMap<String, Object>> planList = new ArrayList<HashMap<String, Object>>();
		try {

			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();

			planList = (List<HashMap<String, Object>>) session.createQuery(
					"select new Map(r.planId as "+PlanConstants.PLAN_ID+",r.contractState as "
							+ PlanConstants.PLAN_CONTRACT_STATE+ ",r.ageReductionSchedule as "
							+ PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE							
							+ ",r.livingBenefitOption as "
							+ PlanConstants.PLAN_LIVINGBENEFITOPTIONTYPE							
							+ ",r.contributionArrangement as "
							+ PlanConstants.EXPERIENCE_ARRANGEMENT
							+ ",r.insuranceAmount as "
							+ PlanConstants.PLAN_TYPE
							+ ",r.compositeRating as "
							+ PlanConstants.PLAN_COMPOSITE
							+ ",r.disablityProvision as "
							+ PlanConstants.DISABILITY_SCHEDULE_DURATION
							+ ",r.duration as "
							+ PlanConstants.DISABILITY_SCHEDULE
							+ ",r.roundingRule as "
							+ PlanConstants.PLAN_ROUNDING_PREFERENCES
							+ ",r.roundingOccurs as "
							+ PlanConstants.PLAN_ROUNDING_OCCURS
							+ ",r.caseFlatAmt as "
							+ PlanConstants.CASE_FLAT_AMT
							+ ",r.ageBandedRating as "
							+ PlanConstants.BL_AGE_BANDED
							+ ",r.travelAssistance as "
							+ PlanConstants.TRAVEL_ASSIST
							+ ",r.maxDollaramt as " + PlanConstants.PLAN_MAX
							+ ",r.minDollarAmt as " + PlanConstants.PLAN_MIN
							+ ",r.dollarAmount as "
							+ PlanConstants.GUARANTEE_ISSUE_DOLLAR_AMT
							+ ",r.rateGurantee as "
							+ PlanConstants.RATE_GUARANTEE_MONTH_NUM
							+ ",r.multipleOfEarnings as "+PlanConstants.PLAN_EARNINGS_FACTOR+" ,r.effectiveDate as "
							+ PlanConstants.PLAN_EFFECTIVEDATE
							+ ",r.volumeAmounts as "+ PlanConstants.VOLUME_TYPE +") from PlanDetailsClass r where r.version.versionNumber = "+versionId
							+ " and r.overId = 0 and r.displayPlan = 'Y'").list();
			transaction.commit();
			// System.out.println("p---"+planList.get(0));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return planList;
	}

	@SuppressWarnings("unchecked")
	public List<Integer> getClassIdsForPlan(int planId) {
		List<Integer> classIds = null;
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createQuery("select p.censusClass.censusClsId from PlanEligibilityClass p where p.planDetails.planId = "
							+ planId);
			classIds = (List<Integer>) query.list();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			classIds = null;
		} finally {
			session.close();
		}
		return classIds;
	}

	@SuppressWarnings("unchecked")
	public List<HashMap<String, Object>> getCommissionDetailsForPlan(
			String planId) {
		List<HashMap<String, Object>> listofcommissions = new ArrayList<HashMap<String, Object>>();
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session
					.createQuery("select new Map (p.flatAmount as "+CommissionConstants.COMMISSIONFLATAMT+",p.flatPercentage as "+CommissionConstants.COMMISSIONFLATPCT+",p.arrangement as "+CommissionConstants.COMMISSION_COMARRANGEMENT+") from ProposalBrokerDetails p where p.proPlanId ="
							+ planId);
			
			listofcommissions = (List<HashMap<String, Object>>) query.list();
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			listofcommissions = null;
		} finally {
			session.close();
		}
		return listofcommissions;
	}
	
	@Override
	public PlanWrapper saveAllPlanDetails(PlanWrapper planWrapper) throws Exception{
		Session session = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.saveOrUpdate(planWrapper.getPlanDetailsClass());
			for (PlanEligibilityClass eligibilityClass : planWrapper.getPlanEligibilityClass()) {
				session.saveOrUpdate(eligibilityClass);
			}
			session.saveOrUpdate(planWrapper.getProposalBrokerDetails());
			session.saveOrUpdate(planWrapper.getOverriddenDetails());
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return planWrapper;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public PlanWrapper getAllPlanDetails(int planId, int brokerId) throws Exception{
		Session session = null;
		PlanDetailsClass planDetails = null;
		PlanDetailsClass overPlanDetails = null;
		ProposalBrokerDetails commissionDetails = null;
		List<PlanEligibilityClass> eligiList = null;
		PlanWrapper planWrapper = new PlanWrapper();
		try {
			session = HibernateConnector.getInstance().getSession();
			Query query = null;
			Transaction txn = session.beginTransaction();
			String planQry = "from com.pru.sparc.model.PlanDetailsClass p where p.planId = "
							+ planId + " and p.overId = 0";
			String overQry = "from com.pru.sparc.model.PlanDetailsClass p where p.originalPlanId = "
							+ planId + " and p.overId = 1";
			String commQry = "from com.pru.sparc.model.ProposalBrokerDetails p where p.proPlanId = '"
							+ String.valueOf(planId)
							+ "' and p.brokerDetails.brokerId = "
							+ brokerId;
			String eligQry = "from com.pru.sparc.model.PlanEligibilityClass p where p.planDetails.planId = "
					+ planId;
			query = session.createQuery(planQry);
			planDetails = (PlanDetailsClass) query.uniqueResult();
			
			query = session.createQuery(overQry);
			overPlanDetails = (PlanDetailsClass) query.uniqueResult();
			
			query = session.createQuery(commQry);
			commissionDetails = (ProposalBrokerDetails) query.uniqueResult();
			
			query = session.createQuery(eligQry);
			eligiList = (List<PlanEligibilityClass>) query.list();
			
			planWrapper.setOverriddenDetails(overPlanDetails);
			planWrapper.setPlanDetailsClass(planDetails);
			planWrapper.setPlanEligibilityClass(eligiList);
			planWrapper.setProposalBrokerDetails(commissionDetails);
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return planWrapper;
	}
	/*public static void main(String[] args) {
		PlanDetailsRepositoryImpl plim=new PlanDetailsRepositoryImpl();
		try {
			plim.getAllPlanDetails(660,1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
*/
	@Override
	public QuotationDetails getVersionDetails(int versionNumber) throws Exception {
		Session session = null;
		QuotationDetails quotationDetails = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			quotationDetails = (QuotationDetails) session.get(QuotationDetails.class, versionNumber);
		} catch(Exception e){
			e.printStackTrace();
			quotationDetails = null;
		} finally{
			session.close();
		}
		return quotationDetails;
	}

	@Override
	public ProductDetails getProductDetails(int planId) throws Exception {
		Session session = null;
		ProductDetails productDetails = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("select pd.product from PlanDetailsClass pd join pd.product pr "
					+ "where pd.planId = "
					+ planId
					+ " and pd.overId = 0");
			productDetails = (ProductDetails) query.uniqueResult();
		} catch(Exception e){
			e.printStackTrace();
			productDetails = null;
		} finally{
			session.close();
		}
		return productDetails;
	}

	@Override
	public String getPlanProposalId(int planId) {
		Session session = null;
		String proposalId = "";
		try {
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("select p.proposalId from PlanDetailsClass pd join pd.version v join v.proposal p "
							+ "where pd.planId = "
							+ planId
							+ " and pd.overId = 0");
			proposalId = (String) query.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
			proposalId = null;
		} finally {
			session.close();
		}
		return proposalId;
	}
	
	
	@Override
	public int getPlanVersionId(int planId) {
		Session session = null;
		int versionID = 0;
		try {
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("select v.versionNumber from PlanDetailsClass pd join pd.version v "
							+ "where pd.planId = "
							+ planId
							+ " and pd.overId = 0");
			versionID = (Integer) query.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
			versionID = 0;
		} finally {
			session.close();
		}
		return versionID;
	}
	
	public static void main(String[] args) throws Exception {
		PlanDetailsRepositoryImpl obj = new PlanDetailsRepositoryImpl();
		System.out.println(obj.getProductDetails(660).getProductDescription());
		System.out.println(obj.getProductDetails(660).getProductId());
	}

	@Override
	public PlanDetailsClass fetchExistingPlanDetails(int planId) {
		Session session = null;
		PlanDetailsClass planDetails = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Query query = null;
			Transaction txn = session.beginTransaction();
			String planQry = "from com.pru.sparc.model.PlanDetailsClass p where p.planId = " + planId;
			
			query = session.createQuery(planQry);
			planDetails = (PlanDetailsClass) query.uniqueResult();
			
			txn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return planDetails;
	}
	
	@Override
	public void deleteEligibilityRecords(int planId){
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("delete from PlanEligibilityClass e where e.planDetails.planId = "+planId);
			query.executeUpdate();
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
	}

	@Override
	public int getCensusTotalLives(int selectedCensusId) {
		Session session = null;
		int totalLives = 0;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("select totalLives from CensusDetail c where c.censusId = "+selectedCensusId);
			totalLives = (Integer) query.uniqueResult();
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return totalLives;
	}

}
