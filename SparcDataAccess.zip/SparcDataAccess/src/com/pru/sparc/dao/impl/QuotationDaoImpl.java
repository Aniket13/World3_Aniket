package com.pru.sparc.dao.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.QuotationDao;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.QuotationDetails;



@Repository("quotationDao")
public class QuotationDaoImpl implements QuotationDao {
	
	
	@Override
	public ProposalDetails getProposalDetails(Map<String, String> proposalSearchRequestMap) {
		Session session = null;
		ProposalDetails proposalDetails = null;
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			proposalDetails = (ProposalDetails) session.get(ProposalDetails.class, proposalSearchRequestMap.get("proposalId"));
		} catch(Exception e){
			e.printStackTrace();
			proposalDetails = null;
		} finally{
			session.close();
		}
		return proposalDetails;
	}


	
	@Override
	public int getProposalVersionsCount(Map<String, String> proposalSearchRequestMap) {
		
		Session session = null;
		ProposalDetails proposalDetails = null;
		
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			proposalDetails = (ProposalDetails) session.get(ProposalDetails.class, proposalSearchRequestMap.get("proposalId"));
			Set<QuotationDetails> quotationList = (Set<QuotationDetails>) proposalDetails.getQuotes();
			if (quotationList != null && quotationList.size() > 0) {
				return quotationList.size();
			}
		} catch(Exception e){
			e.printStackTrace();
			proposalDetails = null;
		} finally{
			session.close();
		}
		return 0;
	}


	@Override
	public QuotationDetails createNewQuotation(QuotationDetails quotationDetails) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.save(quotationDetails);
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
			quotationDetails = null;
		} finally{
			session.close();
		}
		return quotationDetails;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<CensusDetail> getCensusList(int clientId) {
		Session session = null;
		List<CensusDetail> censusList = new ArrayList<CensusDetail>();
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			Transaction transaction = session.beginTransaction();
			Query query = session.createQuery("from CensusDetail c where c.client.clientId = "+clientId);
			//Criteria censusCriteria = session.createCriteria(CensusDetail.class);
			//censusCriteria.add(Restrictions.eq("client.clientId", clientId));
			censusList = (List<CensusDetail>)query.list();
			transaction.commit();
		} catch(Exception e){
			e.printStackTrace();
			censusList = null;
		} finally{
			session.close();
		}
		return censusList;
	}


	/*@SuppressWarnings("unchecked")
	@Override
	public List<ProductDetails> getProductList() {
		Session session = null;
		List<ProductDetails> productList = new ArrayList<ProductDetails>();
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			Criteria productCriteria = session.createCriteria(ProductDetails.class);
			productList = (List<ProductDetails>)productCriteria.list();
		} catch(Exception e){
			e.printStackTrace();
			productList = null;
		} finally{
			session.close();
		}
		return productList;
	}*/


	/*@SuppressWarnings("unchecked")
	@Override
	public List<PlanDetailsClass> getSelectedQuoteProducts(List<String> selectedQuoteProducts, String proposalId, int versionNumber) {

		Session session = null;
		List<PlanDetailsClass> productList = new ArrayList<PlanDetailsClass>();
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			Criteria productCriteria = session.createCriteria(ProductDetails.class);
			productCriteria.add(Restrictions.in("productId", selectedQuoteProducts));
			productList = (List<PlanDetailsClass>)productCriteria.list();
		} catch(Exception e){
			e.printStackTrace();
			productList = null;
		} finally{
			session.close();
		}
		return productList;
	
	}*/


	@SuppressWarnings("unchecked")
	@Override
	public List<CensusDetail> getSelectedCensus(String selectedCensus) {
		Session session = null;
		List<CensusDetail> censusList = new ArrayList<CensusDetail>();
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("from CensusDetail c where c.censusId = '"+selectedCensus+"'");
			//Criteria censusCriteria = session.createCriteria(CensusDetail.class);
			//censusCriteria.add(Restrictions.eq("censusId", selectedCensus));
			censusList = (List<CensusDetail>)query.list();
		} catch(Exception e){
			e.printStackTrace();
			censusList = null;
		} finally{
			session.close();
		}
		return censusList;
	
	
	}

	@Override
	public QuotationDetails getQuotationDetails(String proposalId, int versionNumber) {
		Session session = null;
		QuotationDetails quotationDetails = new QuotationDetails();
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			ProposalDetails proposalDetails = (ProposalDetails) session.get(ProposalDetails.class, proposalId);
			Set<QuotationDetails> quotationList = (Set<QuotationDetails>) proposalDetails.getQuotes();
			Iterator<QuotationDetails> iterator = quotationList.iterator();
			while (iterator.hasNext()) {
				quotationDetails = iterator.next();
				if (quotationDetails.getVersionNumber() == versionNumber) {
					break;
				}
			}
		} catch(Exception e){
			e.printStackTrace();
			quotationDetails = null;
		} finally{
			session.close();
		}
		return quotationDetails;
	}


	@Override
	public void saveQuotation(QuotationDetails quotationDetails) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.update(quotationDetails);
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
			quotationDetails = null;
		} finally{
			session.close();
		}
	}

	@Override
	public ProposalBrokerDetails updateCommission(ProposalBrokerDetails proposalBrokerDetails) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.update(proposalBrokerDetails);
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
			proposalBrokerDetails = null;
		} finally{
			session.close();
		}
		return proposalBrokerDetails;
	}

	public Set<QuotationDetails> getProposalVersions(Map<String, String> searchRequestMap) {

		Session session = null;
		Set<QuotationDetails> quotationSet = new HashSet<QuotationDetails>();
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			ProposalDetails proposalDetails = (ProposalDetails) session.get(ProposalDetails.class, searchRequestMap.get("proposalId"));
			quotationSet = (Set<QuotationDetails>) proposalDetails.getQuotes();
		} catch(Exception e){
			e.printStackTrace();
			quotationSet = null;
		} finally{
			session.close();
		}
		return quotationSet;
	
	}



	@SuppressWarnings("unchecked")
	@Override
	public List<ProductDetails> getProductList() {
		Session session = null;
		List<ProductDetails> productList = new ArrayList<ProductDetails>();
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("from ProductDetails");
			productList = (List<ProductDetails>) query.list();
		} catch(Exception e){
			e.printStackTrace();
			productList = null;
		} finally{
			session.close();
		}
		return productList;
	}



	@Override
	public List<ProductDetails> getSelectedProducts(
			List<Integer> selectedQuoteProducts) {
		Session session = null;
		List<ProductDetails> productList = new ArrayList<ProductDetails>();
		try{
			for (int selectedProduct : selectedQuoteProducts) {
				session = HibernateConnector.getInstance().getSession();
				Criteria productCriteria = session.createCriteria(ProductDetails.class);
				productCriteria.add(Restrictions.eq("productId", selectedProduct));
				ProductDetails productDetails = (ProductDetails)productCriteria.uniqueResult();
				productList.add(productDetails);
			}
		} catch(Exception e){
			e.printStackTrace();
			productList = null;
		} finally{
			session.close();
		}
		return productList;
	}



	@Override
	public ProposalBrokerDetails getCommission(int brokerID,
			String proposalPlanID, int versionNumber) {
		Session session = null;
		ProposalBrokerDetails proposalBrokerDetails = null;
		try {
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from ProposalBrokerDetails p where p.brokerDetails.brokerId = "+brokerID+" and proPlanId = '"+proposalPlanID+"' and p.versionDetails.versionNumber = "+versionNumber);
			proposalBrokerDetails = (ProposalBrokerDetails) query.uniqueResult();
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
			proposalBrokerDetails = null;
		} finally{
			session.close();
		}
		return proposalBrokerDetails;
	}



	@Override
	public ProposalBrokerDetails saveCommission(
			ProposalBrokerDetails prBrokerDetails) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.save(prBrokerDetails);
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
			prBrokerDetails = null;
		} finally{
			session.close();
		}
		return prBrokerDetails;
	}
}
