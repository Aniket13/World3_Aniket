package com.pru.sparc.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.CensusDetailRepository;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.CensusLvsAlloc;

@Repository("censusDetailRepository")
public class CensusDetailRepositoryImpl implements CensusDetailRepository {

	@Override
	public CensusDetail update(CensusDetail census) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			//session.merge(census);
			session.update(census);
			txn.commit();
		}catch(HibernateException e){ 
			e.printStackTrace();
			census = null;
		} finally{
			session.close();
		}
		return census;
	}

	@Override
	public CensusDetail getCensusDetailById(int censusid) {
		Session session = null;
		CensusDetail censusDtl = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			censusDtl = (CensusDetail)session.createQuery("from CensusDetail c where c.censusId ="+censusid+" ").uniqueResult();
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return censusDtl;
	}
	@Override
	public List<CensusDetail> getCensusDetail(int clientId ){
		Session session = null;
		List<CensusDetail> queryList;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from CensusDetail c where c.client.clientId = "+clientId);
			queryList = query.list();
			txn.commit();
			if (queryList != null && queryList.isEmpty()) {
                return null;
            } else {
                System.out.println("list " + queryList);
                return (List<CensusDetail>) queryList;
            }
			
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
		
	}

	@Override
	public List<CensusClass> addCensusClasses(List<CensusClass> census) {
		Session session = null;
		CensusClass cenClass;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			for (CensusClass cls :census) {
				cenClass= getCensusClass(cls);
				if(null != cenClass){
				System.out.println("In Update Mode");
				session.merge(cls);
				}else{
				System.out.println("In Insert Mode");
				session.save(cls);
				}
			}
			txn.commit();
			return census;
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}

	
	public CensusClass getCensusClass(CensusClass censusId) {
		Session session = null;
		CensusClass queryList;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			//Query query = session.createQuery("FROM CensusClass C WHERE C.censusClsId = '"+censusId.getCensusClsId()+"' ").uniqueResult();
			queryList = (CensusClass) session.createQuery("FROM CensusClass C WHERE C.censusDetail.censusId ='"+ censusId.getCensusDetail().getCensusId()+"' AND  C.censusClsId = '"+censusId.getCensusClsId()+"' ").uniqueResult();
			//query.setParameter("vCensusFlId", census.getCensusClsId());
			//queryList = query.list();
			txn.commit();
			//if (queryList != null && queryList.isEmpty()) {
			if (queryList != null) {
                return queryList;
            } else {
                System.out.println("list " + queryList);
                return null;
            }
			
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}
	
	@Override
	public List<CensusClass> getCensusClasses(CensusClass census) {
		Session session = null;
		List<CensusClass> queryList;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("FROM CensusClass C WHERE C.censusDetail.censusId = '"+ census.getCensusDetail().getCensusId()+"' ");
			//query.setParameter("vCensusFlId", census.getCensusClsId());
			queryList = query.list();
			txn.commit();
			if (queryList != null && queryList.isEmpty()) {
                return null;
            } else {
                System.out.println("list " + queryList);
                return (List<CensusClass>) queryList;
            }
			
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}

	/**
	 * Method to save the census allocation details to database
	 * @param List<CensusLvsAlloc>
	 */
	@Override
	public void addCensusLiveAlloc(
			List<CensusLvsAlloc> censusLvcAloc) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			for (CensusLvsAlloc clsAlloc :censusLvcAloc) {
			    session.saveOrUpdate(clsAlloc);
			}
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
	}

	/**
	 * Method to get the census allocation details from database
	 * @param censusId
	 * @return List<CensusLvsAlloc>
	 */
	@Override
	public List<CensusLvsAlloc> getCensusLiveAlloc(
			String censusId) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from CensusLvsAlloc c where c.censusDetail.censusId = '"+censusId+"'");
			@SuppressWarnings("unchecked")
			List<CensusLvsAlloc> resultList = query.list();
			txn.commit();
			return resultList;
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}

	/**
	 * Method to delete the census allocation details from database
	 * @param cenAlloc
	 */
	@Override
	public void deleteCensusLiveAlloc(CensusLvsAlloc cenAlloc) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("delete from CensusLvsAlloc c where c.censusDetail.censusId = '"
							+cenAlloc.getCensusDetail().getCensusId()+"' and c.censusAllocId = '"
							+cenAlloc.getCensusAllocId()+"' and c.noOfLives = '"+cenAlloc.getNoOfLives()+"'");
			query.executeUpdate();
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
	}

	@Override
	public CensusLvsAlloc getCensusLiveAllocByCensusState(String cenState,
			int censusId) {
		Session session = null;
		CensusLvsAlloc result = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from CensusLvsAlloc c where c.censusDetail.censusId = "+censusId+" and c.state = '"+cenState+"'");
			result = (CensusLvsAlloc) query.uniqueResult();
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
			result = null;
		} finally{
			session.close();
		}
		return result;
	}
	
	public static void main(String[] args) {
		CensusDetailRepositoryImpl cdri = new CensusDetailRepositoryImpl();
		cdri.getCensusDetail(4);
		cdri.getCensusLiveAllocByCensusState("CO", 1);
		cdri.getCensusLiveAlloc("1");
	}
}
