package com.pru.sparc.dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
//import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
//import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.PrudentialRepository;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.PrudentialContactDetails;
import com.pru.sparc.model.SalesOffice;


@Repository("prudentialRepository")
public class PrudentialRepositoryImpl implements PrudentialRepository{
	
	/* 
	 * Saving Prudential Contact data in database
	 */
	//private HibernateUtil hibUtil;
	/*public void savePrudentialContact(PrudentialContactEntity prudentialContactEntity) {
	        Session session;
	        Transaction transaction;
	        try {
	            //session = HibernateConnector.getInstance().getSession();
	        	//session = HibernateUtil.getSessionFactory().openSession();
	        	
	        	
	        	
	        	Configuration configuration = new Configuration().configure();
	        	//configuration.setProperty("packagesToScan", "com.pru.sparc.model");
	        	
     	        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
     	        
     	        org.springframework.orm.hibernate4.LocalSessionFactoryBean test = new org.springframework.orm.hibernate4.LocalSessionFactoryBean();
	        	test.setPackagesToScan("com.pru.sparc.model");
	        	
	        	//test.setHibernateProperties(configuration.getProperties());
	        	
     	        SessionFactory sessionFactory = configuration.buildSessionFactory(builder.build());
     	        
	        	session = sessionFactory.openSession();
	        	
	           transaction = session.beginTransaction();
	            
	            session.save(prudentialContact);
	            transaction.commit();
	        } catch (Exception e) {
	            e.getMessage();
	            e.printStackTrace();
			} 
	}*/
	
	public void savePrudentialContact(PrudentialContactDetails prudentialContactDetails) {
        Session session;
        Transaction transaction;
        try {
        	//sessionFactory = HibernateUtil.getSessionFactory();
        	//session = sessionFactory.openSession();
        	session = HibernateConnector.getInstance().getSession();
            transaction = session.beginTransaction();
            session.save(prudentialContactDetails);
            transaction.commit();
        } catch (Exception e) {
            e.getMessage();
            e.printStackTrace();
		} 
}

	@Override
	public ProposalDetails getProposalById(String proposalId) {
		Session session;
		Transaction transaction;
		ProposalDetails proposalDetails;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			proposalDetails = (ProposalDetails) session.get(ProposalDetails.class, proposalId);
			transaction.commit();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
			proposalDetails = null;
		} 
		return proposalDetails;
	}
	
	public SalesOffice getRegion(String salesOffId){
		Session session = null;
		SalesOffice salesClass = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			salesClass = (SalesOffice)session.createQuery("from SalesOffice s where s.salesOfficeId = "+salesOffId).uniqueResult();
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return salesClass;
	}
}
