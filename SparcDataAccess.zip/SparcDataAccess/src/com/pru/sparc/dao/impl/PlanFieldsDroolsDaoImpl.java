package com.pru.sparc.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.model.PlanfieldsValues;

public class PlanFieldsDroolsDaoImpl {

	public List<PlanfieldsValues> getPlanfieldsDetails(List fieldList){
		Session session=null;
		Transaction transaction;
        try {
            //session = HibernateConnector.getInstance().getSession();
        //	session = new Configuration().configure("/hibernate.cfg.xml").buildSessionFactory().openSession();
        	session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
            List<PlanfieldsValues> queryList;
            String plafields = fieldList.toString().replace("[", "'").replace("]", "'")
    	            .replace(", ", "','");
            if(fieldList.size() > 0){
				String sqlQuery = "select c from PlanfieldsValues c where fieldName in ("+plafields+") ";
				/*fieldName,fieldVal*/
				System.out.println("sqlQuery..."+sqlQuery);
            Query query = session.createQuery(sqlQuery);
            queryList = query.list();
            if (queryList != null && queryList.isEmpty()) {
                return null;
            } else {
                System.out.println("list " + queryList);
                return (List<PlanfieldsValues>) queryList;
            }
            }else{
            	 return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            session.close();
        }
	}
}
