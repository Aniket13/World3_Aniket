package com.pru.sparc.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.ProducerRepository;
import com.pru.sparc.model.BrokerDetails;
import com.pru.sparc.model.ProposalBrokerDetails;

@Repository("producerRepository")
public class ProducerRepositoryImpl implements ProducerRepository {

	/**
	 * To fetch producers from database
	 * @param 
	 * @return List<ProducerDetails>
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BrokerDetails> getProducers() {
		Session session = null;
		List<BrokerDetails> brokerList = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from BrokerDetails");
			brokerList = query.list();
			txn.commit();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return brokerList;
	}

	@Override
	public BrokerDetails getProducerById(int brokerID) {
		Session session = null;
		BrokerDetails brokerDetails = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			brokerDetails = (BrokerDetails) session.get(BrokerDetails.class, brokerID);
			txn.commit();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return brokerDetails;
	}

	@Override
	public void saveProposalCommission(ProposalBrokerDetails proposalBroker) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.save(proposalBroker);
			txn.commit();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			session.close();
		}
	}
}
