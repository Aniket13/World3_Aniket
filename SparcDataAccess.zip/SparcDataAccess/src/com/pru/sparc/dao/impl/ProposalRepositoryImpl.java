package com.pru.sparc.dao.impl;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.ProposalRepository;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.ProposalIDEmbeddable;
import com.pru.sparc.model.ProposalIdClass;
import com.pru.sparc.model.SalesOffice;


@Repository("proposalRepository")
public class ProposalRepositoryImpl implements ProposalRepository{

	/* (non-Javadoc)
	 * @Method is used to create Proposal id
	 * returns model
	 */
	@Override
	public String createPropId() {
        Session session;
        Transaction transaction;
        String proposalId;
        Integer  vpropseqid = null;
        Query query =null;
        Query query1 =null;
        String hql0=null;
        String hql1=null;
        String hql2=null;
        Calendar date=Calendar.getInstance();
		int year = date.get(Calendar.YEAR);
		int day = date.get(Calendar.DAY_OF_YEAR);
		String proposalSeqId = null;
        try {
            session = HibernateConnector.getInstance().getSession();
            transaction = session.beginTransaction();
            hql0  = "from ProposalIdClass a where a.proposalIDEmbeddable.propDate ='"+getCurrentDate()+"' ";
            query = session.createQuery(hql0);
			@SuppressWarnings("unchecked")
			List<ProposalIdClass> resultList =  query.list();
            for (ProposalIdClass result : resultList) {
            vpropseqid=(Integer) result.getProposalIDEmbeddable().getSeqId();
            }
            if(vpropseqid==null){
            	vpropseqid = 1;
            	ProposalIdClass prId=new ProposalIdClass();
            	prId.setProposalIDEmbeddable(new ProposalIDEmbeddable());
            	prId.getProposalIDEmbeddable().setPropDate(new Date());
            	prId.getProposalIDEmbeddable().setSeqId(1);
            	session.save(prId);
            }else{
            	hql1 = "select IFNULL(max(a.proposalIDEmbeddable.seqId),0)+1 from ProposalIdClass a where a.proposalIDEmbeddable.propDate ='"+getCurrentDate()+"' ";				
             	vpropseqid=(Integer) session.createQuery(hql1).uniqueResult();
             	hql2 ="update ProposalIdClass p set p.proposalIDEmbeddable.seqId =:maxid  where p.proposalIDEmbeddable.propDate ='"+getCurrentDate()+"'";	
             	query1=session.createQuery(hql2);
             	query1.setParameter("maxid",vpropseqid);
             	query1.executeUpdate();
            }
           transaction.commit();
           if(vpropseqid > 0 && vpropseqid < 100){
        	   proposalSeqId = (String) session.createSQLQuery("SELECT LPAD(`PROPSEQID`,3,'0') from proposalidseq where `PROPDATE` = (select CURDATE())").uniqueResult();
           }
        } catch (HibernateException e) {
            e.printStackTrace();
		} 
        proposalId=String.valueOf(year)+String.valueOf(day)+proposalSeqId;
        return proposalId;   
    }
	
	private static java.sql.Date getCurrentDate() {
		Date today = new Date();
		return new java.sql.Date(today.getTime());
	}

	@Override
	public ProposalDetails getHeaderDetails(String proposalId, int clientId) {
		Session session = null;
		ProposalDetails proposalDetails = null;
		try{
			//session = this.sessionFactory.openSession();
			session = HibernateConnector.getInstance().getSession();
			
			Query query = session.createQuery("from ProposalDetails p where p.proposalId = '"+ proposalId +"' AND"
					+ " p.client.clientId = '"+ clientId +"' ");
			proposalDetails = (ProposalDetails) query.uniqueResult();
			if (proposalDetails == null) {
                return null;
            } else {
                return proposalDetails;
            }
		} catch(Exception e){
			e.printStackTrace();
			proposalDetails = null;
		} finally{
			session.close();
		}
		return proposalDetails;
	
	}

	@Override
	public List<SalesOffice> getSalesOffice() {
		Session session = null;
		Transaction transaction;
		List<SalesOffice> salesList=null;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			Query query=session.createQuery("from SalesOffice S ORDER BY S.salesOffName ASC");
			//query.setParameter("censusId", censusId);
			salesList=query.list();
			transaction.commit();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
		return salesList;
	
	}
	
	
	
	
	
	@Override
	public ProposalDetails getProposalDetails(String proposalId) {

		Session session = null;
		ProposalDetails proposalDetails = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			proposalDetails = (ProposalDetails) session.get(ProposalDetails.class, proposalId);
		} catch(Exception e){
			e.printStackTrace();
			proposalDetails = null;
		} finally{
			session.close();
		}
		return proposalDetails;
	}
	
	@Override
	public ProposalDetails createNewProposal(ProposalDetails proposalDetails) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.save(proposalDetails);
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
			proposalDetails = null;
		} finally{
			session.close();
		}
		return proposalDetails;
	}

	@Override
	public SalesOffice getSalesOfficeByName(String salesOffVal) {
		Session session = null;
		Transaction transaction;
		SalesOffice salesOffice=null;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			Query query=session.createQuery("from SalesOffice S where S.salesOfficeId ='"+salesOffVal+"'");
			salesOffice = (SalesOffice) query.uniqueResult();
			transaction.commit();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
		return salesOffice;
	}

	@Override
	public void updateProposal(ProposalDetails proposalDetails) {
		Session session = null;
		Transaction transaction;
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			session.update(proposalDetails);
			transaction.commit();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
		finally{
			session.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<HashMap<String, Object>> getDataListByHoldingSic(int versionId) {
		Session session = null;
		Transaction transaction;
		List<HashMap<String, Object>> holdingListSic = new ArrayList<HashMap<String, Object>>();
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			holdingListSic = (List<HashMap<String, Object>>) session.createQuery(
					"select new Map(c.sic as "+HoldingConstants.SIC_CODE
							+") from QuotationDetails qv join qv.proposal p join p.client c where qv.versionNumber="+versionId).list();
			transaction.commit();
			//System.out.println("p---"+holdingListSic.get(0));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return holdingListSic;
	}
	
	@SuppressWarnings("unchecked")
	public List<HashMap<String, Object>> getDataListByHoldingLives(int versionId) {
		Session session = null;
		Transaction transaction;
		List<HashMap<String, Object>> holdingCsv_life = new ArrayList<HashMap<String, Object>>();
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			holdingCsv_life = (List<HashMap<String, Object>>) session.createQuery(
					"select new Map(c.totalLives as "+HoldingConstants.HOLDING_CV_CASE_LIVES
							+",c.lastModDate as "+HoldingConstants.CENSUS_MODIFICATION_DATE+") from QuotationDetails qv join qv.census c where qv.versionNumber="+versionId).list();
			transaction.commit();
			//System.out.println("p---"+holdingCsv_life.get(0));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return holdingCsv_life;
	}
	
	@SuppressWarnings("unchecked")
	public List<HashMap<String, Object>> getDataListByHolding(int versionId) {
		Session session = null;
		Transaction transaction;
		List<HashMap<String, Object>> holdingList = new ArrayList<HashMap<String, Object>>();
		try {
			session = HibernateConnector.getInstance().getSession();
			transaction = session.beginTransaction();
			holdingList = (List<HashMap<String, Object>>) session.createQuery(
					"select new Map(qv.billMethod as "+HoldingConstants.DV_BILLMETHOD
							+ ",p.creationDate as "+HoldingConstants.PROPOSALCREATIONDATE
							+ ",so.salesOffName as "+HoldingConstants.HOLDING_SALES_OFFICE
							+ ",qv.contactDocFormat as "+HoldingConstants.CERTIFICATE_TYPE
							+") from QuotationDetails qv join qv.proposal p join p.salesOffice so  where qv.versionNumber ="+versionId).list();
			holdingList.add(new HashMap<String, Object>());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return holdingList;
	}
	
	public static void main (String args []){
		
		ProposalRepositoryImpl pri = new ProposalRepositoryImpl();
		pri.getDataListByHolding(341);
	}

}
