package com.pru.sparc.dao.impl;



import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.StateXmlRepository;
import com.pru.sparc.model.StateXml;
@Repository("stateXmlRepository")
public class StateXmlRepositoryImpl implements StateXmlRepository {
	
	/**
	 * Add update State Xml details 
	 */
	@Override
	public StateXml addUpdateStates(StateXml stateXml) {
		Session session = null;
		StateXml states;
		List<StateXml> prevStates;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
				states= getStates(stateXml);
				if(null != states){
				System.out.println("In Update Mode");
				session.update(stateXml);
				}else{
				System.out.println("In Insert Mode");
				boolean updateFlag = updatePrevStates(stateXml);
				prevStates= getPrevStates(stateXml);
				if(prevStates.size() > 0 &&  updateFlag){
				session.save(stateXml);
				}else if(0 == (null != prevStates ? prevStates.size() : 0)){
					session.save(stateXml);
				  }
				}
			
			txn.commit();
			return stateXml;
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}
	private boolean updatePrevStates(StateXml stateXml) {
		Session session = null;
		List<StateXml> states;
		boolean flag = false;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
				states= getPrevStates(stateXml);
				if(states.size() > 0){
				for(StateXml state : states){
					state.setStateStatus("X");
					state.setModDt(new java.util.Date().toString());
					//state.setModUser();
					System.out.println("In Update Mode");
					session.update(state);
					}
				flag = true;
				}
			txn.commit();
			return flag;
		}catch(HibernateException e){
			e.printStackTrace();
			return flag;
		} finally{
			session.close();
		}
	}
	
	@Override
	public List<StateXml> getPrevStates(StateXml stateXml) {
		Session session = null;
		List<StateXml> queryList;
		
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("FROM StateXml S WHERE S.stateXmlEmbeddable.proposalId = '"+stateXml.getStateXmlEmbeddable().getProposalId()+"' AND S.stateStatus='A' ");
			queryList = query.list();
			txn.commit();
			if (queryList != null ) {
                return (List<StateXml>) queryList;
            } else {
                System.out.println("list " + queryList);
                return  null;
            }
			
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}
	
	@Override
	public StateXml getStates(StateXml stateXml) {
		Session session = null;
		StateXml queryList;
		
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			queryList = (StateXml)session.createQuery("FROM StateXml S WHERE S.stateXmlEmbeddable.proposalId = '"+stateXml.getStateXmlEmbeddable().getProposalId()+"' AND S.stateXmlEmbeddable.currState = '"+stateXml.getStateXmlEmbeddable().getCurrState()+"' AND S.stateStatus ='A'").uniqueResult();
			txn.commit();
			if (queryList != null ) {
                return queryList;
            } else {
                System.out.println("list " + queryList);
                return  null;
            }
			
		}catch(HibernateException e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}

	@Override
	public int getStateId() {
		int stateId = 0;
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Object maxStateIdID = session.createQuery("select max(stateId) FROM StateXml").uniqueResult();
			if(maxStateIdID != null && !maxStateIdID.equals(""))
				stateId = (Integer) maxStateIdID;
			txn.commit();
		}finally{
			session.close();
		}
		return stateId;
	}
}
