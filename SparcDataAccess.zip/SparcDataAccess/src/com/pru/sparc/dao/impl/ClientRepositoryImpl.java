package com.pru.sparc.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.pru.sparc.commons.HibernateConnector;
import com.pru.sparc.dao.ClientRepository;
import com.pru.sparc.model.ClientClass;
//import com.pru.sparc.commons.HibernateUtil_old;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.SIC;

//DAO layer implementation for Clients module
@Repository("clientRepository")
public class ClientRepositoryImpl implements ClientRepository {
	/**
	 * To add new client to database
	 * @param ClientClass
	 * @return ClientClass
	 */
	@Override
	public ClientClass addClient(ClientClass client){
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.save(client);
			txn.commit();
		} catch(Exception e){
			e.printStackTrace();
			client = null;
		} finally{
			session.close();
		}
		return client;
	}

	/**
	 * To search clients based on selected search criteria
	 * @param Map<String, String>
	 * @return List<ClientClass>
	 */
	@Override
	public List<ClientClass> searchClient(Map<String, String> clientSearchRequestMap) {
		
		/*Query query = session.createSQLQuery(
				"select * from stock s where s.stock_code = :stockCode")
				.addEntity(Stock.class)
				.setParameter("stockCode", "7277");
				List result = query.list();*/
		/*select distinct * from client  c join address a on c.client_id = a.client_id join proposal p on c.client_id = p.client_id  where 
			c.client_name = 'TEST' and 
			c.dba = 'sparc' and
			c.dbno = '48965' and
			c.sic_no = '0174' and
			a.city = 'ABC' and
			a.state = 'FL' and
			p.proposal_id = 201621011
*/		
				
		List<String> partialSearchFields = new ArrayList<String>();
		partialSearchFields.add("clientName");
		partialSearchFields.add("dba");
		partialSearchFields.add("city");
		partialSearchFields.add("proposalId");
		if(clientSearchRequestMap.containsKey("proposalId")){
			//return searchClientByProposalId(clientSearchRequestMap, partialSearchFields);
		}
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			StringBuffer sb = new StringBuffer();
			if(clientSearchRequestMap.containsKey("proposalId")){
				sb.append("select distinct * from client  c join address a on c.client_id = a.client_id join proposal p on c.client_id = p.client_id  where ");
			} else {
				sb.append("select distinct * from client  c join address a on c.client_id = a.client_id where ");
			}
			boolean firstFlag = true;
			if(clientSearchRequestMap.containsKey("clientName")){
				if(firstFlag){
					sb.append("c.client_name like('" + clientSearchRequestMap.get("clientName")+"%')");
				} else {
					sb.append(" and c.client_name like('" +clientSearchRequestMap.get("clientName")+"%')");
				}
				firstFlag = false;
			}
			if(clientSearchRequestMap.containsKey("dba")){
				if(firstFlag){
					sb.append("c.dba like('" + clientSearchRequestMap.get("dba")+"%')");
				} else {
					sb.append(" and c.dba like('" +clientSearchRequestMap.get("dba")+"%')");
				}
				firstFlag = false;
			}
			if(clientSearchRequestMap.containsKey("dAndB")){
				if(firstFlag){
					sb.append("c.dbno ='" + clientSearchRequestMap.get("dAndB")+"'");
				} else {
					sb.append(" and c.dbno ='" +clientSearchRequestMap.get("dAndB")+"'");
				}
				firstFlag = false;
			}
			if(clientSearchRequestMap.containsKey("sic")){
				if(firstFlag){
					sb.append("c.sic_no ='" + clientSearchRequestMap.get("sic")+"'");
				} else {
					sb.append(" and c.sic_no ='" +clientSearchRequestMap.get("sic")+"'");
				}
				firstFlag = false;
			}
			if(clientSearchRequestMap.containsKey("city")){
				if(firstFlag){
					sb.append("a.city like('" + clientSearchRequestMap.get("city")+"%')");
				} else {
					sb.append(" and a.city like('" +clientSearchRequestMap.get("city")+"%')");
				}
				firstFlag = false;
			}
			if(clientSearchRequestMap.containsKey("state")){
				if(firstFlag){
					sb.append("a.state ='" + clientSearchRequestMap.get("state")+"'");
				} else {
					sb.append(" and a.state ='" +clientSearchRequestMap.get("state")+"'");
				}
				firstFlag = false;
			}
			if(clientSearchRequestMap.containsKey("proposalId")){
				if(firstFlag){
					sb.append("p.proposal_id like('" + clientSearchRequestMap.get("proposalId")+"%')");
				} else {
					sb.append(" and p.proposal_id like('" +clientSearchRequestMap.get("proposalId")+"%')");
				}
				firstFlag = false;
			}
			
			SQLQuery query = session.createSQLQuery(sb.toString());
			query.addEntity(ClientClass.class);
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			/*sb.append("from ClientClass c where ");
			boolean firstFlag = true;
			while(iterator.hasNext()){
				@SuppressWarnings("rawtypes")
				Map.Entry pairs = (Map.Entry)iterator.next();
				if(firstFlag){
					if(partialSearchFields.contains(pairs.getKey())){
						sb.append("c."+pairs.getKey() + " like('" + pairs.getValue()+"%')");
					} else {
						sb.append("c."+pairs.getKey() + " = '" + pairs.getValue()+"'");
					}
					firstFlag = false;
				} else {
					if(partialSearchFields.contains(pairs.getKey())){
						sb.append(" and c."+pairs.getKey() + " like('" + pairs.getValue()+"%')");
					} else {
						sb.append(" and c."+pairs.getKey() + " = '" + pairs.getValue()+"'");
					}
				}
				
			}*/
			//Query query = session.createQuery(sb.toString());
			@SuppressWarnings("unchecked")
			List<ClientClass> resultList = (List<ClientClass>)query.list();
			//List<Object[]> rows = query.list();
			txn.commit();
			return resultList;
		} catch(Exception e){
			e.printStackTrace();
			return null;
		} finally{
			session.close();
		}
	}
	
	/**
	 * To generate client id for new client creation
	 * @param 
	 * @return int
	 */
	@Override
	public int getClientId(){
		int clientId = 0;
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Object maxClientID = session.createQuery("select max(clientId) from ClientClass").uniqueResult();
			if(maxClientID != null && !maxClientID.equals(""))
				clientId = (Integer) maxClientID;
			txn.commit();
		}finally{
			session.close();
		}
		return clientId;
	}

	/**
	 * To edit client details
	 * @param ClientClass
	 * @return ClientClass
	 */
	@Override
	public ClientClass updateClient(ClientClass requestObject) {
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			session.update(requestObject);
			txn.commit();
		}catch(HibernateException e){ 
			e.printStackTrace();
			requestObject = null;
		} finally{
			session.close();
		}
		return requestObject;
	}
	
	/**
	 * To fetch client by clientId
	 * @param int clientId
	 * @return ClientClass
	 */
	@Override
	public ClientClass getClientById(int clientId){
		Session session = null;
		ClientClass clientClass = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			clientClass = (ClientClass)session.createQuery("from ClientClass c where c.clientId = "+clientId).uniqueResult();
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return clientClass;
	}
	
	/**
	 * To fetch proposals associated with client
	 * @param int clientId
	 * @return List<ProposalDetails>
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ProposalDetails> getAllProposalsForClient(int clientId){
		Session session = null;
		List<ProposalDetails> proposalList = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Query query = session.createQuery("from ProposalDetails p where p.client.clientId = "+clientId);
			proposalList = (List<ProposalDetails>) query.list();
			/*ClientClass clientClass = getClientById(clientId);
			proposalList = new ArrayList<ProposalDetails>();
			proposalList.addAll(clientClass.getProposals());*/
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return proposalList;
	}
	
	/**
	 * To fetch client by proposal id
	 * @param partialSearchFields 
	 * @param Map<String, String>
	 * @return List<ClientClass>
	 */
	/*private static List<ClientClass> searchClientByProposalId(Map<String, String> searchRequestMap, List<String> partialSearchFields){
		Session session = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			StringBuffer sb = new StringBuffer();
			sb.append("from ProposalDetails p INNER JOIN p.client c where ");
			boolean firstFlag = true;
			@SuppressWarnings("rawtypes")
			Iterator iterator = searchRequestMap.entrySet().iterator();
			while(iterator.hasNext()){
				@SuppressWarnings("rawtypes")
				Map.Entry pairs = (Map.Entry)iterator.next();
				if(firstFlag){
					if(partialSearchFields.contains(pairs.getKey())){
						if(pairs.getKey().equals("proposalId")){
							sb.append("p."+pairs.getKey() + " like('" + pairs.getValue()+"%')");
						} else {
							sb.append("c."+pairs.getKey() + " like('" + pairs.getValue()+"%')");
						}
					} else {
						sb.append("c."+pairs.getKey() + " = '" + pairs.getValue()+"'");
					}
					
					firstFlag = false;
				} else {
					if(partialSearchFields.contains(pairs.getKey())){
						if(pairs.getKey().equals("proposalId")){
							sb.append(" and p."+pairs.getKey() + " like('" + pairs.getValue()+"%')");
						} else {
							sb.append(" and c."+pairs.getKey() + " like('" + pairs.getValue()+"%')");
						}
					} else {
						sb.append(" and c."+pairs.getKey() + " = '" + pairs.getValue()+"'");
					}
				}
			}
			Query query = session.createQuery(sb.toString());
			@SuppressWarnings("unchecked")
			List<Object> resultList = (List<Object>)query.list();
			List<ClientClass> clientList = new ArrayList<ClientClass>();
			for (Object result : resultList) {
				Object[] clients = (Object[])result;
				clientList.add((ClientClass) clients[1]);
			}
			txn.commit();
			return clientList;
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return null;
	}*/

	@SuppressWarnings("unchecked")
	@Override
	public List<SIC> getValidSICCodes() {
		Session session = null;
		List<SIC> sicList = null;
		try{
			session = HibernateConnector.getInstance().getSession();
			Transaction txn = session.beginTransaction();
			Query query = session.createQuery("from SIC");
			sicList = (List<SIC>)query.list();
			txn.commit();
		}catch(HibernateException e){
			e.printStackTrace();
		} finally{
			session.close();
		}
		return sicList;
	}
}
