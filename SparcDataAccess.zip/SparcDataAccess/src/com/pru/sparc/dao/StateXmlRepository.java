package com.pru.sparc.dao;
import java.util.List;

import com.pru.sparc.model.StateXml;
public interface StateXmlRepository {
	public StateXml addUpdateStates(StateXml stateXml);
	public StateXml getStates(StateXml stateXml);
	public int getStateId();
	public List<StateXml> getPrevStates(StateXml stateXml); 
}
