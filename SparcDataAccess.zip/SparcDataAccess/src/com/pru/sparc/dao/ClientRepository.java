package com.pru.sparc.dao;

import java.util.List;
import java.util.Map;

import com.pru.sparc.model.ClientClass;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.SIC;

public interface ClientRepository {

	public ClientClass addClient(ClientClass client);
	public ClientClass updateClient(ClientClass client);
	public int getClientId();
	public List<ClientClass> searchClient(Map<String, String> clientSearchRequestMap);
	public ClientClass getClientById(int clientId);
	public List<ProposalDetails> getAllProposalsForClient(int clientId);
	public List<SIC> getValidSICCodes();
}
