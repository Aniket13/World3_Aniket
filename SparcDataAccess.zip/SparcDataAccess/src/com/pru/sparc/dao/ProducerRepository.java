package com.pru.sparc.dao;

import java.util.List;

import com.pru.sparc.model.BrokerDetails;
import com.pru.sparc.model.ProposalBrokerDetails;

public interface ProducerRepository {
	public List<BrokerDetails> getProducers();

	public BrokerDetails getProducerById(int brokerID);

	public void saveProposalCommission(ProposalBrokerDetails proposalBroker);
}
