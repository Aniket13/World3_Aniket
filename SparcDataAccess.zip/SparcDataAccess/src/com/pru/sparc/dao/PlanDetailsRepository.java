package com.pru.sparc.dao;

import java.util.HashMap;
import java.util.List;

import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.PlanEligibilityClass;
import com.pru.sparc.model.PlanWrapper;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.QuotationDetails;

public interface PlanDetailsRepository {
	public PlanDetailsClass addPlanDetails(PlanDetailsClass planDetails);
	public PlanDetailsClass updatePlanDetails(PlanDetailsClass planDetails);
	public List<PlanDetailsClass> getAllPlansForVersion(int versionId, String proposalId, int productId);
	public PlanDetailsClass getOverriddenRecordForPlanId(int planId);
	public List<PlanDetailsClass> getPlanDetailsByProposalVersionProductId(
			int versionNumber, int productId);
	public void saveEligibilityClasses(
	List<PlanEligibilityClass> planEligibilityClasses);
	public List<PlanEligibilityClass> getEligibilityClasses(int planId);
	public void savePlanCommission(ProposalBrokerDetails proposalBroker);
	public ProposalBrokerDetails getCommissionDetails(String planId, int brokerId);
	public List<HashMap<String, Object>> getDataListByPlan(int versionId);
	public List<Integer> getClassIdsForPlan(int planId);
	public CensusClass getCensusClassById(int censusClassId);
	public int getCensusForPlan(int planID, int versionNumber);
	public List<CensusClass> getCensusClassesForPlan(int censusId);
	public int getNoOfLivesPerClass(int censusId, int censusClsId);
	List<HashMap<String, Object>> getCommissionDetailsForPlan(String planId);
	PlanWrapper saveAllPlanDetails(PlanWrapper planWrapper) throws Exception;
	PlanWrapper getAllPlanDetails(int planId, int brokerId) throws Exception;
	PlanDetailsClass getPlanDetails(int planId) throws Exception;
	QuotationDetails getVersionDetails(int versionNumber) throws Exception;
	ProductDetails getProductDetails (int productId) throws Exception;
	public String getPlanProposalId(int planId);
	int getPlanVersionId(int planId);
	public PlanDetailsClass fetchExistingPlanDetails(int planId);
	void updateEligibilityClasses(
			List<PlanEligibilityClass> planEligibilityClasses);
	void deleteEligibilityRecords(int planId);
	public int getCensusTotalLives(int selectedCensusId);
	
}
