package com.pru.sparc.dao;

import java.util.List;

import com.pru.sparc.model.LookupDetails;
import com.pru.sparc.model.PlanLookupDetails;

public interface MainRepository {

	List<LookupDetails> getLookupList(LookupDetails lookupDetails) throws Exception;

	List<PlanLookupDetails> getPlanLookupList()
			throws Exception;

	LookupDetails getPlanContractState(String stateCode) throws Exception;
	
}
