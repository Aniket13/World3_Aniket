package com.pru.sparc.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.QuotationDetails;
public interface QuotationDao {
	ProposalDetails getProposalDetails(Map<String, String> proposal);
	int getProposalVersionsCount(Map<String, String> searchRequestMap);
	QuotationDetails createNewQuotation(QuotationDetails quotationDetails);
	List<CensusDetail> getCensusList(int clientId);
	List<CensusDetail> getSelectedCensus(String string);
	QuotationDetails getQuotationDetails(String proposalId, int versionNumber);
	void saveQuotation(QuotationDetails quotationDetails);
	Set<QuotationDetails> getProposalVersions(Map<String, String> searchRequestMap);
	List<ProductDetails> getProductList();
	List<ProductDetails> getSelectedProducts(List<Integer> selectedQuoteProducts);
	ProposalBrokerDetails getCommission(int brokerID, String proposalPlanID, int versionNumber);
	ProposalBrokerDetails updateCommission(ProposalBrokerDetails proposalBrokerDetails);
	ProposalBrokerDetails saveCommission(ProposalBrokerDetails prBrokerDetails);
}
