package com.pru.sparc.dao;

import java.util.HashMap;
import java.util.List;

import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.CensusMemberDetails;

public interface CensusMemberDtlRepository {
	public void updateCensusMember(CensusMemberDetails censusMemberDetails) throws Exception;
	public List<CensusMemberDetails> getCensusMembers(int censusId);
	public CensusClass getCensusMemberClass(int censusId, int CensusClsId);
	public List<HashMap<String, Object>> getDataListByMember();
	List<HashMap<String, Object>> getCensusMembersForEachClass(List<Integer> classIdList);
	public HashMap<String, Object> getCensusDetails(int proposalVersionId);
	public List<HashMap<String, Object>> getStateDetails(int versionId);
}
