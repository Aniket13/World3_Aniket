package com.pru.sparc.dao;

import java.util.List;

import com.pru.sparc.model.PlanfieldsValues;

public interface PlanFieldsDroolsDao {

	public List<PlanfieldsValues> getPlanfieldsDetails(List fieldList);

}
