package com.pru.sparc.dao;

import java.util.List;

import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.RatingExhibits;


public interface RatingQuoteDAO {
	public RatingExhibits saveRatingEngineResults(RatingExhibits ratingExhibitsRequestObject);
	public RatingExhibits updateRatingEngineOverrides(RatingExhibits ratingExhibitsRequestObject);
	public RatingExhibits retrievePlanRatingEngineResults(int planId, int rateId);
	public String getVersionStatus(int versionNumber);
	public RatingExhibits getPlanRatingDetails(Integer planId,String isOverride);
	public int deleteRatingResults(RatingExhibits ratingEntity);
	public List<RatingExhibits> getAllPlanRatingEngineResults(int planId);
	ProposalDetails getProposalDetails(String proposalId);
	public void updateVersionStatus(int versionNumber,String versionStatus);
}
