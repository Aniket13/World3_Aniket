package com.pru.sparc.dao;


import java.util.List;

import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.CensusLvsAlloc;


public interface CensusDetailRepository {
	
	public CensusDetail update(CensusDetail census);
	public CensusDetail getCensusDetailById(int censusid);
	public List<CensusDetail>  getCensusDetail(int clientId);
	
	public List<CensusClass> addCensusClasses(List<CensusClass> censusCls);
	public List<CensusClass> getCensusClasses(CensusClass censusCls);
	
	public void addCensusLiveAlloc(List<CensusLvsAlloc> censusLvcAloc);
	public List<CensusLvsAlloc> getCensusLiveAlloc(String censusId);
	public void deleteCensusLiveAlloc(CensusLvsAlloc cenAlloc);
	public CensusLvsAlloc getCensusLiveAllocByCensusState(String cenState,
			int censusId);
}
