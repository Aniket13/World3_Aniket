package com.pru.sparc.dao;

import java.util.HashMap;
import java.util.List;

import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.SalesOffice;

public interface ProposalRepository {
	public String createPropId();
	public ProposalDetails getHeaderDetails(String proposalId, int clientId);
	public ProposalDetails getProposalDetails(String proposalId);
	public List<SalesOffice> getSalesOffice();
	ProposalDetails createNewProposal(ProposalDetails proposalDetails);
	public SalesOffice getSalesOfficeByName(String salesOffVal);
	public void updateProposal(ProposalDetails proposalDetails);
	public List<HashMap<String, Object>> getDataListByHoldingSic(int versionId);
	public List<HashMap<String, Object>> getDataListByHolding(int versionId);
	public List<HashMap<String, Object>> getDataListByHoldingLives(int versionId);
}
