package com.pru.sparc.common.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;

public class DroolsPropertyRead {

	private Properties prop = null;
	
	public DroolsPropertyRead(){}
	
	public DroolsPropertyRead(String fileName) {
		//Enumeration enuKeys;
		try {
			this.prop = new Properties();
			InputStream in = getClass().getResourceAsStream(
					"/com/pru/sparc/resources/"+fileName);
			
			prop.load(in);
			in.close();
			/*enuKeys = prop.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = prop.getProperty(key);
				System.out.println(key + ": " + value);
			}*/
		
		}catch (FileNotFoundException e) {
			e.printStackTrace(); 
			} 
		catch (IOException io) {
			io.printStackTrace();
		}
	}

	public Set<Object> getAllKeys() {
		Set<Object> keys = prop.keySet();
		return keys;
	}

	public String getPropertyValue(String key) {
		return this.prop.getProperty(key);
	}
	
	/*public static void main(String args[]){
		PropertyRead PropertyRead = new PropertyRead();
		PropertyRead.getPropVal();
	}*/
}
