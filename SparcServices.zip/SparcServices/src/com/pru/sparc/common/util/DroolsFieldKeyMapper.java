package com.pru.sparc.common.util;

import java.util.HashMap;

public class DroolsFieldKeyMapper {
	public HashMap<String,String>  keyDescMap(){
		HashMap<String,String> hm = new HashMap<String,String>();
		DroolsPropertyRead  PropertyRead = new DroolsPropertyRead("Planfields.properties");
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.planeffdtkey"),PropertyRead.getPropertyValue("label.sparc.plan.planeffdt"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.plandeskey"),PropertyRead.getPropertyValue("label.sparc.plan.plandes"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.typcasekey"),PropertyRead.getPropertyValue("label.sparc.plan.typcase"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.pruvalexckey"),PropertyRead.getPropertyValue("label.sparc.plan.pruvalexc"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.fldlvlexckey"),PropertyRead.getPropertyValue("label.sparc.plan.fldlvlexc"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.contrarrngkey"),PropertyRead.getPropertyValue("label.sparc.plan.contrarrng"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.minpartperckey"),PropertyRead.getPropertyValue("label.sparc.plan.minpartperc"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.volcavperckey"),PropertyRead.getPropertyValue("label.sparc.plan.volcavperc"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.comratkey"),PropertyRead.getPropertyValue("label.sparc.plan.comrat"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.ageratkey"),PropertyRead.getPropertyValue("label.sparc.plan.agerat"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.ratgurkey"),PropertyRead.getPropertyValue("label.sparc.plan.ratgur"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.ratexpkey"),PropertyRead.getPropertyValue("label.sparc.plan.ratexp"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.amtinskey"),PropertyRead.getPropertyValue("label.sparc.plan.amtins"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.maxdolamtkey"),PropertyRead.getPropertyValue("label.sparc.plan.maxdolamt"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.mindolamtkey"),PropertyRead.getPropertyValue("label.sparc.plan.mindolamt"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.mulannearkey"),PropertyRead.getPropertyValue("label.sparc.plan.mulannear"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.rondrulkey"),PropertyRead.getPropertyValue("label.sparc.plan.rondrul"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.agededschkey"),PropertyRead.getPropertyValue("label.sparc.plan.agededsch"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.disrpokey"),PropertyRead.getPropertyValue("label.sparc.plan.disrpo"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.durationkey"),PropertyRead.getPropertyValue("label.sparc.plan.duration"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.volamtkey"),PropertyRead.getPropertyValue("label.sparc.plan.volamt"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.gurisslmtkey"),PropertyRead.getPropertyValue("label.sparc.plan.gurisslmt"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.dolamtkey"),PropertyRead.getPropertyValue("label.sparc.plan.dolamt"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.livbenoptkey"),PropertyRead.getPropertyValue("label.sparc.plan.livbenopt"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.lbomaxkey"),PropertyRead.getPropertyValue("label.sparc.plan.lbomax"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.lboperckey"),PropertyRead.getPropertyValue("label.sparc.plan.lboperc"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.lboexpckey"),PropertyRead.getPropertyValue("label.sparc.plan.lboexpc"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.covterretkey"),PropertyRead.getPropertyValue("label.sparc.plan.covterret"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.ttrvlasskey"),PropertyRead.getPropertyValue("label.sparc.plan.ttrvlass"));
	    hm.put(PropertyRead.getPropertyValue("label.sparc.plan.eardefkey"),PropertyRead.getPropertyValue("label.sparc.plan.eardef"));
	    
	    return hm;
	}

	public String getKeyDescription(String key){
		HashMap<String,String> hm = new HashMap<String,String>();
		hm= keyDescMap();
		String keyVal= hm.get(key);
		return keyVal;
	}
	public static void main(String a[]){ 
		DroolsFieldKeyMapper mpc = new DroolsFieldKeyMapper(); 
		DroolsPropertyRead  PropertyRead = new DroolsPropertyRead();
		System.out.println("****label.sparc.plan.planeffdtkey : "+mpc.getKeyDescription(PropertyRead.getPropertyValue("label.sparc.plan.planeffdtkey")));
		} 
	}

