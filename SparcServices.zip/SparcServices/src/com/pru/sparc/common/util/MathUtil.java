package com.pru.sparc.common.util;
import org.mariuszgromada.math.mxparser.Argument;
import org.mariuszgromada.math.mxparser.Expression;

public class MathUtil {
	
	public static double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		long factor = (long) Math.pow(10, places);
		value = value * factor;
		long tmp = Math.round(value);
		return (double) tmp / factor;
	}

	public static double roundup(double value) {

		return (Math.ceil(value));
	}

	public static double roundDown(double value) {

		double d = Math.round((value * 100)) / 100;

		return (d);
	}

	public static double roundDown1(double value) {

		// double d = Math.round( (value * 100) )/100

		return (Math.floor(value));
	}

	public static double roundNearest(double value, int multipleOf) {

		double d = multipleOf * ((Math.round(value)) / (5));

		return (d);
	}

	public static double roundNearestHalf(double d) {
		return Math.round(d * 2) / 2.0;
	}

	// can use for both nearest half and quarter both
	public static double roundNearestQuarter(double d) {
		// double d1 = Math.add(2,5);
		return Math.round(d * 4) / 4.0;
	}
	
	public static double calculate(double d, double d1, String action) {

		Argument x = new Argument("x", d);
		Argument y = new Argument("y", d1);
		Expression e = null;
		
		e = new Expression("(((x*y)*x*(x-y)*(x+y)+(x^y))/(x*y))",x,y);
		

/*		switch (action) {

		case "addition":
			e = new Expression("x+y", x, y);
			break;

		case "subtraction":
			e = new Expression("x-y", x, y);
			break;

		case "times":
			e = new Expression("x^y", x, y);
			break;

		case "divide":
			e = new Expression("x/y", x, y);
			break;

		case "multiply":
			e = new Expression("x*y", x, y);
			break;

		case "complex":
			e = new Expression("(((x*y)*x*(x-y)*(x+y)+(x^y))/(x*y))",x,y);
			break;

		}*/

		// double dResults
		return e.calculate();
	}
	

	 public static int increase(int x, int y, boolean z)

	 {

	   double percentage;

	   double price;

	    

	   if (z=true)

	    {

	      percentage = y /100;

	      price = x * (1 + percentage);

	      price = Math.round(price);

	      return (int) price;

	    }

	    else 

	    {

	      percentage = y /100;

	      price = x * (1 - percentage);

	      price = Math.round(price);
	      return (int)price;

	    }

	  }

}
