package com.pru.sparc.common.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ibm.websphere.cache.DistributedMap;

public class PlanConfigDynaCacheUtil {
	private static DistributedMap cache;

	static {

		InitialContext ic;
		try {
			ic = new InitialContext();
			cache = (DistributedMap) ic.lookup("jndi/planConfigDynaCache");
		} catch (NamingException e) {
			e.printStackTrace();
		}

	}

	public Object getValue(Object key) {

		return (cache.get(key));

	}

	public void putValue(Object key, Object value) {

		cache.put(key, value);

	}

}
