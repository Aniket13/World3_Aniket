package com.pru.sparc.common.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;

public class RatingDisPropertyRead {
private Properties prop = null;
	
	//public RatingDisPropertyRead(){}
	public RatingDisPropertyRead() {
		//Enumeration enuKeys;
		try {
			this.prop = new Properties();
			InputStream in = getClass().getResourceAsStream(
					"/com/pru/sparc/resources/"+SparcConstants.RATING_PROP_FILENM);
			
			prop.load(in);
			in.close();
			/*enuKeys = prop.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = prop.getProperty(key);
				System.out.println(key + ": " + value);
			}*/
		
		}catch (FileNotFoundException e) {
			e.printStackTrace(); 
			} 
		catch (IOException io) {
			io.printStackTrace();
		}
	}

	public Set<Object> getAllKeys() {
		Set<Object> keys = prop.keySet();
		return keys;
	}

	public List<String> getAllKeyValues() {
		//Set<Object> keys = prop.keySet();
		Set<Object> keys = prop.keySet();
		List<String> list = Arrays.asList(keys.toArray( new String[0]));
		List<String> listKey = new ArrayList<String>();
		for(String str: list){
			listKey.add(prop.getProperty(str));
		}
		return listKey;
	}
	
	public List<String> getAllPersistKey() {
		//Set<Object> keys = prop.keySet();
		Set<Object> keys = prop.keySet();
		List<String> list = Arrays.asList(keys.toArray( new String[0]));
		List<String> listKey = new ArrayList<String>();
		for(String str: list){
			if(str.startsWith("persist.sparc.rating.key.")){
			listKey.add(prop.getProperty(str));
			}
		}
		return listKey;
	}
	
	public String getPropertyValue(String key) {
		return this.prop.getProperty(key);
	}
	
	
	public HashMap<String,String>  getKeyDescMap(){
		HashMap<String,String> hm = new HashMap<String,String>();
		RatingDisPropertyRead propertyRead = new RatingDisPropertyRead();
		hm.put(propertyRead.getPropertyValue("persist.sparc.rating.key.regorigrate"),propertyRead.getPropertyValue("label.sparc.rating.regorigrate"));
	    hm.put(propertyRead.getPropertyValue("persist.sparc.rating.key.regdesrate"),propertyRead.getPropertyValue("label.sparc.rating.regdesrate"));
	    hm.put(propertyRead.getPropertyValue("persist.sparc.rating.key.advorigrate"),propertyRead.getPropertyValue("label.sparc.rating.advorigrate"));
	    hm.put(propertyRead.getPropertyValue("persist.sparc.rating.key.advdesrate"),propertyRead.getPropertyValue("label.sparc.rating.advdesrate"));
	    hm.put(propertyRead.getPropertyValue("persist.sparc.rating.key.finundorigrate"),propertyRead.getPropertyValue("label.sparc.rating.finundorigrate"));
	    return hm;
	}
	
	/*public HashMap<String,String>  getAllKeys(){
		HashMap<String,String> hm = new HashMap<String,String>();
		RatingDisPropertyRead propertyRead = new RatingDisPropertyRead("RatingDisplay.properties");
		hm.put(propertyRead.getPropertyValue("label.sparc.rating.regorigratekey"),propertyRead.getPropertyValue("label.sparc.rating.regorigrate"));
	    hm.put(propertyRead.getPropertyValue("label.sparc.rating.regdesratekey"),propertyRead.getPropertyValue("label.sparc.rating.regdesrate"));
	    hm.put(propertyRead.getPropertyValue("label.sparc.rating.advorigratekey"),propertyRead.getPropertyValue("label.sparc.rating.advorigrate"));
	    hm.put(propertyRead.getPropertyValue("label.sparc.rating.advdesratekey"),propertyRead.getPropertyValue("label.sparc.rating.advdesrate"));
	    hm.put(propertyRead.getPropertyValue("label.sparc.rating.finundorigratekey"),propertyRead.getPropertyValue("label.sparc.rating.finundorigrate"));
	    return hm;
	}*/
	
	public String getKeyDescription(String key){
		HashMap<String,String> hm = new HashMap<String,String>();
		hm= getKeyDescMap();
		String keyVal= hm.get(key);
		return keyVal;
	}
	
	public static void main(String[] args) {
		RatingDisPropertyRead dis=new RatingDisPropertyRead();
		System.out.println(dis.getAllKeyValues());
		System.out.println("*****************"+ dis.getAllPersistKey());
		System.out.println("*****key***"+ dis.getKeyDescription("finUndOrigRate"));
		
	}
}
