package com.pru.sparc.common.util;

public class StringUtil {
	
	/**
	 * Converts null to empty string. If not null, it trims the string
	 * 
	 * @param str  - a string to check for null.
	 * @return string or dbl quotes if null.
	 */
	public static String convNull(final String str) {

		if (str == null) {
			return "";
		}
		return str.trim();
	}
	
	
	    /**
     * pad spaces on the total length.
     * @param str the string to pad.
     * @param len - total length.
     * @return a right padded string.
     */
	public static String makeRightAdjusted(final String str, final int len) {
		String val = str;
		if (str == null) {
			val = "";

		}
		final int strLen = val.length();
		if (strLen == len) {
			return val;
		} else if (strLen > len) {
			return val.substring(0, len);
		} else {
			final int appendLen = len - strLen;
			//val = paddingChar(val, ' ', appendLen, 0);
			return val;
		}
	}
	
	
	 
	  /**
     * shorten a string to the max length.
     * @param maxLen the max length to return.
     * @param str the string to trim.
     * @return the shortened string.
     */
	public static String shortenString(final int maxLen, final String str) {
		if (str.length() > maxLen) {
			return str.substring(0, maxLen);
		} else {
			return str;
		}
	}	
	
	
	/**
     * shortle and camel case a string.
     * @param len the total length.
     * @param name the string to work on.
     * @return the string to return.
     */
	public static String shortNameForDisplay(final int len, final String name) {
		String val = shortenString(len, name);
		//val = camelCaseString(val);
		return val;
	}
	
	/**
	 * 
	 * @param data
	 * @return
	 */
	public static int stringToInt(final String data) {
		int i = 0;
		try {
			i = Integer.parseInt(data);
		} catch (NumberFormatException n) {
			// ignore 
		}
		return i;
	}
}


