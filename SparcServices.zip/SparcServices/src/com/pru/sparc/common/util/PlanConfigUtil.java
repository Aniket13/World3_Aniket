package com.pru.sparc.common.util;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;

/*Utility for alt values*/

public class PlanConfigUtil {

	public static String getFirstVisibleKeyFromDropDown(PlanDetailsMap plan, String compId){
		String lookupKey = null;
		int leastOrder = Integer.MAX_VALUE;
		if (null != plan) {
			if(null != plan.get(compId)){
				Map<String,PlanConfigLookup> mapAltVal = plan.get(compId).getAltValues();
				for (Map.Entry<String, PlanConfigLookup> entry : mapAltVal.entrySet())
				{
					if("Yes".equals(entry.getValue().getVisibleFlag())
							&& leastOrder > entry.getValue().getLookupOrder()){
						leastOrder = entry.getValue().getLookupOrder();
						lookupKey = entry.getValue().getLookupKey();
					}
				}
			}
		}
		return lookupKey;
	}

public static void include(PlanDetailsMap plan, String compId,
		String fieldKey) {

	if (null != plan) {
		if (null != fieldKey
				&& plan.get(compId).getAltValues().get(fieldKey)
				.getLookupKey().equalsIgnoreCase(fieldKey)) {
			plan.get(compId).getAltValues().get(fieldKey)
			.setVisibleFlag("Yes");
			plan.get(compId).setFieldIndicator("C");
		} else {
			System.out
			.println("include:Alternate Values fieldKey is null..!"
					+ fieldKey);
		}
	} else {
		System.out.println("includeAltValuesFlag:Plan Object is null..!");
	}

}

public static void exclude(PlanDetailsMap plan, String compId,
		String fieldKey) {

	if (null != plan) {
		if (null != fieldKey
				&& plan.get(compId).getAltValues().get(fieldKey)
				.getLookupKey().equalsIgnoreCase(fieldKey)) {
			plan.get(compId).getAltValues().get(fieldKey)
			.setVisibleFlag("No");
			plan.get(compId).setFieldIndicator("C");
		} else {
			System.out
			.println("exclude:Alternate Values fieldKey is null..!"
					+ fieldKey);
		}
	} else {
		System.out.println("excludeAltValuesFlag:Plan Object is null..!");
	}

}

public static float minValue(float value1, float value2) {

	int diff1 = Float.compare(value1, value2);
	int diff2 = Float.compare(value2, value1);
	float returnVal = 0.0f;
	if (diff1 < 0) {
		returnVal = value1;
	} else if (diff2 < 0) {
		returnVal = value2;
	}

	return returnVal;
}



public static float maxValue(float value1, float value2) {

	int diff1 = Float.compare(value1, value2);
	int diff2 = Float.compare(value2, value1);
	float returnVal = 0.0f;
	if (diff1 > 0) {
		returnVal = value1;
	} else if (diff2 > 0) {
		returnVal = value2;
	}

	return returnVal;
}

public static void assignMinValue(PlanDetailsMap plan, String compId,
		String fieldKey,float value1, float value2) {

	float returnVal = minValue(value1,value2);
	if (null != plan) {
		if (null != fieldKey
				&& plan.get(compId).getAltValues().get(fieldKey)
				.getLookupKey().equalsIgnoreCase(fieldKey)) {
			plan.get(compId).setFieldValue(String.valueOf(returnVal));
			plan.get(compId).setFieldIndicator("C");
		} else {
			System.out
			.println("minValue:compId is null..!"
					+ compId+","+returnVal);
		}
	} else {
		System.out.println("minValue:Plan Object is null..!");
	}
}
public static void assignMaxValue(PlanDetailsMap plan, String compId,
		String fieldKey,float value1, float value2) {

	float returnVal = maxValue(value1,value2);
	if (null != plan) {
		if (null != fieldKey
				&& plan.get(compId).getAltValues().get(fieldKey)
				.getLookupKey().equalsIgnoreCase(fieldKey)) {
			plan.get(compId).setFieldValue(String.valueOf(returnVal));
			plan.get(compId).setFieldIndicator("C");
		} else {
			System.out
			.println("minValue:compId is null..!"
					+ compId+","+returnVal);
		}
	} else {
		System.out.println("assignMaxValue:Plan Object is null..!");
	}
}

	public static Map<String, PlanMetadata> setOverriddenFlagToY(Map<String, PlanMetadata> planFieldMap){
		for (Entry<String, PlanMetadata> entry : planFieldMap.entrySet()) {
			PlanMetadata metadata = entry.getValue();
			if(metadata.getOverriddenFlag() == null){
				metadata.setOverriddenFlag("N");
			}
			if(StringUtils.equalsIgnoreCase(metadata.getTabId(), "4") && StringUtils.equalsIgnoreCase(metadata.getOverriddenFlag(), "Y")) {
				if (planFieldMap.get(metadata.getOriginalField()) != null) {
					planFieldMap.get(metadata.getOriginalField()).setOverriddenFlag("Y");
				}
			}
		}
		return planFieldMap;
	}

	public static Map<String, PlanMetadata> transferExceptionValue(Map<String, PlanMetadata> planFieldMap) {
		for (Entry<String, PlanMetadata> entry : planFieldMap.entrySet()) {
			PlanMetadata metadata = entry.getValue();
			if(StringUtils.equalsIgnoreCase(metadata.getTabId(), "4") && StringUtils.equalsIgnoreCase(metadata.getOverriddenFlag(), "Y")) {
				if (planFieldMap.get(metadata.getOriginalField()) != null) {
					planFieldMap.get(metadata.getOriginalField()).setOverriddenFlag("Y");
					planFieldMap.get(metadata.getOriginalField()).setFieldValue(metadata.getFieldValue());	
				}
			}
		}
		return planFieldMap;
	}
	
	public static Map<String, PlanMetadata> transferOriginalValue(Map<String, PlanMetadata> planFieldMap) {
		for (Entry<String, PlanMetadata> entry : planFieldMap.entrySet()) {
			PlanMetadata metadata = entry.getValue();
			if(StringUtils.equalsIgnoreCase(metadata.getTabId(), "1") && StringUtils.equalsIgnoreCase(metadata.getFieldIndicator(), "C")) {
				
				if (planFieldMap.get(metadata.getOverriddenField()) != null &&
						StringUtils.equalsIgnoreCase(planFieldMap.get(metadata.getOverriddenField()).getFieldKey(),
								PlanConfigConstants.AMOUNTS__OF_INSURANCE_EXCEPTION)) {
					
					//planFieldMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue(null);
					planFieldMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setOverriddenFlag("N");
					
					//planFieldMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue(null);
					planFieldMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setOverriddenFlag("N");
					
					//planFieldMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue(null);
					planFieldMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setOverriddenFlag("N");
					
					//planFieldMap.get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).setFieldValue(null);
					planFieldMap.get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).setOverriddenFlag("N");

				}
				
				
				if (planFieldMap.get(metadata.getOverriddenField()) != null) {
					//metadata.setOverriddenFlag("N");
					//planFieldMap.get(metadata.getOverriddenField()).setOverriddenFlag("N");
					planFieldMap.get(metadata.getOverriddenField()).setFieldValue(metadata.getFieldValue());	
				}
			}
		}
		return planFieldMap;
	}
	
}
