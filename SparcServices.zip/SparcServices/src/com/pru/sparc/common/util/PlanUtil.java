package com.pru.sparc.common.util;

import com.pru.sparc.bo.model.PlanDetailsMap;

/*Utility for component id*/

public class PlanUtil {

	public static void include(PlanDetailsMap plan, String compId) {

		if (null != plan) {
			if (plan.contains(compId)) {
				plan.get(compId).setVisibleFlag("Yes");
				plan.get(compId).setFieldIndicator("A");
			} else {
				System.out.println("compId is null");
			}
		} else {
			System.out.println("include:Plan Object is null..!");
		}

	}

	public static void exclude(PlanDetailsMap plan, String compId) {

		if (null != plan) {
			if (plan.contains(compId)) {
				plan.get(compId).setVisibleFlag("No");
				plan.get(compId).setFieldIndicator("R");
			} else {
				System.out.println("compId is null");
			}
		} else {
			System.out.println("include:Plan Object is null..!");
		}

	}

	public static float minValue(float value1, float value2) {

		int diff1 = Float.compare(value1, value2);
		int diff2 = Float.compare(value2, value1);
		float returnVal = 0.0f;
		if (diff1 < 0) {
			returnVal = value1;
		} else if (diff2 < 0) {
			returnVal = value2;
		} else {
			returnVal = value1;
		}
		return returnVal;
	}

	public static float maxValue(float value1, float value2) {

		int diff1 = Float.compare(value1, value2);
		int diff2 = Float.compare(value2, value1);
		float returnVal = 0.0f;
		if (diff1 > 0) {
			returnVal = value1;
		} else if (diff2 > 0) {
			returnVal = value2;
		} else {
			returnVal = value1;
		}
		return returnVal;
	}

	public static void assignMinValue(PlanDetailsMap plan, String compId,
			float value1, float value2) {

		float returnVal = minValue(value1, value2);
		if (null != plan) {
			if (null != compId && plan.contains(compId)) {
				plan.get(compId).setFieldValue(String.valueOf(returnVal));
				//plan.get(compId).setVisibleFlag("Yes");
				if(plan.get(compId).getFieldIndicator()==null || plan.get(compId).getFieldIndicator()==""){
					plan.get(compId).setFieldIndicator("C");
				}
			} else {
				System.out.println("minValue:compId is null..!" + compId + ","
						+ returnVal);
			}
		} else {
			System.out.println("minValue:Plan Object is null..!");
		}
	}

	public static void assignMaxValue(PlanDetailsMap plan, String compId,
			float value1, float value2) {

		float returnVal = maxValue(value1, value2);
		if (null != plan) {
			if (null != compId && plan.contains(compId)) {
				plan.get(compId).setFieldValue(String.valueOf(returnVal));
				//plan.get(compId).setVisibleFlag("Yes");
				if(plan.get(compId).getFieldIndicator()==null || plan.get(compId).getFieldIndicator()==""){
					plan.get(compId).setFieldIndicator("C");
				}
			} else {
				System.out.println("minValue:compId is null..!" + compId + ","
						+ returnVal);
			}
		} else {
			System.out.println("assignMaxValue:Plan Object is null..!");
		}
	}

	public static void assignMinMaxValue(PlanDetailsMap plan, String compId,
			int val1, int val2) {

		if (null != plan) {
			if (null != compId && plan.contains(compId)) {
				float value1 = (float) val1;
				float value2 = (float) val2;
				float compVal = Float.parseFloat(plan.get(compId)
						.getFieldValue());
				float returnMaxVal = maxValue(compVal, value2);
				float returnMinVal = minValue(value1, returnMaxVal);
				plan.get(compId).setFieldValue(String.valueOf(returnMinVal));
				//plan.get(compId).setVisibleFlag("Yes");
				if(plan.get(compId).getFieldIndicator()==null || plan.get(compId).getFieldIndicator()==""){
					plan.get(compId).setFieldIndicator("C");
				}
			} else {
				System.out.println("assignMinMaxValue:compId is null..!"
						+ compId);
			}
		} else {
			System.out.println("assignMinMaxValue:Plan Object is null..!");
		}
	}

	public static float roundValue(float val1, float val2, float val3) {
		float value1 = val1;
		float value2 = val2;
		float value3 = val3;
		float finalValue = value1 * Math.round((value2 / value3));
		//float finalValue = Math.round((value2 / value3));
		System.out.println(finalValue);
		return finalValue;
	}

	public static void setCompFieldVal(PlanDetailsMap plan, String compId, String fieldVal){
		if(null!= plan) {
			if(plan.contains(compId)){
				//plan.get(compId).setVisibleFlag("Yes");
				plan.get(compId).setFieldValue(fieldVal);
				if(plan.get(compId).getFieldIndicator()==null || plan.get(compId).getFieldIndicator()==""){
					plan.get(compId).setFieldIndicator("C");
				}
			}
			else{
				System.out.println("compId is null");
			}
		}
		else{
			System.out.println("include:Plan Object is null..!");
		}
	}
	
	public static void setCompOnChange(PlanDetailsMap plan, String compId, String onChg){
		if(null!= plan) {
			if(plan.contains(compId)){
				//plan.get(compId).setVisibleFlag("Yes");
				plan.get(compId).setOnChange(onChg);
				if(plan.get(compId).getFieldIndicator()==null || plan.get(compId).getFieldIndicator()==""){
					plan.get(compId).setFieldIndicator("C");
				}
			}
			else{
				System.out.println("compId is null");
			}
		}
		else{
			System.out.println("setCompOnChange Object is null..!");
		}
	}
	
	public static void setCompOnBlur(PlanDetailsMap plan, String compId, String onBlur){
		if(null!= plan) {
			if(plan.contains(compId)){
				//plan.get(compId).setVisibleFlag("Yes");
				plan.get(compId).setOnBlur(onBlur);
				if(plan.get(compId).getFieldIndicator()==null || plan.get(compId).getFieldIndicator()==""){
					plan.get(compId).setFieldIndicator("C");
				}
			}
			else{
				System.out.println("compId is null");
			}
		}
		else{
			System.out.println("setCompOnBlur Object is null..!");
		}
	}

}
