package com.pru.sparc.common.util;

public class PlanConfigConstants {

	// list of fields on plan screen
	public final static String CONT_STATE = "contract_State";
	public final static String PLANEFFDT = "effective_Date";
	public final static String PLAN_DESC = "plan_Description";
	public final static String TYP_OF_CASE = "Type_OF_Case";
	public final static String PRU_VAL_EXCP = "pru_Value_Exceptions";
	public final static String FIELD_LVL_EXCP = "Field_Level_Exceptions";
	public final static String CONTRI_ARRANG = "Contribution_Arrangement";
	public final static String MIN_PARTCI_PERCEN = "Plan_Contribution_Attributes__Minimum_Participation_Percentage";
	public final static String VOLA_CAVEAT_REATING = "Plan_Contribution_Attributes__Volatility_Caveat_Percentage";
	public final static String COMP_RATING = "Composite_Rating";
	public final static String AGE_BANDED_RATING = "Age_Banded_Rating";// This
																		// has
																		// been
																		// updated
																		// as
																		// per
																		// component
																		// ID in
																		// XMl
																		// file
	public final static String PLAN_ID = "planId";
	public final static String PRODUCT_CD = "prodCode";
	public final static String OVERRIDE_IND = "overrideInd";
	public final static String RATE_GRTY = "Rate_Guarantee_Attributes";
	public final static String RATE_EXPR = "Rate_Expression";//
	public final static String AMT_INSU = "Amounts_of_Insurance"; // This has
																	// been
																	// updated
																	// as per
																	// component
																	// ID in XMl
																	// file
	public final static String MAX_DOLLAR_AMT = "Incremental_Flat_Dollar_Amounts_Attributes__Maximum_Dollar_Amount";
	public final static String MIN_DOLLAR_AMT = "Incremental_Flat_Dollar_Amounts_Attributes__Minimum_Dollar_Amount";
	public final static String MULTI_OF_EARN = "Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings";
	public final static String ROUNDING_RULE = "Rounding_Rule"; // Rounding Rule
	public final static String ROUNDING_OCCUR = "Rounding_Occurs"; // Rounding_Occurs
	public final static String QUALIFYING_AGE = "Qualifying_Age"; // Rounding_Occurs
	public final static String AGE_RED_SCH = "Age_Reduction_Schedule";
	public final static String DIASBLE_PROV = "Disability_Provision";
	public final static String DURATION = "Duration";
	public final static String VOL_AMT = "Volume_Amounts";
	public final static String GURANTEE_ISS_LMT = "Guarantee_Issue_Limit";
	public final static String GUARANTEE_ISSUE = "Guarantee_Issue";
	public final static String DOLLAR_AMT = "Guarantee_Issue_Limit_Attributes__Dollar_Amount";
	public final static String LIV_BEN_OPN = "Living_Benefit_Option";
	public final static String LBO_MAX = "Living_Benefit_Option_Attributes__LBO_Maximum";
	public final static String LBO_PCT = "Living_Benefit_Option_Attributes__LBO_Percentage";
	public final static String LBO_LIFE_EXPT = "LBO_Life_Expectancy";
	public final static String COV_TERMI_RETI = "Coverage_Terminates_at_Retirement";
	public final static String TRAVEL_ASSISTANCE = "Travel_Assistance";
	public final static String RETENTION_BASIS = "Retention_Basis";
	public final static String MEDICAL_UNDERWRITING = "Medical_Underwriting";
	
	public final static String TRAVEL_ASSISTANCE_EXCEPTION = "Travel_Assistance_Exception";
	public final static String EARNING_DEF = "Earnings_Definition";
	public final static String INCLUDE_BONUSES = "Include_Bonuses_in_Earnings_Definition";
	public final static String INCLUDE_COMMISSION = "Include_Commissions_in_Earnings_Definition";
	public final static String INCLUDE_OVERTIME = "Include_Overtime_in_Earnings_Definition";
	public final static String PLAN_CREATION_DATE = "plan_Creation_Date";
	public final static String EMPLOYEE_CONTRIBUTION_TYPE = "Employee_Contribution_Type";
	public final static String CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE = "Current_Selected_Contract_State_Attribute";
	public final static String ROUNDING_RULE_ATTRIBUTES = "Rounding_Rule_Attributes";
	public final static String DURATION_ATTRIBUTES = "Duration_Attributes";
	public final static String LIVING_BENEFIT_OPTION_ATTR = "Living_Benefit_Option_Attributes";
	public final static String GUARANTEE_ISSUE_LIMIT_ATTR = "Guarantee_Issue_Limit_Attributes";
	public final static String PRU_VALUE_ATTR ="Type_OF_Case";// "PruValue_Attribute";
	public final static String PRU_VALUE_PARTS_ATTR ="Type_OF_Case"; //"PruValueParts_Attribute";
	public final static String AMOUNTS_OF_INSURANCE = "Amounts_of_Insurance";
	public final static String AGE_REDUCTION_SCHEDULE_ATTRIBUTES = "Age_Reduction_Schedule_Attributes";
	public final static String DISABILITY_PROVISION_PREMIUM_CONTNUANCE_DETAILS_ATTRIBUTES = "Disability_Provision_Premium_Contnuance_Details_Attributes";
	public final static String DURATION_EXCEPTION_ATTRIBUTES = "Duration__Exception_Attributes";
	public final static String GURARNTEE_ISSUE_LIMIT = "Guarantee_Issue_Limit";
	public final static String LBO_LIFE_EXPECTANCY_ATTRIBUTES = "LBO_Life_Expectancy_Attributes";
	public final static String LBO_LIFE_EXPECTANCY = "LBO_Life_Expectancy";
	public final static String BURIAL_EXPENSE_PAYMENT = "Burial_Expense_Payment";
	public final static String RATE_GUARANTEE_ATTRIBUTES__RATE_GUARANTEE = "Rate_Guarantee_Attributes__Rate_Guarantee_in_years";
	public final static String CONTRIBUTION__ARRANGEMENT_EXCEPTION = "Contribution__Arrangement_Exception";
	
	public final static String BENEFICIARY_FINANCIAL_COUNSELING_SERVICES = "Beneficiary_Financial_Counseling_Services";
	public final static String EMPLOYEE_WAITING_PERIOD_OPTIONS = "Employee_Waiting_Period_Options";
	public final static String EXISTING_EARNINGS_DEFINITION = "Existing_Earnings_Definition";
	

	public final static String LIFE_BENEFIT_OPTION = "Living_Benefit_Option";
	public final static String RATE_GUARANTEE_ATTRIBUTES = "Rate_Guarantee_Attributes";
	public final static String ENROLLMENT_ASSUMPTION_VARIATION = "Enrollment_Assumption_Variation";
	public final static String RATE_EXPRESSION_ATTR = "Rate_Expression_Attributes";
	public final static String FLAT_DOLLAR_AMOUNT_ATTR = "Flat_Dollar_Amount_Attributes";
	public final static String GRANDFATHERING_GROUP = "Grandfathering_Group";
	public final static String SUBPRODUCT_TYPE_ATTRIBUTE = "SubProduct_Type_Attribute";
	public final static String AMOUNTS_OF_INSURANCE_FLAT_DOLLAR_AMOUNT = "Amounts_of_Insurance__Flat_Dollar_Amount";
	public final static String EMPLOYEE_CONTRIBUTION_TYPE_FLAT_AMOUNT = "Employee_Contribution_Type__Flat_Amount";
	public final static String AGE_BANDED_RATING_EXCEPTION = "Age__Banded_Rating_Exception";
	public final static String AGE__REDUCTION_SCHEDULE_EXCEPTION = "Age__Reduction_Schedule_Exception";
	public final static String AMOUNTS__OF_INSURANCE_EXCEPTION = "Amounts__of_Insurance_Exception";
	public final static String COMPOSITE__RATING_EXCEPTION = "Composite__Rating_Exception";
	public final static String COVERAGE__TERMINATES_AT_RETIREMENT_EXCEPTION = "Coverage__Terminates_at_Retirement_Exception";
	public final static String DISABILITY__PROVISION_EXCEPTION = "Disability__Provision_Exception";
	public final static String DURATION__EXCEPTION = "Duration__Exception";
	public final static String GUARANTEE__ISSUE_LIMIT_EXCEPTION = "Guarantee__Issue_Limit_Exception";
	public final static String LBO__LIFE_EXPECTANCY_EXCEPTION = "LBO__Life_Expectancy_Exception";
	public final static String LIVING__BENEFIT_OPTION_EXCEPTION = "Living__Benefit_Option_Exception";
	public final static String RATE__EXPRESSION_EXCEPTION = "Rate__Expression_Exception";
	public final static String ROUNDING__OCCURS_EXCEPTION = "Rounding__Occurs_Exception";
	public final static String ROUNDING__RULE_EXCEPTION = "Rounding__Rule_Exception";
	public final static String VOLUME__AMOUNTS_EXCEPTION = "Volume__Amounts_Exception";
	public final static String TRAVEL__ASSISTANCE_EXCEPTION = "Travel__Assistance_Exception";
	
	public final static String LOOKUP_CATEGORY_CONTRACT_STATE = "Contract_State";
	public final static String LOOKUP_CATEGORY_TYPE_OF_CASE = "Type_of_Case";
	public final static String LOOKUP_CATEGORY_CONTRIB_ARRNGMT = "Contribution_Arrangement";
	public final static String LOOKUP_CATEGORY_VOLAT_CAVEAT_PRCT = "Volatility_Caveat_Percentage";
	public final static String LOOKUP_CATEGORY_COMPOSITE_RATING = "Composite_Rating";
	public final static String LOOKUP_CATEGORY_AGE_BANDED_RATING = "Age_Banded_Rating";
	public final static String LOOKUP_CATEGORY_RATE_EXPRESSION = "Rate_Expression";
	public final static String LOOKUP_CATEGORY_AMT_OF_INSURANCE = "Amounts_Of_Insurance";
	public final static String LOOKUP_CATEGORY_AGE_RED_SCH = "Age_Reduction_Schedule";
	public final static String LOOKUP_CATEGORY_DISAB_PROVI = "Disability_Provision";
	public final static String LOOKUP_CATEGORY_DURATION = "Duration";
	public final static String LOOKUP_CATEGORY_VOLUME_AMT = "Volume_Amounts";
	public final static String LOOKUP_CATEGORY_GUARANTEE_ISSUE_LIMIT = "Guarantee_Issue_Limit";
	public final static String LOOKUP_CATEGORY_LIVING_BNFT_OPT = "Living_Benefit_Option";
	public final static String LOOKUP_CATEGORY_LBO_EXPECTANCY = "LBO_Life_Expectancy";
	public final static String LOOKUP_CATEGORY_COV_TERMI_RETIRE = "Coverage_Terminates_at_Retirement";
	public final static String LOOKUP_CATEGORY_TRAVEL_ASSIST = "Travel_Assistance";
	public final static String LOOKUP_CATEGORY_EARNING_DEFINITION = "Earnings_Definition";
	public final static String LOOKUP_CATEGORY_INCLUDE_BONUS = "Include_Bonuses_in_Earnings_Definition";
	public final static String LOOKUP_CATEGORY_INCLUDE_COMMISSION = "Include_Commissions_in_Earnings_Definition";
	public final static String LOOKUP_CATEGORY_INCLUDE_OVERTIME = "Include_Overtime_in_Earnings_Definition";
	public final static String LOOKUP_CATEGORY_ROUNDING_RULE = "Rounding_Rule";
	public final static String LOOKUP_CATEGORY_ROUNDING_OCCURS = "Rounding_Occurs";
	public final static String LOOKUP_CATEGORY_EMP_CONTRI = "Employee_Contribution_Type";
	public final static String LOOKUP_CATEGORY_GRANDFATHERING_GRP = "Grandfathering_Group";
	
	public final static String CURRENT_CONTRACT_STATE_ATTRIBUTE = "Current_Contract_State_Attribute";
	public final static String MULTINATIONAL_POOLING_ATTRIBUTE = "Multinational_Pooling_Attribute";
	public final static String MULTINATIONAL_POOLING_FLAG_ATTRIBUTE = "Multinational_Pooling_Flag_Attribute";
	public final static String PRUVALUE_TYPE_ATTRIBUTE ="Type_OF_Case";// "PruValue_Type_Attribute";
	public final static String PRUVALUEPARTS_ATTRIBUTE ="Type_OF_Case";// "PruValueParts_Attribute";
	public final static String PRUVALUE_PARTS_GROUPINGS ="Type_OF_Case";// "PruValue_Parts_Groupings";
	public final static String FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE = "Field_Level_Exceptions_Apply_Attribute";
	public final static String IS_USER_EXCEPTION_ROLE_ATTRIBUTE = "Is_User_Exception_Role_Attribute";
	public final static String SUBPRODUCT_ATTRIBUTE = "SubProduct_Attribute";

	public final static String PLAN_CONTRIBUTION_ATTR = "Plan_Contribution_Attributes";
	public final static String PLAN_CONTRIBUTION_ATTRIBUTES__VOLATILITY_CAVEAT_PERCENTAGE = "Plan_Contribution_Attributes__Volatility_Caveat_Percentage";
	public final static String PLAN_CONTRIB_ATTR_VOLA_CAVEAT_PERC = "Plan Contribution Attributes - Volatility Caveat Percentage";
	public final static String FIELD_LEVEL_EXCEPTIONS_APPLY_ATTR = "Field_Level_Exceptions_Apply_Attributes";
	public final static String PLAN__CONTRIBUTION_EXCEPTION_ATTR = "Plan__Contribution_Exception_Attributes";
	public final static String NO_EXCEPTION_MAX = "No_Exception_Max";
	public final static String MULTIPLE__OF_EARNINGS_EXCEPTION_ATTR = "Multiple__of_Earnings_Exception_Attributes";
	public final static String PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT = "Plan__Contribution_Exception_Attributes__Employee_Contribution_Flat_Amount";
	public final static String PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT = "Plan_Contribution_Attributes__Employee_Contribution_Flat_Amount";
	public final static String PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT__NO_EXCEPTION_MAX = "Plan__Contribution_Exception_Attributes__Employee_Contribution_Flat_Amount__No_Exception_Max";
	public final static String MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS = "Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings";
	public final static String FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT = "Flat_Dollar_Amount_Attributes__Dollar_Amount";
	public final static String PLAN_CONTRIBUTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE = "Plan_Contribution_Attributes__Minimum_Participation_Percentage";
	public final static String PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE = "Plan__Contribution_Exception_Attributes__Minimum_Participation_Percentage";
	public final static String SIC_ID = "sic_ID";
	public final static String TOTAL_LIVES = "Total_Lives";
	public final static String MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT = "Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount";
	public final static String GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP = "Guarantee_Issue_Limit_Attributes__Maximum_Dollar_Cap";
	public final static String PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE__NO_EXCEPTION_MAX = "Plan__Contribution_Exception_Attributes__Minimum_Participation_Percentage__No_Exception_Max";
	public final static String CONTRIBUTION_ARRANGEMENT__NONCONTRIBUTORY_EMPLOYER_PAID = "Contribution_Arrangement__NonContributory_Employer_Paid";
	public final static String GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__DOLLAR_AMOUNT = "Guarantee_Issue_Limit_Attributes__Dollar_Amount";
	public final static String FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION = "Flat__Dollar__Amount__Attributes__Dollar_Amount_Exception";
	public final static int METADATA_FIELDS_COUNT = 200;

	public final static String MULTIPLE_OF_EARNINGS_ATTRIBUTES_MAXIMUM_DOLLAR_AMOUNT_NO_EXCEPTION_MAX = "Multiple_of_Earnings_Attributes_Maximum_Dollar_Amount_No_Exception_Max";
	public final static String MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT = "Multiple_of_Earnings_Attributes__Minimum_Dollar_Amount";
	public final static String MULTIPLE_OF_EARNINGS_ATTRIBUTES_MINIMUM_DOLLAR_AMOUNT_NO_EXCEPTION_MAX = "Multiple_of_Earnings_Attributes_Minimum_Dollar_Amount_No_Exception_Max";
	public final static String MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT = "Multiple__of_Earnings_Exception_Attributes__Maximum_Dollar_Amount";
	public final static String MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT = "Multiple__of_Earnings_Exception_Attributes__Minimum_Dollar_Amount";
	public final static String MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS = "Multiple__of_Earnings_Exception_Attributes__Multiple_of_Annual_Earnings";
	public final static String PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE = "Plan__Contribution_Exception_Attributes__Employee_Contribution_Percentage";
	public final static String PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE = "Plan_Contribution_Attributes__Employee_Contribution_Percentage";
	public final static String RATE_EXPRESSION_ATTRIBUTES__OTHER = "Rate_Expression_Attributes__Other";
	public final static String RATE__EXPRESSION_EXCEPTION_ATTRIBUTES__OTHER = "Rate__Expression_Exception_Attributes__Other";
	public final static String FIELD_LEVEL_EXCEPTIONS_APPLYATTRIBUTE = "Field_Level_Exceptions_ApplyAttribute";
	public final static String PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE__NO_EXCEPTION_MAX = "Plan__Contribution_Exception_Attributes__Employee_Contribution_Percentage__No_Exception_Max";
	public final static String PLAN_CONTRIBUTION_ATTRIBUTES_EMPLOYEE_CONTRIBUTION_PERCENTAGE_NO_EXCEPTION_MAX = "Plan_Contribution_Attributes_Employee_Contribution_Percentage_No_Exception_Max";
	public final static String GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MULTIPLE_OF_EARNINGS = "Guarantee_Issue_Limit_Attributes__Multiple_of_Earnings";

	public final static String PLAN_CONTRIBUTION_EXCEPTION_ATTRIBUTES_EMPLOYEE_CONTRIBUTION_PERCENTAGE = "Plan_Contribution_Exception_Attributes_Employee_Contribution_Percentage";

	public final static String DURATION_ATTRIBUTES__OTHER = "Duration_Attributes__Other";
	public final static String DISABILITY__PROVISION_PREMIUM_CONTINUANCE_DETAILS_EXCEPTION_ATTRIBUTES = "Disability__Provision_Premium_Continuance_Details_Exception_Attributes";
	public final static String DURATION__EXCEPTION_ATTRIBUTES__OTHER = "Duration__Exception_Attributes__Other";
	public final static String DURATION__EXCEPTION_ATTRIBUTES__OTHER__NO_EXCEPTION_MAX = "Duration__Exception_Attributes__Other__No_Exception_Max";
	public final static String FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX = "Flat__Dollar_Amount_Attributes_No_Exception_Max";
	public final static String MULTIPLE_OF_EARNINGS_ATTRIBUTES_MULTIPLE_OF_ANNUAL_EARNINGS_NO_EXCEPTION_MAX = "Multiple_of_Earnings_Attributes_Multiple_of_Annual_Earnings_No_Exception_Max";
	public final static String MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS__NO_EXCEPTION_MAX = "Multiple__of_Earnings_Exception_Attributes__Multiple_of_Annual_Earnings__No_Exception_Max";
	public final static String PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_MAXIMUMUM_DOLLAR_AMOUNT = "Percentage_of_Basic_Life_Active_Amount_Attributes__Maximum_Dollar_Amount";
	
	
	public final static String PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_MINIMUM_DOLLAR_AMOUNT = "Percentage_of_Basic_Life_Active_Amount_Attributes__Minimum_Dollar_Amount";
	public final static String PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MINIMUM_DOLLAR_AMOUNT = "Percentage_of_Basic_Life_Active_Amount_Exception_Attributes_Minimum_Dollar_Amount";
	public final static String PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MAXIMUM_DOLLAR_AMOUNT = "Percentage_of_Basic_Life_Active_Amount_Exception_Attributes_Maximum_Dollar_Amount";
	public final static String PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MAXIMUM_DOLLAR_AMOUNT_NO_EXCEPTION_MAX = "Percentage_of_Basic_Life_Active_Amount_Exception_Attributes_Maximum_Dollar_Amount_No_Exception_Max";
	public final static String PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MINIMUM_DOLLAR_AMOUNT_NO_EXCEPTION_MAX = "Percentage_of_Basic_Life_Active_Amount_Exception_Attributes_Minimum_Dollar_Amount_No_Exception_Max";
	public final static String PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT = "Percentage_of_Basic_Life_Active_Amount_Attributes__Percentage_of_Basic_Life_Active_Amount";
	public final static String PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT = "Percentage_of_Basic_Life_Active_Amount_Exception_Attributes_Percentage_of_Basic_Life_Active_Amount";
	public final static String PERCENTAGE_OF_EMPLOYEE_AMOUNT_CHILD_ATTRIBUTES_PERCENTAGE_OF_EMPLOYEES_INSURANCE_AMOUNT_NO_EXCEPTION_MAX = "Percentage_of_Employee_Amount_Child_Attributes_Percentage_of_Employees_insurance_amount_No_Exception_Max";
	public final static String GUARANTEE_ISSUE_LIMIT_EXCEPTION_ATTRIBUTES_DOLLAR_AMOUNT = "Guarantee__Issue_Limit_Exception_Attributes__Dollar_Amount";

	public final static String GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_EARNINGS__NO_EXCEPTION_MAX = "Guarantee__Issue_Limit_Exception_Attributes__Multiple_of_Earnings__No_Exception_Max";
	public final static String GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_EARNINGS = "Guarantee__Issue_Limit_Exception_Attributes__Multiple_of_Earnings";
	public final static String GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP = "Guarantee__Issue_Limit_Exception_Attributes__Maximum_Dollar_Cap";
	public final static String GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP__NO_EXCEPTION_MAX = "Guarantee__Issue_Limit_Exception_Attributes__Maximum_Dollar_Cap__No_Exception_Max";

	public final static String LBO_LIFE_EXPECTANCY_ATTRIBUTES__OTHER = "LBO_Life_Expectancy_Attributes__Other";
	public final static String LBO_LIFE_EXPECTANCY_EXCEPTION_ATTRIBUTES__OTHER = "LBO__Life_Expectancy_Exception_Attributes__Other";
	public final static String GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__DOLLAR_AMOUNT__NO_EXCEPTION_MAX = "Guarantee__Issue_Limit_Exception_Attributes__Dollar_Amount__No_Exception_Max";
	public static final String RATE_CALC_GATEKEEPER_USER_ROLE = "Rate Calc Gatekeeper";

	public static final String SPECIFIC_EMPLOYEE_WAITING_PERIOD_ATTRIBUTES__DAYS = "Specific_Employee_Waiting_Period_Attributes__Days";

	public static final String  LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTE__LBO_MAXIMUM ="Living__Benefit_Option_Exception_Attributes__LBO_Maximum";
	public static final String  LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTE__LBO_PERCENTAGE="Living__Benefit_Option_Exception_Attributes__LBO_Percentage";
	public static final String  PERCENTAGE_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_MAXIMUM_DOLLAR_AMOUNT="Percentage__of_Basic_Life_Active_Amount_Exception_Attributes__Maximum_Dollar_Amount";
	public static final String  PERCENTAGE_BASIC_LIFE_ACTIVE_AMOUNT_MAXIMUM_DOLLAR_AMOUNT="Percentage_of_Basic_Life_Active_Amount_Attributes__Maximum_Dollar_Amount";
	public static final String  LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTES__LBO_MAXIMUM__NO_EXCEPTION_MAX="Living__Benefit_Option_Exception_Attributes__LBO_Maximum__No_Exception_Max";
	public static final String  LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTES__LBO_MAXIMUM="Living__Benefit_Option_Exception_Attributes__LBO_Maximum";
	public static final String LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTES__LBO_PERCENTAGE__NO_EXCEPTION_MAX = "Living__Benefit_Option_Exception_Attributes__LBO_Percentage__No_Exception_Max";
	public static final String MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX = "Multiple__of_Earnings_Exception_Attributes__Maximum_Dollar_Amount__No_Exception_Max";
	public static final String DIS_S_TIME_SUBMISSION_PERIOD = "Dis_S_Time_Submission_Period";
	public static final String ELIMINATION_PERIOD = "Elimination_Period";
	public static final String CONVERSION_PRIVILEGE_APPLIES = "Conversion_Privilege_Applies";
	public static final String ARE_LATE_ENTRANTS_RULES_WAIVED_WITH_CHANGE_IN_FAMILY_STATUS = "Are_Late_Entrants_rules_waived_with_change_in_Family_Status";
	public static final String WHAT_ARE_THE_LIMITS_WITHOUT_MEDICAL_EVIDENCE_ANNUAL_ENROLLMENT = "What_are_the_limits_without_Medical_Evidence_Annual_Enrollment";
	public static final String RETIREMENT_REDUCTION = "Retirement_Reduction";
	public static final String MEDICAL_UNDERWRITING_FORM = "Medical_Underwriting_Form";
	public static final String LBO_APPLIES_TO = "LBO_Applies_to";
	public static final String ORDER_OF_PRIORITY_FOR_LBO_CLAIM_PAYMENT = "Order_of_Priority_for_LBO_Claim_Payment";
	public static final String ARE_RETIREES_ELIGIBLE_TO_PORT_BASIC_LIFE = "Are_Retirees_eligible_to_Port_Basic_Life";
	public static final String WHAT_ARE_THE_LIMITS_WITHOUT_MEDICAL_EVIDENCE_LATE_ENTRANTS = "What_are_the_limits_without_Medical_Evidence_Late_Entrants";
	public static final String CONTINUITY_OF_COVERAGE_NO_LOSS_NO_GAIN = "Continuity_of_Coverage_No_Loss_No_Gain";
	public static final String REHIRE_WAITING_PERIOD = "Rehire_Waiting_Period";
	public static final String SPECIFIC_EMPLOYEE_WAITING_PERIOD = "Specific_Employee_Waiting_Period";
	public static final String COVERAGE_BEGINS = "Coverage_begins";
	public static final String AMOUNT_REDUCTIONS_TAKE_EFFECT = "Amount_Reductions_take_effect";
	public static final String BONUS_AVERAGED_OVER = "Bonus_Averaged_Over";
	public static final String COMMISSIONS_AVERAGED_OVER ="Commissions_Averaged_Over";
	public static final String OVERTIME_AVERAGED_OVER = "Overtime_Averaged_Over";
	public static final String FIELD_INDICATOR_ADD = "A";
	public static final String FIELD_INDICATOR_CHANGE = "C";
	public static final String FIELD_INDICATOR_REMOVE = "R";
	public static final String TERMINATION_AGE = "Termination_Age";
	
	public static final String INCREMENTAL_DOLLAR_AMOUNT = "Incremental_Dollar_Amount";
	public final static String ENROLLMENT_ASSUMPTION = "Enrollment_Assumption";
	public static final String EXPERIENCE_ARRANGEMENT = "Experience_Arrangement";
	public static final String GRANDFATHERING_TYPE = "Grandfathering_Type";
	public static final String DISABILITY_PROVISION_PREMIUM_CONTNUANCE_DETAILS_ATTRIBUTES__PREMIUM_CONTINUANCE_DETAILS = "Disability_Provision_Premium_Contnuance_Details_Attributes__Premium_Continuance_Details";
	
	public final static String RATE__GUARANTEE_EXCEPTION_ATTRIBUTES__RATE_GUARANTEE_IN_YEARS = "Rate__Guarantee_Exception_Attributes__Rate_Guarantee_in_years";
	public final static String INCREMENTAL__FLAT_DOLLAR_AMOUNTS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT = "Incremental__Flat_Dollar_Amounts_Exception_Attributes__Maximum_Dollar_Amount";
	public final static String INCREMENTAL__FLAT_DOLLAR_AMOUNTS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT = "Incremental__Flat_Dollar_Amounts_Exception_Attributes__Minimum_Dollar_Amount";
	
	public static final String VISIBLE_FLAG_YES = "Yes";
	public static final String VISIBLE_FLAG_NO = "No";
	public static final String DISABILITY__PROVISION_PREMIUM_CONTNUANCE_DETAILS_EXCEPTION_ATTRIBUTES__PREMIUM_CONTINUANCE_DETAILS ="Disability__Provision_Premium_Contnuance_Details_Exception_Attributes__Premium_Continuance_Details";
	public static final String INCLUDE_BONUSES_AVERAGED_OVER = "Include_Bonuses_Averaged_Over";
	public static final String INCLUDE_COMMISSIONS_AVERAGED_OVER = "Include_Commissions_Averaged_Over";
	public static final String INCLUDE_OVERTIME_AVERAGED_OVER = "Include_Overtime_Averaged_Over";
	public static final String PLAN_DISPLAY_YES = "Y";
	public static final String PLAN_DISPLAY_NO = "N";
}

