package com.pru.sparc.common.util;

public class DroolsPlanfieldConstant {

	public final static  String CONT_STATE= "constate";
	public final static  String PLANEFFDT= "planEffectivDt";
	public final static  String PLAN_DESC= "planDesc";
	public final static  String TYP_OF_CASE= "typeOfCase";
	public final static  String PRU_VAL_EXCP= "pruValExcep";
	public final static  String FIELD_LVL_EXCP= "fieldLevleExcep";
	public final static  String CONTRI_ARRANG= "contriArrang";
	public final static  String MIN_PARTCI_PERCEN= "mimPartiPercent";
	public final static  String VOLA_CAVEAT_REATING= "volaCaveatPercent";
	public final static  String COMP_RATING= "compositeRating";
	public final static  String AGE_BANDED_RATING= "ageBandRating";
	public final static  String SPACE= " ";
	
}
