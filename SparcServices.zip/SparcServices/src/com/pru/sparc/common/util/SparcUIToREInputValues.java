package com.pru.sparc.common.util;

import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.pru.sparc.drools.common.util.DateUtil;
import com.pru.sparc.drools.model.CensusConstants;
import com.pru.sparc.drools.model.CommissionConstants;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.model.State;
import com.pru.sparc.drools.model.StateConstants;

@Component
public class SparcUIToREInputValues {

	public void mapPlanValues(final HashMap<String, Object> planMap) {

		if (planMap.containsKey(PlanConstants.PLAN_LIVINGBENEFITOPTIONTYPE)) {
			if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_LIVINGBENEFITOPTIONTYPE),
					"Living_Benefit_Option__Yes")) {

				planMap.put(PlanConstants.PLAN_LIVINGBENEFITOPTIONTYPE,
						"LivingBenefitY");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_LIVINGBENEFITOPTIONTYPE),
					"Living_Benefit_Option__No")) {

				planMap.put(PlanConstants.PLAN_LIVINGBENEFITOPTIONTYPE,
						"LivingBenefitN");

			}

		}

		if (planMap.containsKey(PlanConstants.EXPERIENCE_ARRANGEMENT)) {
			if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.EXPERIENCE_ARRANGEMENT),
					"Experience_Arrangement__NonParticipating")) {

				planMap.put(PlanConstants.EXPERIENCE_ARRANGEMENT,
						"Non_Participating");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.EXPERIENCE_ARRANGEMENT),
					"Experience_Arrangement__Participating")) {

				planMap.put(PlanConstants.EXPERIENCE_ARRANGEMENT,
						"Participating");

			}

		}

		if (planMap.containsKey(PlanConstants.PLAN_COMPOSITE)) {
			if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.PLAN_COMPOSITE),
					"Composite_Rating__Yes")) {

				planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.PLAN_COMPOSITE),
					"Composite_Rating__No")) {

				planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeN");

			}

		}

		if (planMap.containsKey(PlanConstants.DISABILITY_SCHEDULE)) {

			planMap.put(PlanConstants.DISABILITY_SCHEDULE, StringUtils
					.trim((String) planMap
							.get(PlanConstants.DISABILITY_SCHEDULE)));

		}

		if (planMap.containsKey(PlanConstants.BL_AGE_BANDED)) {
			if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.BL_AGE_BANDED),
					"Age_Banded_Rating__Yes")) {

				planMap.put(PlanConstants.BL_AGE_BANDED, "BL_Age_Banded_Yes");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.BL_AGE_BANDED),
					"Age_Banded_Rating__No")) {

				planMap.put(PlanConstants.BL_AGE_BANDED, "BL_Age_Banded_No");

			}

		}

		if (planMap.containsKey(PlanConstants.TRAVEL_ASSIST)) {
			if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.TRAVEL_ASSIST),
					"Travel_Assistance__Yes")) {

				planMap.put(PlanConstants.TRAVEL_ASSIST, "Travel_Assist_Yes");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.TRAVEL_ASSIST),
					"Travel_Assistance__No")) {

				planMap.put(PlanConstants.TRAVEL_ASSIST, "Travel_Assist_No");

			}

		}

		if (planMap.containsKey(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE)) {
			if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__35__65")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched5");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__35__65_50__70")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched1");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__35__70_50__75")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched6");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__40__65")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched7");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__40__65_60__70")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched9");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__40__65_60__70_75__75_85__80")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched8");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__50__70_85__Age_75")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE,
						"Sched10");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__50__Age_70")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched2");

			} else if (StringUtils
					.equalsIgnoreCase(
							(String) planMap
									.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
							"Age_Reduction_Schedule__8_per_year_beginning__age_65_to_a_cumulative_reduction_of_40__70")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched3");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__No_reduction")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE, "Sched4");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE),
					"Age_Reduction_Schedule__Other")) {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE,
						"Sched11");

			} else {

				planMap.put(PlanConstants.PLAN_AGE_REDUCTION_SCHEDULE,
						"Sched12");

			}

		}

		if (planMap.containsKey(PlanConstants.PLAN_DISABILITYDURATION)) {
			if (StringUtils
					.equalsIgnoreCase((String) planMap
							.get(PlanConstants.PLAN_DISABILITYDURATION),
							"Qualifying_Age__Prior_to_Age_60")) {

				planMap.put(PlanConstants.PLAN_DISABILITYDURATION,
						"PriorToAge60");

			} else if (StringUtils
					.equalsIgnoreCase((String) planMap
							.get(PlanConstants.PLAN_DISABILITYDURATION),
							"Qualifying_Age__Other")) {

				planMap.put(PlanConstants.PLAN_DISABILITYDURATION, "Other");

			} else if (StringUtils
					.equalsIgnoreCase((String) planMap
							.get(PlanConstants.PLAN_DISABILITYDURATION),
							"Qualifying_Age__60_or_Older")) {

				planMap.put(PlanConstants.PLAN_DISABILITYDURATION, "60orOlder");
			}

		}

		if (planMap.containsKey(PlanConstants.VOLUME_TYPE)) {
			if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.VOLUME_TYPE),
					"Volume_Amounts__System_calculated_volume")) {

				planMap.put(PlanConstants.VOLUME_TYPE, "SystemCalculated");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.VOLUME_TYPE),
					"Volume_Amounts__Use_census_volume_unaltered")) {

				planMap.put(PlanConstants.VOLUME_TYPE, "CensusVolumeUnaltered");

			} else if (StringUtils
					.equalsIgnoreCase(
							(String) planMap.get(PlanConstants.VOLUME_TYPE),
							"Volume_Amounts__Use_census_volumes_within_plan_parameters")) {

				planMap.put(PlanConstants.PLAN_DISABILITYDURATION,
						"CensusVolumeInParameters");

			}
		}

		if (planMap.containsKey(PlanConstants.PLAN_TYPE)) {
			if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.PLAN_TYPE),
					"Amounts_of_Insurance__Multiple_of_Earnings")) {

				planMap.put(PlanConstants.PLAN_TYPE, "MultipleEarnings");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.PLAN_TYPE),
					"Amounts_of_Insurance__Flat_Dollar_Amount")) {

				planMap.put(PlanConstants.PLAN_TYPE, "FlatAmt");

			} else if (StringUtils
					.equalsIgnoreCase(
							(String) planMap.get(PlanConstants.PLAN_TYPE),
							"Amounts_of_Insurance__Multiple_of_Earnings__Flat_Dollar_Amount")) {

				planMap.put(PlanConstants.PLAN_TYPE, "MultipleEarnings_FlatAmt");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.PLAN_TYPE),
					"Amounts_of_Insurance__Grandfathered_Amounts")) {

				planMap.put(PlanConstants.PLAN_TYPE, "Grandfathered_Amounts");

			}
		}

		if (planMap.containsKey(PlanConstants.DISABILITY_SCHEDULE)) {
			if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.DISABILITY_SCHEDULE),
					"Duration__Lifetime")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisS100");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.DISABILITY_SCHEDULE),
					"Duration__Other")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisS100");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.DISABILITY_SCHEDULE),
					"Duration__Age_65")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisS65");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.DISABILITY_SCHEDULE),
					"Duration__Age_70")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisS70");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.DISABILITY_SCHEDULE),
					"Disability_Provision__None")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisabilityNone");

			} else if (StringUtils
					.equalsIgnoreCase((String) planMap
							.get(PlanConstants.DISABILITY_SCHEDULE),
							"Disability_Provision__1_Year_Contract_Termination_Extension")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisabilityNone");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.DISABILITY_SCHEDULE),
					"Disability_Provision__Dis_A")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisA");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.DISABILITY_SCHEDULE),
					"Disability_Provision__Admin_Dis_S")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisA");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.DISABILITY_SCHEDULE),
					"Disability_Provision__Exception_of_Disability")) {

				planMap.put(PlanConstants.DISABILITY_SCHEDULE, "DisA");

			}
		}

		if (planMap.containsKey(PlanConstants.PLAN_ROUNDING_PREFERENCES)) {
			if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__NA")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundingDoesNotApply");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Higher_1000")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundUpNext1000");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Higher_100")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundUpNext100");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Higher_10")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundUpNext10");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Higher_1")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundUpNearestDollar");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Nearer_1000_Round_Up")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundUp500");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Nearer_1000_Round_Down")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundDown500");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Lower_1000")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundDownNext1000");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Lower_100")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundDownNext100");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Lower_10")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundDownNext10");

			} else if (StringUtils.equalsIgnoreCase((String) planMap
					.get(PlanConstants.PLAN_ROUNDING_PREFERENCES),
					"Rounding_Rule__Lower_1")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_PREFERENCES,
						"RoundDownNearestDollar");

			}
		}

		if (planMap.containsKey(PlanConstants.PLAN_ROUNDING_OCCURS)) {
			if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.PLAN_ROUNDING_OCCURS),
					"Rounding_Occurs__After_Amount_is_Multiplied")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_OCCURS,
						"RoundingOccursAfterAmtIsMultiplied");

			} else if (StringUtils.equalsIgnoreCase(
					(String) planMap.get(PlanConstants.PLAN_ROUNDING_OCCURS),
					"Rounding_Occurs__Before_Amount_is_Multiplied")) {

				planMap.put(PlanConstants.PLAN_ROUNDING_OCCURS,
						"RoundingOccursBeforeAmtIsMultiplied");

			}
		}

	}

	public void mapCensusValues(final HashMap<String, Object> censusMap) {

		if (censusMap.containsKey(CensusConstants.SALARY_SET_FOR_ALL)) {

			if (StringUtils.equalsIgnoreCase(
					(String) censusMap.get(CensusConstants.SALARY_SET_FOR_ALL),
					"True")) {

				censusMap.put(CensusConstants.SALARY_SET_FOR_ALL,
						"SalarySetForAll_Yes");

			} else if (StringUtils.equalsIgnoreCase(
					(String) censusMap.get(CensusConstants.SALARY_SET_FOR_ALL),
					"False")) {

				censusMap.put(CensusConstants.SALARY_SET_FOR_ALL,
						"SalarySetForAll_No");

			}

		}

	}

	public void castHoldingMap(final HashMap<String, Object> holdingMap) {
		
		if(holdingMap.containsKey(HoldingConstants.HOLDING_CV_CASE_LIVES)){

		holdingMap.put(
				HoldingConstants.HOLDING_CV_CASE_LIVES,
				new SBigDecimal(String.valueOf(holdingMap
						.get(HoldingConstants.HOLDING_CV_CASE_LIVES))));
		}
		
		if(holdingMap.containsKey(HoldingConstants.SIC_CODE)){
		holdingMap.put(
				HoldingConstants.SIC_CODE,
				new SBigDecimal(String.valueOf(holdingMap
						.get(HoldingConstants.SIC_CODE))));
		}
		Date proposalCreationDate = (Date) holdingMap
				.get(HoldingConstants.PROPOSALCREATIONDATE);
		if (proposalCreationDate != null) {
			holdingMap.put(HoldingConstants.PROPOSALCREATIONDATE,
					DateUtil.formatDate(proposalCreationDate));
			holdingMap
					.put(HoldingConstants.PROPOSALCREATIONDATE_TIMESTAMP,
							DateUtil.formatMMddyyyyToEEEMMMddhhmmsszyyyy((String) holdingMap
									.get(HoldingConstants.PROPOSALCREATIONDATE)));
		}

		String censusModificationDate = (String) holdingMap
				.get(HoldingConstants.CENSUS_MODIFICATION_DATE);
		
		System.out.println("Census Modififcation Date " +censusModificationDate);
		
		if (censusModificationDate != null) {

		holdingMap.put(HoldingConstants.CENSUS_MODIFICATION_DATE, DateUtil
				.formatMMddyyyyToEEEMMMddhhmmsszyyyyDiffFormat(censusModificationDate));
		}

	}

	public void castPlanMap(final HashMap<String, Object> planMap) {
		
		
		if(planMap.containsKey(PlanConstants.PLAN_MAX)&&planMap.get(PlanConstants.PLAN_MAX)!=null){
		planMap.put(PlanConstants.PLAN_MAX,new SBigDecimal(String.valueOf(planMap.get(PlanConstants.PLAN_MAX))));
		}
		if(planMap.containsKey(PlanConstants.PLAN_MIN)&&planMap.get(PlanConstants.PLAN_MIN)!=null){
		planMap.put(PlanConstants.PLAN_MIN,new SBigDecimal(String.valueOf(planMap.get(PlanConstants.PLAN_MIN))));
		}
		if(planMap.containsKey(PlanConstants.GUARANTEE_ISSUE_DOLLAR_AMT)&&planMap.get(PlanConstants.GUARANTEE_ISSUE_DOLLAR_AMT)!=null){
		planMap.put(PlanConstants.GUARANTEE_ISSUE_DOLLAR_AMT,new SBigDecimal(String.valueOf(planMap.get(PlanConstants.GUARANTEE_ISSUE_DOLLAR_AMT))));
		}
		
		if(planMap.containsKey(PlanConstants.RATE_GUARANTEE_MONTH_NUM)&&planMap.get(PlanConstants.RATE_GUARANTEE_MONTH_NUM)!=null){
		planMap.put(PlanConstants.RATE_GUARANTEE_MONTH_NUM,new SBigDecimal(String.valueOf(planMap.get(PlanConstants.RATE_GUARANTEE_MONTH_NUM))));
		}

		if (planMap.get(PlanConstants.PLAN_EARNINGS_FACTOR) != null) {
			planMap.put(
					PlanConstants.PLAN_EARNINGS_FACTOR,
					new SBigDecimal(String.valueOf(planMap
							.get(PlanConstants.PLAN_EARNINGS_FACTOR))));
		} else {
			planMap.put(PlanConstants.PLAN_EARNINGS_FACTOR, new SBigDecimal(0));
		}
		if (planMap.get(PlanConstants.CASE_FLAT_AMT) != null) {
			planMap.put(
					PlanConstants.CASE_FLAT_AMT,
					new SBigDecimal(String.valueOf(planMap
							.get(PlanConstants.CASE_FLAT_AMT))));
		} else {
			planMap.put(PlanConstants.CASE_FLAT_AMT, new SBigDecimal(0));
		}


		Date planEffectiveDate = (Date) planMap
				.get(PlanConstants.PLAN_EFFECTIVEDATE);
		if (planEffectiveDate != null) {
			planMap.put(PlanConstants.PLAN_EFFECTIVEDATE,
					DateUtil.formatDate(planEffectiveDate));
			planMap.put(PlanConstants.PLAN_EFFECTIVEDATE_TIMESTAMP, DateUtil
					.formatMMddyyyyToEEEMMMddhhmmsszyyyy((String) planMap
							.get(PlanConstants.PLAN_EFFECTIVEDATE)));
		}
		
	}

	public void castPersonValues(final HashMap<String, Object> personMap) {
		
		if(personMap.containsKey(PersonConstants.PEOPLE_SALARY)){

		personMap.put(
				PersonConstants.PEOPLE_SALARY,
				new SBigDecimal(String.valueOf(personMap
						.get(PersonConstants.PEOPLE_SALARY))));
		}
		
		if(personMap.containsKey(PersonConstants.PEOPLE_BASIC_AMT)){
		
		
		personMap.put(
				PersonConstants.PEOPLE_BASIC_AMT,
				new SBigDecimal(String.valueOf(personMap
						.get(PersonConstants.PEOPLE_BASIC_AMT))));
		}
		if(personMap.containsKey(PersonConstants.PEOPLE_AGE)&& personMap.get(PersonConstants.PEOPLE_AGE)!=null){
			
			
			personMap.put(
					PersonConstants.PEOPLE_AGE,
					new SBigDecimal(String.valueOf(personMap
							.get(PersonConstants.PEOPLE_AGE))));
			}

	}

	public void castCensusMap(final HashMap<String, Object> censusMap) {
		if(censusMap.containsKey(CensusConstants.SALARY_ESTIMATE)){
		censusMap.put(
				CensusConstants.SALARY_ESTIMATE,
				new SBigDecimal(String.valueOf(censusMap
						.get(CensusConstants.SALARY_ESTIMATE))));
		}

	}

	public void castComissionValues(final HashMap<String, Object> comissionsMap) {
		
		if(comissionsMap.containsKey(CommissionConstants.COMMISSIONFLATAMT)&&comissionsMap.get(CommissionConstants.COMMISSIONFLATAMT)!=null){

		comissionsMap.put(
				CommissionConstants.COMMISSIONFLATAMT,
				new SBigDecimal(String.valueOf(comissionsMap
						.get(CommissionConstants.COMMISSIONFLATAMT))));
		}
		
		if(comissionsMap.containsKey(CommissionConstants.COMMISSIONFLATPCT)&&comissionsMap.get(CommissionConstants.COMMISSIONFLATPCT)!=null){
		comissionsMap.put(
				CommissionConstants.COMMISSIONFLATPCT,
				new SBigDecimal(String.valueOf(comissionsMap
						.get(CommissionConstants.COMMISSIONFLATPCT))));
		}

	}

	public void mapComissionValues(final HashMap<String, Object> comissionsMap) {

		if (comissionsMap
				.containsKey(CommissionConstants.COMMISSION_COMARRANGEMENT)) {

			if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty((String) comissionsMap
					.get(CommissionConstants.COMMISSION_COMARRANGEMENT)),
					"Flat %")) {

				comissionsMap.put(
						CommissionConstants.COMMISSION_COMARRANGEMENT,
						"ComArrangementFLATPERC");

			} else if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty((String) comissionsMap.get(CommissionConstants.COMMISSION_COMARRANGEMENT)),"Level Scale")) {

					comissionsMap.put(CommissionConstants.COMMISSION_COMARRANGEMENT,"ComArrangementLEVEL");

			}
			else if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty((String) comissionsMap.get(CommissionConstants.COMMISSION_COMARRANGEMENT)),"Flat Amount")) {

				comissionsMap.put(CommissionConstants.COMMISSION_COMARRANGEMENT,"ComArrangementFLATAMT");

			}
			else if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty((String) comissionsMap.get(CommissionConstants.COMMISSION_COMARRANGEMENT)),"Direct")) {

				comissionsMap.put(CommissionConstants.COMMISSION_COMARRANGEMENT,"ComArrangementDIRECT");

			}
			else if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty((String) comissionsMap.get(CommissionConstants.COMMISSION_COMARRANGEMENT)),"None")) {

				comissionsMap.put(CommissionConstants.COMMISSION_COMARRANGEMENT,"ComArrangementNONE");

			}
		}

	}
	
	public void mapStateAllocFactor (final HashMap<String, Object> stateMap){
		
		if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"PA")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.17333333333333334"));
			
		}else if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"PA2")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.022222222222222223"));
			
		}else if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"HI")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.1"));
			
		}else if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"MA")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.06888888888888889"));
			
		}else if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"NJ1")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.14222222222222222"));
			
		}else if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"NJ1")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.14222222222222222"));
			
		}else if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"PA1")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.03333333333333333"));
		}else if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"NYC")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.13333333333333333"));
		}else if(StringUtils.equalsIgnoreCase((String)stateMap.get(StateConstants.STATE),"VT")){
			stateMap.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
					"0.12222222222222222"));
		}		
	}	

	public void castStateMap(final HashMap<String, Object> stateMap) {
		
		
		if (stateMap.containsKey(StateConstants.STATE_ALLOCATION_FACTOR)
				&& stateMap.get(StateConstants.STATE_ALLOCATION_FACTOR) != null) {
			stateMap.put(
					StateConstants.STATE_ALLOCATION_FACTOR,
					new SBigDecimal(String.valueOf(stateMap.get(StateConstants.STATE_ALLOCATION_FACTOR))));
		}
	}
}
