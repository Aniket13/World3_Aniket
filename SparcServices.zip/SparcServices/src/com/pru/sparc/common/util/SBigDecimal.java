package com.pru.sparc.common.util;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

@SuppressWarnings("serial")
public class SBigDecimal extends BigDecimal {

	private static MathContext context = new MathContext(18, RoundingMode.HALF_EVEN);
	
	public int compareTo(SBigDecimal arg0) {
		return super.compareTo(arg0);
	}

	public SBigDecimal multiply(SBigDecimal arg0) {

		return new SBigDecimal(super.multiply(arg0,context).toString());
	};

	public SBigDecimal add(SBigDecimal arg0) {

		return new SBigDecimal(super.add(arg0,context).toString());
	};
	
	public SBigDecimal subtract(SBigDecimal arg0) {

		return new SBigDecimal(super.subtract(arg0,context).toString());
	};
	
	public SBigDecimal divide(SBigDecimal arg0) {

		return new SBigDecimal(super.divide(arg0,context).toString());
	};
	
	public SBigDecimal min(SBigDecimal arg0) {
		return new SBigDecimal(super.min(arg0).toString());
	};

	public SBigDecimal max(SBigDecimal arg0) {
		return new SBigDecimal(super.max(arg0).toString());
	};
	
	public SBigDecimal remainder(SBigDecimal arg0) {
		return new SBigDecimal(super.remainder(arg0,context).toString());
	};
	
	
	public SBigDecimal(String string) {
		super(string);
		new BigDecimal(string,context);
	}

	public SBigDecimal(int string) {
		super(string);
		 new BigDecimal(string,context);
	}

	public SBigDecimal(Integer val) {
		super(val,context);
		new BigDecimal(val,context);
	}

	/*public SBigDecimal(Object string) {
		super((char[]) string);
		if (string.equals(null)) {
			string = "";
		}
		new BigDecimal((char[]) string,context);
	}
	*/
	public SBigDecimal(double val) {
		super(val,context);
		new BigDecimal(val,context);
	}

	public SBigDecimal(Double val) {
		super(val,context);
		new BigDecimal(val,context);
	}
}
