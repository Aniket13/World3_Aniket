package com.pru.sparc.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.pru.sparc.model.PlanDetailsClass;
public class SparcUtil {
	//@Autowired
	//private ProposalRepository proposalRepository;
	//Logger
	private static final Logger LOGGER = Logger.getLogger(SparcUtil.class);
	public static final String VIEW_DATE_FORMAT = "MM/dd/yyyy";
	//returns time in ms consumed for each complete functionality execution
	public static final String getTimeLog(final String methodName, 
    		final boolean start, final long startTime) {
    	StringBuilder result = new StringBuilder(); 
    	try {
	    	result.append("EXECUTION TIME LOG. METHOD NAME: " + methodName);
	    	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:SSS");
			Calendar cal = Calendar.getInstance(); 
	    	if (start) {
	    		 result.append(", START TIME: " + dateFormat.format(cal.getTime()));
	    	} else {
	    		//result.append(", START TIME: " + dateFormat.format(startTime));
	    		//result.append(", END TIME: " + dateFormat.format(cal.getTime()));
	    		result.append(", ELAPSED TIME: " + (System.currentTimeMillis() - startTime) +"ms");
	    	}	
    	} catch (Exception e) {
    		LOGGER.error("Error generating time log for method: " + methodName +" Exception: "+ e);
    	}
    	return result.toString();
    }

	/**
	 * 
	 * @param inDate inDate
	 * @return Date
	 */
	public static Date convertStrToDate(final String inDate) {
		if (inDate == null) {
			return null;
		}
		Date result = null;
	    SimpleDateFormat dateFormat = new SimpleDateFormat(VIEW_DATE_FORMAT);		    		
	    //dateFormat.setLenient(false);	    
		try {
			result = dateFormat.parse(inDate.trim());
		} catch (ParseException pe) {
			return null;
		}
		return result;
	}

	public static Date convertStrToSqlDate(final String inDate) {
		if (inDate == null) {
			return null;
		}
		Date result = null;
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");		    		
	    //dateFormat.setLenient(false);	    
		try {
			result = dateFormat.parse(inDate.trim());
		} catch (ParseException pe) {
			return null;
		}
		return result;
	}
		
	public static PlanDetailsClass mergePlanDetailClassObjects(
			PlanDetailsClass planDetails, PlanDetailsClass planDetails2) {
		if(StringUtils.isNotBlank(planDetails2.getAgeBandedRating())){
			planDetails.setAgeBandedRating(planDetails2.getAgeBandedRating());
		}
		if(StringUtils.isNotBlank(planDetails2.getAgeReductionSchedule())){
			planDetails.setAgeReductionSchedule(planDetails2.getAgeReductionSchedule());
		}
		if(StringUtils.isNotBlank(planDetails2.getCompositeRating())){
			planDetails.setCompositeRating(planDetails2.getCompositeRating());
		}
		if(StringUtils.isNotBlank(planDetails2.getContractState())){
			planDetails.setContractState(planDetails2.getContractState());
		}
		if(StringUtils.isNotBlank(planDetails2.getContributionArrangement())){
			planDetails.setContributionArrangement(planDetails2.getContributionArrangement());
		}
		if(StringUtils.isNotBlank(planDetails2.getCoverageTerminateAtRetirement())){
			planDetails.setCoverageTerminateAtRetirement(planDetails2.getCoverageTerminateAtRetirement());
		}
		if(StringUtils.isNotBlank(planDetails2.getDisablityProvision())){
			planDetails.setDisablityProvision(planDetails2.getDisablityProvision());
		}
		if(StringUtils.isNotBlank(planDetails2.getDuration())){
			planDetails.setDuration(planDetails2.getDuration());
		}
		if(planDetails2.getDollarAmount() != null && planDetails2.getDollarAmount() != 0d && planDetails.getDollarAmount() != planDetails2.getDollarAmount()){
			planDetails.setDollarAmount(planDetails2.getDollarAmount());
		}
		if(StringUtils.isNotBlank(planDetails2.getEarningDefiniton())){
			planDetails.setEarningDefiniton(planDetails2.getEarningDefiniton());
		}
		if(planDetails2.getEffectiveDate() != null && planDetails.getEffectiveDate() != planDetails2.getEffectiveDate()){
			planDetails.setEffectiveDate(planDetails2.getEffectiveDate());
		}
		/*if(StringUtils.isNotBlank(planDetails2.getFieldLevelException())){
			planDetails.setFieldLevelException(planDetails2.getFieldLevelException());
		}*/
		if(StringUtils.isNotBlank(planDetails2.getGuranteeIssueLimit())){
			planDetails.setGuranteeIssueLimit(planDetails2.getGuranteeIssueLimit());
		}
		if(StringUtils.isNotBlank(planDetails2.getInsuranceAmount())){
			planDetails.setInsuranceAmount(planDetails2.getInsuranceAmount());
		}
		if(StringUtils.isNotBlank(planDetails2.getIncludeBonus())){
			planDetails.setIncludeBonus(planDetails2.getIncludeBonus());
		}
		if(StringUtils.isNotBlank(planDetails2.getIncludeCommission())){
			planDetails.setIncludeCommission(planDetails2.getIncludeCommission());
		}
		if(StringUtils.isNotBlank(planDetails2.getIncludeOvertime())){
			planDetails.setIncludeOvertime(planDetails2.getIncludeOvertime());
		}
		if(StringUtils.isNotBlank(planDetails2.getLboLifeExpectancy())){
			planDetails.setLboLifeExpectancy(planDetails2.getLboLifeExpectancy());
		}
		if(StringUtils.isNotBlank(planDetails2.getLivingBenefitOption())){
			planDetails.setLivingBenefitOption(planDetails2.getLivingBenefitOption());
		}
		if(planDetails2.getLboMax() != null && planDetails2.getLboMax() != 0d && planDetails.getLboMax() != planDetails2.getLboMax()){
			planDetails.setLboMax(planDetails2.getLboMax());
		}
		if(null != planDetails2.getLboPercent() && planDetails2.getLboPercent() != 0f && planDetails.getLboPercent() != planDetails2.getLboPercent()){
			planDetails.setLboPercent(planDetails2.getLboPercent());
		}
		if(StringUtils.isNotBlank(planDetails2.getMultipleOfEarnings())){
			planDetails.setMultipleOfEarnings(planDetails2.getMultipleOfEarnings());
		}
		if(StringUtils.isNotBlank(planDetails2.getOverrideIndicator())){
			planDetails.setOverrideIndicator(planDetails2.getOverrideIndicator());
		}
		if(StringUtils.isNotBlank(planDetails2.getPlanDescription())){
			planDetails.setPlanDescription(planDetails2.getPlanDescription());
		}
		if(StringUtils.isNotBlank(planDetails2.getPruValueException())){
			planDetails.setPruValueException(planDetails2.getPruValueException());
		}
		if(StringUtils.isNotBlank(planDetails2.getRateExpression())){
			planDetails.setRateExpression(planDetails2.getRateExpression());
		}
		if(StringUtils.isNotBlank(planDetails2.getRoundingOccurs())){
			planDetails.setRoundingOccurs(planDetails2.getRoundingOccurs());
		}
		if(StringUtils.isNotBlank(planDetails2.getRoundingRule())){
			planDetails.setRoundingRule(planDetails2.getRoundingRule());
		}
		if(StringUtils.isNotBlank(planDetails2.getTravelAssistance())){
			planDetails.setTravelAssistance(planDetails2.getTravelAssistance());
		}
		if(StringUtils.isNotBlank(planDetails2.getTypeOfCase())){
			planDetails.setTypeOfCase(planDetails2.getTypeOfCase());
		}
		if(StringUtils.isNotBlank(planDetails2.getVolumeAmounts())){
			planDetails.setVolumeAmounts(planDetails2.getVolumeAmounts());
		}
		if(planDetails2.getMaxDollaramt() != null && planDetails2.getMaxDollaramt() != 0d && planDetails.getMaxDollaramt() != planDetails2.getMaxDollaramt()){
			planDetails.setMaxDollaramt(planDetails2.getMaxDollaramt());
		}
		if(planDetails2.getMinDollarAmt() != null && planDetails2.getMinDollarAmt() != 0d && planDetails.getMinDollarAmt() != planDetails2.getMinDollarAmt()){
			planDetails.setMinDollarAmt(planDetails2.getMinDollarAmt());
		}
		if(planDetails2.getMinParticipationPct() != null && planDetails2.getMinParticipationPct() != 0f && planDetails.getMinParticipationPct() != planDetails2.getMinParticipationPct()){
			planDetails.setMinParticipationPct(planDetails2.getMinParticipationPct());
		}
		if(planDetails2.getVolatilityCaveatPct() != null && planDetails2.getVolatilityCaveatPct() != 0f && planDetails.getVolatilityCaveatPct() != planDetails2.getVolatilityCaveatPct()){
			planDetails.setVolatilityCaveatPct(planDetails2.getVolatilityCaveatPct());
		}
		if(planDetails2.getRateGurantee() != null && planDetails2.getRateGurantee() != 0 && planDetails.getRateGurantee() != planDetails2.getRateGurantee()){
			planDetails.setRateGurantee(planDetails2.getRateGurantee());
		}
		return planDetails;
	}
	
	/**
	 * 
	 * @param inDate inDate
	 * @return boolean
	 */
	public static boolean isValidDate(final String inDate) {
		if (inDate == null) {
			return false;
		}
	    SimpleDateFormat dateFormat = new SimpleDateFormat(FormatUtil.VIEW_DATE_FORMAT);		    
	    //dateFormat.setLenient(false);	    
		try {
			dateFormat.parse(inDate.trim());
		} catch (ParseException pe) {
			return false;
		}
		return true;
	}
	
	/**
	 * 
	 * @param value value
	 * @return boolean
	 */
	public static boolean isInteger(final String value) {
		boolean result = false;
		if (StringUtils.isNotBlank(value)) {
			try {
				Integer.parseInt(value);
				result = true;
			} catch (NumberFormatException n) {
				
			}
		}
		return result;
	}
	
	/**
	 * 
	 * @param value value
	 * @return boolean
	 */
	public static boolean isDouble(final String value) {
		boolean result = false;
		if (StringUtils.isNotBlank(value)) {
			try {
				Double.parseDouble(value);
				result = true;
			} catch (NumberFormatException n) {
				
			}
		}
		return result;
	}
}
