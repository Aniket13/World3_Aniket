package com.pru.sparc.common.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.apache.commons.validator.GenericValidator;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public final class Utility {

	// Logger
	private static final Logger LOGGER = Logger.getLogger(Utility.class);

	private Utility() {
		super();
	}

	/**
	 * Description : This method is used to validate whether an object passed is
	 * not null
	 * 
	 * @param obj
	 * @return String
	 */
	public static String checkNullObject(Object obj) {
		Object result = obj;
		if (null == result || "NULL".equalsIgnoreCase(String.valueOf(result))) {
			result = "";
		}
		return result.toString().trim();
	}

	/**
	 * Description: This method is used for null checking of variables
	 * 
	 * @param field
	 * @return String
	 */
	public static String checkNull(String field) {
		String returnString = field;
		if (GenericValidator.isBlankOrNull(returnString)) {
			returnString = SparcConstants.BLANK_STRING;
		}
		return returnString.trim();
	}

	/**
	 * Description: This method is used for null checking of List
	 * 
	 * @param list
	 * @return List
	 */
	public static List checkNullList(List list) {
		List returnList = list;
		if (null == returnList) {
			returnList = new ArrayList();
		}
		return returnList;
	}

	/**
	 * Description : This method is used to validate whether an object passed is
	 * not null
	 * 
	 * @param obj
	 * @return boolean
	 */
	public static boolean isNotNullObject(Object obj) {
		boolean result = false;
		if (null != obj) {
			result = true;
		}
		return result;
	}
	
	/**
	 * Description : This method is used to convert boolean as char
	 * 
	 * @param boolean
	 * @return String
	 */
	public static String boolAsChar(boolean b) {
		String result="";
		if (b==true) {
			result = "T";
		}if(b==false){
			result = "F";
		}
		return result;
	}
	
	/**
	 * Description : This method is used to convert char as boolean
	 * 
	 * @param str
	 * @return boolean
	 */
	public static boolean charAsBool(String str) {
		boolean result=false;
		if ("t".equalsIgnoreCase(str.trim())) {
			result = true;
		}if("f".equalsIgnoreCase(str.trim())){
			result = false;
		}
		return result;
	}
	

	/**
	 * Description : Method to get current Timestamp
	 * 
	 * @return Timestamp
	 */
	public static Timestamp getCurrentTimestamp() {
		return new Timestamp(new Date().getTime());
	}

	/**
	 * Description : Method to check if given time is between two specified
	 * times
	 * 
	 * @param target
	 * @param start
	 * @param end
	 * @return boolean
	 */
	public static boolean isTimeInInterval(String target, String start,
			String end) {
		if ((target.compareTo(start) >= 0) && (target.compareTo(end) < 0)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Description : Method to format Timestamp/Date
	 * 
	 * @param dateTime
	 * @param reqFmt
	 * @param actFmt
	 * @return String
	 */
	public static String frmtDateTime(String dateTime, String reqFmt,
			String actFmt) {
		SimpleDateFormat reqFormat = new SimpleDateFormat(reqFmt, Locale.US);
		SimpleDateFormat actFormat = new SimpleDateFormat(actFmt, Locale.US);
		String frmtdDtTime = SparcConstants.BLANK_STRING;
		try {
			frmtdDtTime = reqFormat.format(actFormat.parse(dateTime.trim()));
		} catch (ParseException e) {
			LOGGER.info("Error while parsing date : " + dateTime);
		}
		return frmtdDtTime;
	}

	/**
	 * Description : This function formats the name in "LastNm, FirstNm" or
	 * "LastNm, FirstNm MiddleNm."
	 * 
	 * @Input - firstNm, middleNm, lastNm
	 * 
	 * @Output - Formatted String
	 */
	public static String formatName(String firstNm, String middleNm,
			String lastNm) {
		StringBuilder repFullNm = new StringBuilder();
		if (!"null".equals(lastNm) && !"".equals(lastNm)) {
			repFullNm.append(lastNm);
			if (!"null".equals(firstNm) && !"".equals(firstNm)) {
				repFullNm.append(SparcConstants.COMMA);
				repFullNm.append(SparcConstants.SPACE);
				repFullNm.append(firstNm);
			}
		} else {
			if (!"null".equals(firstNm) && !"".equals(firstNm)) {
				repFullNm.append(firstNm);
			}
		}

		if (!"null".equals(middleNm) && !"".equals(middleNm)
				&& null != middleNm) {

			repFullNm.append(SparcConstants.SPACE);
			repFullNm.append(middleNm);
			repFullNm.append(SparcConstants.DOT);
		}

		/*
		 * Output formatted name as "LastNm, FirstNm" or
		 * "LastNm, FirstNm MiddleNm."
		 */
		return repFullNm.toString();
	}

	/**
	 * Description : This function formats the name in
	 * "LastNm, FirstNm (percentage%)" or
	 * "LastNm, FirstNm MiddleNm. (percentage%)"
	 * 
	 * @Input - firstNm, middleNm, lastNm
	 * 
	 * @Output - Formatted String
	 */
	public static String formatNameWithPercent(String firstNm, String middleNm,
			String lastNm, String percent) {
		Double percentage = null;
		StringBuilder repFullNm = new StringBuilder();
		if (!"null".equals(lastNm) && !"".equals(lastNm)) {
			repFullNm.append(lastNm);
			if (!"null".equals(firstNm) && !"".equals(firstNm)) {
				repFullNm.append(SparcConstants.COMMA);
				repFullNm.append(SparcConstants.SPACE);
				repFullNm.append(firstNm);
			}
		} else {
			if (!"null".equals(firstNm) && !"".equals(firstNm)) {
				repFullNm.append(firstNm);
			}
		}

		if (!"null".equals(middleNm) && !"".equals(middleNm)
				&& null != middleNm) {

			repFullNm.append(SparcConstants.SPACE);
			repFullNm.append(middleNm);
			repFullNm.append(SparcConstants.DOT);
		}
		if (!"null".equals(percent) && !"".equals(percent)) {
			percentage = Double.parseDouble(percent) * 100;
			repFullNm.append(SparcConstants.SPACE);
			repFullNm.append(SparcConstants.OPEN_BRACKET);
			repFullNm.append(Math.round(percentage));
			repFullNm.append(SparcConstants.PER);
			repFullNm.append(SparcConstants.CLOSE_BRACKET);
		}

		/*
		 * Output formatted name as "LastNm, FirstNm" or
		 * "LastNm, FirstNm MiddleNm."
		 */
		return repFullNm.toString();
	}

	/**
	 * Description : This function replaces the & with &amp; in the data to
	 * middleNme passed within the XML Tags.
	 * 
	 * @Input - The input string
	 * 
	 * @Output - The replaced string with the &
	 */

	public static String replaceSpecialChar(String inputStr) {
		String strReplacedAmpString = null;
		String strReplacedAposString = null;
		String strReplacedString = null;
		if (inputStr != null && !"".equals(inputStr)) {
			strReplacedAmpString = replaceAmpersand(inputStr);
			strReplacedAposString = replaceSingleQuote(strReplacedAmpString);
			strReplacedString = strReplacedAposString;
		}

		return strReplacedString;

	}

	/**
	 * Description : This function replaces the & with &amp; in the data to be
	 * passed within the XML Tags.
	 * 
	 * @Input - The input string
	 * 
	 * @Output - The replaced string with the &
	 */

	public static String replaceAmpersand(String inputStr) {
		String strReplacedString = null;
		StringBuilder builder;
		if (inputStr != null && !"".equals(inputStr)) {
			if ((inputStr.indexOf('&')) == -1) {
				strReplacedString = inputStr;
			} else {
				String[] arrInputTokens = Utility.toStringArray(inputStr, "&");
				for (int iCtr = 0; iCtr < arrInputTokens.length - 1; iCtr++) {
					builder = new StringBuilder();
					builder.append(arrInputTokens[iCtr]).append("&amp;")
							.append(arrInputTokens[iCtr + 1]);
					strReplacedString = builder.toString();
				}
			}
		}

		return strReplacedString;

	}

	/**
	 * Description : This function replaces the ' with &apos; in the data to be
	 * passed within the XML Tags.
	 * 
	 * @Input - The input string
	 * 
	 * @Output - The replaced string with the 'apos;
	 */

	public static String replaceSingleQuote(String inputStr) {
		String strReplacedString = null;
		StringBuilder builder;
		if (inputStr != null && !"".equals(inputStr)) {
			if ((inputStr.indexOf('\'')) == -1) {
				strReplacedString = inputStr;
			} else {
				String[] arrInputTokens = Utility.toStringArray(inputStr, "\'");
				for (int iCtr = 0; iCtr < arrInputTokens.length - 1; iCtr++) {
					builder = new StringBuilder();
					builder.append(arrInputTokens[iCtr]).append("&apos;")
							.append(arrInputTokens[iCtr + 1]);
					strReplacedString = builder.toString();
				}
			}
		}
		return strReplacedString;
	}

	/**
	 * Description : Splits the input String into String[] using the delimiter.
	 * 
	 * @param inStr
	 *            String to be split into String[]
	 * @param delimiter
	 *            String that delimits parts of inStr
	 * 
	 * @return Empty or populated String[]
	 */
	public static String[] toStringArray(String inStr, String delimiter) {
		String[] tokens = new String[0];

		if ((inStr != null) && !"".equals(inStr) && (delimiter != null)
				&& !"".equals(delimiter)) {
			List<String> tokensList = new ArrayList<String>();
			StringTokenizer tokenizer = new StringTokenizer(inStr, delimiter);

			while (tokenizer.hasMoreTokens()) {
				tokensList.add(tokenizer.nextToken());
			}

			tokens = new String[tokensList.size()];
			System.arraycopy(tokensList.toArray(), 0, tokens, 0, tokens.length);
		}

		return tokens;
	}

	public static String getElementValue(Document doc, String tag) {
		NodeList nl = doc.getElementsByTagName(tag);
		if (nl.getLength() > SparcConstants.INT_ZERO
				&& nl.item(0).getFirstChild() != null) {
			return (nl.item(0).getFirstChild().getNodeValue());
		}
		return SparcConstants.BLANK_STRING;
	}

	public static Document getDocument(String is)
			throws ParserConfigurationException, SAXException, IOException {
		// Step 1: create a DocumentBuilderFactory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		// Step 2: create a DocumentBuilder
		DocumentBuilder db = dbf.newDocumentBuilder();
		// Step 3: parse the input file to get a Document object
		ByteArrayInputStream sis = new ByteArrayInputStream(is.getBytes());
		return db.parse(sis);
	}

	/**
	 * Description : to return long value for orderID
	 * 
	 * @return Long
	 */
	public static long getTime() {
		GregorianCalendar objCal = new GregorianCalendar();
		return objCal.getTime().getTime();
	}

	public static SOAPMessage getSoapMessageFromString(String xml)
			throws SOAPException, IOException {
		MessageFactory factory = MessageFactory.newInstance();
		return factory
				.createMessage(
						new MimeHeaders(),
						new ByteArrayInputStream(xml.getBytes(Charset
								.forName("UTF-8"))));
	}

	public static String getXmlFromSOAPMessage(SOAPMessage msg)
			throws SOAPException, IOException {
		ByteArrayOutputStream byteArrayOS = new ByteArrayOutputStream();
		msg.writeTo(byteArrayOS);
		return new String(byteArrayOS.toByteArray());
	}

}