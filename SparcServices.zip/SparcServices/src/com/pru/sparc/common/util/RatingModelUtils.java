package com.pru.sparc.common.util;

import org.springframework.stereotype.Component;


@Component
public class RatingModelUtils  {/*

	public static RatingModelWraperUI getRatingModelsForUI(RuleRatingModelWrapper ratingModelDrols){
		List<RuleRatingModelOverrideGrp> listRatingOverGrp = new ArrayList<RuleRatingModelOverrideGrp>();
		List<RuleRatingCensusCompGrp> listRatingCensusGrp = new ArrayList<RuleRatingCensusCompGrp>();
		List<RuleRatingModelRuleResultGrp> listRatingRuleResultGrp = new ArrayList<RuleRatingModelRuleResultGrp>();
		
		listRatingOverGrp= ratingModelDrols.getRuleRatingModelOverrideGrp();
		listRatingCensusGrp=ratingModelDrols.getRuleRatingCensusCompGrp();
		listRatingRuleResultGrp= ratingModelDrols.getRuleRatingModelRuleResultGrp();
		
		List<RatingModelOverideGrp> group = setUpData(); 
		List<ArrayList<RuleRatingModelOverrideGrp>> finallistRating = new ArrayList<ArrayList<RuleRatingModelOverrideGrp>>();
		
		 ==================================This list is to modify as per no of groups start====================================== 
		ArrayList<RuleRatingModelOverrideGrp> modelGrp1= selectObjectsByGroupName(listRatingOverGrp,"groupId", "group 1");
		ArrayList<RuleRatingModelOverrideGrp> modelGrp2= selectObjectsByGroupName(listRatingOverGrp,"groupId", "group 2");
		ArrayList<RuleRatingModelOverrideGrp> modelGrp3= selectObjectsByGroupName(listRatingOverGrp,"groupId", "group 3");
		ArrayList<RuleRatingModelOverrideGrp> modelGrp4= selectObjectsByGroupName(listRatingOverGrp,"groupId", "group 4");
		ArrayList<RuleRatingModelOverrideGrp> modelGrp5= selectObjectsByGroupName(listRatingOverGrp,"groupId", "group 5");
		finallistRating.add(modelGrp1);
		finallistRating.add(modelGrp2);
		finallistRating.add(modelGrp3);
		finallistRating.add(modelGrp4);
		finallistRating.add(modelGrp5);
		
		==================================This list is to modify as per no of groups end====================================== 
		
		System.out.println("Below are model are =" + finallistRating);
		
		======================================finally setting up the same object for response after grouping==========================================
		RatingModelWraperUI ratingWraperGrp = new RatingModelWraperUI();
		ratingWraperGrp.setRatingModelOverideGrp(finallistRating);
		ratingWraperGrp.setRatingCensusCompGrp(listRatingCensusGrp);
		ratingWraperGrp.setRatingRuleResultGrp(listRatingRuleResultGrp);
	    
	    ======================================================================== ======================================================
		
		return ratingWraperGrp;
	}
		
	public RuleRatingModelWrapper getRatingModelsForDrools(RatingModelWraperUI ratingModelUi){
		
		List<ArrayList<RuleRatingModelOverrideGrp>> groupingModellist = new ArrayList<ArrayList<RuleRatingModelOverrideGrp>>();
		List<RuleRatingModelOverrideGrp> listRatingOverGrp = new ArrayList<RuleRatingModelOverrideGrp>();
		List<RuleRatingCensusCompGrp> listRatingCensusGrp = new ArrayList<RuleRatingCensusCompGrp>();
		List<RuleRatingModelRuleResultGrp> listRatingRuleResultGrp = new ArrayList<RuleRatingModelRuleResultGrp>();
		
		groupingModellist= ratingModelUi.getRatingModelOverideGrp();
		listRatingCensusGrp=ratingModelUi.getRatingCensusCompGrp();
		listRatingRuleResultGrp= ratingModelUi.getRatingRuleResultGrp();
		
		======================================de-grouping for UI model groups into single list ============
		 for(ArrayList<RuleRatingModelOverrideGrp> modelList : groupingModellist){
			 listRatingOverGrp.addAll(modelList);
		 }
		System.out.println("Un grouping model List=" +listRatingOverGrp);
		====================================================================================================================================================
		
		======================================finally setting up the same object for response after de-grouping for Drools and DB persistance ============
		RuleRatingModelWrapper ratingDroolsWraperGrp = new RuleRatingModelWrapper();
		ratingDroolsWraperGrp.setRuleRatingModelOverrideGrp(listRatingOverGrp);
		ratingDroolsWraperGrp.setRuleRatingCensusCompGrp(listRatingCensusGrp);
		ratingDroolsWraperGrp.setRuleRatingModelRuleResultGrp(listRatingRuleResultGrp);
	    
	    ======================================================================== ======================================================
		
		return ratingDroolsWraperGrp;
		
	}
	
		 This is to set the temporaray data for drools response 
	
		public List<RuleRatingModelOverrideGrp> setUpData(){
			List<RuleRatingModelOverrideGrp> listRatingOverGrp = new ArrayList<RuleRatingModelOverrideGrp>();
			
			RuleRatingModelOverrideGrp grp1= new RuleRatingModelOverrideGrp();
			RuleRatingModelOverrideGrp grp2= new RuleRatingModelOverrideGrp();
			RuleRatingModelOverrideGrp grp3= new RuleRatingModelOverrideGrp();
			RuleRatingModelOverrideGrp grp4= new RuleRatingModelOverrideGrp();
			RuleRatingModelOverrideGrp grp5= new RuleRatingModelOverrideGrp();
			RuleRatingModelOverrideGrp grp6= new RuleRatingModelOverrideGrp();
			
			grp1.setGroupId("group-1");
			grp1.setFieldKey("fieldKey1");
			grp1.setFieldValue(new Double(12.365));
			
			grp2.setGroupId("group-2");
			grp2.setFieldKey("fieldKey2");
			grp2.setFieldValue(new Double(12.365));
			
			grp3.setGroupId("group-1");
			grp3.setFieldKey("fieldKey3");
			grp3.setFieldValue(new Double(12.365));
			
			grp4.setGroupId("group-2");
			grp4.setFieldKey("fieldKey4");
			grp4.setFieldValue(new Double(12.365));
			
			grp5.setGroupId("group-5");
			grp5.setFieldKey("fieldKey5");
			grp5.setFieldValue(new Double(12.365));
			
			
			grp6.setGroupId("group-1");
			grp6.setFieldKey("fieldKey6");
			grp6.setFieldValue(new Double(12.365));
			
			
			listRatingOverGrp.add(grp1);
			listRatingOverGrp.add(grp2);
			listRatingOverGrp.add(grp3);
			listRatingOverGrp.add(grp4);
			listRatingOverGrp.add(grp5);
			listRatingOverGrp.add(grp6);
			
			return listRatingOverGrp;
		}


		public static ArrayList<RuleRatingModelOverrideGrp> selectObjectsByGroupName(List<RuleRatingModelOverrideGrp> listRatingOverGrp, String propertyName, String value) {
			EqualPredicate nameEqlPredicate = new EqualPredicate(value);
			BeanPredicate beanPredicate = new BeanPredicate(propertyName, nameEqlPredicate);
			Collection<RuleRatingModelOverrideGrp> filteredCollection = CollectionUtils.select(listRatingOverGrp, beanPredicate);
			System.out.println("Below are model override group object(s) whose " + propertyName + " is " + value);
			System.out.println("Matches for entered criteria "
					+ CollectionUtils.countMatches(listRatingOverGrp, beanPredicate));
			ArrayList<RuleRatingModelOverrideGrp> listRating =new ArrayList<RuleRatingModelOverrideGrp>();
			for (RuleRatingModelOverrideGrp modelgrp : filteredCollection) {
				System.out.println(modelgrp);
				listRating.add(modelgrp);
				
			}
			System.out.println("Below are model override group object(s) whose are in one group=" + listRating);
			return listRating;
		}

		*//**
		 * select's the person object from collcetion based on propetyName and value
		 * @param propertyName - Person's attribute (firstName (or) lastName (or) salary )
		 * @param value - Value to be compared to propertyName
		 *//*
		

		public static void main(String[] args) {
			RatingModelUtils example = new RatingModelUtils();
			
			RatingModelWraperUI ratingWraper = new RatingModelWraperUI();
			RatingModelWraperDrools ratingModelDrols = new RatingModelWraperDrools(); // this the filled object received from drools
			
			List<RatingRuleResultGrp> listRatingRuleResultGrp = new ArrayList<RatingRuleResultGrp>();
			List<RuleRatingModelOverrideGrp> listModelGrp = new ArrayList<RuleRatingModelOverrideGrp>();
			List<RatingCensusCompGrp> listRatingCensusGrp = new ArrayList<RatingCensusCompGrp>();
			
			RatingCensusCompGrp ratingCensusGrp1 = new RatingCensusCompGrp();
			RatingCensusCompGrp ratingCensusGrp2 = new RatingCensusCompGrp();
			
			RatingRuleResultGrp ratingRuleResultGrp1 = new RatingRuleResultGrp();
			RatingRuleResultGrp ratingRuleResultGrp2 = new RatingRuleResultGrp();
			RatingRuleResultGrp object setting 
			
			ratingRuleResultGrp1.setRuleId("1");
			ratingRuleResultGrp2.setRuleId("2");
			listRatingRuleResultGrp.add(ratingRuleResultGrp1);
			listRatingRuleResultGrp.add(ratingRuleResultGrp2);
			
			RatingCensusGrp object setting 
			ratingCensusGrp1.setTabRate(123.98);
			ratingCensusGrp2.setTabRate(1234.98);
			listRatingCensusGrp.add(ratingCensusGrp1);
			listRatingCensusGrp.add(ratingCensusGrp2);
			
			List<RuleRatingModelOverrideGrp> group = example.setUpData();
			
			ratingModelDrols.setRatingCensusCompGrp(listRatingCensusGrp);
			ratingModelDrols.setRatingRuleResultGrp(listRatingRuleResultGrp);
			ratingModelDrols.setRuleRatingModelOverrideGrp(group);
			
			example.getRatingModelsForUI(ratingModelDrols);
			
			example.getRatingModelsForDrools(example.getRatingModelsForUI(ratingModelDrols));
			
		}
	
*/}
