package com.pru.sparc.common.util;

public final class SparcConstants {
	
	/**
	 * Instantiates a new Sparc constants.
	 */
	private SparcConstants() {
		
	}
	
	public static final String ADMIN  = "Admin";
	public static final String CAROLLTILGHMAN="Caroll,Tilghman";
	public static final String LDSMTILGHMAN="Ldsm, Tilghman";
	public static final String LDSMNEWTILGHMAN  ="LdsmNew, Tilghman";
	
	
	public static final String MELLENDORFSTACY ="Mellendorf, Stacy";
	public static final String MELLENDORFSTACY1 ="Mellendorf1, Stacy1";
	public static final String MELLENDORFSTACY2 ="Mellendorf2, Stacy2";
	

	public static final String WILLIAM="William";
	public static final String JAMES="James";
	public static final String ANTHONY="Anthony";
		 	 	 	
	public static final String JACOB="Jacob";
	public static final String ETHAN="Ethan";
	public static final String LANDON="Landon";
		 	 	
	public static final String CHRISTOPHER="Christopher";
	public static final String JOSHUA="Joshua";
	public static final String MICHAEL="Michael";
		 	 	
	public static final String ALEXANDER="Alexander";
	public static final String DANIEL="Daniel";
	public static final String LOGAN="Logan";
	
	 	 	 		
	public static final String WYATT="Wyatt";
	public static final String HUNTER="Hunter";
	public static final String TYLER="Tyler";
	
	
	public static final String AIDEN="Aiden";
	public static final String GAVIN="Gavin";
	public static final String NOAH="Noah";
	
	
	 	 	
	public static final String KEVIN="Kevin";
	public static final String JUAN="Juan";
	public static final String ADRIAN="Adrian";
	
	 	 	
	public static final String CALEB="Caleb";
	public static final String MATTHEW="Matthew";
	public static final String DAVID="David";
	
	public static final String BLANK_STRING = "";
	public static final int INT_ZERO = 0;
	public static final String COMMA = ",";
	public static final String SPACE = " ";
	public static final String DOT = ".";
	public static final String OPEN_BRACKET = "(";
	public static final String PER = "%";
	public static final String CLOSE_BRACKET = ")";

	public static final String GENERIC_UI_MSG = "We are currently experiencing technical difficulties" +
			"which restrict the display of details for this account. " +
			"We apologize for any inconvenience this may cause. " +
			"Please contact Customer Service for up-to-date information.";
	
	//Validation error messages
	public static final String EMPTY_CLIENT_NAME = "Please enter a name.";
	public static final String NOT_FOUND_SIC_CODE = "Invalid SIC id. No match found.";
	public static final String INVALID_SIC_CODE = "Please enter a valid SIC code.";
	public static final String EMPTY_CONTRACT_STATE = "Please select a state.";
	public static final String EMPTY_CLIENT_CITY = "Please enter a city.";
	public static final String EMPTY_CLIENT_STATE = "Please select a state.";
	public static final String EMPTY_CLIENT_US_ZIP = "Please enter US zip in 'XXXXX(-XXXX)' format.";
	public static final String EMPTY_CLIENT_CANADA_ZIP = "Please enter Canada zip in 'XXX-XXX' format.";
	public static final String INVALID_CLIENT_TIN = "Please enter TIN in format XX-XXXXXXX.";
	public static final String INVALID_CLIENT_PHONE = "Please enter an office phone number in the right format.";
	public static final String INVALID_CLIENT_ZIP = "Please enter a zip code in the right format.";
	public static final String EMPTY_CLIENT_COUNTRY = "Please select a country";
	public static final String EMPTY_REC_FROM_CLIENT = "Recieved from client cannot be empty";
	public static final String EMPTY_SALES_OFF = "Sales office cannot be empty";
	public static final String EMPTY_MARKET_SEG = "Market Segment cannot be empty";
	public static final String EMPTY_LDSM = "Ldsm name cannot be empty";
	public static final String EMPTY_UW_VALUE = "Under writer name cannot be empty";
	public static final String EMPTY_RATE_CALC_TECH = "Rate calc tech name is required";
	public static final String EMPTY_DESC = "Proposal description is required";
	public static final String EMPTY_ACCT_MANAGER = "Account manageris required";
	public static final String PROPOSAL_ID_BLANK = "Proposal ID cannot be blank";
	public static final String INVALID_VERSION_NO = "Invalid Version Number";
	public static final String INVALID_BROKER_ID = "Invalid Broker Id";
	public static final String INVALID_COMMISSION = "Total Split is not 100.Please recheck,otherwise this commission will not be copied into plan level.";
	public static final String INVALID_COMM_PERCENTAGE = "Commission Split must be a number between 0.0 and 100.0.";
	public static final String EMPTY_MANDATORY_SEARCH_FIELDS = "Please enter value for at least one field from Name, Proposal ID# and SIC#";
	public static final String CENSUS_STATE_LOOKUP_CATEGORY = "censusAllocState";
	public static final String COUNTRY_UNITED_STATES = "United States";
	public static final String COUNTRY_CANADA = "Canada";
	public static final String TIN_REGEX = "[0-9]{2}-[0-9]{7}";
	public static final String PHONE_REGEX = "[0-9\\-\\(\\) ]+";
	public static final String ZIP_REGEX = "[0-9A-Z\\-]+";
	public static final String DATE_REGEX = "[0-9]{2}/[0-9]{2}/[0-9]{4}";
	public static final String INVALID_LOCAL_CONTRACT = "Please select a value for the Local Contract Client field.";
	public static final String INVALID_FEDERAL_CONTRACT = "Please select a value for the Federal Contract Client field.";
	public static final String INVALID_STATE_CONTRACT = "Please select a value for the State Contract Client field.";
	public static final String INVALID_PRU_SALES_OFFICE = "Data cannot be saved because attribute \"PruSalesOffice\"has a bad value";
	public static final String INVALID_CASE_EFFECTIVE_DATE = "Please enter a case effective date in the format of 'mm/dd/yyyy'.";
	public static final String INVALID_REQUIRED_DATE = "Please enter Date Required in the format of 'mm/dd/yyyy'.";
	public static final String INVALID_RECEIVED_FROM_CLIENT_DATE = "Please enter a case Received from Client date in the format of 'mm/dd/yyyy'.";
	public static final String EMPTY_RECEIVED_FROM_CLIENT_DATE = "Received from Client date cannot be blank.";
	
    
    
	
	public static final String RATING_PROP_FILENM  = "RatingDisplay.properties";

}
