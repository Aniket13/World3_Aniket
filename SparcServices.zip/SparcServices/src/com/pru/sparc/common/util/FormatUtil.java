package com.pru.sparc.common.util;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;



public final class FormatUtil {
                       
    /**
     * Value is N/A.
     */
    public static final String VALUE_NA = "N/A";
    /**
     * private default constructor.
     */
	private FormatUtil() {
		
	}

    /**
     * date format.
     */
    public static final String VIEW_DATE_FORMAT = "MM/dd/yyyy";
    public static final String TIMESTAMP_FORMAT = "MMddyyHHmmss";
    /**
     * money format.
     */
	public static final String UNIT_FORMAT = "#,###,###,###.00000";
	/**
	 * 
	 */
	public static final String TWO_DECIMAL_FORMAT = "##.00";
	/**
	 * 
	 */
	public static final String XML_DATE_FORMAT = "yyyy-MM-dd";
	/**
	 * 
	 * @param d d
	 * @return String
	 */
	public static String formatDateInXml(final Date d) {
		if (d == null) {
			return "";
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat(XML_DATE_FORMAT);
		return dateFormat.format(d);
	}
    

    /**
     * display date based on format.
     * @param d date to format as a string.
     * @return a formatted date.
     */
	public static String displayDate(final Date d) {
		if (d == null) {
			return "";
		} else {
			SimpleDateFormat dateFormat = new SimpleDateFormat(VIEW_DATE_FORMAT);
			return dateFormat.format(d);
		}
	}

	/**
	 * Get month value from date.
	 * @param dateStr
	 * @return Month value
	 */
	public static String displayDateMonth(final String dateStr) {
	    String strTmp = StringUtils.trimToEmpty(dateStr);
	    Date dtTmp = null;
	    Calendar cal = Calendar.getInstance();
	    try {
	        if (strTmp.length() >=1 && strTmp.length() <= 2) {
	            // only month was sent
	            dtTmp = CommonUtils.convertStrToDate(strTmp+"/01/"+cal.get(Calendar.YEAR));
	        } else {
	            // date string was sent
	            dtTmp = CommonUtils.convertStrToDate(strTmp);
	        }
	        strTmp = new SimpleDateFormat("MMMM").format(dtTmp);
        } catch (Exception e) {
            e.printStackTrace();
        }
	    return strTmp;
	}
	
    /**
     * format units.
     * @param value - value to format.
     * @param printNA - print he N/A
     * @return N/A
     */
	public static String formatUnits(final double value, final boolean printNA) {
		if (value == 0.0) {
			return VALUE_NA;
		}
		DecimalFormat unitsFormatter = new DecimalFormat(UNIT_FORMAT);
		return unitsFormatter.format(value);
	}
	/**
	 * 
	 * @param value
	 * @return
	 */
	public static String formatTwoDecimal(final double value) {	
		DecimalFormat unitsFormatter = new DecimalFormat(TWO_DECIMAL_FORMAT);
		return unitsFormatter.format(value);
	}
	/**
	 * Format number as currency.
	 * 
	 * @param value
	 * @param printNA
	 * @return
	 */
    public static String formatCurrency(final double value, final boolean printNA) {
        if (printNA && value == 0.0) {
            return VALUE_NA;
        }
        return DecimalFormat.getCurrencyInstance().format(value);
    }
    

    
    /**
     * Converts the date format
     * 
     * @param inDate
     * @param fromFormat
     * @param toFormat
     * @return
     */
    public static String converDateFormat(final String inDate , String fromFormat, String toFormat) {
		if (inDate == null) {
			return null;
		}
		  SimpleDateFormat sdfSource = new SimpleDateFormat(fromFormat);     
	      //parse the string into Date object
	      Date date = null;
		try {
			date = sdfSource.parse(inDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block			
		}
		  SimpleDateFormat sdfDestination = new SimpleDateFormat(toFormat);
	      return sdfDestination.format(date);		
	}   
    
    /**
     * returns date based on String date
     * @param d date to format as a date.
     * @return a formatted date.
     */
	public static Date convertStringToDate(final String strDate) {
		Date d = null;
		if (StringUtils.isBlank(strDate)) {
			return null;
		} else {
			try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(VIEW_DATE_FORMAT);
			d = dateFormat.parse(strDate);
			} catch (Exception e) {}
		}
		return d;
	}
	
	/**
	 * Format US Currency
	 * 
	 * @param value
	 * @param acceptZero
	 * @return
	 */
	public static String formatUSCurrency(final double value, final boolean acceptZero) {
		String result = "";
		try {
			if (!acceptZero && value <= 0) {
				return "";
			}
			NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
			result = currencyFormat.format(value);			
		} catch (Exception e) {
			
		}
		return result;
	}
	
    /**
     * Format positive values and zero as currency. Negative values return "N/A".
     * 
     * @param value
     *            Double value to be formatted.
     * @return String formatted value for positive/zero or "N/A" for negative.
     */
    public static String formatCurrencyPositiveOnly(final double value) {
        if (value < 0.0) {
            return "N/A";
        }
        return NumberFormat.getCurrencyInstance().format(value);
    }
    
   
    
}
