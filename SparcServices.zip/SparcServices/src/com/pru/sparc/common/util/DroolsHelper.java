package com.pru.sparc.common.util;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import com.pru.sparc.bo.model.DroolsDynamicPlanFields;

public class DroolsHelper {

	public DroolsDynamicPlanFields getDroolsResponse(DroolsDynamicPlanFields dynamicPlanFields){
		
		// load up the knowledge base
        KnowledgeBase kbase;
        //DynamicPlanFields dynamicPlanFields = new DynamicPlanFields();
		try {
			kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
	        ksession.insert(dynamicPlanFields);
	        ksession.fireAllRules();
	        
	        System.out.println(">>>> = " + dynamicPlanFields.getConstate());
	        System.out.println(">>>> = " + dynamicPlanFields.getPlaneffdt());
	        System.out.println(">>>> = " + dynamicPlanFields.getPlandesc());
	        System.out.println(">>>> = " + dynamicPlanFields.getTypeofcase());
	        System.out.println(">>>> = " + dynamicPlanFields.getPruvalexcp());
	        System.out.println(">>>> = " + dynamicPlanFields.getFildlvlexcp());
	        System.out.println(">>>> = " + dynamicPlanFields.getContrarrang());
	        System.out.println(">>>> = " + dynamicPlanFields.getMinpartpercn());
	        System.out.println(">>>> = " + dynamicPlanFields.getVolcavpercn());
	        System.out.println(">>>> = " + dynamicPlanFields.getComprat());
	        System.out.println(">>>> = " + dynamicPlanFields.getAgebndrat());
	        
	        ksession.dispose();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
        
		
		return dynamicPlanFields;
	}
	
	private static KnowledgeBase readKnowledgeBase() throws Exception {
	      KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
	     
	      DecisionTableConfiguration dtconf = KnowledgeBuilderFactory.newDecisionTableConfiguration();
	      dtconf.setInputType(DecisionTableInputType.XLS);
	      
	      
	    //  kbuilder.add(ResourceFactory.newClassPathResource("mytable.drl"),ResourceType.DRL);
	      
	     kbuilder.add(ResourceFactory.newClassPathResource("com/pru/sparc/ratingengine/DecisionTables/PlanFields.xls"),ResourceType.DTABLE,dtconf);
	      KnowledgeBuilderErrors errors = kbuilder.getErrors();
	      
	      if (errors.size() > 0) {
	         for (KnowledgeBuilderError error: errors) {
	            System.err.println(error);
	         }
	         throw new IllegalArgumentException("Could not parse knowledge.");
	      }
	      KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
	      kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
	      return kbase;
	   }
}
