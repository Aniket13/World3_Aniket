package com.pru.sparc.common.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;

public class CommonUtils {

	private static DatatypeFactory df;
	static {
		try {
			df = DatatypeFactory.newInstance();
		} catch (DatatypeConfigurationException dce) {
			throw new IllegalStateException(
					"Exception while obtaining DatatypeFactory instance", dce);
		}
	}

	public static XMLGregorianCalendar asXMLGregorianCalendar(final Date date) {
		if (date == null) {
			return null;
		} else {
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTimeInMillis(date.getTime());
			return df.newXMLGregorianCalendar(gc);
		}
	}

	public static String getTimeStamp() {
		String result = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				FormatUtil.TIMESTAMP_FORMAT);
		Date date = new Date();
		try {
			result = dateFormat.format(date);
		} catch (Exception e) {
			// TODO
		}
		return result;
	}

	/**
	 * 
	 * @param xmlCal
	 *            xmlCal
	 * @return Date
	 */

	public static Date convertXmlCaltoDate(final XMLGregorianCalendar xmlCal) {
		if (xmlCal == null) {
			return null;
		} else {
			return xmlCal.toGregorianCalendar().getTime();
		}
	}

	/**
	 * 
	 * @param value
	 *            value
	 * @return boolean
	 */
	public static boolean convertStrToBoolean(final String value) {
		boolean result = false;
		if (StringUtils.isNotBlank(value)) {
			if (StringUtils.equalsIgnoreCase(value, "Y")
					|| StringUtils.equalsIgnoreCase(value, "1")
					|| StringUtils.equalsIgnoreCase(value, "true")
					|| StringUtils.equalsIgnoreCase(value, "T")) {
				result = true;
			}
		}
		return result;
	}

	public static String convertBooleanToStr(final boolean value) {
		if (value == true) {
			return "Y";
		} else {
			return "N";
		}
	}
	
	/**
	 * 
	 * @param value
	 *            value
	 * @return boolean
	 */
	public static boolean isInteger(final String value) {
		boolean result = false;
		if (StringUtils.isNotBlank(value)) {
			try {
				Integer.parseInt(value);
				result = true;
			} catch (NumberFormatException n) {

			}
		}
		return result;
	}

	/**
	 * 
	 * @param inDate
	 *            inDate
	 * @return boolean
	 */
	public static boolean isValidDate(final String inDate) {
		if (inDate == null) {
			return false;
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				FormatUtil.VIEW_DATE_FORMAT);
		// dateFormat.setLenient(false);
		try {
			dateFormat.parse(inDate.trim());
		} catch (ParseException pe) {
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @param inDate
	 *            inDate
	 * @return Date
	 */
	public static Date convertStrToDate(final String inDate) {
		if (inDate == null) {
			return null;
		}
		Date result = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				FormatUtil.VIEW_DATE_FORMAT);
		// dateFormat.setLenient(false);
		try {
			result = dateFormat.parse(inDate.trim());
		} catch (ParseException pe) {
			return null;
		}
		return result;
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static String ConvertDateToStr(final Date date) {
		String result = null;
		if (date != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					FormatUtil.VIEW_DATE_FORMAT);
			try {
				result = dateFormat.format(date);
			} catch (Exception e) {
			}
		}
		return result;
	}

	/**
	 * 
	 * @param value
	 * @return
	 */
	public static BigDecimal stringToValue(final String value) {
		String cleanValue = StringUtils.replaceChars(value, ", $", "");
		try {
			return new BigDecimal(cleanValue);
		} catch (Throwable e) {
			// LOGGER.error("BobUtil stringToValue error + " + e);
			return BigDecimal.ZERO;
		}
	}

	/**
	 * 
	 * @param value
	 * @return
	 */
	public static double stringToDouble(final String value) {
		try {
			return Double.parseDouble(value);
		} catch (Throwable e) {
			// LOGGER.error("BobUtil stringToDouble error + " + e);
		}
		return 0;
	}

	public static double stringAmtToDouble(final String value) {
		String amt = StringUtils.remove(StringUtils.trimToEmpty(value), "$");
		try {
			return Double.parseDouble(amt);
		} catch (Throwable e) {
			// LOGGER.error("BobUtil stringToDouble error + " + e);
		}
		return 0;
	}

	/**
	 * 
	 * @param value
	 * @return
	 */
	public static BigInteger stringToBigInt(final String value) {
		String cleanValue = StringUtils.replaceChars(value, ", $", "");
		try {
			return new BigInteger(cleanValue);
		} catch (Throwable e) {
			// LOGGER.error("BobUtil stringToValue error + " + e);
			return BigInteger.ZERO;
		}
	}

	/**
	 * 
	 * @param value
	 * @return
	 */
	public static int stringToInt(final String value) {
		try {
			return Integer.parseInt(value);
		} catch (Throwable e) {
			// LOGGER.error("BobUtil stringToDouble error + " + e);
		}
		return 0;
	}

	/**
	 * remove all nulls from a list
	 * 
	 * @param dataList
	 */
	public static void removeNullFromList(final List<?> dataList) {
		dataList.removeAll(Collections.singleton(null));
	}

	public static Date createDate(final int day, final int month, int year) {
		Date date = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				FormatUtil.VIEW_DATE_FORMAT);
		try {
			date = dateFormat.parse(Integer.toString(month) + "/"
					+ Integer.toString(day) + "/" + Integer.toString(year));
		} catch (ParseException e) {
			// Ignore
		}
		return date;
	}

	public static boolean compareMaps(HashMap<String, String> map1,
			HashMap<String, String> map2) {
		boolean result = false;
		Set<String> allKeys = new HashSet<String>();
		allKeys.addAll(map1.keySet());
		allKeys.addAll(map2.keySet());
		for (final String key : allKeys) {
			if (map1.containsKey(key) && map2.containsKey(key)
					&& (map1.get(key).equalsIgnoreCase(map2.get(key)))) {
				result = true;
			} else {
				return false;
			}
		}
		return result;
	}

	

	public static String trimNullString(final String param) {
		String trimParam = StringUtils.trimToEmpty(param);
		if (StringUtils.equalsIgnoreCase(trimParam, "null")) {
			trimParam = "";
		}
		return trimParam;
	}

	public static String convertToDollar(final double amount) {
		NumberFormat numberFormat = NumberFormat.getCurrencyInstance();
		return numberFormat.format(amount);
	}

}
