package com.pru.sparc.common.constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@SuppressWarnings("serial")
public final class ProposalConstants {
	
	private ProposalConstants() {
		
	}
	
	public static final List<String> QUOTE_REASON_LIST = new ArrayList<String>() {
		{
			add("Add Product");
			add("Broker Change");
			add("Census: New or Change to Existing");
			add("Class Change");
			add("Commission Change");
			add("Error");
			add("Plan Design Change");
			add("Plan Design Exception Needed");
			add("Rate Relief/Rate Change");
			add("Remove Product");
			add("STD Experience");
			add("Initial Quote");
			add("Create Sold Version");
		}
	};

	public static final List<String> BILL_DELIVERY_METHOD_LIST = new ArrayList<String>() {
		{
			add("Mail");
			add("Internet");
		}
	};
	
	
	public static final List<String> BILL_METHOD_LIST = new ArrayList<String>() {
		{
			add("Roster");
			add("Client");
		}
	};
	
	public static final String VERSION_STATUS_ACCEPTED = "Accepted";
	public static final String VERSION_STATUS_PENDING = "Pending Rate Calculation";
	//public static final String VERSION_STATUS_OPENED = "Opened";
	public static final List<String> VERSION_STATUS_LIST = new ArrayList<String>() {
		{
			add(VERSION_STATUS_ACCEPTED);
			add("Declined");
			add("Pending Rate Calculation");
			add("Pending Underwriting");
			add("Released");
			add("Opened");
			add("Cancelled");
			add("Selected");
		}
	};
	
	
	public static final List<String> CONTACT_DOCUMENT_FORMAT_LIST = new ArrayList<String>() {
		{
			add("PDF");
			add("Paper");
		}
	};
	
	public static final HashMap<Integer,String> PERFORMANCE_GUARANTEE_LIFE_MAP = new HashMap<Integer,String>() {
		{
			put(1,"Claim Processing");
			put(2,"Claim Processing");
			put(3,"Transactional Quality");
			put(4,"Financial Accuracy");
			put(5,"Management Reports");
			put(6,"Renewals");
			put(7,"Medical Underwriting");
			put(8,"Medical Underwriting");
			put(9,"Immediate Payment Option");
			put(10,"Contracts");
			put(11,"Call Center");
			put(12,"Other");
		}
	};
	
	public static final HashMap<Integer,String> PERFORMANCE_GUARANTEE_LIFE_FIELD_MAP = new HashMap<Integer,String>() {
		{
			put(1,"95");
			put(2,"95-5");
			put(3,"98");
			put(4,"98");
			put(5,"B-B");
			put(6,"E");
			put(7,"0-B");
			put(8,"95-15-95-15");
			put(9,"E");
			put(10,"B-B");
			put(11,"80-20-5");
			put(12,"B");
		}
	};
	
	public static final HashMap<String,String> PLAN_PRODUCTS = new HashMap<String,String>() {
		{
			put("BL","Basic Life");
			put("OL","Optional Life");
			put("DL","Dependent Life");
			put("BAD","Basic AD&D");
			put("OAD","Optional AD&D");
			put("STD","Short Term Disability");
			put("LTD","Long Term Disability");
			put("DT","Dental");
		}
	};
	
	 public static final String PROPOSAL_STATUS_OPEN = "OPEN";
	 public static final String NEW_PROPOSAL_DESCRIPTION = "NEW PROPOSAL";
	 
	 public static final List<String> DENTAL_DECLINE_WITHDRAW_REASON = new ArrayList<String>() {
			{
				add("Decline - Broker Not Appointed");
				add("Decline - Client Risk");
				add("Decline - Employee Participation");
				add("Decline - Excessive Administrative Work");
				add("Decline - Industry");
				add("Decline - Lack Of Information");
				add("Decline - Not Competitive");
				add("Decline - Number Of Lives");
				add("Decline - Other");
				add("Decline - Persistency");
				add("Decline - Plan Design");
				add("Decline - No Strategy Memo Submitted");
				add("Withdraw - Lack Of Information");
				add("Withdraw - Not Competitive");
				add("Withdraw - Other");
				add("Withdraw - Plan Design");
			}
		};
		
		
		public static final List<String> LIFE_DISABILITY_DECLINE_WITHDRAW_REASON = new ArrayList<String>() {
			{
				add("Decline - Broker Not Appointed");
				add("Decline - Client Risk");
				add("Decline - Employee Participation");
				add("Decline - Excessive Administrative Work");
				add("Decline - Industry");
				add("Decline - Lack Of Information");
				add("Decline - Not Competitive");
				add("Decline - Number Of Lives");
				add("Decline - Other");
				add("Decline - Persistency");
				add("Decline - Plan Design");
				add("Decline - No Strategy Memo Submitted");
				add("Not Competitive - Disablity Rate");
				add("Not Competitive - In Rate Gurantee");
				add("Not Competitive - Lack Of Capability");
				add("Not Competitive - Sales/Producer Direction");
				add("Withdraw - Lack Of Information");
				add("Withdraw - Not Competitive");
				add("Withdraw - Other");
				add("Withdraw - Plan Design");
			}
		};

		public static final String RATE_OVERRIDE = "Y";
		public static final String RATE_NON_OVERRIDE = "N";
		public static final String OVERRIDE_ALLOWED = "Y";
		public static final String OVERRIDE_NOT_ALLOWED = "N";
		public static final String OVERRIDE_Y_INDICATOR = "Y";
		public static final String OVERRIDE_N_INDICATOR = "N";
}
