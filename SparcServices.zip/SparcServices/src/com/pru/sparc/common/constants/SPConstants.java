package com.pru.sparc.common.constants;

public class SPConstants {

}
