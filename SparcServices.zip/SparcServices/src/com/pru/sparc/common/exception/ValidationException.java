/**
 * 
 */
package com.pru.sparc.common.exception;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;





public class ValidationException extends Exception {

	// map to hold multiple error messages
	private List<ErrorMessage> errorList = new ArrayList<ErrorMessage>();
	
	//map to divide the error messages
	private Map<String,List<ErrorMessage>> errorMap = new LinkedHashMap<String,List<ErrorMessage>>();
	/**
	 * 
	 * @param screenCode String
	 * @param error String
	 */
	public ValidationException(final String screenCode, final String error) {
		errorList.add(new ErrorMessage(screenCode, error));
	}
	
	/**
	 * 
	 */
	public ValidationException() {
		super();
	}

	/**
	 * @param message String
	 * @param cause Throwable
	 */
	public ValidationException(final String message, final Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message String
	 */
	public ValidationException(final String message) {
		super(message);
	}

	/**
	 * @param cause Throwable
	 */
	public ValidationException(final Throwable cause) {
		super(cause);

	}
	/**
	 * 
	 * @return List<ErrorMessage>
	 */
	public List<ErrorMessage> getErrorList() {
		return errorList;
	}

	/**
	 * 
	 * @param screenCode String
	 * @param error Throwable
	 */
	public void addError(final String screenCode, final String error) {
		errorList.add(new ErrorMessage(screenCode, error));
	}

	public void addErrorList(final String key, final List<ErrorMessage> errorList) {
		errorMap.put(key, errorList);
	}
	
	public Map<String,List<ErrorMessage>> getErrorMap() {
		return errorMap;
	}

	public void setErrorMap(Map<String,List<ErrorMessage>> errorMap) {
		this.errorMap = errorMap;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
