package com.pru.sparc.common.exception;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.json.JsonExceptionHandler;

import com.pru.sparc.common.util.SparcConstants;


public class SparcExceptionHandler implements JsonExceptionHandler {
	
	public static final String MESSAGE_MODEL_KEY = "errorMsg";


	@SuppressWarnings("unchecked")
	@Override
	public void triggerException(Exception exception, Map model,
			HttpServletRequest arg2, HttpServletResponse arg3) throws Exception {
		
		if(exception instanceof DataAccessException) {
			model.put(MESSAGE_MODEL_KEY, ((DataAccessException) exception).getMessage());
		} else if (exception instanceof ValidationException) {
			
			if (((ValidationException) exception).getMessage() != null) {
				model.put(MESSAGE_MODEL_KEY, ((ValidationException) exception).getMessage());
			} else if (((ValidationException) exception).getMessage() == null) {
				if (((ValidationException) exception).getErrorMap()!= null) {
					model.put(MESSAGE_MODEL_KEY,((ValidationException) exception).getErrorMap());
				}
			}
		} 
		else {
			model.put(MESSAGE_MODEL_KEY, SparcConstants.GENERIC_UI_MSG);
		}
	}
}
