/**
 * 
 */
package com.pru.sparc.common.exception;

public class DataAccessException extends Exception {
	
private String errorCode;

	/**
	 * 
	 */
	public DataAccessException() {
		super();

	}

	/**
	 * @param message -
	 * @param cause -
	 */
	public DataAccessException(final String message, final Throwable cause) {
		super(message, cause);

	}

	/**
	 * @param message -
	 */
	public DataAccessException(final String message) {
		super(message);

	}

	/**
	 * @param cause -
	 */
	public DataAccessException(final Throwable cause) {
		super(cause);

	}
	
	/**
	 * 
	 * @param message -
	 * @param errorCode -
	 */
	public DataAccessException(final String message, final String errorCode) {
		super(message);
		this.errorCode = errorCode;
		
	}
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(final String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
