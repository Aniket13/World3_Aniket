package com.pru.sparc.common.exception;

/**
 * 
 * ErrorMessage.
 *
 */
public class ErrorMessage {

	private String screenCode;
	private String error;
	
	/**
	 * 
	 * @param screenCode -
	 * @param error -
	 */
	public ErrorMessage(final String screenCode, final String error) {
		this.screenCode = screenCode;
		this.error = error;
		
	}
	public String getscreenCode() {
		return screenCode;
	}
	public void setscreenCode(final String screenCode) {
		this.screenCode = screenCode;
	}
	public String getError() {
		return error;
	}
	
	public void setError(final String error) {
		this.error = error;
	}
	
	
}
