package com.pru.sparc.common.session;

import java.io.Serializable;

public class Attribute implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String attributeName;
	
	private Object attributeValue;

	public String getAttributeName() {
		return attributeName;
	}

	public Object getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public void setAttributeValue(Object attributeValue) {
		this.attributeValue = attributeValue;
	}

}

