package com.pru.sparc.common.session;

import org.springframework.beans.factory.annotation.Autowired;

import com.pru.sparc.bo.model.Proposal;

public class SparcCache {
	@Autowired
	private HttpSessionCacheProvider sparcSessionCache;
	private boolean isSessionCache;
	
	public final static String DATA_HOLDER_ATTR_NAME_CACHE = "DATA_HOLDER";
	public final static String PROPOSAL_HEADER_CACHE = "PROPOSAL_HEADER";
	
	public SparcCache() {}
	
	public SparcCache (boolean isSessionCache) {
		this.isSessionCache = isSessionCache;
	}
	
	//managed header details
	public Proposal getCachedProposal(String proposalId, int clientId) {
		Proposal proposal = null;
		if (isSessionCache) {
			proposal = (Proposal) sparcSessionCache.getFromCache(PROPOSAL_HEADER_CACHE, new HttpSessionCachingModel());	
		} 
		return proposal;
	}
	
	public void setCachedProposal (Proposal proposal) {
		if (isSessionCache) {
			sparcSessionCache.removeFromCache(PROPOSAL_HEADER_CACHE, new HttpSessionCachingModel());
			sparcSessionCache.putInCache(PROPOSAL_HEADER_CACHE, new HttpSessionCachingModel(), proposal);
		}
	}
	
	public void removeCachedProposal (String proposalId, int clientId) {
		Proposal proposal  = this.getCachedProposal(proposalId,clientId);
		proposal = null;
		setCachedProposal(proposal);
	}
}
