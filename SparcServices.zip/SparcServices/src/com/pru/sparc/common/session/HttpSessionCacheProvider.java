package com.pru.sparc.common.session;

import java.beans.PropertyEditor;
import java.io.Serializable;
import java.util.Enumeration;

import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springmodules.cache.CacheException;
import org.springmodules.cache.CachingModel;
import org.springmodules.cache.FatalCacheException;
import org.springmodules.cache.FlushingModel;
import org.springmodules.cache.provider.AbstractCacheProviderFacade;
import org.springmodules.cache.provider.CacheModelValidator;
import org.springmodules.cache.provider.ReflectionCacheModelEditor;

public class HttpSessionCacheProvider extends AbstractCacheProviderFacade{
	
	private CacheModelValidator cacheModelValidator;
	private static final String KEY_PREFIX = "SessionCache:";
	
	public HttpSessionCacheProvider() {
		cacheModelValidator = new HttpSessionModelValidator();
	}
	
	@Override
	public PropertyEditor getCachingModelEditor() {
		ReflectionCacheModelEditor editor = new ReflectionCacheModelEditor();
		editor.setCacheModelClass(HttpSessionCachingModel.class);
		return editor;
	}

	@Override
	public PropertyEditor getFlushingModelEditor() {
		ReflectionCacheModelEditor editor = new ReflectionCacheModelEditor();
		editor.setCacheModelClass(HttpSessionFlushingModel.class);
		return editor;
	}

	@Override
	public CacheModelValidator modelValidator() {
		return cacheModelValidator;
	}

	@Override
	protected boolean isSerializableCacheElementRequired() {
		return true;
	}

	@Override
	protected void onFlushCache(FlushingModel arg0) throws CacheException {
		HttpSession session = getHttpSession();
		Enumeration<?> names = session.getAttributeNames();
		while (names.hasMoreElements()) {
			String key = (String) names.nextElement();
			if (key.startsWith(KEY_PREFIX)) {
				session.removeAttribute(key);
			}
		}
	}

	@Override
	protected Object onGetFromCache(Serializable arg0, CachingModel arg1)
			throws CacheException {
		String key = buildKey(arg0);
		HttpSession session = getHttpSession();
		return session.getAttribute(key);
	}

	@Override
	protected void onPutInCache(Serializable arg0, CachingModel arg1,
			Object arg2) throws CacheException {
		String key = buildKey(arg0);
		getHttpSession().setAttribute(key, arg2);
	}

	@Override
	protected void onRemoveFromCache(Serializable arg0, CachingModel arg1)
			throws CacheException {
		String key = buildKey(arg0);
		getHttpSession().removeAttribute(key);	
	}

	@Override
	protected void validateCacheManager() throws FatalCacheException {
		// TODO Auto-generated method stub
		
	}
	
	protected HttpSession getHttpSession() {
		return ((ServletRequestAttributes) RequestContextHolder
			.currentRequestAttributes()).getRequest().getSession();
	}

	private String buildKey(final Serializable key) {
		return KEY_PREFIX + convertKey(key);
	}
	private String convertKey(final Serializable key) {
			return (String) key;
	}
	public String getSessionID() {
		return getHttpSession().getId();
	}
}
