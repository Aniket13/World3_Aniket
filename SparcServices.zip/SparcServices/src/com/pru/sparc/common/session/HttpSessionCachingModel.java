package com.pru.sparc.common.session;

import org.springmodules.cache.CachingModel;

@SuppressWarnings("serial")
public class HttpSessionCachingModel implements CachingModel{

}
