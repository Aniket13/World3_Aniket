package com.pru.sparc.common.session;

import java.io.Serializable;
import java.util.Enumeration;

import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
public class SessionManager implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final static String DATA_HOLDER_ATTR_NAME = "DATA_HOLDER";
	public final static String DATA_HEADER_ATTR_NAME = "DATA_HEADER";
	public final static String USER = "USER";

	public static void storeInSession(HttpSession session, Attribute object) {

		if (session != null) {
			session.setAttribute(object.getAttributeName(),
					object);
		}
	}

	public static Attribute retriveFromSession(HttpSession session, String attributeName) {
		if (session != null) {
			return (Attribute) session.getAttribute(attributeName);
		}
		return null;
	}
	
	public static void removeFromSession(HttpSession session, String attributeName) {
		if (session != null) {
			session.removeAttribute(attributeName);
		}		
	}

	@SuppressWarnings("unchecked")
	public static void cleanSession(HttpSession session) {

		if (session != null) {
			Enumeration<String> attributeNames = session.getAttributeNames();

			while (attributeNames.hasMoreElements()) {
				session.removeAttribute(attributeNames.nextElement());
			}
		}

	}

	public static void killSession(HttpSession session) {

		if (session != null && !(session.isNew())) {
			session.invalidate();
		}
	}
	
	public static HttpSession getHttpSession() {
		return ((ServletRequestAttributes) RequestContextHolder
			.currentRequestAttributes()).getRequest().getSession();
	}
	
}
