package com.pru.sparc.common.session;

import org.springmodules.cache.provider.AbstractCacheModelValidator;

@SuppressWarnings("rawtypes")
public class HttpSessionModelValidator extends AbstractCacheModelValidator {

	@Override
	protected Class getCachingModelTargetClass() {
		return HttpSessionCachingModel.class;
	}

	@Override
	protected Class getFlushingModelTargetClass() {
		return HttpSessionFlushingModel.class;
	}

}
