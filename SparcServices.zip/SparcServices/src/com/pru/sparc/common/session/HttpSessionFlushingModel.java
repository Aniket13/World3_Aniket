package com.pru.sparc.common.session;

import org.springmodules.cache.provider.AbstractFlushingModel;

@SuppressWarnings("serial")
public class HttpSessionFlushingModel extends AbstractFlushingModel {

}
