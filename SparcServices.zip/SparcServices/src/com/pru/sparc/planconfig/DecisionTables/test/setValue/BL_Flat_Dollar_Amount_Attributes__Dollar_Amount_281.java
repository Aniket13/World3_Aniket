package com.pru.sparc.planconfig.DecisionTables.test.setValue;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;




public class BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_281 {

	

	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_280_Rule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");
		System.out.println("Current Date="+plan.getCurrentDate());
		
		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM1.setFieldValue("true");
		
		
		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.IS_USER_EXCEPTION_ROLE_ATTRIBUTE);
		planM2.setFieldValue("false");
		
		PlanMetadata planM3 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION);
		planM2.setFieldValue("45");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		planM2.setFieldValue("10");
		
		
		
		
		//planM1.setFieldValue("0");
		/*PlanConfigLookup plnConfig1= new PlanConfigLookup();
		plnConfig1.setLookupKey("Plan_Contribution_Attributes__Volatility_Caveat_Percentage");
		plnConfig1.setLookupValue("10.0");
		plnConfig1.setLookupOrder(4);
		
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Plan_Contribution_Attributes__Volatility_Caveat_Percentage", plnConfig1);
		
		planObj.setAltValues(altMap);*/
		
		
		
		
		
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE,planM1);
		plan.getPlanMap().put(PlanConfigConstants.IS_USER_EXCEPTION_ROLE_ATTRIBUTE,planM2);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION,planM3);
		plan.getPlanMap().put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,planM4);
		
		/*System.out
				.println("Plan_Contribution_Attributes__Volatility_Caveat_Percentage:="
						+ Float.parseFloat(plan.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR)
								.getAltValues()
								.get("Plan_Contribution_Attributes__Volatility_Caveat_Percentage")
								.getLookupValue()));*/
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_281.xls",
						"", new Object[] { plan});

		/*assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE).getFieldValue(),
				"75.0",
				plan.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE).getFieldValue());*/	
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
