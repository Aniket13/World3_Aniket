package com.pru.sparc.planconfig.DecisionTables.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class BLCompositeRating {

	

	@Test
	public void test_BLCompositeRating_Rule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		/*....Plan Composite Rating Start .....*/
		PlanMetadata planCompRat = new PlanMetadata();
		
		
		PlanConfigLookup plnConfNo= new PlanConfigLookup();
		plnConfNo.setLookupKey("Age_Banded_Rating__No");
		plnConfNo.setLookupValue("No");
		plnConfNo.setLookupOrder(1);
		
		PlanConfigLookup plnConfYes= new PlanConfigLookup();
		plnConfYes.setLookupKey("Age_Banded_Rating__Yes");
		plnConfYes.setLookupValue("Yes");
		plnConfYes.setLookupOrder(2);
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Age_Banded_Rating__Yes", plnConfYes);
		altMap.put("Age_Banded_Rating__No", plnConfNo);
		
		planCompRat.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.COMP_RATING,planCompRat);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//BL_Composite_Rating.xls",
						"", new Object[] { plan});

		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.COMP_RATING).getFieldValue(),
				"Age_Banded_Rating__No",
				plan.getPlanMap().get(PlanConfigConstants.COMP_RATING).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
