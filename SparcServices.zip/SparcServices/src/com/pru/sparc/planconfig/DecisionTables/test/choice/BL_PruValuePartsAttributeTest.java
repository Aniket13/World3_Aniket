package com.pru.sparc.planconfig.DecisionTables.test.choice;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;



public class BL_PruValuePartsAttributeTest {

	

	@Test
	public void test_PruValuePartsAttribute_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		/*....Plan PruValueParts_Attribute Start .....*/
		PlanMetadata planCompRat = new PlanMetadata();
		
		
		PlanConfigLookup plnConfOne= new PlanConfigLookup();
		plnConfOne.setLookupKey("Grandfathering");
		plnConfOne.setLookupValue("Grandfathering");
		plnConfOne.setLookupOrder(1);
		
		PlanConfigLookup plnConfTwo= new PlanConfigLookup();
		plnConfTwo.setLookupKey("PruValue_GA");
		plnConfTwo.setLookupValue("PruValue GA");
		plnConfTwo.setLookupOrder(2);
		
		PlanConfigLookup plnConfThree= new PlanConfigLookup();
		plnConfThree.setLookupKey("PruValue_IFS");
		plnConfThree.setLookupValue("PruValue IFS");
		plnConfThree.setLookupOrder(3);
		
		PlanConfigLookup plnConfFour= new PlanConfigLookup();
		plnConfFour.setLookupKey("PruValue_LDSM");
		plnConfFour.setLookupValue("PruValue LDSM");
		plnConfFour.setLookupOrder(4);
		
		
		PlanConfigLookup plnConfFive= new PlanConfigLookup();
		plnConfFive.setLookupKey("PruValue_Mid_Large_Market");
		plnConfFive.setLookupValue("PruValue Mid Large Market");
		plnConfFive.setLookupOrder(5);
		
		PlanConfigLookup plnConfSix= new PlanConfigLookup();
		plnConfSix.setLookupKey("PruValue_NPV");
		plnConfSix.setLookupValue("PruValue NPV");
		plnConfSix.setLookupOrder(6);
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Grandfathering", plnConfOne);
		altMap.put("PruValue_GA", plnConfTwo);
		altMap.put("PruValue_IFS", plnConfThree);
		altMap.put("PruValue_LDSM", plnConfFour);
		altMap.put("PruValue_Mid_Large_Market", plnConfFive);
		altMap.put("PruValue_NPV", plnConfSix);
		
		planCompRat.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.PRUVALUEPARTS_ATTRIBUTE,planCompRat);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//choice//BL_PruValueParts_Attribute.xls",
						"", new Object[] { plan});

		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.PRUVALUEPARTS_ATTRIBUTE).getFieldValue(),
				"Grandfathering",
				plan.getPlanMap().get(PlanConfigConstants.PRUVALUEPARTS_ATTRIBUTE).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
