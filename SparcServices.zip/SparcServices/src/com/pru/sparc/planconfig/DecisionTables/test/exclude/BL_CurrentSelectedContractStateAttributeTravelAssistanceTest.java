package com.pru.sparc.planconfig.DecisionTables.test.exclude;

import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;



public class BL_CurrentSelectedContractStateAttributeTravelAssistanceTest {
	
	@Test
	public void test_CurrentSelectedContractStateAttribute_Rule_1_Travel_Assistance() throws ParseException {
		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		//....Plan Creation Date Start .....
		plan.setPlanCreationDate("12/31/2098");
		
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.TRAVEL_ASSISTANCE);
		
		PlanConfigLookup trvlAsstYes= new PlanConfigLookup();
		trvlAsstYes.setLookupKey("Travel_Assistance__Yes");
		trvlAsstYes.setLookupValue("Yes");
		trvlAsstYes.setLookupOrder(1);

		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Travel_Assistance__Yes", trvlAsstYes);
		
		planMetaD.setAltValues(altMap);
		
		
		PlanMetadata planMetaDContract = new PlanMetadata();
		planMetaDContract.setFieldKey("Current_Selected_Contract_State_Attribute");
		planMetaDContract.setFieldValue("MA");
		
		
		plan.getPlanMap().put(PlanConfigConstants.TRAVEL_ASSISTANCE,planMetaD);
		plan.getPlanMap().put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE,planMetaDContract);
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_CurrentSelectedContractState_Attribute_TravAssistance.xls",
						"", new Object[] { plan});
		

		assertTrue(plan.get(PlanConfigConstants.TRAVEL_ASSISTANCE).getAltValues().get("Travel_Assistance__Yes").getVisibleFlag().equals("No"));
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
	}
}
