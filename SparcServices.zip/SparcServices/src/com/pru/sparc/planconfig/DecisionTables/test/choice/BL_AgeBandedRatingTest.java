package com.pru.sparc.planconfig.DecisionTables.test.choice;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;



public class BL_AgeBandedRatingTest {

	

	@Test
	public void test_PruValuePartsAttribute_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		/*....Plan Age banded rating Start .....*/
		PlanMetadata planCompRat = new PlanMetadata();
		
		
		PlanConfigLookup plnConfOne= new PlanConfigLookup();
		plnConfOne.setLookupKey("Age_Banded_Rating__No");
		plnConfOne.setLookupValue("Age Banded Rating - No");
		plnConfOne.setLookupOrder(1);
		
		PlanConfigLookup plnConfTwo= new PlanConfigLookup();
		plnConfTwo.setLookupKey("Age_Banded_Rating__Yes");
		plnConfTwo.setLookupValue("Age Banded Rating - Yes");
		plnConfTwo.setLookupOrder(2);
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Age_Banded_Rating__No", plnConfOne);
		altMap.put("Age_Banded_Rating__Yes", plnConfTwo);
		
		planCompRat.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.AGE_BANDED_RATING,planCompRat);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//choice//BL_Age_Banded_Rating.xls",
						"", new Object[] { plan});

		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.AGE_BANDED_RATING).getFieldValue(),
				"Age_Banded_Rating__No",
				plan.getPlanMap().get(PlanConfigConstants.AGE_BANDED_RATING).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
