package com.pru.sparc.planconfig.DecisionTables.test.choice;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;



public class BL_PlanConfigEngineRuleTest {

	

	@Test
	public void test_BL_PlanConfigEngineChoiceRule_Rule_No_2(PlanDetailsMap planMap) {
		//PlanDetailsMap plan = planMap.getMockupPlanDtlMspData();
		PlanDetailsMap plan = new PlanDetailsMap();
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//choice//BL_Age_Banded_Rating.xls",
						"", new Object[] { plan});
		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.AGE_BANDED_RATING).getFieldValue(),
				"Age_Banded_Rating__No",
				plan.getPlanMap().get(PlanConfigConstants.AGE_BANDED_RATING).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
