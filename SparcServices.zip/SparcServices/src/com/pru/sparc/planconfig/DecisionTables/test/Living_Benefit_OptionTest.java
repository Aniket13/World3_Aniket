package com.pru.sparc.planconfig.DecisionTables.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class Living_Benefit_OptionTest {

	

	@Test
	public void test_Living_Benefit_OptionRule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		/*....Plan Composite Rating Start .....*/
		PlanMetadata planCompRat = new PlanMetadata();
		
		
		PlanConfigLookup Living_Benefit_Option__No= new PlanConfigLookup();
		Living_Benefit_Option__No.setLookupKey("Living_Benefit_Option__No");
		Living_Benefit_Option__No.setLookupValue("0.0");
		Living_Benefit_Option__No.setLookupOrder(1);
		
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Living_Benefit_Option__No", Living_Benefit_Option__No);
		
		
		planCompRat.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.LIFE_BENEFIT_OPTION,planCompRat);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//BL_Living_Benefit_Option.xls",
						"", new Object[] { plan});

		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.LIFE_BENEFIT_OPTION).getFieldValue(),
				"Living_Benefit_Option__No",
				plan.getPlanMap().get(PlanConfigConstants.LIFE_BENEFIT_OPTION).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
