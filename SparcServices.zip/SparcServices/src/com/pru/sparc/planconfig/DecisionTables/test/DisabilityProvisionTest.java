package com.pru.sparc.planconfig.DecisionTables.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class DisabilityProvisionTest {

	

	@Test
	public void test_DisabilityProvisionRule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		/*....Plan Composite Rating Start .....*/
		PlanMetadata planCompRat = new PlanMetadata();
		
		
		PlanConfigLookup Disability_Provision__Admin_Dis_S= new PlanConfigLookup();
		Disability_Provision__Admin_Dis_S.setLookupKey("Disability_Provision__Admin_Dis_S");
		Disability_Provision__Admin_Dis_S.setLookupValue("0.0");
		Disability_Provision__Admin_Dis_S.setLookupOrder(1);
		
		PlanConfigLookup Disability_Provision__Dis_A= new PlanConfigLookup();
		Disability_Provision__Dis_A.setLookupKey("Disability_Provision__Dis_A");
		Disability_Provision__Dis_A.setLookupValue("0.0");
		Disability_Provision__Dis_A.setLookupOrder(2);
		
		PlanConfigLookup Disability_Provision__Dis_S= new PlanConfigLookup();
		Disability_Provision__Dis_S.setLookupKey("Disability_Provision__Dis_S");
		Disability_Provision__Dis_S.setLookupValue("0.0");
		Disability_Provision__Dis_S.setLookupOrder(3);
		
		PlanConfigLookup Disability_Provision__Exception_of_Disability= new PlanConfigLookup();
		Disability_Provision__Exception_of_Disability.setLookupKey("Disability_Provision__Exception_of_Disability");
		Disability_Provision__Exception_of_Disability.setLookupValue("0.0");
		Disability_Provision__Exception_of_Disability.setLookupOrder(4);
		
		PlanConfigLookup Disability_Provision__None= new PlanConfigLookup();
		Disability_Provision__None.setLookupKey("Disability_Provision__None");
		Disability_Provision__None.setLookupValue("0.0");
		Disability_Provision__None.setLookupOrder(5);
		
		PlanConfigLookup Disability_Provision__Premium_Continuance= new PlanConfigLookup();
		Disability_Provision__Premium_Continuance.setLookupKey("Disability_Provision__Premium_Continuance");
		Disability_Provision__Premium_Continuance.setLookupValue("0.0");
		Disability_Provision__Premium_Continuance.setLookupOrder(6);
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Disability_Provision__Admin_Dis_S", Disability_Provision__Admin_Dis_S);
		altMap.put("Disability_Provision__Dis_A", Disability_Provision__Dis_A);
		altMap.put("Disability_Provision__Dis_S", Disability_Provision__Dis_S);
		altMap.put("Disability_Provision__Exception_of_Disability", Disability_Provision__Exception_of_Disability);
		altMap.put("Disability_Provision__None", Disability_Provision__None);
		altMap.put("Disability_Provision__Premium_Continuance", Disability_Provision__Premium_Continuance);
		
		planCompRat.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.DIASBLE_PROV,planCompRat);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//BL_Disability_Provision.xls",
						"", new Object[] { plan});

		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue(),
				"Disability_Provision__Admin_Dis_S",
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
