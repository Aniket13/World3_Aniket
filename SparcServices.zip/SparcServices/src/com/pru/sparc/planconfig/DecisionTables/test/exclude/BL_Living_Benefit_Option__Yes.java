package com.pru.sparc.planconfig.DecisionTables.test.exclude;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;



public class BL_Living_Benefit_Option__Yes {

	

	@Test
	public void test_BL_Living_Benefit_Option__Yes_Rule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		plan.setPlanCreationDate("08/04/2016");
		
		
		PlanMetadata planMetaD1 = new PlanMetadata();
		planMetaD1.setFieldKey(PlanConfigConstants.SUBPRODUCT_TYPE_ATTRIBUTE);
		
				
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.LIFE_BENEFIT_OPTION);
		
		PlanConfigLookup pllkp1= new PlanConfigLookup();
		pllkp1.setLookupKey("Living_Benefit_Option__No");
		pllkp1.setLookupValue("No");
		pllkp1.setLookupOrder(1);
		
		PlanConfigLookup pllkp2= new PlanConfigLookup();
		pllkp2.setLookupKey("Living_Benefit_Option__Yes");
		pllkp2.setLookupValue("Yes");
		pllkp2.setLookupOrder(2);
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Living_Benefit_Option__No", pllkp1);
		altMap.put("Living_Benefit_Option__Yes", pllkp2);
		
		planMetaD.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_TYPE_ATTRIBUTE,planMetaD1);
		plan.getPlanMap().put(PlanConfigConstants.LIFE_BENEFIT_OPTION,planMetaD);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_Living_Benefit_Option__Yes.xls",
						"", new Object[] { plan});

		/*assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.AMT_INSU).getFieldValue(),
				"Yes",
				plan.getPlanMap().get(PlanConfigConstants.AMT_INSU).getFieldValue());*/
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
