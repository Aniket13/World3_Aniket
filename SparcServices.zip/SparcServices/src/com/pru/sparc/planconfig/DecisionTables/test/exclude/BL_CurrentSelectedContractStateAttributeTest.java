package com.pru.sparc.planconfig.DecisionTables.test.exclude;

import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;



public class BL_CurrentSelectedContractStateAttributeTest {

	

	@Test
	public void test_CurrentSelectedContractStateAttribute_Rule_1_IL() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		plan.setPlanCreationDate("08/04/2016");
		
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.LBO_LIFE_EXPT);
		
		Map<String,PlanConfigLookup> altMap =  buildAltMap();
		
		planMetaD.setAltValues(altMap);
		
		
		PlanMetadata planMetaDContract = new PlanMetadata();
		planMetaDContract.setFieldKey("Current_Selected_Contract_State_Attribute");
		planMetaDContract.setFieldValue("IL");
		
		plan.getPlanMap().put(PlanConfigConstants.LBO_LIFE_EXPT,planMetaD);
		plan.getPlanMap().put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE,planMetaDContract);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_CurrentSelectedContractState_Attribute.xls",
						"", new Object[] { plan});

		assertTrue(plan.get(PlanConfigConstants.LBO_LIFE_EXPT).getAltValues().get("LBO_Life_Expectancy__12_months").getVisibleFlag().equals("No"));
		assertTrue(plan.get(PlanConfigConstants.LBO_LIFE_EXPT).getAltValues().get("LBO_Life_Expectancy__6_months").getVisibleFlag().equals("No"));
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}
	
	@Test
	public void test_CurrentSelectedContractStateAttribute_Rule_1_MA() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		plan.setPlanCreationDate("08/04/2016");
		
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.LBO_LIFE_EXPT);
		
		Map<String,PlanConfigLookup> altMap =  buildAltMap();
		
		planMetaD.setAltValues(altMap);
		
		
		PlanMetadata planMetaDContract = new PlanMetadata();
		planMetaDContract.setFieldKey("Current_Selected_Contract_State_Attribute");
		planMetaDContract.setFieldValue("MA");
		
		plan.getPlanMap().put(PlanConfigConstants.LBO_LIFE_EXPT,planMetaD);
		plan.getPlanMap().put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE,planMetaDContract);
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_CurrentSelectedContractState_Attribute.xls",
						"CurrentSelectedContractState_Attribute_6_12", new Object[] { plan});

		assertTrue(plan.get(PlanConfigConstants.LBO_LIFE_EXPT).getAltValues().get("LBO_Life_Expectancy__12_months").getVisibleFlag().equals("No"));
		assertTrue(plan.get(PlanConfigConstants.LBO_LIFE_EXPT).getAltValues().get("LBO_Life_Expectancy__6_months").getVisibleFlag().equals("No"));
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
	
	@Test
	public void test_CurrentSelectedContractStateAttribute_Rule_2_24() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		plan.setPlanCreationDate("08/04/2016");
		
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.LBO_LIFE_EXPT);
		
		Map<String,PlanConfigLookup> altMap =  buildAltMap();
		
		planMetaD.setAltValues(altMap);
		
		
		PlanMetadata planMetaDContract = new PlanMetadata();
		planMetaDContract.setFieldKey("Current_Selected_Contract_State_Attribute");
		planMetaDContract.setFieldValue("FL");
		
		plan.getPlanMap().put(PlanConfigConstants.LBO_LIFE_EXPT,planMetaD);
		plan.getPlanMap().put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE,planMetaDContract);
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_CurrentSelectedContractState_Attribute.xls",
						"", new Object[] { plan});

		assertTrue(plan.get(PlanConfigConstants.LBO_LIFE_EXPT).getAltValues().get("LBO_Life_Expectancy__24_months").getVisibleFlag().equals("No"));
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
	
	@Test
	public void test_CurrentSelectedContractStateAttribute_Rule_3_24() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		plan.setPlanCreationDate("08/04/2015");
		
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.LBO_LIFE_EXPT);
		
		Map<String,PlanConfigLookup> altMap =  buildAltMap();
		planMetaD.setAltValues(altMap);
		
		
		PlanMetadata planMetaDContract = new PlanMetadata();
		planMetaDContract.setFieldKey("Current_Selected_Contract_State_Attribute");
		planMetaDContract.setFieldValue("FL");
		
		plan.getPlanMap().put(PlanConfigConstants.LBO_LIFE_EXPT,planMetaD);
		plan.getPlanMap().put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE,planMetaDContract);
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_CurrentSelectedContractState_Attribute.xls",
						"CurrentSelectedContractState_Attribute_24_2", new Object[] { plan});

		assertTrue(plan.get(PlanConfigConstants.LBO_LIFE_EXPT).getAltValues().get("LBO_Life_Expectancy__24_months").getVisibleFlag().equals("No"));
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		
	}
	
	@Test
	public void test_CurrentSelectedContractStateAttribute_Rule_4_24() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		plan.setPlanCreationDate("08/04/2002");
		
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.LBO_LIFE_EXPT);
		
		Map<String,PlanConfigLookup> altMap =  buildAltMap();
		
		planMetaD.setAltValues(altMap);
		
		
		PlanMetadata planMetaDContract = new PlanMetadata();
		planMetaDContract.setFieldKey("Current_Selected_Contract_State_Attribute");
		planMetaDContract.setFieldValue("FL");
		
		plan.getPlanMap().put(PlanConfigConstants.LBO_LIFE_EXPT,planMetaD);
		plan.getPlanMap().put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE,planMetaDContract);
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_CurrentSelectedContractState_Attribute.xls",
						"CurrentSelectedContractState_Attribute_24_3", new Object[] { plan});

		assertTrue(plan.get(PlanConfigConstants.LBO_LIFE_EXPT).getAltValues().get("LBO_Life_Expectancy__24_months").getVisibleFlag().equals("No"));
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
	
	@Test
	public void test_CurrentSelectedContractStateAttribute_Rule_5_6() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		plan.setPlanCreationDate("12/31/2098");
		
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.LBO_LIFE_EXPT);
		
		Map<String,PlanConfigLookup> altMap =  buildAltMap();
		planMetaD.setAltValues(altMap);
		
		PlanMetadata planMetaDContract = new PlanMetadata();
		planMetaDContract.setFieldKey("Current_Selected_Contract_State_Attribute");
		planMetaDContract.setFieldValue("OK");
		
		
		plan.getPlanMap().put(PlanConfigConstants.LBO_LIFE_EXPT,planMetaD);
		plan.getPlanMap().put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE,planMetaDContract);
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_CurrentSelectedContractState_Attribute.xls",
						"", new Object[] { plan});
		
		assertTrue(plan.get(PlanConfigConstants.LBO_LIFE_EXPT).getAltValues().get("LBO_Life_Expectancy__6_months").getVisibleFlag().equals("No"));
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
	}
	
	public static Map<String,PlanConfigLookup> buildAltMap(){
		PlanConfigLookup pllkp12= new PlanConfigLookup();
		pllkp12.setLookupKey("LBO_Life_Expectancy__12_months");
		pllkp12.setLookupValue("12 months");
		pllkp12.setLookupOrder(1);
		
		PlanConfigLookup pllkp24= new PlanConfigLookup();
		pllkp24.setLookupKey("LBO_Life_Expectancy__24_months");
		pllkp24.setLookupValue("24 months");
		pllkp24.setLookupOrder(2);
		
		
		PlanConfigLookup pllkp6= new PlanConfigLookup();
		pllkp6.setLookupKey("LBO_Life_Expectancy__6_months");
		pllkp6.setLookupValue("6 months");
		pllkp6.setLookupOrder(3);
		
		
		PlanConfigLookup pllkpOther= new PlanConfigLookup();
		pllkpOther.setLookupKey("LBO_Life_Expectancy__Other");
		pllkpOther.setLookupValue("Other");
		pllkpOther.setLookupOrder(4);
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("LBO_Life_Expectancy__12_months", pllkp12);
		altMap.put("LBO_Life_Expectancy__24_months", pllkp24);
		altMap.put("LBO_Life_Expectancy__6_months", pllkp6);
		altMap.put("LBO_Life_Expectancy__Other", pllkpOther);
		return altMap;
	}
	
}
