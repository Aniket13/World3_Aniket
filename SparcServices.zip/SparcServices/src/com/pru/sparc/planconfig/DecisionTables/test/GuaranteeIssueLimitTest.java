package com.pru.sparc.planconfig.DecisionTables.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class GuaranteeIssueLimitTest {

	

	@Test
	public void test_GuaranteeIssueLimitRule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		/*....Plan Composite Rating Start .....*/
		PlanMetadata planCompRat = new PlanMetadata();
		
		
		PlanConfigLookup Guarantee_Issue_Limit__Dollar= new PlanConfigLookup();
		Guarantee_Issue_Limit__Dollar.setLookupKey("Guarantee_Issue_Limit__Dollar");
		Guarantee_Issue_Limit__Dollar.setLookupValue("0.0");
		Guarantee_Issue_Limit__Dollar.setLookupOrder(1);
		
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Guarantee_Issue_Limit__Dollar", Guarantee_Issue_Limit__Dollar);
		
		
		planCompRat.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.GURARNTEE_ISSUE_LIMIT,planCompRat);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//BL_Guarantee_Issue_Limit.xls",
						"", new Object[] { plan});

		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.GURARNTEE_ISSUE_LIMIT).getFieldValue(),
				"Guarantee_Issue_Limit__Dollar",
				plan.getPlanMap().get(PlanConfigConstants.GURARNTEE_ISSUE_LIMIT).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
