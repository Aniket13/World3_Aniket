package com.pru.sparc.processor;

import java.util.List;

import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.common.exception.ValidationException;
import com.pru.sparc.common.util.RatingDisPropertyRead;
import com.pru.sparc.drools.model.Holding;

@Component
public class RatingDisplayProcessor {
	
	public List<String> getDisplayKeys(){
		RatingDisPropertyRead ratDisProRead=new RatingDisPropertyRead();
		return ratDisProRead.getAllPersistKey();
	}
	
	public String getDispalyValues(String key){
		RatingDisPropertyRead ratDisProRead=new RatingDisPropertyRead();
		return ratDisProRead.getKeyDescription(key);
	}

	public void processInvokeRatingEngineRequest(int versionNumber) throws Exception {
		// TODO: validations
		
	}

	public void processLoadRatingDataRequest(RatingModel model) throws ValidationException {
		if (model.getPlanId() <= 0) {
			throw new ValidationException("Plan Id is missing");
		}
		//if (model.getRateId() <= 0) {
		//	throw new ValidationException("Rate Id is missing");
		//}
	}

	public void processSaveOverridesRequest(RatingModel model) throws ValidationException {
		if (model.getOverriddenValues() == null && model.getOverriddenValues().size() <= 0) {
			throw new ValidationException("Overriden values are missing");
		}
		if (model.getPlanId() <= 0) {
			throw new ValidationException("Plan Id is missing");
		}
		
	}
	
}
