package com.pru.sparc.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.Census;
import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.LookupInfo;
import com.pru.sparc.bo.model.Product;
import com.pru.sparc.bo.model.ProposalVersion;
import com.pru.sparc.bo.model.Quotation;
import com.pru.sparc.common.constants.ProposalConstants;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.QuotationDetails;
import com.pru.sparc.model.QuoteReasonLookup;


@Component
public class ProposalDetailsAdapter {

	public Quotation parseQuotationResponse(QuotationDetails quotationDetails, 
				List<CensusDetail> CensusDetailList, List<ProductDetails> productDetailList, List<LookupInfo> lookupList) {
		Quotation quotation = new Quotation();
		
		quotation.setVersionNumber(quotationDetails.getVersionNumber());
		quotation.setVersionDesc(quotationDetails.getVersionDesc());
		
		quotation.setBasicLife(quotationDetails.getBasicLife());
		quotation.setLtd(quotationDetails.getLtd());
		quotation.setProposalId(quotationDetails.getProposal().getProposalId());
		//All census information
		List<Census> censusList = new ArrayList<Census>();
		if (CensusDetailList != null && CensusDetailList.size() > 0) {
			for (CensusDetail CensusDetail : CensusDetailList) {
				Census census = new Census();
				census.setCensus_id(CensusDetail.getCensusId());
				census.setCensus_fl_Name(CensusDetail.getCensusName());
				censusList.add(census);
			}
		}
		quotation.setCensusList(censusList);
		//All Product information
		List<Product> productList = new ArrayList<Product>();
		if(CollectionUtils.isNotEmpty(productDetailList)){
			for(ProductDetails productDetails : productDetailList){
				Product product = new Product();
				product.setProductId(productDetails.getProductId());
				product.setProductDesc(String.valueOf(productDetails.getProductDescription()));
				productList.add(product);
			}
		}
		quotation.setProductList(productList);
		//current census information
		if (quotationDetails.getCensus() != null && quotationDetails.getCensus().getCensusId() > 0) {
			quotation.setSelectedCensus(String.valueOf(quotationDetails.getCensus().getCensusId()));
		}
		
		//Entire quote reason information
		List<String> quoteReasonList = new ArrayList<String>();
		for (LookupInfo lookupInfo : lookupList) {
			quoteReasonList.add(lookupInfo.getDescription());
		}
		quotation.setQuoteReasonOptions(quoteReasonList);//ProposalConstants.QUOTE_REASON_LIST);
		
		//selected quotes
		List<String> selectedQuoteReasons = new ArrayList<String>();
		if (quotationDetails.getQuoteReasons() != null && quotationDetails.getQuoteReasons().size() > 0) {
			Iterator<QuoteReasonLookup> it = quotationDetails.getQuoteReasons().iterator();
			while (it.hasNext()) {
				QuoteReasonLookup reason = (QuoteReasonLookup) it.next();
				selectedQuoteReasons.add(reason.getQuoteDesc());
			}
		}
		quotation.setSelectedQuoteReasons(selectedQuoteReasons);
		
		/*//All product information
		List<Product> productList = new ArrayList<Product>();
		Iterator<Entry<String, String>> productIterator = ProposalConstants.PLAN_PRODUCTS.entrySet().iterator();
		while (productIterator.hasNext()) {
			Entry<String, String> entry = productIterator.next();
			Product product = new Product();
			product.setProductId(entry.getKey());
			product.setProductDesc(entry.getValue());
		}
		quotation.setProductList(productList);*/
		
		//selected products
		//change: add according to inserted plan entries
		List<Integer> selectedQuoteProducts = new ArrayList<Integer>();
		if (quotationDetails.getPlans() != null && quotationDetails.getPlans().size() > 0) {
			for (PlanDetailsClass productPlanDetails : quotationDetails.getPlans()) {
				if (productPlanDetails.getOverId() == 0 ){/*&&
						 StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(productPlanDetails.getDisplayPlan()),PlanConfigConstants.PLAN_DISPLAY_YES)) {*/
					selectedQuoteProducts.add(Integer.parseInt(productPlanDetails.getProductCode()));
				}
			}
		}
		quotation.setSelectedQuoteProducts(selectedQuoteProducts);
		
		//bill delivery method
		quotation.setBillDeliveryMethodList(ProposalConstants.BILL_DELIVERY_METHOD_LIST);
		quotation.setBillingDeliveryMethod(quotationDetails.getBillDeliveryMethod());
		//Contact document format
		quotation.setDocFormatList(ProposalConstants.CONTACT_DOCUMENT_FORMAT_LIST);
		quotation.setDocumentFormat(quotationDetails.getContactDocFormat());
		//bill Method
		quotation.setBillMethodList(ProposalConstants.BILL_METHOD_LIST);
		quotation.setBillingMethod(quotationDetails.getBillMethod());
		//Version Status List
		quotation.setVersionStatusList(ProposalConstants.VERSION_STATUS_LIST);
		quotation.setVersionStatus(quotationDetails.getVersionStatus());
		
		quotation.setComment(quotationDetails.getComment());
		quotation.setRsmComment(quotationDetails.getRsmComment());
		
		quotation.setDentalReasonList(ProposalConstants.DENTAL_DECLINE_WITHDRAW_REASON);
		quotation.setDisabilityReasonList(ProposalConstants.LIFE_DISABILITY_DECLINE_WITHDRAW_REASON);
		quotation.setLifeReasonList(ProposalConstants.LIFE_DISABILITY_DECLINE_WITHDRAW_REASON);
		
		quotation.setDentalReason(quotationDetails.getDentalReason());
		quotation.setDisabilityReason(quotationDetails.getDisabilityReason());
		quotation.setLifeReason(quotationDetails.getLifeReason());
		return quotation;
	}

	public List<ProposalVersion> parseProposalVersions(Set<QuotationDetails> quotationDetailsSet) {
		List<ProposalVersion> versionList = new ArrayList<ProposalVersion>();
		if (CollectionUtils.isNotEmpty(quotationDetailsSet)) {
			for (QuotationDetails quote : quotationDetailsSet) {
				ProposalVersion version = new ProposalVersion();
				version.setProposalId(quote.getProposal().getProposalId());
				version.setVersionNumber(quote.getVersionNumber());
				if (quote.getVersionDesc() != null) {
					version.setVersionDesc(quote.getVersionDesc());
				}
				if (quote.getCensus() != null && quote.getCensus().getCensusName() != null) {
					version.setCensusDescription(quote.getCensus().getCensusName());
				}
				if (quote.getClonedFrom() > 0) {
					version.setClonedFrom(quote.getClonedFrom());
				}
				if (quote.getCreationDate() != null) {
					version.setCreationDate(quote.getCreationDate());
					SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM-dd-yyyy h.mm a");
					try {
						version.setCreationDateStr(dateFormat.format(quote.getCreationDate()));
					} catch (Exception e) {
						e.printStackTrace(); 				
					} 
				}
				versionList.add(version);
			}
		}
		return versionList;
	}

	public Commission parseCommissionResponse(
			ProposalBrokerDetails prBrokerDetails) {
		Commission commission = new Commission();
		commission.setAdvanceCommission(prBrokerDetails.getAdvComm());
		commission.setAdvaceCommissionOccurs(prBrokerDetails.getAdvCommOccurs());
		commission.setArrangement(prBrokerDetails.getArrangement());
		commission.setCommissionSplit(prBrokerDetails.getCommissionSplit());
		commission.setCommissionPaidTo(prBrokerDetails.getCommPaidTo());
		commission.setFlatAmount(prBrokerDetails.getFlatAmount());
		commission.setFlatPercentage(prBrokerDetails.getFlatPercentage());
		commission.setBrokerID(prBrokerDetails.getBrokerDetails().getBrokerId());
		commission.setProposalPlanID(prBrokerDetails.getProPlanId());
		commission.setAdvanceCommissionFlag(prBrokerDetails.getAdvanceCommissionFlag());
		commission.setVersionNumber(prBrokerDetails.getVersionDetails().getVersionNumber());
		return commission;
	}
}
