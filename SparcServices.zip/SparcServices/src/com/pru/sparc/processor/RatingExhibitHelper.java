package com.pru.sparc.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.common.constants.ProposalConstants;
import com.pru.sparc.common.util.CommonUtils;
import com.pru.sparc.common.util.SparcUIToREInputValues;
import com.pru.sparc.dao.CensusMemberDtlRepository;
import com.pru.sparc.dao.PlanDetailsRepository;
import com.pru.sparc.dao.ProposalRepository;
import com.pru.sparc.dao.RatingQuoteDAO;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Comission;
import com.pru.sparc.drools.model.CommissionConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.RatingOutputConstants;
import com.pru.sparc.drools.model.RuleRatingAggregatedCensusGrp;
import com.pru.sparc.drools.model.RuleRatingCensusCompGrp;
import com.pru.sparc.drools.model.RuleRatingModelOverrideGrp;
import com.pru.sparc.drools.model.RuleRatingModelRuleResultGrp;
import com.pru.sparc.drools.model.RuleRatingOutputModelWrapper;
import com.pru.sparc.drools.model.RuleRatingProposalPlanDetails;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.model.State;
import com.pru.sparc.drools.model.StateConstants;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.RatingAggregatedCensus;
import com.pru.sparc.model.RatingExhibits;
import com.pru.sparc.model.RatingOverride;
import com.pru.sparc.model.RatingProposalPlanDetails;
import com.pru.sparc.model.RatingQuoteCensus;
import com.pru.sparc.model.RatingRuleResult;

@Component
public class RatingExhibitHelper {

	@Autowired
	PlanDetailsRepository planDetailsRepository;
	
	@Autowired
	CensusMemberDtlRepository censusMemberDtlRepository;
	
	@Autowired
	private RatingQuoteDAO ratingQuoteDAO;
	
	@Autowired
	ProposalRepository proposalRepository;
	
	@Autowired
	SparcUIToREInputValues sparcUIToREInputValues;

	public RatingExhibits mapToRatingResultObject(
			RuleRatingOutputModelWrapper response, PlanDetailsClass plan, RatingExhibits ratingExhibitsEntity) {
		boolean isUpdate = false;
		if (ratingExhibitsEntity == null) {
			ratingExhibitsEntity = new RatingExhibits();
			isUpdate = false;
		} else {
			isUpdate = true;
			response.setRateId(ratingExhibitsEntity.getRateId());
		}
		
		if (response.isOverriddenPlanRating()) {
			ratingExhibitsEntity.setOverId(ProposalConstants.RATE_OVERRIDE);
		} else {
			ratingExhibitsEntity.setOverId(ProposalConstants.RATE_NON_OVERRIDE);
		}
		
		// set Plan Id
		ratingExhibitsEntity.setPlan(plan);

		// override details

		List<RatingOverride> overrideEntityList = 
						setRatingOverrideDetails(response.getRatingModelOverideGrp(),ratingExhibitsEntity,isUpdate);
		ratingExhibitsEntity.setRatingOverride(overrideEntityList);

		// census aggregated details

		List<RatingAggregatedCensus> aggregatedCensusEntityList = 
						setRatingAggregatedCensusList(response.getRatingAggregatedCensusGrp(),ratingExhibitsEntity,isUpdate);
		ratingExhibitsEntity.setRatingAggregatedCensus(aggregatedCensusEntityList);

		// Proposal Plan details
		RatingProposalPlanDetails proposalPlanDetailsEntity = 
						setRatingProposalPlanDetails(response.getProposalPlanDetails(),ratingExhibitsEntity,isUpdate);
		ratingExhibitsEntity.setRatingProposalPlanDetails(proposalPlanDetailsEntity);

		// census group details

		List<RatingQuoteCensus> quoteCensusEntityList = 
						setRatingQuoteCensus(response.getRatingCensusCompGrp(),ratingExhibitsEntity,isUpdate);
		ratingExhibitsEntity.setRatingQuoteCensus(quoteCensusEntityList);

		// Rule result details
		List<RatingRuleResult> ruleResultEntityList = 
						setRatingRuleResult(response.getRatingRuleResultGrp(),ratingExhibitsEntity,isUpdate);
		ratingExhibitsEntity.setRatingRuleResult(ruleResultEntityList);

		return ratingExhibitsEntity;
	}

	private List<RatingOverride> setRatingOverrideDetails(
			List<ArrayList<RuleRatingModelOverrideGrp>> ratingModelOverideGrp, 
			RatingExhibits ratingExhibitsEntity, boolean isUpdate) {
		List<RatingOverride> overrideEntityList = null;
		if (isUpdate) {
			overrideEntityList = ratingExhibitsEntity.getRatingOverride();
		} else {
			overrideEntityList = new ArrayList<RatingOverride>();
		}
		List<RuleRatingModelOverrideGrp> listRatingOverGrp = new ArrayList<RuleRatingModelOverrideGrp>();
		if (CollectionUtils.isNotEmpty(ratingModelOverideGrp)) {
			for (ArrayList<RuleRatingModelOverrideGrp> modelList : ratingModelOverideGrp) {
				listRatingOverGrp.addAll(modelList);
			}
		}

		if (CollectionUtils.isNotEmpty(listRatingOverGrp)) {
			int index = 0;
			for (RuleRatingModelOverrideGrp objOverrride : listRatingOverGrp) {
				RatingOverride ratingOverrideEntity = null;
				if (isUpdate) {
					ratingOverrideEntity = overrideEntityList.get(index);
					index++;
				} else {
					ratingOverrideEntity = new RatingOverride();
				}
				ratingOverrideEntity.setFieldKey(StringUtils.trimToEmpty(objOverrride.getFieldKey()));
				ratingOverrideEntity.setFieldValue(objOverrride.getFieldValue());
				ratingOverrideEntity.setGroupId(StringUtils.trimToEmpty(objOverrride.getGroupId()));
				ratingOverrideEntity.setOverrideAllowed(CommonUtils.convertBooleanToStr(objOverrride.isOverrideAllowed()));
				ratingOverrideEntity.setOverrideIndicator((CommonUtils.convertBooleanToStr(objOverrride.isOverrideIndicator())));
				ratingOverrideEntity.setOverrideValue(objOverrride.getOverrideValue());
				
				ratingOverrideEntity.setUwApproval(StringUtils.trimToEmpty(CommonUtils.convertBooleanToStr(objOverrride.isUwApproval())));
				ratingOverrideEntity.setApprovingUW(StringUtils.trimToEmpty(objOverrride.getApprovingUW()));
				ratingOverrideEntity.setUwEvalulation(StringUtils.trimToEmpty(objOverrride.getUwEvaluation()));
				if (objOverrride.getApprovalDate() != null) {
					ratingOverrideEntity.setApprovalDate(objOverrride.getApprovalDate());
				}

				ratingOverrideEntity.setRatingExhibits(ratingExhibitsEntity);
				overrideEntityList.add(ratingOverrideEntity);
			}
		}

		return overrideEntityList;
	}

	private List<RatingAggregatedCensus> setRatingAggregatedCensusList(
			List<RuleRatingAggregatedCensusGrp> ratingAggregatedCensusGrp, 
			RatingExhibits ratingExhibitsEntity, boolean isUpdate) {
		List<RatingAggregatedCensus> aggregatedCensusEntityList = null;

		if (isUpdate) {
			aggregatedCensusEntityList = ratingExhibitsEntity.getRatingAggregatedCensus();
		} else {
			aggregatedCensusEntityList = new ArrayList<RatingAggregatedCensus>();
		}
		
		if (CollectionUtils.isNotEmpty(ratingAggregatedCensusGrp)) {
			int index = 0;
			for (RuleRatingAggregatedCensusGrp objAggregatedCensus : ratingAggregatedCensusGrp) {
				RatingAggregatedCensus ratingAggregatedCensusEntity = null;
				if (isUpdate) {
					ratingAggregatedCensusEntity = aggregatedCensusEntityList.get(index);
					index++;
				} else {
					ratingAggregatedCensusEntity = new RatingAggregatedCensus();
				}
				ratingAggregatedCensusEntity.setAgeBracket(StringUtils.trimToEmpty(objAggregatedCensus.getAgeBracket()));
				ratingAggregatedCensusEntity.setStatus(StringUtils.trimToEmpty(objAggregatedCensus.getStatus()));
				ratingAggregatedCensusEntity.setGender(StringUtils.trimToEmpty(objAggregatedCensus.getGender()));
				ratingAggregatedCensusEntity.setLives(objAggregatedCensus.getLives());
				ratingAggregatedCensusEntity.setCoveredVolume(objAggregatedCensus.getCoveredVolume());
				ratingAggregatedCensusEntity.setNonPooledVolume(objAggregatedCensus.getNonPooledVolume());
				ratingAggregatedCensusEntity.setPooledVolume(objAggregatedCensus.getPooledVolume());
				ratingAggregatedCensusEntity.setNonPooledManualRate(objAggregatedCensus.getNonPooledManualRate());
				ratingAggregatedCensusEntity.setPooledManualRate(objAggregatedCensus.getPooledManualRate());
				ratingAggregatedCensusEntity.setGroupId(StringUtils.trimToEmpty(objAggregatedCensus.getGroupId()));
				ratingAggregatedCensusEntity.setRatingExhibits(ratingExhibitsEntity);
				aggregatedCensusEntityList.add(ratingAggregatedCensusEntity);
			}
		}
		return aggregatedCensusEntityList;
	}

	private RatingProposalPlanDetails setRatingProposalPlanDetails(
			RuleRatingProposalPlanDetails proposalPlanDetails, 
			RatingExhibits ratingExhibitsEntity, boolean isUpdate) {
		RatingProposalPlanDetails proposalPlanDetailsEntity = null;

		if (isUpdate) {
			proposalPlanDetailsEntity = ratingExhibitsEntity.getRatingProposalPlanDetails();
		} else {
			proposalPlanDetailsEntity = new RatingProposalPlanDetails();
		}
		
		if (proposalPlanDetails != null) {
			proposalPlanDetailsEntity.setProposalExhibitLives(proposalPlanDetails.getProposalExhibitLives());
			proposalPlanDetailsEntity.setProposalExhibitVolume(proposalPlanDetails.getProposalExhibitVolume());
			proposalPlanDetailsEntity.setProposalExhibitRate(proposalPlanDetails.getProposalExhibitRate());
			proposalPlanDetailsEntity.setProposalExhibitPremium(proposalPlanDetails.getProposalExhibitPremium());
			proposalPlanDetailsEntity.setCompositeRate(proposalPlanDetails.getCompositeRate());
			proposalPlanDetailsEntity.setEstLivesForPlan(proposalPlanDetails.getEstLivesForPlan());
			proposalPlanDetailsEntity.setEstLivesAllCompositePlan(proposalPlanDetails.getEstLivesAllCompositePlan());
			proposalPlanDetailsEntity.setEstVolumeForPlan(proposalPlanDetails.getEstVolumeForPlan());
			proposalPlanDetailsEntity.setEstVolumeAllCompositePlan(proposalPlanDetails.getEstVolumeAllCompositePlan());
			proposalPlanDetailsEntity.setMonthlyRates(proposalPlanDetails.getMonthlyRates());
			proposalPlanDetailsEntity.setManualRate(proposalPlanDetails.getManualRate());
			proposalPlanDetailsEntity.setMonthlyPremiumForPlan(proposalPlanDetails.getMonthlyPremiumForPlan());
			proposalPlanDetailsEntity.setMonthlyPremiumAllCompositePlan(proposalPlanDetails.getMonthlyPremiumAllCompositePlan());
			proposalPlanDetailsEntity.setGroupId(StringUtils.trimToEmpty(proposalPlanDetails.getGroupId()));
			proposalPlanDetailsEntity.setRatingExhibits(ratingExhibitsEntity);
		}
		return proposalPlanDetailsEntity;
	}

	private List<RatingQuoteCensus> setRatingQuoteCensus(
			List<RuleRatingCensusCompGrp> ratingCensusCompGrp, 
			RatingExhibits ratingExhibitsEntity, boolean isUpdate) {
		List<RatingQuoteCensus> quoteCensusEntityList = null;

		if (isUpdate) {
			quoteCensusEntityList = ratingExhibitsEntity.getRatingQuoteCensus();
		} else {
			quoteCensusEntityList = new ArrayList<RatingQuoteCensus>();
		}
		
		if (CollectionUtils.isNotEmpty(ratingCensusCompGrp)) {
			int index = 0;
			for (RuleRatingCensusCompGrp objRatingCensusCompGrp : ratingCensusCompGrp) {
				RatingQuoteCensus ratingQuoteCensusEntity = null;
				
				if (isUpdate) {
					ratingQuoteCensusEntity = quoteCensusEntityList.get(index);
					index++;
				} else {
					ratingQuoteCensusEntity = new RatingQuoteCensus();
				}
				
				ratingQuoteCensusEntity.setAgeBracket(objRatingCensusCompGrp.getAgeBracket());
				ratingQuoteCensusEntity.setTotalLives(objRatingCensusCompGrp.getTotalLives());
				ratingQuoteCensusEntity.setTotalCoveredVolume(objRatingCensusCompGrp.getTotalCoveredVolume());
				ratingQuoteCensusEntity.setMonthlyPremiumStepRate(objRatingCensusCompGrp.getMonthlyPayPremStepRate());
				ratingQuoteCensusEntity.setTableIRate(objRatingCensusCompGrp.getTableIRate());
				ratingQuoteCensusEntity.setCrossTableI(objRatingCensusCompGrp.getCrossTableRate());
				ratingQuoteCensusEntity.setFinalRate(objRatingCensusCompGrp.getFinalRate());
				ratingQuoteCensusEntity.setGroupId(StringUtils.trimToEmpty(objRatingCensusCompGrp.getGroupId()));
				ratingQuoteCensusEntity.setRatingExhibits(ratingExhibitsEntity);
				quoteCensusEntityList.add(ratingQuoteCensusEntity);
			}
		}
		return quoteCensusEntityList;
	}

	private List<RatingRuleResult> setRatingRuleResult(
			List<RuleRatingModelRuleResultGrp> ratingRuleResultGrp, 
			RatingExhibits ratingExhibitsEntity, 
			boolean isUpdate) {
		
		List<RatingRuleResult> ruleResultEntityList = null;

		if (isUpdate) {
			ruleResultEntityList = ratingExhibitsEntity.getRatingRuleResult();
		} else {
			ruleResultEntityList = new ArrayList<RatingRuleResult>();
		}
		
		if (CollectionUtils.isNotEmpty(ratingRuleResultGrp)) {
			int index = 0;
			for (RuleRatingModelRuleResultGrp objRatingModelRuleResultGrp : ratingRuleResultGrp) {
				
				
				RatingRuleResult ratingRuleResultEntity = null;
				
				if (isUpdate) {
					ratingRuleResultEntity = ruleResultEntityList.get(index);
					index++;
				} else {
					ratingRuleResultEntity = new RatingRuleResult();
				}
				
				ratingRuleResultEntity.setRuleDesc(StringUtils.trimToEmpty(objRatingModelRuleResultGrp.getRuleDesc()));
				ratingRuleResultEntity.setRuleResult(StringUtils.trimToEmpty(objRatingModelRuleResultGrp.getRuleResult()));
				ratingRuleResultEntity.setGroupId(StringUtils.trimToEmpty(objRatingModelRuleResultGrp.getGroupId()));
				ratingRuleResultEntity.setRatingExhibits(ratingExhibitsEntity);
				ruleResultEntityList.add(ratingRuleResultEntity);
			}
		}
		return ruleResultEntityList;
	}

	public Holding createRatingInputData(int proposalVersionId) {
		//PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();
		//RatingQuoteDaoImpl ratingQuoteDAO = new RatingQuoteDaoImpl();
		//SparcUIToREInputValues sparcUIToREInputValues = new SparcUIToREInputValues();
		
		List<HashMap<String, Object>> listOfPlans = planDetailsRepository.getDataListByPlan(proposalVersionId);
		Holding holding = new Holding();
		holding.setHoldingMap(setHoldingMap(proposalVersionId));
		// method to set hardcoded values for holding map
		setHoldingMapExtraValues(holding);
		if (CollectionUtils.isNotEmpty(listOfPlans)) {
			List<Plan> holdingPlanList = new ArrayList<Plan>();
			for (HashMap<String, Object> planMap : listOfPlans) {
				Plan plan = new Plan();
				mapPlanValues(planMap, plan);				
				Integer planId = (Integer) planMap.get(PlanConstants.PLAN_ID);

				//call the original row and pass to below method
				RatingExhibits originalRatingExhibits= ratingQuoteDAO.getPlanRatingDetails(planId,ProposalConstants.RATE_NON_OVERRIDE);
				if (originalRatingExhibits != null) {
					plan.setOverRideMap(this.getOverridenValuesInMap(originalRatingExhibits));
				} 
				

				List<Integer> classIdList = planDetailsRepository
						.getClassIdsForPlan(planId);

				Census census = retriveCensusdata(classIdList);
				retriveListOfStates(proposalVersionId,census);
				census.setCensusMap(setCensusMap(proposalVersionId));
				sparcUIToREInputValues.mapCensusValues(census.getCensusMap());				
				plan.setCensus(census);
				List<Comission> commissionList = mapComissions(planId, plan);
				plan.setListOfComission(commissionList);
				holdingPlanList.add(plan);
			}
			holding.setListOfPlans(holdingPlanList);
		}
		return holding;
	}
	
	private void retriveListOfStates(int proposalVersionId,Census census ) {
		
		List<HashMap<String, Object>> stateDetails = censusMemberDtlRepository
				.getStateDetails(proposalVersionId);
		
		ArrayList<State> listOfStates = new ArrayList<State>();
				
		for (HashMap<String, Object> stateMap : stateDetails) {
			
			State state = new State();
			state.setStateMap(stateMap);			
			sparcUIToREInputValues.castStateMap(state.getStateMap());
			listOfStates.add(state);				
		}
		census.setListOfStates(listOfStates);

		/*State state1 = new State();
		state1.put(StateConstants.STATE, "PA");
		state1.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.17333333333333334"));

		State state2 = new State();
		state2.put(StateConstants.STATE, "PA2");
		state2.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.022222222222222223"));

		State state3 = new State();
		state3.put(StateConstants.STATE, "HI");
		state3.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.1"));

		State state4 = new State();
		state4.put(StateConstants.STATE, "MA");
		state4.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.06888888888888889"));

		State state5 = new State();
		state5.put(StateConstants.STATE, "NJ1");
		state5.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.14222222222222222"));

		State state6 = new State();
		state6.put(StateConstants.STATE, "MA");
		state6.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.20444444444444446"));

		State state7 = new State();
		state7.put(StateConstants.STATE, "PA1");
		state7.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.03333333333333333"));

		State state8 = new State();
		state8.put(StateConstants.STATE, "NYC");
		state8.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.13333333333333333"));

		State state9 = new State();
		state9.put(StateConstants.STATE, "VT");
		state9.put(StateConstants.STATE_ALLOCATION_FACTOR, new SBigDecimal(
				"0.12222222222222222"));

		listOfStates.add(state1);
		listOfStates.add(state2);
		listOfStates.add(state3);
		listOfStates.add(state4);
		listOfStates.add(state5);
		listOfStates.add(state6);
		listOfStates.add(state7);
		listOfStates.add(state8);
		listOfStates.add(state9);

		census.setListOfStates(listOfStates);*/
		
		
	}

	private Census retriveCensusdata(List<Integer> classIdList) {
		//CensusMemberDtlRepositoryImpl censusMemberDtlRepository = new CensusMemberDtlRepositoryImpl();
		List<HashMap<String, Object>> memberList = censusMemberDtlRepository
				.getCensusMembersForEachClass(classIdList);
		Census census = mapPersonDetails(memberList);
		
		return census;
	}

	private Census mapPersonDetails(List<HashMap<String, Object>> memberList) {
		//SparcUIToREInputValues sparcUIToREInputValues = new SparcUIToREInputValues();
		Census census = new Census();
		ArrayList<Person> listOfPeople = new ArrayList<Person>();
		for (int i = 0; i < memberList.size(); i++) {
			Person person = new Person();
			person.setPeopleMap(memberList.get(i));
			sparcUIToREInputValues.castPersonValues(person.getPeopleMap());
			if(StringUtils.equalsIgnoreCase((String)memberList.get(i).get("RetrireeStatus"),"F")){
				person.getPeopleMap().put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_ACTIVE_STATUS);
				
			}else{
				person.getPeopleMap().put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_RETIREE_STATUS);
				
			}
			
			if(StringUtils.equalsIgnoreCase((String)memberList.get(i).get(PersonConstants.PEOPLE_GENDER),"F")){
				person.getPeopleMap().put(PersonConstants.PEOPLE_GENDER, "Female");
				
			}else if(StringUtils.equalsIgnoreCase((String)memberList.get(i).get(PersonConstants.PEOPLE_GENDER),"M")){
				person.getPeopleMap().put(PersonConstants.PEOPLE_GENDER, "Male");
				
			}
			
			listOfPeople.add(person);
		}
		census.setListOfPeople(listOfPeople);
		return census;
	}

	private List<Comission> mapComissions(Integer planId, Plan plan) {
		//PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();
		//SparcUIToREInputValues sparcUIToREInputValues = new SparcUIToREInputValues();
		
		List<HashMap<String, Object>> listofcommissions = planDetailsRepository
				.getCommissionDetailsForPlan(planId.toString());
		ArrayList<Comission> comissionsList = new ArrayList<Comission>();
		if (CollectionUtils.isNotEmpty(listofcommissions)) {
			for (HashMap<String, Object> objCommission : listofcommissions) {
				Comission commission = new Comission();
				commission.setCommissionMap(objCommission);
				mapCommissionsExtraValues(commission);
				sparcUIToREInputValues.castComissionValues(commission.getCommissionMap());
				sparcUIToREInputValues.mapComissionValues(commission.getCommissionMap());
				comissionsList.add(commission);
			}
		}
		return comissionsList;
	}

	private void mapPlanValues(HashMap<String, Object> planMap, Plan plan) {
		//SparcUIToREInputValues sparcUIToREInputValues = new SparcUIToREInputValues();
		plan.setPlanMap(planMap);		
		sparcUIToREInputValues.mapPlanValues(plan.getPlanMap());
		setPlanMapExtraValues(plan);
		sparcUIToREInputValues.castPlanMap(plan.getPlanMap());

	}

	private void mapCommissionsExtraValues(Comission commission) {
		
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_ADMINSYSDESIGN,"AdminSysDesignN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_CLAIMCONTROLPARTICIP,"ClaimControlParticipN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_CLAIMANALYSIS,"ClaimAnalysisN");
		commission.getCommissionMap().put(CommissionConstants. COMMISSION_BARGAINCONSULT,"BargainConsultN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_PROVISIONREVIEW,"ProvisionReviewN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_CUSTSATISFMONITOR,"CustSatisfMonitorN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_ENROLLASSIST,"EnrollAssistN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_MAINTAINRECORDS,"MaintainRecordsN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_PLANDOCASSIST,"PlanDocAssistN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_PLANCHANGECONSULT,"PlanChangeConsultN");
		commission.getCommissionMap().put(CommissionConstants.COMMISSION_SUPERVISINGAGENT,"SupervisingAgentN");		
	
	}
	
	private HashMap<String, Object> setHoldingMap(int proposalVersionId) {
		// call the method to retrieve the values from the tables
		//ProposalRepositoryImpl proposalRepository = new ProposalRepositoryImpl();
		HashMap<String, Object> holdingOutputMap = new HashMap<String, Object>();
		//query to fetch sales office
		List<HashMap<String, Object>> holdinglist = proposalRepository
				.getDataListByHolding(proposalVersionId);
		List<HashMap<String, Object>> holdinglistLives = proposalRepository
				.getDataListByHoldingLives(proposalVersionId);
		List<HashMap<String, Object>> holdinglistSic = proposalRepository
				.getDataListByHoldingSic(proposalVersionId);
		for (HashMap<String, Object> map : holdinglist) {
			holdingOutputMap.putAll(map);
		}
		for (HashMap<String, Object> mapSic : holdinglistSic) {
			holdingOutputMap.putAll(mapSic);
		}
		for (HashMap<String, Object> mapLives : holdinglistLives) {
			holdingOutputMap.putAll(mapLives);
		}
		//SparcUIToREInputValues sparcUIToREInputValues = new SparcUIToREInputValues();
		sparcUIToREInputValues.castHoldingMap(holdingOutputMap);
		return holdingOutputMap;

	}

	private HashMap<String, Object> setCensusMap(int proposalVersionId) {
		//SparcUIToREInputValues sparcUIToREInputValues = new SparcUIToREInputValues();
		//CensusMemberDtlRepositoryImpl censusMemberDtlRepository = new CensusMemberDtlRepositoryImpl();		
		HashMap<String, Object> censusDetails = censusMemberDtlRepository.getCensusDetails(proposalVersionId);
		sparcUIToREInputValues.castCensusMap(censusDetails);	
		
		return censusDetails;

	}

	private void setHoldingMapExtraValues(Holding holding) {
		holding.getHoldingMap().put(HoldingConstants.HOLDING_LIFE_100_PILOT, "Life_100_Pilot_No");
		holding.getHoldingMap().put(HoldingConstants.ADDQUOTED, "ADDQuotedN");
		holding.getHoldingMap().put(HoldingConstants.LTDQUOTED, "LTDQuotedN");
		holding.getHoldingMap().put(HoldingConstants.STDQUOTED, "STDQuotedN");
		holding.getHoldingMap().put(HoldingConstants.HOLDING_OLQUOTED, "OLQuotedN");
		holding.getHoldingMap().put(HoldingConstants.ROSTER_BILL_METHOD, "Mail");
		holding.getHoldingMap().put(HoldingConstants.LDSM_PILOT_REP, "LDSM_Pilot_Rep_No");
		holding.getHoldingMap().put(HoldingConstants.DENTAL_QUOTED, "DentalQuotedN");
		holding.getHoldingMap().put(HoldingConstants.PRU_VALUE, "PruValueYes");
		holding.getHoldingMap().put(HoldingConstants.RATING_TYPE, "Rating_Type_RFP");
		//holding.getHoldingMap().put(HoldingConstants.HOLDING_SALES_OFFICE, "New Jersey");
		holding.getHoldingMap().put(HoldingConstants.HOLDING_100_PILOT_CASE_INDICATOR,
				HoldingConstants.HOLDING_LIFE_100_PILOT);		
		holding.getHoldingMap().put(HoldingConstants.AGED_CENSUS, "AgedCensusNo");
		holding.getHoldingMap().put(HoldingConstants.RENEWAL, "RenewalNo");	
		holding.getHoldingMap().put(HoldingConstants.HOLDING_QL_QUOTED, "OLQuotedN");	
		
		holding.getHoldingMap().put(HoldingConstants.RATING_ENGINE_EFFECTIVE_DATE, "05/16/2016");
		holding.getHoldingMap().put(HoldingConstants.RATING_ENGINE_EFFECTIVE_DATETIME,
				"Mon May 16 10:00:00 EST 2016");
		holding.getHoldingMap().put(HoldingConstants.PROPOSALCREATIONDATE_TIMESTAMP, "Mon Aug 15 05:00:00 IST 2016");
		
		holding.getHoldingMap().put(HoldingConstants.PROPOSALEFFECTIVEDATE, "08/05/2017");
		
		
		//holding.getHoldingMap().put(HoldingConstants., "CompositeY");
		
	}

	private void setPlanMapExtraValues(Plan plan) {
		plan.getPlanMap().put(PlanConstants.PLAN_FILING_RETENTION, "FilingRetentionY");
		plan.getPlanMap().put(PlanConstants.BENEFICIARY_SERVICES, "BeneficiaryServicesN");
		
		Integer planId = (Integer)plan.getPlanMap().get(PlanConstants.PLAN_ID);
		plan.getPlanMap().put(PlanConstants.PLAN_CONSTANT, "07/01/2016");
		plan.getPlanMap().put(PlanConstants.ORIGINAL_PLAN_EFFECTIVE_DATE,
				"Fri Jan 01 00:00:00 IST 2016");	
		plan.getPlanMap().put(PlanConstants.PLAN_DISABILITYDURATION, "PriorToAge60");
		
		/*if(StringUtils.equalsIgnoreCase((String)plan.getPlanMap().get(PlanConstants.PLAN_TYPE),"FlatAmt")){
			
			if(planId == 840 || planId == 862 || planId == 863){
			plan.getPlanMap().put(PlanConstants.CASE_FLAT_AMT,new SBigDecimal(100000.0));
			}else if(planId == 843){
				plan.getPlanMap().put(PlanConstants.CASE_FLAT_AMT,new SBigDecimal(50000.0));
			}else if(planId == 866){
				plan.getPlanMap().put(PlanConstants.CASE_FLAT_AMT,new SBigDecimal(20000.0));
			}
		}
		if(StringUtils.equalsIgnoreCase((String)plan.getPlanMap().get(PlanConstants.PLAN_TYPE),"MultipleEarnings_FlatAmt")){
			if(planId == 848 || planId == 860){
				plan.getPlanMap().put(PlanConstants.CASE_FLAT_AMT,new SBigDecimal(10000.0));
			}else if(planId == 849||planId == 842){
				plan.getPlanMap().put(PlanConstants.CASE_FLAT_AMT,new SBigDecimal(25000.0));
			}else if(planId == 852){
				plan.getPlanMap().put(PlanConstants.CASE_FLAT_AMT,new SBigDecimal(15000.0));
			}
		}*/
	}

	public HashMap<String, Object> getOverridenValuesInMap(RatingExhibits overridenRatingExhibits) {
		HashMap<String,Object> overriddenValues = new HashMap<String,Object>(); 
		if (CollectionUtils.isNotEmpty(overridenRatingExhibits.getRatingOverride())) {
			for (RatingOverride overrideEntity : overridenRatingExhibits.getRatingOverride()) {
				if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(overrideEntity.getOverrideAllowed()), 
						ProposalConstants.OVERRIDE_ALLOWED)) {
					if (overrideEntity.getOverrideValue() != 0) {
						overriddenValues.put(RatingOutputConstants.OVERRIDEN_KEYS.get(overrideEntity.getFieldKey()), 
								new SBigDecimal(overrideEntity.getOverrideValue()));
					}
				}
			}
		}
		return overriddenValues;
	}

	public RatingExhibits createsaveOverridesRequestObject(RatingExhibits ratingExhibitsEntity, RatingModel model) {
		ratingExhibitsEntity = setOverridenValuesInEntity(ratingExhibitsEntity,model.getOverriddenValues());
		return ratingExhibitsEntity;
	}
	
	public RatingExhibits setOverridenValuesInEntity(RatingExhibits ratingExhibitsEntity, 
			HashMap<String, String> overriddenValues) {
		
		//clearing the previously selected values checked by the user - to handle the unchecked overrides on Rating Screen
		//if (overriddenValues != null & overriddenValues.size() > 0) {
			for (RatingOverride overrideEntity : ratingExhibitsEntity.getRatingOverride()) {
				if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(overrideEntity.getOverrideAllowed()), 
						ProposalConstants.OVERRIDE_ALLOWED)) {
					overrideEntity.setOverrideValue(0);						
					overrideEntity.setOverrideIndicator(ProposalConstants.OVERRIDE_N_INDICATOR);
				}
			}
		//}
		
		if (overriddenValues != null & overriddenValues.size() > 0) {
			for (RatingOverride overrideEntity : ratingExhibitsEntity.getRatingOverride()) {
				if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(overrideEntity.getOverrideAllowed()), 
						ProposalConstants.OVERRIDE_ALLOWED)) {
					if (overriddenValues.containsKey(String.valueOf(overrideEntity.getOverrideId()))) {
						overrideEntity.setOverrideValue(Double.parseDouble(overriddenValues.get(String.valueOf(overrideEntity.getOverrideId()))));						
						overrideEntity.setOverrideIndicator(ProposalConstants.OVERRIDE_Y_INDICATOR);
					}
				}
			}
		}
		return ratingExhibitsEntity;
	}	
	

	
}
