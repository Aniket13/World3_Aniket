package com.pru.sparc.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.beanutils.BeanPredicate;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.PredicateUtils;
import org.apache.commons.collections.functors.EqualPredicate;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.CensusCls;
import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.PlanBO;
import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsAggregator;
import com.pru.sparc.bo.model.PlanDetailsWrapper;
import com.pru.sparc.bo.model.PlanEligibility;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.exception.ErrorMessage;
import com.pru.sparc.common.exception.ValidationException;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.common.util.SparcConstants;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.dao.PlanDetailsRepository;
import com.pru.sparc.model.BrokerDetails;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.PlanEligibilityClass;
import com.pru.sparc.model.PlanWrapper;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.QuotationDetails;

@Component
public class PlanDetailsServiceProcessor {

	@Autowired
	private PlanDetailsRepository planDetailsRepository;
	
	public PlanDetailsClass mapToPlanDetailsClass(PlanDetailsClass planDetails, PlanDetailsAggregator planWrapper) {
		return convertToPlanDetailsClass(planDetails, planWrapper
				.getListOfPlanField());
	}

	public Map<String, List<PlanMetadata>> filterOverridenFields(
			List<PlanMetadata> planDetailsList, List<PlanMetadata> overriddenFields) {
		
		
		EqualPredicate tabEqlPredicate = new EqualPredicate("4");
	    BeanPredicate tabBeanPredicate = new BeanPredicate("tabId", tabEqlPredicate);
	    EqualPredicate flagEqlPredicate = new EqualPredicate("Y");
	    BeanPredicate flagBeanPredicate = new BeanPredicate("overriddenFlag", flagEqlPredicate);
	    
		
		Predicate[] allPredicateArray = { tabBeanPredicate, flagBeanPredicate };
		Predicate allPredicate = PredicateUtils.allPredicate(allPredicateArray);
		Collection<PlanMetadata> filteredCollection = CollectionUtils.select(planDetailsList, allPredicate);
		overriddenFields.addAll(filteredCollection);
		
		
		/*Map<String, List<PlanMetadata>> fieldListMap = new HashMap<String, List<PlanMetadata>>();
		Iterator<PlanMetadata> planIterator = planDetailsList
				.iterator();
		while (planIterator.hasNext()) {
			PlanMetadata planField = planIterator.next();
			if (StringUtils.equals(planField.getTabId(), "4")) {
				if(StringUtils.equalsIgnoreCase(planField.getOverriddenFlag(), "Y")){
					overriddenFields.add(planField);
				}
				planIterator.remove();
			}
		}
		fieldListMap.put("originalValues", planDetailsList);*/
		
		Map<String, List<PlanMetadata>> fieldListMap = new HashMap<String, List<PlanMetadata>>();
		fieldListMap.put("overriddenFields", overriddenFields);
		return fieldListMap;
	}

	public PlanDetailsClass mergePlanDetailsClassObjects(PlanDetailsClass planDetails,
			PlanDetailsClass planDetails2) {
		return SparcUtil.mergePlanDetailClassObjects(planDetails, planDetails2);
	}

	public List<PlanDetailsWrapper> getAllPlansMapping(
			List<PlanDetailsClass> allPlansForVersion) {

		List<PlanDetailsWrapper> detailsWrappersLst = new ArrayList<PlanDetailsWrapper>();
		PlanDetailsWrapper detailsWrapper = null;

		for (PlanDetailsClass detailsClass : allPlansForVersion) {
			detailsWrapper = new PlanDetailsWrapper();
			detailsWrapper.setEffDate(detailsClass.getEffectiveDate().toString());
			detailsWrapper
					.setPlanDescription(detailsClass.getPlanDescription());
			/*detailsWrapper
					.setPlanId(detailsClass.getPlanId());*/

			detailsWrappersLst.add(detailsWrapper);
		}

		return detailsWrappersLst;
	}

	public PlanDetailsWrapper getPlanMapped(PlanDetailsClass planDetails) {
		return null;
	}

	/**
	 * 
	 * @param existingPlanObject
	 * @param planDetails, PlanBO
	 * @return PlanDetailsClass
	 */
	public PlanDetailsClass mapToPlanDetailsClass(
			PlanDetailsClass existingPlanObject, PlanBO planDetails) {
		return createPlanDetailsRequest(existingPlanObject, planDetails);
	}

	private PlanDetailsClass createPlanDetailsRequest(PlanDetailsClass planDetails, PlanBO planModel){
		if(StringUtils.isNotBlank(planModel.getContractState())){
			planDetails.setContractState(planModel.getContractState());
		}
		if(StringUtils.isNotBlank(planModel.getEffectiveDate())){
			planDetails.setEffectiveDate(SparcUtil.convertStrToDate(planModel.getEffectiveDate()));
		}
		if(StringUtils.isNotBlank(planModel.getPlanDescription())){
			planDetails.setPlanDescription(planModel.getPlanDescription());
		}
		if(StringUtils.isNotBlank(planModel.getTypeOFCase())){
			planDetails.setTypeOfCase(planModel.getTypeOFCase());
		}
		if(StringUtils.isNotBlank(planModel.getPruValueExceptions())){
			planDetails.setPruValueException(planModel.getPruValueExceptions());
		}
		if(StringUtils.isNotBlank(planModel.getFieldLevelExceptions())){
			planDetails.setFieldLevelException(planModel.getFieldLevelExceptions());
		}
		if(StringUtils.isNotBlank(planModel.getContributionArrangement())){
			planDetails.setContributionArrangement(planModel.getContributionArrangement());
		}
		if(StringUtils.isNotBlank(planModel.getMinimumParticipationPercentage())){
			planDetails.setMinParticipationPct(Float.parseFloat(planModel.getMinimumParticipationPercentage()));
		}
		if(StringUtils.isNotBlank(planModel.getVolatilityCaveatPercentage())){
			planDetails.setVolatilityCaveatPct(Float.parseFloat(planModel.getVolatilityCaveatPercentage()));
		}
		if(StringUtils.isNotBlank(planModel.getCompositeRating())){
			planDetails.setCompositeRating(planModel.getCompositeRating());
		}
		if(StringUtils.isNotBlank(planModel.getAgeBandedRating())){
			planDetails.setAgeBandedRating(planModel.getAgeBandedRating());
		}
		if(StringUtils.isNotBlank(planModel.getRateGuarantee())){
			planDetails.setRateGurantee(Integer.parseInt(planModel.getRateGuarantee()));
		}
		if(StringUtils.isNotBlank(planModel.getRateExpression())){
			planDetails.setRateExpression(planModel.getRateExpression());
		}
		if(StringUtils.isNotBlank(planModel.getAmountOfInsurance())){
			planDetails.setInsuranceAmount(planModel.getAmountOfInsurance());
		}
		if(StringUtils.isNotBlank(planModel.getMaximumDollarAmount())){
			planDetails.setMaxDollaramt(Double.parseDouble(planModel.getMaximumDollarAmount()));
		}
		if(StringUtils.isNotBlank(planModel.getMinimumDollarAmount())){
			planDetails.setMinDollarAmt(Double.parseDouble(planModel.getMinimumDollarAmount()));
		}
		if(StringUtils.isNotBlank(planModel.getMultipleOfAnnualEarning())){
			planDetails.setMultipleOfEarnings(planModel.getMultipleOfAnnualEarning());
		}
		if(StringUtils.isNotBlank(planModel.getRoundingRule())){
			planDetails.setRoundingRule(planModel.getRoundingRule());
		}
		if(StringUtils.isNotBlank(planModel.getRoundingOccurs())){
			planDetails.setRoundingOccurs(planModel.getRoundingOccurs());
		}
		if(StringUtils.isNotBlank(planModel.getAgeReductionSchedule())){
			planDetails.setAgeReductionSchedule(planModel.getAgeReductionSchedule());
		}
		if(StringUtils.isNotBlank(planModel.getDisabilityProvision())){
			planDetails.setDisablityProvision(planModel.getDisabilityProvision());
		}
		if(StringUtils.isNotBlank(planModel.getDuration())){
			planDetails.setDuration(planModel.getDuration());
		}
		if(StringUtils.isNotBlank(planModel.getVolumeAmounts())){
			planDetails.setVolumeAmounts(planModel.getVolumeAmounts());
		}
		if(StringUtils.isNotBlank(planModel.getGuranteeIssueLimit())){
			planDetails.setGuranteeIssueLimit(planModel.getGuranteeIssueLimit());
		}
		if(StringUtils.isNotBlank(planModel.getDollarAmount())){
			planDetails.setDollarAmount(Double.parseDouble(planModel.getDollarAmount()));
		}
		if(StringUtils.isNotBlank(planModel.getLivingBenifitOption())){
			planDetails.setLivingBenefitOption(planModel.getLivingBenifitOption());
		}
		if(StringUtils.isNotBlank(planModel.getlBOMaximum())){
			planDetails.setLboMax(Double.parseDouble(planModel.getlBOMaximum()));
		}
		if(StringUtils.isNotBlank(planModel.getlBOPercentage())){
			planDetails.setLboPercent(Float.parseFloat(planModel.getlBOPercentage()));
		}
		if(StringUtils.isNotBlank(planModel.getlBOLifeExpectancy())){
			planDetails.setLboLifeExpectancy(planModel.getlBOLifeExpectancy());
		}
		if(StringUtils.isNotBlank(planModel.getCoverageTerminatesAtRetirement())){
			planDetails.setCoverageTerminateAtRetirement(planModel.getCoverageTerminatesAtRetirement());
		}
		if(StringUtils.isNotBlank(planModel.getTravelAssistance())){
			planDetails.setTravelAssistance(planModel.getTravelAssistance());
		}
		if(StringUtils.isNotBlank(planModel.getEarningDefination())){
			planDetails.setEarningDefiniton(planModel.getEarningDefination());
		}
		if(StringUtils.isNotBlank(planModel.getIncludeBonusInEarningDefination())){
			planDetails.setIncludeBonus(planModel.getIncludeBonusInEarningDefination());
		}
		if(StringUtils.isNotBlank(planModel.getIncludeCommisionInEarningDefination())){
			planDetails.setIncludeCommission(planModel.getIncludeCommisionInEarningDefination());
		}
		if(StringUtils.isNotBlank(planModel.getIncludeOvertimeInEarningDefination())){
			planDetails.setIncludeOvertime(planModel.getIncludeOvertimeInEarningDefination());
		}
		return planDetails;
	}

	public PlanDetailsClass createNewPlanRequest(QuotationDetails version, ProductDetails product) {
		PlanDetailsClass planDetailsClass = new PlanDetailsClass();
		planDetailsClass.setVersion(version);
		planDetailsClass.setProduct(product);
		planDetailsClass.setDisplayPlan("Y");
		planDetailsClass.setProductCode(String.valueOf(product.getProductId()));
		planDetailsClass.setContractState(version.getProposal().getContractState());
		planDetailsClass.setEffectiveDate(version.getProposal().getCaseEffectiveDt());
		//overId set to 0 for normal insertion and 1 for overridden values
		planDetailsClass.setOverId(0);
		return planDetailsClass;
	}

	public PlanBO mapPlanDetailsToPlanBO(PlanDetailsClass planDetailsClass) {
		PlanBO planDetails = new PlanBO();
		if(StringUtils.isNotBlank(planDetailsClass.getContractState())){
			planDetails.setContractState(planDetailsClass.getContractState());
		}
		if(null != planDetailsClass.getEffectiveDate()){
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			planDetails.setEffectiveDate(dateFormat.format(planDetailsClass.getEffectiveDate()));
		}
		if(StringUtils.isNotBlank(planDetailsClass.getPlanDescription())){
			planDetails.setPlanDescription(planDetailsClass.getPlanDescription());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getTypeOfCase())){
			planDetails.setTypeOFCase(planDetailsClass.getTypeOfCase());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getPruValueException())){
			planDetails.setPruValueExceptions(planDetailsClass.getPruValueException());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getFieldLevelException())){
			planDetails.setFieldLevelExceptions(planDetailsClass.getFieldLevelException());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getContributionArrangement())){
			planDetails.setContributionArrangement(planDetailsClass.getContributionArrangement());
		}
		planDetails.setMinimumParticipationPercentage(String.valueOf(planDetailsClass.getMinParticipationPct()));
		planDetails.setVolatilityCaveatPercentage(String.valueOf(planDetailsClass.getVolatilityCaveatPct()));
		if(StringUtils.isNotBlank(planDetailsClass.getCompositeRating())){
			planDetails.setCompositeRating(planDetailsClass.getCompositeRating());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getAgeBandedRating())){
			planDetails.setAgeBandedRating(planDetailsClass.getAgeBandedRating());
		}
		planDetails.setRateGuarantee(String.valueOf(planDetailsClass.getRateGurantee()));
		if(StringUtils.isNotBlank(planDetailsClass.getRateExpression())){
			planDetails.setRateExpression(planDetailsClass.getRateExpression());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getInsuranceAmount())){
			planDetails.setAmountOfInsurance(planDetailsClass.getInsuranceAmount());
		}
		planDetails.setMaximumDollarAmount(String.valueOf(planDetailsClass.getMaxDollaramt()));
		planDetails.setMinimumDollarAmount(String.valueOf(planDetailsClass.getMinDollarAmt()));
		if(StringUtils.isNotBlank(planDetailsClass.getMultipleOfEarnings())){
			planDetails.setMultipleOfAnnualEarning(planDetailsClass.getMultipleOfEarnings());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getRoundingRule())){
			planDetails.setRoundingRule(planDetailsClass.getRoundingRule());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getRoundingOccurs())){
			planDetails.setRoundingOccurs(planDetailsClass.getRoundingOccurs());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getAgeReductionSchedule())){
			planDetails.setAgeReductionSchedule(planDetailsClass.getAgeReductionSchedule());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getDisablityProvision())){
			planDetails.setDisabilityProvision(planDetailsClass.getDisablityProvision());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getDuration())){
			planDetails.setDuration(planDetailsClass.getDuration());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getVolumeAmounts())){
			planDetails.setVolumeAmounts(planDetailsClass.getVolumeAmounts());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getGuranteeIssueLimit())){
			planDetails.setGuranteeIssueLimit(planDetailsClass.getGuranteeIssueLimit());
		}
		planDetails.setDollarAmount(String.valueOf(planDetailsClass.getDollarAmount()));
		if(StringUtils.isNotBlank(planDetailsClass.getLivingBenefitOption())){
			planDetails.setLivingBenifitOption(planDetailsClass.getLivingBenefitOption());
		}
		planDetails.setlBOMaximum(String.valueOf(planDetailsClass.getLboMax()));
		planDetails.setlBOPercentage(String.valueOf(planDetailsClass.getLboPercent()));
		if(StringUtils.isNotBlank(planDetailsClass.getLboLifeExpectancy())){
			planDetails.setlBOLifeExpectancy(planDetailsClass.getLboLifeExpectancy());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getCoverageTerminateAtRetirement())){
			planDetails.setCoverageTerminatesAtRetirement(planDetailsClass.getCoverageTerminateAtRetirement());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getTravelAssistance())){
			planDetails.setTravelAssistance(planDetailsClass.getTravelAssistance());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getEarningDefiniton())){
			planDetails.setEarningDefination(planDetailsClass.getEarningDefiniton());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getIncludeBonus())){
			planDetails.setIncludeBonusInEarningDefination(planDetailsClass.getIncludeBonus());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getIncludeCommission())){
			planDetails.setIncludeCommisionInEarningDefination(planDetailsClass.getIncludeCommission());
		}
		if(StringUtils.isNotBlank(planDetailsClass.getIncludeOvertime())){
			planDetails.setIncludeOvertimeInEarningDefination(planDetailsClass.getIncludeOvertime());
		}
		return planDetails;
	}
	
	public Map<String, PlanMetadata> convertToPlanMap(List<PlanMetadata> planFields){
		Map<String, PlanMetadata> planMap = new LinkedHashMap<String, PlanMetadata>();
		for (PlanMetadata planMetadata : planFields) {
			planMap.put(planMetadata.getFieldKey(), planMetadata);
		}
		return planMap;
	}
	
	/*public PlanBO mapToPlanBoFromPlanFieldList(List<PlanMetadata> planFields){
		PlanBO planDetails = new PlanBO();
		if(CollectionUtils.isNotEmpty(planFields)){
			for (PlanMetadata planField : planFields) {
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.CONT_STATE)){
				planDetails.setContractState(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLANEFFDT)){
					planDetails.setEffectiveDate(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLAN_DESC)){
					planDetails.setPlanDescription(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.TYP_OF_CASE)){
					planDetails.setTypeOFCase(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PRU_VAL_EXCP)){
					planDetails.setPruValueExceptions(planField.getFieldValue());
				}
				//if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FIELD_LVL_EXCP)){
				//	planDetails.setFieldLevelExceptions(planField.getFieldValue());
				//}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE)){
					planDetails.setFieldLevelExceptions(planField.getFieldValue());
				}
				
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.CONTRI_ARRANG)){
					planDetails.setContributionArrangement(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MIN_PARTCI_PERCEN)){
					planDetails.setMinimumParticipationPercentage(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.VOLA_CAVEAT_REATING)){
					planDetails.setVolatilityCaveatPercentage(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.COMP_RATING)){
					planDetails.setCompositeRating(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AGE_BANDED_RATING)){
					planDetails.setAgeBandedRating(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RATE_GRTY)){
					planDetails.setRateGuarantee(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RATE_EXPR)){
					planDetails.setRateExpression(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AMT_INSU)){
					planDetails.setAmountOfInsurance(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MAX_DOLLAR_AMT)){
					planDetails.setMaximumDollarAmount(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MIN_DOLLAR_AMT)){
					planDetails.setMinimumDollarAmount(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MULTI_OF_EARN)){
					planDetails.setMultipleOfAnnualEarning(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ROUNDING_RULE)){
					planDetails.setRoundingRule(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ROUNDING_OCCUR)){
					planDetails.setRoundingOccurs(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AGE_RED_SCH)){
					planDetails.setAgeReductionSchedule(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DIASBLE_PROV)){
					planDetails.setDisabilityProvision(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DURATION)){
					planDetails.setDuration(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.VOL_AMT)){
					planDetails.setVolumeAmounts(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GURANTEE_ISS_LMT)){
					planDetails.setGuranteeIssueLimit(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DOLLAR_AMT)){
					planDetails.setDollarAmount(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LIV_BEN_OPN)){
					planDetails.setLivingBenifitOption(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_MAX)){
					planDetails.setlBOMaximum(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_PCT)){
					planDetails.setlBOPercentage(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_LIFE_EXPT)){
					planDetails.setlBOLifeExpectancy(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.COV_TERMI_RETI)){
					planDetails.setCoverageTerminatesAtRetirement(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.TRAVEL_ASSISTANCE)){
					planDetails.setTravelAssistance(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.EARNING_DEF)){
					planDetails.setEarningDefination(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_BONUSES)){
					planDetails.setIncludeBonusInEarningDefination(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_COMMISSION)){
					planDetails.setIncludeCommisionInEarningDefination(planField.getFieldValue());
				}
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_OVERTIME)){
					planDetails.setIncludeOvertimeInEarningDefination(planField.getFieldValue());
				}
			}
		}
		return planDetails;
	}*/
	
	public PlanDetailsClass convertToOverriddenPlanDetailsClass(PlanDetailsClass planDetails , List<PlanMetadata> planFieldsList){
		if(planDetails == null){
			planDetails = new PlanDetailsClass();
		}
		//replace with keys of overridden fields
		boolean overriddenFlag = false;
		for (PlanMetadata planField : planFieldsList) {
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.CONT_STATE)){
				planDetails.setContractState(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLANEFFDT)){
				planDetails.setEffectiveDate(SparcUtil.convertStrToSqlDate(planField.getFieldValue()));
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLAN_DESC)){
				planDetails.setPlanDescription(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.TYP_OF_CASE)){
				planDetails.setTypeOfCase(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PRU_VAL_EXCP)){
				planDetails.setPruValueException(planField.getFieldValue());
			}
			/*if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FIELD_LVL_EXCP)){
				planDetails.setFieldLevelException(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE)){
				planDetails.setFieldLevelException(planField.getFieldValue());
			}*/
			
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.CONTRIBUTION__ARRANGEMENT_EXCEPTION)){
				planDetails.setContributionArrangement(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setMinParticipationPct(Float.parseFloat(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.VOLA_CAVEAT_REATING)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setVolatilityCaveatPct(Float.parseFloat(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.COMPOSITE__RATING_EXCEPTION)){
				planDetails.setCompositeRating(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AGE_BANDED_RATING_EXCEPTION)){
				planDetails.setAgeBandedRating(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RATE__GUARANTEE_EXCEPTION_ATTRIBUTES__RATE_GUARANTEE_IN_YEARS)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setRateGurantee(Integer.parseInt(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RATE__EXPRESSION_EXCEPTION)){
				planDetails.setRateExpression(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AMOUNTS__OF_INSURANCE_EXCEPTION)){
				planDetails.setInsuranceAmount(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setMaxDollaramt(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setMinDollarAmt(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS)){
				planDetails.setMultipleOfEarnings(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setCaseFlatAmt(Double.parseDouble(planField.getFieldValue()));
				} else {
					planDetails.setCaseFlatAmt(null);
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ROUNDING__RULE_EXCEPTION)){
				planDetails.setRoundingRule(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ROUNDING__OCCURS_EXCEPTION)){
				planDetails.setRoundingOccurs(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AGE__REDUCTION_SCHEDULE_EXCEPTION)){
				planDetails.setAgeReductionSchedule(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DISABILITY__PROVISION_EXCEPTION)){
				planDetails.setDisablityProvision(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DURATION__EXCEPTION)){
				planDetails.setDuration(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.VOLUME__AMOUNTS_EXCEPTION)){
				planDetails.setVolumeAmounts(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION)){
				planDetails.setGuranteeIssueLimit(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_EXCEPTION_ATTRIBUTES_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setDollarAmount(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LIV_BEN_OPN)){
				planDetails.setLivingBenefitOption(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTES__LBO_MAXIMUM)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setLboMax(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTE__LBO_PERCENTAGE)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setLboPercent(Float.parseFloat(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO__LIFE_EXPECTANCY_EXCEPTION)){
				planDetails.setLboLifeExpectancy(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.COVERAGE__TERMINATES_AT_RETIREMENT_EXCEPTION)){
				planDetails.setCoverageTerminateAtRetirement(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.TRAVEL__ASSISTANCE_EXCEPTION)){
				planDetails.setTravelAssistance(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.EARNING_DEF)){
				planDetails.setEarningDefiniton(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_BONUSES)){
				planDetails.setIncludeBonus(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_COMMISSION)){
				planDetails.setIncludeCommission(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_OVERTIME)){
				planDetails.setIncludeOvertime(planField.getFieldValue());
			}
			//new fields
			/*if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCREMENTAL__FLAT_DOLLAR_AMOUNTS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setMaxDollaramt(Double.parseDouble(planField.getFieldValue()));
				}
			}*/
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCREMENTAL__FLAT_DOLLAR_AMOUNTS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setMultiOfEarningsMaxDollarAmt(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setDollarAmount(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setEmployeeContribFlatAmt(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setEmployeeContribPercent(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DISABILITY_PROVISION_PREMIUM_CONTNUANCE_DETAILS_ATTRIBUTES__PREMIUM_CONTINUANCE_DETAILS)){
				planDetails.setPremiumContinuanceDetails(planField.getFieldValue());
			}
			/*if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCREMENTAL__FLAT_DOLLAR_AMOUNTS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setMinDollarAmt(Double.parseDouble(planField.getFieldValue()));
				}
			}*/
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCREMENTAL__FLAT_DOLLAR_AMOUNTS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setMultiOfEarningsMinDollarAmt(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RATE__EXPRESSION_EXCEPTION_ATTRIBUTES__OTHER)){
				planDetails.setRateExpressionOther(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_LIFE_EXPECTANCY_EXCEPTION_ATTRIBUTES__OTHER)){
				planDetails.setLboLifeExpectancyOther(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ROUNDING__RULE_EXCEPTION)){
					planDetails.setRoundingRule(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AGE__REDUCTION_SCHEDULE_EXCEPTION)){
					planDetails.setAgeRedScheduleAttribute(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DURATION_EXCEPTION_ATTRIBUTES)){
					planDetails.setDurationAttribute(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_EARNINGS)){
				planDetails.setGuaranteeIssueLmtMultiOfEarn(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MAXIMUM_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setPrctBlActiveAmtMaxDollarAmt(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MINIMUM_DOLLAR_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setPrctBlActiveAmtMinDollarAmt(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT)){
				if(StringUtils.isNotBlank(planField.getFieldValue())){
					planDetails.setPrctBlActiveAmt(Double.parseDouble(planField.getFieldValue()));
				}
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DURATION__EXCEPTION_ATTRIBUTES__OTHER)){
				planDetails.setOtherDurationAge(planField.getFieldValue());
			}
			if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION)){
				planDetails.setGuaranteeIssue(planField.getFieldValue());
			}
			//end 
			overriddenFlag = overriddenFlag || StringUtils.equalsIgnoreCase("Y", planField.getOverriddenFlag());
		}
		if(overriddenFlag){
			planDetails.setOverrideIndicator("Y");
		} else {
			planDetails.setOverrideIndicator("N");
		}
		return planDetails; 
	}
	
	public PlanDetailsClass convertToPlanDetailsClass(PlanDetailsClass planDetails , List<PlanMetadata> planFieldsList){
		if(planDetails == null){
			planDetails = new PlanDetailsClass();
		}
		boolean overriddenFlag = false;
		try{
			for (PlanMetadata planField : planFieldsList) {
				
				if(StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(planField.getVisibleFlag()), PlanConfigConstants.VISIBLE_FLAG_NO)) {
					planField.setFieldValue(null);
				}
				
				if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE)){
					planDetails.setContractState(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLANEFFDT)){
					planDetails.setEffectiveDate(SparcUtil.convertStrToDate(planField.getFieldValue()));
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLAN_DESC)){
					planDetails.setPlanDescription(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.TYP_OF_CASE)){
					planDetails.setTypeOfCase(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PRU_VAL_EXCP)){
					planDetails.setPruValueException(planField.getFieldValue());
				}
				/*else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FIELD_LVL_EXCP)){
					planDetails.setFieldLevelException(planField.getFieldValue());
				}*/
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE)){
					planDetails.setFieldLevelException(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.CONTRI_ARRANG)){
					planDetails.setContributionArrangement(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MIN_PARTCI_PERCEN)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setMinParticipationPct(Float.parseFloat(planField.getFieldValue()));
					} else {
						planDetails.setMinParticipationPct(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.VOLA_CAVEAT_REATING)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setVolatilityCaveatPct(Float.parseFloat(planField.getFieldValue()));
					} else {
						planDetails.setVolatilityCaveatPct(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.COMP_RATING)){
					planDetails.setCompositeRating(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AGE_BANDED_RATING)){
					planDetails.setAgeBandedRating(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RATE_GUARANTEE_ATTRIBUTES)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setRateGurantee(Integer.parseInt(planField.getFieldValue()));
					} else {
						planDetails.setRateGurantee(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RATE_EXPR)){
					planDetails.setRateExpression(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AMT_INSU)){
					planDetails.setInsuranceAmount(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setMaxDollaramt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setMaxDollaramt(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setMinDollarAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setMinDollarAmt(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MULTI_OF_EARN)){
					planDetails.setMultipleOfEarnings(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ROUNDING_RULE)){
					planDetails.setRoundingRule(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ROUNDING_OCCUR)){
					planDetails.setRoundingOccurs(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AGE_RED_SCH)){
					planDetails.setAgeReductionSchedule(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DIASBLE_PROV)){
					planDetails.setDisablityProvision(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DURATION)){
					planDetails.setDuration(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.VOL_AMT)){
					planDetails.setVolumeAmounts(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GURANTEE_ISS_LMT)){
					planDetails.setGuranteeIssueLimit(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DOLLAR_AMT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setDollarAmount(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setDollarAmount(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LIV_BEN_OPN)){
					planDetails.setLivingBenefitOption(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_MAX)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setLboMax(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setLboMax(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_PCT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setLboPercent(Float.parseFloat(planField.getFieldValue()));
					} else {
						planDetails.setLboPercent(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_LIFE_EXPT)){
					planDetails.setLboLifeExpectancy(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.COV_TERMI_RETI)){
					planDetails.setCoverageTerminateAtRetirement(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.TRAVEL_ASSISTANCE)){
					planDetails.setTravelAssistance(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.EARNING_DEF)){
					planDetails.setEarningDefiniton(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_BONUSES)){
					planDetails.setIncludeBonus(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_COMMISSION)){
					planDetails.setIncludeCommission(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_OVERTIME)){
					planDetails.setIncludeOvertime(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setCaseFlatAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setCaseFlatAmt(null);
					}
				}
				//new fields added
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE)){
					planDetails.setEmployeeContribType(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE_FLAT_AMOUNT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setEmployeeContribFlatAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setEmployeeContribFlatAmt(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setEmployeeContribPercent(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setEmployeeContribPercent(null);
					}
				}
				/*else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MAX_DOLLAR_AMT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setMaxDollaramt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setMaxDollaramt(null);
					}
				}*/
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MAX_DOLLAR_AMT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setMultiOfEarningsMaxDollarAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setMultiOfEarningsMaxDollarAmt(null);
					}
				}
				/*else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MIN_DOLLAR_AMT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setMinDollarAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setMinDollarAmt(null);
					}
				}*/
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MIN_DOLLAR_AMT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setMultiOfEarningsMinDollarAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setMultiOfEarningsMinDollarAmt(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DISABILITY_PROVISION_PREMIUM_CONTNUANCE_DETAILS_ATTRIBUTES__PREMIUM_CONTINUANCE_DETAILS)){
					planDetails.setPremiumContinuanceDetails(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ENROLLMENT_ASSUMPTION_VARIATION)){
					planDetails.setEnrollmentAssumptionVariation(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RATE_EXPRESSION_ATTRIBUTES__OTHER)){
					planDetails.setRateExpressionOther(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_LIFE_EXPECTANCY_ATTRIBUTES__OTHER)){
					planDetails.setLboLifeExpectancyOther(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GRANDFATHERING_GROUP)){
					planDetails.setGrandfatheringGroup(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTR)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setFlatDollarAmount(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setFlatDollarAmount(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ROUNDING_RULE_ATTRIBUTES)){
					planDetails.setRoundingRuleAttribute(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.AGE_REDUCTION_SCHEDULE_ATTRIBUTES)){
					planDetails.setAgeRedScheduleAttribute(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DURATION_ATTRIBUTES)){
					planDetails.setDurationAttribute(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.SUBPRODUCT_ATTRIBUTE)){
					planDetails.setSubProductAttribute(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCREMENTAL_DOLLAR_AMOUNT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setIncrementalDollAramount(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setIncrementalDollAramount(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ENROLLMENT_ASSUMPTION)){
					planDetails.setEnrollmentAssumption(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MULTINATIONAL_POOLING_ATTRIBUTE)){
					planDetails.setMultinationalPoolingValue(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.EXPERIENCE_ARRANGEMENT)){
					planDetails.setExperienceArrangement(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MULTIPLE_OF_EARNINGS)){
					planDetails.setGuaranteeIssueLmtMultiOfEarn(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GRANDFATHERING_TYPE)){
					planDetails.setGrandFatheringType(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_MAXIMUMUM_DOLLAR_AMOUNT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setPrctBlActiveAmtMaxDollarAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setPrctBlActiveAmtMaxDollarAmt(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_MINIMUM_DOLLAR_AMOUNT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setPrctBlActiveAmtMinDollarAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setPrctBlActiveAmtMinDollarAmt(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setPrctBlActiveAmt(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setPrctBlActiveAmt(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ELIMINATION_PERIOD)){
					planDetails.setEliminationPeriod(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.QUALIFYING_AGE)){
					planDetails.setQualifyingAge(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.TERMINATION_AGE)){
					planDetails.setTerminationAge(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.LBO_APPLIES_TO)){
					planDetails.setLboAppliesTo(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.ORDER_OF_PRIORITY_FOR_LBO_CLAIM_PAYMENT)){
					planDetails.setOrderOfPriorityLboClaimPayment(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.DURATION_ATTRIBUTES__OTHER)){
					planDetails.setOtherDurationAge(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.SPECIFIC_EMPLOYEE_WAITING_PERIOD_ATTRIBUTES__DAYS)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setSpecificEmployeeWaitingPeriodDays(Integer.parseInt(planField.getFieldValue()));
					}  else {
						planDetails.setSpecificEmployeeWaitingPeriodDays(null);
					}
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.RETENTION_BASIS)){
					planDetails.setRetentionBasis(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GUARANTEE_ISSUE)){
					planDetails.setGuaranteeIssue(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.MEDICAL_UNDERWRITING)){
					planDetails.setMedicalUnderwriting(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.BURIAL_EXPENSE_PAYMENT)){
					planDetails.setBurialExpensePayment(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.BENEFICIARY_FINANCIAL_COUNSELING_SERVICES)){
					planDetails.setEmployeeWaitingPeriodOption(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.EXISTING_EARNINGS_DEFINITION)){
					planDetails.setExistingEarningDefinition(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.EMPLOYEE_WAITING_PERIOD_OPTIONS)){
					planDetails.setEmployeeContribType(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP)){
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						planDetails.setMaxDollarCap(Double.parseDouble(planField.getFieldValue()));
					} else {
						planDetails.setMaxDollarCap(null);
					}
				}
				//new fields end
				
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && 
						StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_BONUSES_AVERAGED_OVER)){
					planDetails.setBonusAvgDollar(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && 
						StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_COMMISSIONS_AVERAGED_OVER)){
					planDetails.setCommissionAvgDollar(planField.getFieldValue());
				}
				else if(StringUtils.isNotBlank(planField.getFieldKey()) && 
						StringUtils.equalsIgnoreCase(planField.getFieldKey(), PlanConfigConstants.INCLUDE_OVERTIME_AVERAGED_OVER)){
					planDetails.setOvertimeAvgDollar(planField.getFieldValue());
				}
				
				overriddenFlag = overriddenFlag || StringUtils.equalsIgnoreCase("Y", planField.getOverriddenFlag());
			}
		} catch(Exception e){
			e.printStackTrace();
		}
		if(overriddenFlag){
			planDetails.setOverrideIndicator("Y");
		} else {
			planDetails.setOverrideIndicator("N");
		}
		return planDetails; 
	}

	public List<PlanMetadata> mergePlanMetaDataLists(
			List<PlanMetadata> planMetadataList,
			List<PlanMetadata> listOfPlanField) {
		if(CollectionUtils.isEmpty(listOfPlanField) && CollectionUtils.isEmpty(planMetadataList)){
			return new ArrayList<PlanMetadata>();
		}
		if(CollectionUtils.isEmpty(listOfPlanField)){
			//this condition will be true on first load while creating new plan
			return planMetadataList;
		}
		if(CollectionUtils.isEmpty(planMetadataList)){
			//this condition will be true on fetching plan details from database befor merging with metadata
			return listOfPlanField;
		}
		for (PlanMetadata metaData : planMetadataList) {
			for (PlanMetadata planField : listOfPlanField) {
				if(StringUtils.equalsIgnoreCase(planField.getFieldKey(), metaData.getFieldKey())){
					metaData.setFieldIndicator(planField.getFieldIndicator());
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						metaData.setFieldValue(planField.getFieldValue());
					}
					metaData.setOverriddenFlag(planField.getOverriddenFlag());
					//metaData.setVisibleFlag(planField.getVisibleFlag());
				} 
			}
		}
		return planMetadataList;
	}

	
	public List<PlanMetadata> mergePlanlatestValues(
			List<PlanMetadata> planMetadataList,
			List<PlanMetadata> listOfPlanField) {
		for (PlanMetadata metaData : planMetadataList) {
			for (PlanMetadata planField : listOfPlanField) {
				if(StringUtils.equalsIgnoreCase(planField.getFieldKey(), metaData.getFieldKey())){
					//metaData.setFieldIndicator(planField.getFieldIndicator());
					if(StringUtils.isNotBlank(planField.getFieldValue())){
						metaData.setFieldValue(planField.getFieldValue());
					}
					//metaData.setOverriddenFlag(planField.getOverriddenFlag());
					//metaData.setVisibleFlag(planField.getVisibleFlag());
				} 
			}
		}
		return planMetadataList;
		
	}
	/*public static void main(String[] args) {
		PlanDetailsServiceProcessor pdsp = new PlanDetailsServiceProcessor();
		List<PlanMetadata> planMetadataList = new ArrayList<PlanMetadata>();
		
		pdsp.
	}*/
	public List<PlanMetadata> setLookupValuesInFieldList(
			List<PlanMetadata> planMetadataList,
			List<PlanConfigLookup> planLookupList) {
		Map<String, PlanConfigLookup> contractStateAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> typeOfCaseAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> contriArrangmntAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> volatCaveatPrctAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> compositeRatingAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> ageBandedRatingAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> rateExpressionAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> amtOfInsuranceAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> roundingRuleAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> roundingOccursAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> ageRedScheduleAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> disablityProvisionAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> durationAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> volumeAmtAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> guatanteeIssueLimitAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> livingBnftOptAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> lboExpectancyAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> covTermiRetireAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> travelAssistAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> earningDefnAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> includeBonusAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> includeCommissionAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> includeOvertimeAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		/*Added on 08/13/2016 for additional field*/
		Map<String, PlanConfigLookup> empContriAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> grandFatherAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		
		Map<String, PlanConfigLookup> bonuseAvgOverAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> commissionAvgOverAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		Map<String, PlanConfigLookup> overtimeAvgOverAltValues = new LinkedHashMap<String, PlanConfigLookup>();
		for (PlanConfigLookup planConfigLookup : planLookupList) {
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_AGE_BANDED_RATING)){
				ageBandedRatingAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_AGE_RED_SCH)){
				ageRedScheduleAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_AMT_OF_INSURANCE)){
				amtOfInsuranceAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_COMPOSITE_RATING)){
				compositeRatingAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_CONTRACT_STATE)){
				contractStateAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_CONTRIB_ARRNGMT)){
				contriArrangmntAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_COV_TERMI_RETIRE)){
				covTermiRetireAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_DISAB_PROVI)){
				disablityProvisionAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_DURATION)){
				durationAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_EARNING_DEFINITION)){
				earningDefnAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_GUARANTEE_ISSUE_LIMIT)){
				guatanteeIssueLimitAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_INCLUDE_BONUS)){
				includeBonusAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_INCLUDE_COMMISSION)){
				includeCommissionAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_INCLUDE_OVERTIME)){
				includeOvertimeAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_LBO_EXPECTANCY)){
				lboExpectancyAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_LIVING_BNFT_OPT)){
				livingBnftOptAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_RATE_EXPRESSION)){
				rateExpressionAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_ROUNDING_OCCURS)){
				roundingOccursAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_ROUNDING_RULE)){
				roundingRuleAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_TRAVEL_ASSIST)){
				travelAssistAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.PRUVALUEPARTS_ATTRIBUTE)){
				typeOfCaseAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_VOLAT_CAVEAT_PRCT)){
				volatCaveatPrctAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_VOLUME_AMT)){
				volumeAmtAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_EMP_CONTRI)){
				empContriAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.LOOKUP_CATEGORY_GRANDFATHERING_GRP)){
				grandFatherAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			
			
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.INCLUDE_BONUSES_AVERAGED_OVER)){
				bonuseAvgOverAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.INCLUDE_COMMISSIONS_AVERAGED_OVER)){
				commissionAvgOverAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			if(StringUtils.equalsIgnoreCase(planConfigLookup.getLookupCategory(), PlanConfigConstants.INCLUDE_OVERTIME_AVERAGED_OVER)){
				overtimeAvgOverAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
			}
			
			
			for (PlanMetadata planMetadata : planMetadataList) {
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_AGE_BANDED_RATING) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.AGE_BANDED_RATING_EXCEPTION)){
					planMetadata.setAltValues(ageBandedRatingAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_AGE_RED_SCH) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.AGE__REDUCTION_SCHEDULE_EXCEPTION)){
					planMetadata.setAltValues(ageRedScheduleAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_AMT_OF_INSURANCE) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.AMOUNTS__OF_INSURANCE_EXCEPTION)){
					planMetadata.setAltValues(amtOfInsuranceAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_COMPOSITE_RATING) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.COMPOSITE__RATING_EXCEPTION)){
					planMetadata.setAltValues(compositeRatingAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_CONTRACT_STATE)){
					planMetadata.setAltValues(contractStateAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_CONTRIB_ARRNGMT) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.CONTRIBUTION__ARRANGEMENT_EXCEPTION)){
					planMetadata.setAltValues(contriArrangmntAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_COV_TERMI_RETIRE) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.COVERAGE__TERMINATES_AT_RETIREMENT_EXCEPTION)){
					planMetadata.setAltValues(covTermiRetireAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_DISAB_PROVI) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.DISABILITY__PROVISION_EXCEPTION)){
					planMetadata.setAltValues(disablityProvisionAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_DURATION) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.DURATION__EXCEPTION)){
					planMetadata.setAltValues(durationAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_EARNING_DEFINITION)){
					planMetadata.setAltValues(earningDefnAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_GUARANTEE_ISSUE_LIMIT) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION)){
					planMetadata.setAltValues(guatanteeIssueLimitAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_INCLUDE_BONUS)){
					planMetadata.setAltValues(includeBonusAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_INCLUDE_COMMISSION)){
					planMetadata.setAltValues(includeCommissionAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_INCLUDE_OVERTIME)){
					planMetadata.setAltValues(includeOvertimeAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_LBO_EXPECTANCY) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LBO__LIFE_EXPECTANCY_EXCEPTION)){
					planMetadata.setAltValues(lboExpectancyAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_LIVING_BNFT_OPT) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LIVING__BENEFIT_OPTION_EXCEPTION)){
					planMetadata.setAltValues(livingBnftOptAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_RATE_EXPRESSION) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.RATE__EXPRESSION_EXCEPTION)){
					planMetadata.setAltValues(rateExpressionAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_ROUNDING_OCCURS) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.ROUNDING__OCCURS_EXCEPTION)){
					planMetadata.setAltValues(roundingOccursAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_ROUNDING_RULE) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.ROUNDING__RULE_EXCEPTION)){
					planMetadata.setAltValues(roundingRuleAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_TRAVEL_ASSIST) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.TRAVEL__ASSISTANCE_EXCEPTION)){
					planMetadata.setAltValues(travelAssistAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_TYPE_OF_CASE)){
					planMetadata.setAltValues(typeOfCaseAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_VOLAT_CAVEAT_PRCT)){
					planMetadata.setAltValues(volatCaveatPrctAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_VOLUME_AMT) || StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.VOLUME__AMOUNTS_EXCEPTION)){
					planMetadata.setAltValues(volumeAmtAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_EMP_CONTRI)){
					planMetadata.setAltValues(empContriAltValues);
				}
				
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.LOOKUP_CATEGORY_GRANDFATHERING_GRP)){
					planMetadata.setAltValues(grandFatherAltValues);
				}
				
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.INCLUDE_BONUSES_AVERAGED_OVER)){
					planMetadata.setAltValues(bonuseAvgOverAltValues);
				}
				
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.INCLUDE_COMMISSIONS_AVERAGED_OVER)){
					planMetadata.setAltValues(commissionAvgOverAltValues);
				}
				if(StringUtils.equalsIgnoreCase(planMetadata.getFieldKey(), PlanConfigConstants.INCLUDE_OVERTIME_AVERAGED_OVER)){
					planMetadata.setAltValues(overtimeAvgOverAltValues);
				}
				
			}
		}
		return planMetadataList;
	}
	
	public ProposalBrokerDetails mapToProposalBrokerDetails(
			Commission commission, BrokerDetails brokerDetails, ProposalBrokerDetails proposalBrokerDetails, QuotationDetails quotationDetails) {
		if(proposalBrokerDetails == null){
			proposalBrokerDetails = new ProposalBrokerDetails();
		}
		proposalBrokerDetails.setAdvanceCommissionFlag(commission.getAdvanceCommissionFlag());
		proposalBrokerDetails.setAdvComm(commission.getAdvanceCommission());
		proposalBrokerDetails.setAdvCommOccurs(commission.getAdvaceCommissionOccurs());
		proposalBrokerDetails.setArrangement(commission.getArrangement());
		proposalBrokerDetails.setCommissionSplit(commission.getCommissionSplit());
		proposalBrokerDetails.setCommPaidTo(commission.getCommissionPaidTo());
		proposalBrokerDetails.setFlatAmount(commission.getFlatAmount());
		proposalBrokerDetails.setFlatPercentage(commission.getFlatPercentage());// Added for Testing Fix
		proposalBrokerDetails.setBrokerDetails(brokerDetails);
		proposalBrokerDetails.setVersionDetails(quotationDetails);
		proposalBrokerDetails.setProPlanId(commission.getProposalPlanID());
		//proposalPlanInd value is set to 1 for proposal and 0 for plan
		proposalBrokerDetails.setProposalPlanInd(0);
		return proposalBrokerDetails;
	}
	
	public Commission parseCommissionResponse(
			ProposalBrokerDetails prBrokerDetails) {
		Commission commission = null;
		if(null != prBrokerDetails){
			commission = new Commission();
			commission.setAdvanceCommission(prBrokerDetails.getAdvComm());
			commission.setAdvaceCommissionOccurs(prBrokerDetails.getAdvCommOccurs());
			commission.setArrangement(prBrokerDetails.getArrangement());
			commission.setCommissionSplit(prBrokerDetails.getCommissionSplit());
			commission.setCommissionPaidTo(prBrokerDetails.getCommPaidTo());
			commission.setFlatAmount(prBrokerDetails.getFlatAmount());
			commission.setFlatPercentage(prBrokerDetails.getFlatPercentage());
			commission.setBrokerID(prBrokerDetails.getBrokerDetails().getBrokerId());
			commission.setProposalPlanID(prBrokerDetails.getProPlanId());
			commission.setAdvanceCommissionFlag(prBrokerDetails.getAdvanceCommissionFlag());
			commission.setVersionNumber(prBrokerDetails.getVersionDetails().getVersionNumber());
		}
		return commission;
	}

	public PlanEligibilityClass mapToPlanEligibilityClass(
			PlanEligibilityClass planEligibilityClass, PlanEligibility planEligibility, CensusCls censusCls, PlanDetailsClass planDetailsClass,
			CensusClass censusClass) {
		if(censusCls != null && censusCls.isClassSelected()){
			if(planEligibilityClass == null){
				planEligibilityClass = new PlanEligibilityClass();
			}
			planEligibilityClass.setCensusClass(censusClass);
			planEligibilityClass.setNoOfLives(censusCls.getNoOfLives());
			planEligibilityClass.setClassSelected(String.valueOf(censusCls.isClassSelected()));
			planEligibilityClass.setPlanDetails(planDetailsClass);
			planDetailsClass.setMinHrsReqd(planEligibility.getMinHrsRequired());
		}
		return planEligibilityClass;
	}

	public PlanEligibility mapToPlanEligibility(
			List<PlanEligibilityClass> planEligibilityList, PlanEligibility planEligibilityModel, List<CensusClass> allocatedCensusClasses, int censusId) {
		//PlanEligibility eligibility = new PlanEligibility();
		List<CensusCls> classList = new ArrayList<CensusCls>();
		if(CollectionUtils.isNotEmpty(allocatedCensusClasses)){
			for (CensusClass censusClass : allocatedCensusClasses) {
				CensusCls censusCls = new CensusCls();
				censusCls.setCensusClsId(censusClass.getCensusClsId());
				censusCls.setClassDesc(censusClass.getClassDesc());
				planEligibilityModel.setCensusID(censusClass.getCensusDetail().getCensusId());
				
				for (PlanEligibilityClass planEligibility : planEligibilityList) {
					if(censusClass.getCensusClsId() == planEligibility.getCensusClass().getCensusClsId()) {
						censusCls.setClassSelected(true);
						if(null == planEligibility.getPlanDetails().getMinHrsReqd()){
							planEligibility.getPlanDetails().setMinHrsReqd(30d);
						}
						planEligibilityModel.setMinHrsRequired(planEligibility.getPlanDetails().getMinHrsReqd());
					}
				}
				int noOfLives = planDetailsRepository.getNoOfLivesPerClass(censusId, censusClass.getCensusClsId());
				censusCls.setNoOfLives(noOfLives);
				classList.add(censusCls);
			}
		}
		planEligibilityModel.setCensusClassList(classList);
		
		
		return planEligibilityModel;
	}

	public List<PlanMetadata> convertPlanDetailsToFieldList(
			PlanDetailsClass planDetails) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		List<PlanMetadata> planFieldList = new ArrayList<PlanMetadata>();
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.AGE_BANDED_RATING, planDetails.getAgeBandedRating()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.AGE_RED_SCH, planDetails.getAgeReductionSchedule()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.COMP_RATING, planDetails.getCompositeRating()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE, planDetails.getContractState()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.CONTRI_ARRANG, planDetails.getContributionArrangement()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.COV_TERMI_RETI, planDetails.getCoverageTerminateAtRetirement()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DIASBLE_PROV, planDetails.getDisablityProvision()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DURATION, planDetails.getDuration()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EARNING_DEF, planDetails.getEarningDefiniton()));
		//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FIELD_LVL_EXCP, planDetails.getFieldLevelException()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planDetails.getFieldLevelException()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GURANTEE_ISS_LMT, planDetails.getGuranteeIssueLimit()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_BONUSES, planDetails.getIncludeBonus()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_COMMISSION, planDetails.getIncludeCommission()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_OVERTIME, planDetails.getIncludeOvertime()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.AMT_INSU, planDetails.getInsuranceAmount()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_LIFE_EXPT, planDetails.getLboLifeExpectancy()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LIV_BEN_OPN, planDetails.getLivingBenefitOption()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTI_OF_EARN, planDetails.getMultipleOfEarnings()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLAN_DESC, planDetails.getPlanDescription()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PRU_VAL_EXCP, planDetails.getPruValueException()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RATE_EXPR, planDetails.getRateExpression()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ROUNDING_OCCUR, planDetails.getRoundingOccurs()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ROUNDING_RULE, planDetails.getRoundingRule()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.TRAVEL_ASSISTANCE, planDetails.getTravelAssistance()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.TYP_OF_CASE, planDetails.getTypeOfCase()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.VOL_AMT, planDetails.getVolumeAmounts()));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DOLLAR_AMT, String.valueOf(planDetails.getDollarAmount())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_MAX, String.valueOf(planDetails.getLboMax())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_PCT, String.valueOf(planDetails.getLboPercent())));
		//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMultiOfEarningsMaxDollarAmt())));
		//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMultiOfEarningsMinDollarAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMaxDollaramt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMinDollarAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MIN_PARTCI_PERCEN, String.valueOf(planDetails.getMinParticipationPct())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RATE_GRTY, String.valueOf(planDetails.getRateGurantee())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.VOLA_CAVEAT_REATING, String.valueOf(planDetails.getVolatilityCaveatPct())));
		if(null != planDetails.getEffectiveDate()){
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLANEFFDT, dateFormat.format(planDetails.getEffectiveDate())));		
		}
		//new fields added
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RATE_GUARANTEE_ATTRIBUTES__RATE_GUARANTEE, String.valueOf(planDetails.getRateGurantee())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MAX_DOLLAR_AMT, String.valueOf(planDetails.getMultiOfEarningsMaxDollarAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT, String.valueOf(planDetails.getCaseFlatAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE, String.valueOf(planDetails.getEmployeeContribType())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE_FLAT_AMOUNT, String.valueOf(planDetails.getEmployeeContribFlatAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE, String.valueOf(planDetails.getEmployeeContribPercent())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DISABILITY_PROVISION_PREMIUM_CONTNUANCE_DETAILS_ATTRIBUTES__PREMIUM_CONTINUANCE_DETAILS, String.valueOf(planDetails.getPremiumContinuanceDetails())));
		//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MIN_DOLLAR_AMT, String.valueOf(planDetails.getMinDollarAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MIN_DOLLAR_AMT, String.valueOf(planDetails.getMultiOfEarningsMinDollarAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ENROLLMENT_ASSUMPTION_VARIATION, String.valueOf(planDetails.getEnrollmentAssumptionVariation())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RATE_EXPRESSION_ATTRIBUTES__OTHER, String.valueOf(planDetails.getRateExpressionOther())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_LIFE_EXPECTANCY_ATTRIBUTES__OTHER, String.valueOf(planDetails.getLboLifeExpectancyOther())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GRANDFATHERING_GROUP, String.valueOf(planDetails.getGrandfatheringGroup())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTR, String.valueOf(planDetails.getFlatDollarAmount())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ROUNDING_RULE_ATTRIBUTES, String.valueOf(planDetails.getRoundingRuleAttribute())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.AGE_REDUCTION_SCHEDULE_ATTRIBUTES, String.valueOf(planDetails.getAgeRedScheduleAttribute())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DURATION_ATTRIBUTES, String.valueOf(planDetails.getDuration())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, String.valueOf(planDetails.getSubProductAttribute())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCREMENTAL_DOLLAR_AMOUNT, String.valueOf(planDetails.getIncrementalDollAramount())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ENROLLMENT_ASSUMPTION, String.valueOf(planDetails.getEnrollmentAssumption())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTINATIONAL_POOLING_ATTRIBUTE, String.valueOf(planDetails.getMultinationalPoolingValue())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EXPERIENCE_ARRANGEMENT, String.valueOf(planDetails.getExperienceArrangement())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MULTIPLE_OF_EARNINGS, String.valueOf(planDetails.getGuaranteeIssueLmtMultiOfEarn())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GRANDFATHERING_TYPE, String.valueOf(planDetails.getGrandFatheringType())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_MAXIMUMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getPrctBlActiveAmtMaxDollarAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_MINIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getPrctBlActiveAmtMinDollarAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT, String.valueOf(planDetails.getPrctBlActiveAmt())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ELIMINATION_PERIOD, String.valueOf(planDetails.getEliminationPeriod())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.QUALIFYING_AGE, String.valueOf(planDetails.getQualifyingAge())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.TERMINATION_AGE, String.valueOf(planDetails.getTerminationAge())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_APPLIES_TO, String.valueOf(planDetails.getLboAppliesTo())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ORDER_OF_PRIORITY_FOR_LBO_CLAIM_PAYMENT, String.valueOf(planDetails.getOrderOfPriorityLboClaimPayment())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DURATION_ATTRIBUTES__OTHER, String.valueOf(planDetails.getDurationAttribute())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.SPECIFIC_EMPLOYEE_WAITING_PERIOD_ATTRIBUTES__DAYS, String.valueOf(planDetails.getSpecificEmployeeWaitingPeriodDays())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RETENTION_BASIS, String.valueOf(planDetails.getRetentionBasis())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GUARANTEE_ISSUE, String.valueOf(planDetails.getGuaranteeIssue())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MEDICAL_UNDERWRITING, String.valueOf(planDetails.getMedicalUnderwriting())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.BURIAL_EXPENSE_PAYMENT, String.valueOf(planDetails.getBurialExpensePayment())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.BENEFICIARY_FINANCIAL_COUNSELING_SERVICES, String.valueOf(planDetails.getBeneficiaryFinCounselingService())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EXISTING_EARNINGS_DEFINITION, String.valueOf(planDetails.getExistingEarningDefinition())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EMPLOYEE_WAITING_PERIOD_OPTIONS, String.valueOf(planDetails.getEmployeeWaitingPeriodOption())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP, String.valueOf(planDetails.getMaxDollarCap())));
		//end of new fields
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_BONUSES_AVERAGED_OVER, String.valueOf(planDetails.getBonusAvgDollar())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_COMMISSIONS_AVERAGED_OVER, String.valueOf(planDetails.getCommissionAvgDollar())));
		planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_OVERTIME_AVERAGED_OVER, String.valueOf(planDetails.getOvertimeAvgDollar())));
		return planFieldList;
	}
	
	public PlanMetadata setPlanMetadataValue(String key, String value){
		PlanMetadata metaData = new PlanMetadata();
		metaData.setFieldKey(key);
		//Temporary code for handling "null" String, To be modified in method convertPlanDetailsToFieldList, convertOverriddenDetailsToFieldList
		if (StringUtils.equalsIgnoreCase(value, "null")) {
			value = null;
		}
		metaData.setFieldValue(value);
		return metaData;
	}
	
	public PlanMetadata setOverriddenPlanMetadataValue(PlanMetadata metaData){
		//Temporary code for handling "null" String, To be modified in method convertPlanDetailsToFieldList, convertOverriddenDetailsToFieldList
		if (StringUtils.equalsIgnoreCase(metaData.getFieldValue(), "null")) {
			metaData.setFieldValue(null);
		}
		metaData.setOverriddenFlag("N");
		if(StringUtils.isNotBlank(metaData.getFieldValue())){
			metaData.setOverriddenFlag("Y");
		}/* else {
			metaData.setOverriddenFlag("N");
		}*/
		return metaData;
	}

	public Map<String, PlanMetadata> filterVisibleRecords(
			Map<String, PlanMetadata> planMap) {
		if(CollectionUtils.isNotEmpty(planMap.entrySet())){
			Set<Entry<String, PlanMetadata>> planEntrySet = planMap.entrySet();
			for (Entry<String, PlanMetadata> entry : planEntrySet) {
				if(null != entry.getValue()){
					if(StringUtils.equalsIgnoreCase(entry.getValue().getVisibleFlag(), "No")){
						planMap.remove(entry.getKey());
					} else if(null != entry.getValue().getAltValues()){
						for ( Entry<String, PlanConfigLookup> altValue : entry.getValue().getAltValues().entrySet()) {
							if(StringUtils.equalsIgnoreCase(altValue.getValue().getVisibleFlag(), "No")){
								entry.getValue().getAltValues().remove(altValue.getKey());
							}
						}
					}
				}
			}
		}
		return planMap;
	}

	public PlanDetailsAggregator parsePlanResponse(
			PlanDetailsAggregator planDetailsAggregator, PlanWrapper planWrapper/*, List<CensusClass> allocatedCensusClassesr*/) {
		/*List<PlanMetadata> planFieldsList = convertPlanDetailsToFieldList(planWrapper.getPlanDetailsClass());
		//planDetailsAggregator.setPlanEligibility(mapToPlanEligibility(planWrapper.getPlanEligibilityClass(), planDetailsAggregator.getPlanEligibility(), allocatedCensusClassesr));
		//planDetailsAggregator.setCommission(parseCommissionResponse(planWrapper.getProposalBrokerDetails()));
		List<PlanMetadata> overriddenFieldsList = new ArrayList<PlanMetadata>();
		if(null != planWrapper.getOverriddenDetails()){
			overriddenFieldsList = convertOverriddenDetailsToFieldList(mergePlanDetailsClassObjects(planWrapper.getPlanDetailsClass(), planWrapper.getOverriddenDetails()));
		} else {
			overriddenFieldsList = convertOverriddenDetailsToFieldList(planWrapper.getOverriddenDetails());
		}
		List<PlanMetadata> allFieldsList = new ArrayList<PlanMetadata>();
		allFieldsList.addAll(mergePlanMetaDataLists(planDetailsAggregator.getListOfPlanField(), planFieldsList));
		//add conditions for override in merge.. method
		allFieldsList.addAll(mergePlanMetaDataLists(planDetailsAggregator.getListOfPlanField(), overriddenFieldsList));
		planDetailsAggregator.setListOfPlanField(allFieldsList);
		return planDetailsAggregator;*/
		
		List<PlanMetadata> planFieldsList = convertPlanDetailsToFieldList(planWrapper.getPlanDetailsClass());
		List<PlanMetadata> overriddenFieldsList = new ArrayList<PlanMetadata>();
		if(null != planWrapper.getOverriddenDetails()){
			List<PlanMetadata> overriddenFieldsWithFlagList = convertOverriddenDetailsToFieldList( planWrapper.getOverriddenDetails());
			for (PlanMetadata planMetadata : overriddenFieldsWithFlagList) {
				if(StringUtils.isNotBlank(planMetadata.getFieldValue())){
					setOverriddenPlanMetadataValue(planMetadata);
				}
			}
			overriddenFieldsList = convertOverriddenDetailsToFieldList(mergePlanDetailsClassObjects(planWrapper.getPlanDetailsClass(), planWrapper.getOverriddenDetails()));
			overriddenFieldsList = mergePlanMetaDataLists(overriddenFieldsList, overriddenFieldsWithFlagList);
		} else {
			overriddenFieldsList = convertOverriddenDetailsToFieldList(planWrapper.getPlanDetailsClass());
		}
		List<PlanMetadata> allFieldsList = new ArrayList<PlanMetadata>();
		allFieldsList.addAll(planFieldsList);
		allFieldsList.addAll(overriddenFieldsList);
		planDetailsAggregator.setListOfPlanField(allFieldsList);
		return planDetailsAggregator;
	}

	public List<PlanMetadata> convertOverriddenDetailsToFieldList(
			PlanDetailsClass planDetails) {
		List<PlanMetadata> planFieldList = null;
		if(null != planDetails){
			//SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			planFieldList = new ArrayList<PlanMetadata>();
			//CREATE CONSTANTS AND SET VALUES TO THAT KEY
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.CONTRIBUTION__ARRANGEMENT_EXCEPTION, planDetails.getContributionArrangement()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.AGE_BANDED_RATING_EXCEPTION, planDetails.getAgeBandedRating()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.AGE__REDUCTION_SCHEDULE_EXCEPTION, planDetails.getAgeReductionSchedule()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.COMPOSITE__RATING_EXCEPTION, planDetails.getCompositeRating()));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.CONT_STATE, planDetails.getContractState()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTR, planDetails.getContributionArrangement()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.COVERAGE__TERMINATES_AT_RETIREMENT_EXCEPTION, planDetails.getCoverageTerminateAtRetirement()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DISABILITY__PROVISION_EXCEPTION, planDetails.getDisablityProvision()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DURATION__EXCEPTION, planDetails.getDuration()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EARNING_DEF, planDetails.getEarningDefiniton()));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FIELD_LVL_EXCP, planDetails.getFieldLevelException()));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planDetails.getFieldLevelException()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION, planDetails.getGuranteeIssueLimit()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_BONUSES, planDetails.getIncludeBonus()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_COMMISSION, planDetails.getIncludeCommission()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCLUDE_OVERTIME, planDetails.getIncludeOvertime()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.AMOUNTS__OF_INSURANCE_EXCEPTION, planDetails.getInsuranceAmount()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO__LIFE_EXPECTANCY_EXCEPTION, planDetails.getLboLifeExpectancy()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LIVING__BENEFIT_OPTION_EXCEPTION, planDetails.getLivingBenefitOption()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS, planDetails.getMultipleOfEarnings()));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLAN_DESC, planDetails.getPlanDescription()));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PRU_VAL_EXCP, planDetails.getPruValueException()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RATE__EXPRESSION_EXCEPTION, planDetails.getRateExpression()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ROUNDING__OCCURS_EXCEPTION, planDetails.getRoundingOccurs()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ROUNDING__RULE_EXCEPTION, planDetails.getRoundingRule()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.TRAVEL__ASSISTANCE_EXCEPTION, planDetails.getTravelAssistance()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.TYP_OF_CASE, planDetails.getTypeOfCase()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.VOLUME__AMOUNTS_EXCEPTION, planDetails.getVolumeAmounts()));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION, String.valueOf(planDetails.getDollarAmount())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_MAX, String.valueOf(planDetails.getLboMax())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_PCT, String.valueOf(planDetails.getLboPercent())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMultiOfEarningsMaxDollarAmt())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMaxDollaramt())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMultiOfEarningsMinDollarAmt())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMinDollarAmt())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE, String.valueOf(planDetails.getMinParticipationPct())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RATE_GRTY, String.valueOf(planDetails.getRateGurantee())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.VOLA_CAVEAT_REATING, String.valueOf(planDetails.getVolatilityCaveatPct())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE, String.valueOf(planDetails.getEmployeeContriPrct())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DISABILITY__PROVISION_PREMIUM_CONTINUANCE_DETAILS_EXCEPTION_ATTRIBUTES, String.valueOf(planDetails.getPremiumContiDetails())));
			/*if(null != planDetails.getEffectiveDate()){
				planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLANEFFDT, dateFormat.format(planDetails.getEffectiveDate())));		
			}*/
			
			//new fields added
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RATE__GUARANTEE_EXCEPTION_ATTRIBUTES__RATE_GUARANTEE_IN_YEARS, String.valueOf(planDetails.getRateGurantee())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCREMENTAL__FLAT_DOLLAR_AMOUNTS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMultiOfEarningsMaxDollarAmt())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION, String.valueOf(planDetails.getCaseFlatAmt())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE, String.valueOf(planDetails.getEmployeeContribType())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT, String.valueOf(planDetails.getEmployeeContribFlatAmt())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE, String.valueOf(planDetails.getEmployeeContribPercent())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DISABILITY__PROVISION_PREMIUM_CONTNUANCE_DETAILS_EXCEPTION_ATTRIBUTES__PREMIUM_CONTINUANCE_DETAILS, String.valueOf(planDetails.getPremiumContinuanceDetails())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCREMENTAL__FLAT_DOLLAR_AMOUNTS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getMultiOfEarningsMinDollarAmt())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ENROLLMENT_ASSUMPTION_VARIATION, String.valueOf(planDetails.getEnrollmentAssumptionVariation())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RATE__EXPRESSION_EXCEPTION_ATTRIBUTES__OTHER, String.valueOf(planDetails.getRateExpressionOther())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_LIFE_EXPECTANCY_EXCEPTION_ATTRIBUTES__OTHER, String.valueOf(planDetails.getLboLifeExpectancyOther())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GRANDFATHERING_GROUP, String.valueOf(planDetails.getGrandfatheringGroup())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION, String.valueOf(planDetails.getFlatDollarAmount())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ROUNDING__RULE_EXCEPTION, String.valueOf(planDetails.getRoundingRuleAttribute())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.AGE__REDUCTION_SCHEDULE_EXCEPTION, String.valueOf(planDetails.getAgeRedScheduleAttribute())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DURATION_EXCEPTION_ATTRIBUTES, String.valueOf(planDetails.getDuration())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, String.valueOf(planDetails.getSubProductAttribute())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.INCREMENTAL_DOLLAR_AMOUNT, String.valueOf(planDetails.getIncrementalDollAramount())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ENROLLMENT_ASSUMPTION, String.valueOf(planDetails.getEnrollmentAssumption())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MULTINATIONAL_POOLING_ATTRIBUTE, String.valueOf(planDetails.getMultinationalPoolingValue())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EXPERIENCE_ARRANGEMENT, String.valueOf(planDetails.getExperienceArrangement())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_EARNINGS, String.valueOf(planDetails.getGuaranteeIssueLmtMultiOfEarn())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GRANDFATHERING_TYPE, String.valueOf(planDetails.getGrandFatheringType())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MAXIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getPrctBlActiveAmtMaxDollarAmt())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MINIMUM_DOLLAR_AMOUNT, String.valueOf(planDetails.getPrctBlActiveAmtMinDollarAmt())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT, String.valueOf(planDetails.getPrctBlActiveAmt())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ELIMINATION_PERIOD, String.valueOf(planDetails.getEliminationPeriod())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.QUALIFYING_AGE, String.valueOf(planDetails.getQualifyingAge())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.TERMINATION_AGE, String.valueOf(planDetails.getTerminationAge())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.LBO_APPLIES_TO, String.valueOf(planDetails.getLboAppliesTo())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.ORDER_OF_PRIORITY_FOR_LBO_CLAIM_PAYMENT, String.valueOf(planDetails.getOrderOfPriorityLboClaimPayment())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.DURATION__EXCEPTION_ATTRIBUTES__OTHER, String.valueOf(planDetails.getOtherDurationAge())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.SPECIFIC_EMPLOYEE_WAITING_PERIOD_ATTRIBUTES__DAYS, String.valueOf(planDetails.getSpecificEmployeeWaitingPeriodDays())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.RETENTION_BASIS, String.valueOf(planDetails.getRetentionBasis())));
			planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION, String.valueOf(planDetails.getGuaranteeIssue())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.MEDICAL_UNDERWRITING, String.valueOf(planDetails.getMedicalUnderwriting())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.BURIAL_EXPENSE_PAYMENT, String.valueOf(planDetails.getBurialExpensePayment())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.BENEFICIARY_FINANCIAL_COUNSELING_SERVICES, String.valueOf(planDetails.getBeneficiaryFinCounselingService())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EXISTING_EARNINGS_DEFINITION, String.valueOf(planDetails.getExistingEarningDefinition())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.EMPLOYEE_WAITING_PERIOD_OPTIONS, String.valueOf(planDetails.getEmployeeWaitingPeriodOption())));
			//planFieldList.add(setPlanMetadataValue(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP, String.valueOf(planDetails.getMaxDollarCap())));
			//end of new fields
		}
		return planFieldList;
	}
	
	public Commission createDefaultCommission(ProposalBrokerDetails proposalBrokerDetails, PlanDetailsAggregator planDetailsAggregator){
		Commission commission = null;
		if(null == proposalBrokerDetails){
			commission = new Commission();
			commission.setBrokerID(planDetailsAggregator.getBrokerId());
			commission.setProposalPlanID(String.valueOf(planDetailsAggregator.getPlanId()));
			commission.setVersionNumber(planDetailsAggregator.getProposalVersionId());
		} else {
			commission = parseCommissionResponse(proposalBrokerDetails);
		}
		return commission;
	}
	
	public PlanEligibility createDefaultEligibility(PlanDetailsAggregator planDetailsAggregator, PlanWrapper planWrapper, int censusId, List<CensusClass> allocatedCensusClasses){
		List<PlanEligibilityClass> planEligibilityList = new ArrayList<PlanEligibilityClass>();
		if(null != planWrapper){
			planEligibilityList = planWrapper.getPlanEligibilityClass();
		}
		
		PlanEligibility eligibility = new PlanEligibility();
		//if(CollectionUtils.isEmpty(planEligibilityList)){
			if(censusId > 0){
				eligibility.setCensusID(censusId);
			}
			if(planWrapper!= null && planWrapper.getPlanDetailsClass() != null && planWrapper.getPlanDetailsClass().getMinHrsReqd() != null){
				eligibility.setMinHrsRequired(planWrapper.getPlanDetailsClass().getMinHrsReqd());
			} else {
				eligibility.setMinHrsRequired(30F);
			}
			eligibility.setPlanID(planDetailsAggregator.getPlanId());
			eligibility.setVersionNumber(planDetailsAggregator.getProposalVersionId());
		//} else {
			eligibility = mapToPlanEligibility(planEligibilityList, eligibility, allocatedCensusClasses,censusId);
	//	}
		return eligibility;
	}
	
	public CensusCls getCensusClassDetails(CensusClass censusClass, int noOfLives){
		CensusCls censusCls = new CensusCls();
		censusCls.setCensusClsId(censusClass.getCensusClsId());
		censusCls.setClassDesc(censusClass.getClassDesc());
		censusCls.setClassSelected(false);
		censusCls.setNoOfLives(noOfLives);
		return censusCls;
	}

	public void validateCommissionDetails(Commission commission) throws Exception{
		if(commission != null){
			ValidationException exceptionObj1 = new ValidationException();
			if(commission.getCommissionSplit() < 0 || commission.getCommissionSplit() >100 ){
				exceptionObj1.addError("Commission",SparcConstants.INVALID_COMM_PERCENTAGE);
			}else if (commission.getCommissionSplit() !=100) {
				throw new ValidationException(SparcConstants.INVALID_COMMISSION);
			}
			List<ErrorMessage> subList = null;
			if (CollectionUtils.isNotEmpty(exceptionObj1.getErrorList())) {
				subList = new ArrayList<ErrorMessage>(exceptionObj1.getErrorList().subList(0,
						exceptionObj1.getErrorList().size()));
				exceptionObj1.getErrorMap().put("Commission",subList);
			}
			if (exceptionObj1 != null && exceptionObj1.getErrorMap().size() > 0) {
				throw exceptionObj1;
			}
		}
	}
}
