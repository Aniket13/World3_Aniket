package com.pru.sparc.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.CensusCls;
import com.pru.sparc.bo.model.CensusMemberDtl;
import com.pru.sparc.common.exception.ErrorMessage;
import com.pru.sparc.common.exception.ValidationException;
import com.pru.sparc.common.util.SparcConstants;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.common.util.Utility;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.CensusMemberDetails;

@Component
public class CensusMemberDtlProcessor {
	
	/**
	 * Method is used to set entity values
	 * @param CensusMemberDtl, CensusMemberDetailsEntity
	 * @return boolean
	 * @throws ValidationException 
	 * @throws Exception
	 */
	public CensusMemberDetails mapToCensusDtlEntity(CensusMemberDtl model,
			 CensusClass censusClass,CensusDetail censusDetail) throws ValidationException {
		CensusMemberDetails censusMemberDetails = new CensusMemberDetails();
		ValidationException exceptionObj1 = new ValidationException();
		
		if (StringUtils.isNotBlank(model.getAddVolume()) 
				&& !SparcUtil.isDouble(model.getAddVolume())) {
			exceptionObj1.addError("PruBasicADDAmount","field requires a NUMERIC value.");
		} else {
			censusMemberDetails.setAddVolume(Utility.checkNullObject(model.getAddVolume()));
		}
		if (StringUtils.isEmpty(model.getAge())){
			exceptionObj1.addError("Age","Error: Census member with age < 1");
		}else if(!SparcUtil.isInteger(model.getAge())) {
			exceptionObj1.addError("Age","field requires a NUMERIC value.");
		} else {
			int age=0;
			if(StringUtils.isNotEmpty(model.getAge())){
				 age = Integer.parseInt(model.getAge());
			}
			if (age < 1) {
				exceptionObj1.addError("Age","Error: Census member with age < 1");
			} else if (age > 99) {
				model.setAge("99");
			}
		}
		censusMemberDetails.setAge(model.getAge()+"");
		if (StringUtils.isNotBlank(model.getBasicLifeVol()) 
				&& !SparcUtil.isDouble(model.getBasicLifeVol())) {
			exceptionObj1.addError("PruBasicLifeAmount","field requires a NUMERIC value.");
		} else {
			censusMemberDetails.setBasicLifeVol(Utility.checkNullObject(model.getBasicLifeVol()));
		}
		if (StringUtils.isNotEmpty(model.getBirthDate())){
			if (!model.getBirthDate().matches(SparcConstants.DATE_REGEX)) {
			exceptionObj1.addError("BirthDate","field requires a DATE format.");
			}
		} else {
			censusMemberDetails.setBirthDate(SparcUtil.convertStrToDate(model.getBirthDate()));
		}
		censusMemberDetails.setCity(Utility.checkNullObject(model.getCity()));
		if (StringUtils.isNotBlank(model.getDentalChildPart()) 
				&& !SparcUtil.isInteger(model.getDentalChildPart())) {
			exceptionObj1.addError("DependentDentChildPart","field requires a NUMERIC value.");
		} else {
			censusMemberDetails.setDentalChildPart(Utility.checkNullObject(model.getDentalChildPart()));
		}
		censusMemberDetails.setDentalPart(Utility.checkNullObject(model.getDentalPart()));
		censusMemberDetails.setDentalSpoucePart(Utility.checkNullObject(model.getDentalSpoucePart()));
		censusMemberDetails.setDglChildPart(Utility.checkNullObject(model.getDglChildPart()));
		if (StringUtils.isNotBlank(model.getDglChildVolume()) 
				&& !SparcUtil.isDouble(model.getDglChildVolume())) {
			exceptionObj1.addError("PruDGLChildAmount","field requires a NUMERIC value.");
		} else {
			censusMemberDetails.setDglChildVolume(Utility.checkNullObject(model.getDglChildVolume()));
		}
		censusMemberDetails.setDglSpoucePart(Utility.checkNullObject(model.getDglSpoucePart()));
		if (StringUtils.isNotBlank(model.getDglSpouceVolume()) 
				&& !SparcUtil.isDouble(model.getDglSpouceVolume())) {
			exceptionObj1.addError("PruDGLSpouseAmount","field requires a NUMERIC value.");
		} else {
			censusMemberDetails.setDglSpouceVolume(Utility.checkNullObject(model.getDglSpouceVolume()));
		}
		censusMemberDetails.setEmpID(Utility.checkNullObject(model.getEmpID()));
		censusMemberDetails.setFirstName(Utility.checkNullObject(model.getFirstName()));
		censusMemberDetails.setGender(Utility.checkNullObject(model.getGender()));
		censusMemberDetails.setGovtID(Utility.checkNullObject(model.getGovtID()));
		if (StringUtils.isNotEmpty(model.getHireDate())){
			if(!model.getHireDate().matches(SparcConstants.DATE_REGEX)) {
			exceptionObj1.addError("PruHireDate","field requires a DATE format.");
			}
		 else {
				censusMemberDetails.setHireDate(SparcUtil.convertStrToDate(model.getHireDate()));
		 	}
		}
		if (StringUtils.isNotBlank(model.getJobDescription())) {
			censusMemberDetails.setJobDescription(model.getJobDescription());
		}
		censusMemberDetails.setLastName(Utility.checkNullObject(model.getLastName()));
		if (StringUtils.isNotBlank(model.getCensusClsId())) {
		 censusClass.setCensusClsId(Integer.parseInt(model.getCensusClsId()));
		}
		censusMemberDetails.setMemberClass(censusClass);
		censusMemberDetails.setOaddPart(Utility.checkNullObject(model.getOaddPart()));
		if (StringUtils.isNotBlank(model.getOaddVolume()) 
				&& !SparcUtil.isDouble(model.getOaddVolume())) {
			exceptionObj1.addError("PruOptionalADDAmount","field requires a NUMERIC value.");
		} else {
			censusMemberDetails.setOaddVolume(Utility.checkNullObject(model.getOaddVolume()));
		}
		censusMemberDetails.setOccupationCode(Utility.checkNullObject(model.getOccupationCode()));
		censusMemberDetails.setOglPart(Utility.checkNullObject(model.getOglPart()));
		if (StringUtils.isNotBlank(model.getOglVolume()) 
				&& !SparcUtil.isDouble(model.getOglVolume())) {
			exceptionObj1.addError("PruOptionalLifeAmount","field requires a NUMERIC value.");
		} else {
			censusMemberDetails.setOglVolume(Utility.checkNullObject(model.getOglVolume()));
		}
		censusMemberDetails.setOptionalLtdPart(Utility.checkNullObject(model.getOptionalLtdPart()));
		censusMemberDetails.setOptionalStdPart(Utility.checkNullObject(model.getOptionalStdPart()));
		censusMemberDetails.setResidenceZip(Utility.checkNullObject(model.getResidenceZip()));
		if (StringUtils.isNotBlank(model.getSalary()) 
				&& !SparcUtil.isDouble(model.getSalary())) {
			exceptionObj1.addError("PruSalary","field requires a NUMERIC value.");
		} else {
			censusMemberDetails.setSalary(Utility.checkNullObject(model.getSalary()));
		}
		censusMemberDetails.setState(Utility.checkNullObject(model.getState()));
		censusMemberDetails.setZipCode(Utility.checkNullObject(model.getZipCode()));
		censusDetail.setCensusId(model.getCensusId());
		censusMemberDetails.setCensusDetail(censusDetail);
		censusMemberDetails.setCensusMemberId(model.getCensusMemId());
		List<ErrorMessage> subList = null;
		if (CollectionUtils.isNotEmpty(exceptionObj1.getErrorList())) {
			subList = new ArrayList<ErrorMessage>(exceptionObj1.getErrorList().subList(0,exceptionObj1.getErrorList().size()));
			exceptionObj1.getErrorMap().put("BLANK",subList);
			// checkpoint to add the new sublist from below index
		}
		//censusMemberDetails.setCensusMemEmbadable(censusMemberEmbadable);
		if (exceptionObj1 != null && exceptionObj1.getErrorMap().size() > 0) {
			 throw exceptionObj1;
		}
		return censusMemberDetails;
	}

	public List<CensusMemberDtl> mapCensusMemberObject(
			List<CensusMemberDetails> censusMembersLst) {
		List<CensusMemberDtl> memberDtlLst=new ArrayList<CensusMemberDtl>(); 
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy");
		for(CensusMemberDetails censusMemberDetails:censusMembersLst){
			CensusMemberDtl model=new CensusMemberDtl();
			model.setAddVolume(Utility.checkNullObject(censusMemberDetails.getAddVolume()));
			model.setAge(censusMemberDetails.getAge());
			model.setBasicLifeVol(Utility.checkNullObject(censusMemberDetails.getBasicLifeVol()));
			if(censusMemberDetails.getBirthDate()!=null){
			model.setBirthDate(Utility.checkNullObject(dateFormat1.format(censusMemberDetails.getBirthDate())));
			}
			model.setCity(Utility.checkNullObject(censusMemberDetails.getCity()));
			model.setDentalChildPart(Utility.checkNullObject(censusMemberDetails.getDentalChildPart()));
			model.setDentalPart(Utility.checkNullObject(censusMemberDetails.getDentalPart()));
			model.setDentalSpoucePart(Utility.checkNullObject(censusMemberDetails.getDentalSpoucePart()));
			model.setDglChildPart(Utility.checkNullObject(censusMemberDetails.getDglChildPart()));
			model.setDglChildVolume(Utility.checkNullObject(censusMemberDetails.getDglChildVolume()));
			model.setDglSpoucePart(Utility.checkNullObject(censusMemberDetails.getDglSpoucePart()));
			model.setDglSpouceVolume(Utility.checkNullObject(censusMemberDetails.getDglSpouceVolume()));
			model.setEmpID(Utility.checkNullObject(censusMemberDetails.getEmpID()));
			model.setFirstName(Utility.checkNullObject(censusMemberDetails.getFirstName()));
			model.setGender(Utility.checkNullObject(censusMemberDetails.getGender()));
			model.setGovtID(Utility.checkNullObject(censusMemberDetails.getGovtID()));
			if(censusMemberDetails.getHireDate()!=null){
			model.setHireDate(Utility.checkNullObject(dateFormat1.format(censusMemberDetails.getHireDate())));
			}
			model.setJobDescription(Utility.checkNullObject(censusMemberDetails.getJobDescription()));
			model.setLastName(Utility.checkNullObject(censusMemberDetails.getLastName()));
			model.setMemberClass(mapToCensusCls(censusMemberDetails.getMemberClass()));
			model.setOaddPart(Utility.checkNullObject(censusMemberDetails.getOaddPart()));
			model.setOaddVolume(Utility.checkNullObject(censusMemberDetails.getOaddVolume()));
			model.setOccupationCode(Utility.checkNullObject(censusMemberDetails.getOccupationCode()));
			model.setOglPart(Utility.checkNullObject(censusMemberDetails.getOglPart()));
			model.setOglVolume(Utility.checkNullObject(censusMemberDetails.getOglVolume()));
			model.setOptionalLtdPart(Utility.checkNullObject(censusMemberDetails.getOptionalLtdPart()));
			model.setOptionalStdPart(Utility.checkNullObject(censusMemberDetails.getOptionalStdPart()));
			model.setResidenceZip(Utility.checkNullObject(censusMemberDetails.getResidenceZip()));
			model.setSalary(Utility.checkNullObject(censusMemberDetails.getSalary()));
			model.setState(Utility.checkNullObject(censusMemberDetails.getState()));
			model.setZipCode(Utility.checkNullObject(censusMemberDetails.getZipCode()));
			model.setCensusMemId(censusMemberDetails.getCensusMemberId());
			model.setCensusId(censusMemberDetails.getCensusDetail().getCensusId());
			model.setCensusClsId(Utility.checkNullObject(censusMemberDetails.getMemberClass().getCensusClsId()));
			memberDtlLst.add(model);
		}
		
		return memberDtlLst;
	}

	public CensusCls mapToCensusCls(CensusClass censusClsDtl) {
		CensusCls census = new CensusCls();
		census.setCensusClsId(censusClsDtl.getCensusClsId());
		census.setClassDesc(censusClsDtl.getClassDesc());
		census.setColBargain(charAsBool(censusClsDtl.getCollBargain()));
		census.setExempt(charAsBool(censusClsDtl.getExempt()));
		census.setFulTime(charAsBool(censusClsDtl.getFullTime()));
		census.setGrandFather(charAsBool(censusClsDtl.getGrandFathered()));
		census.setMedicallyUnd(charAsBool(censusClsDtl.getMedicallyUnd()));
		census.setMgmt(charAsBool(censusClsDtl.getManagement()));
		census.setRetire(charAsBool(censusClsDtl.getRetiree()));
		census.setSalaried(charAsBool(censusClsDtl.getSalaried()));
		census.setSmoker(charAsBool(censusClsDtl.getSmoker()));
		return census;
	}
	
	public boolean charAsBool(String str) {

		boolean result = false;

		if ("t".equalsIgnoreCase(str.trim())) {

			result = true;

		}
		if ("f".equalsIgnoreCase(str.trim())) {

			result = false;

		}
		return result;
	}
	
}
