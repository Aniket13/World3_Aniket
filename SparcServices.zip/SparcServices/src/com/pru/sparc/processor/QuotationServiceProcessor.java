package com.pru.sparc.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.LookupInfo;
import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.bo.model.Quotation;
import com.pru.sparc.common.exception.ErrorMessage;
import com.pru.sparc.common.exception.ValidationException;
import com.pru.sparc.common.util.SparcConstants;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.QuotationDetails;


@Component("quotationServiceProcessor")
public class QuotationServiceProcessor {

	public void processNewQuotationrequest(Proposal proposal) throws Exception {
		if (StringUtils.isBlank(proposal.getProposalId())) {
			throw new ValidationException(SparcConstants.PROPOSAL_ID_BLANK);
		}
	}

	public void processSaveQuotationrequest(Quotation quotation) throws Exception {
		if (StringUtils.isBlank(quotation.getProposalId())) {
			throw new ValidationException(SparcConstants.PROPOSAL_ID_BLANK);
		}
		if (quotation.getVersionNumber() <= 0 ) {
			throw new ValidationException(SparcConstants.INVALID_VERSION_NO);
		}
	}

	public void processgetProposalVersionsrequest(Proposal proposal) throws Exception {
		if (StringUtils.isBlank(proposal.getProposalId())) {
			throw new ValidationException(SparcConstants.PROPOSAL_ID_BLANK);
		}
	}

	public void getVersionDetails(Quotation quotation) throws Exception {
		if (StringUtils.isBlank(quotation.getProposalId())) {
			throw new ValidationException(SparcConstants.PROPOSAL_ID_BLANK);
		}
		if (quotation.getVersionNumber() <= 0 ) {
			throw new ValidationException(SparcConstants.INVALID_VERSION_NO);
		}
	}

	public void getProposalVersionsCount(Proposal proposal) throws Exception {
		if (StringUtils.isBlank(proposal.getProposalId())) {
			throw new ValidationException(SparcConstants.PROPOSAL_ID_BLANK);
		}
	}

	public Map<String, String> mapToNewQuotationRequestMap(Proposal proposal) throws Exception {
		if (StringUtils.isBlank(proposal.getProposalId())) {
			throw new ValidationException(SparcConstants.PROPOSAL_ID_BLANK);
		}
		Map<String, String> requestMap = new HashMap<String, String>();
		requestMap.put("proposalId", proposal.getProposalId());
		return requestMap;
	}

	public void createNewPerformanceGuarantee(Quotation quotation) throws Exception {
		if (StringUtils.isBlank(quotation.getProposalId())) {
			throw new ValidationException(SparcConstants.PROPOSAL_ID_BLANK);
		}
		if (quotation.getVersionNumber() <= 0 ) {
			throw new ValidationException(SparcConstants.INVALID_VERSION_NO);
		}
	}
	
	public void processUpdateCommissionrequest(Commission commission) throws Exception {
		ValidationException exceptionObj1 = new ValidationException();
		if (StringUtils.isBlank(commission.getProposalPlanID())) {
			throw new ValidationException(SparcConstants.PROPOSAL_ID_BLANK);
		}
		if (commission.getBrokerID() <= 0 ) {
			throw new ValidationException(SparcConstants.INVALID_BROKER_ID);
		}
		
		if(commission.getCommissionSplit() < 0 || commission.getCommissionSplit() >100 ){
			exceptionObj1.addError("Commission",SparcConstants.INVALID_COMM_PERCENTAGE);
		}else if (commission.getCommissionSplit() !=100) {
			throw new ValidationException(SparcConstants.INVALID_COMMISSION);
		}
		List<ErrorMessage> subList = null;
		if (CollectionUtils.isNotEmpty(exceptionObj1.getErrorList())) {
			subList = new ArrayList<ErrorMessage>(exceptionObj1.getErrorList().subList(0,
					exceptionObj1.getErrorList().size()));
			exceptionObj1.getErrorMap().put("Commission",subList);
		}
		if (exceptionObj1 != null && exceptionObj1.getErrorMap().size() > 0) {
			throw exceptionObj1;
		}
	}

	public ProposalBrokerDetails createUpdateCommissionRequest(ProposalBrokerDetails proposalBrokerDetails,	Commission commission, QuotationDetails quotationDetails) {
		proposalBrokerDetails.setAdvComm(commission.getAdvanceCommission());
		proposalBrokerDetails.setAdvCommOccurs(commission.getAdvaceCommissionOccurs());
		proposalBrokerDetails.setArrangement(commission.getArrangement());
		proposalBrokerDetails.setCommissionSplit(commission.getCommissionSplit());
		proposalBrokerDetails.setCommPaidTo(commission.getCommissionPaidTo());
		proposalBrokerDetails.setFlatAmount(commission.getFlatAmount());
		proposalBrokerDetails.setFlatPercentage(commission.getFlatPercentage());
		//proposalBrokerDetails.getBrokerDetails().setBrokerId(commission.getBrokerID());
		proposalBrokerDetails.setAdvanceCommissionFlag(commission.getAdvanceCommissionFlag());
		proposalBrokerDetails.setVersionDetails(quotationDetails);
		return proposalBrokerDetails;
	}

	public LookupInfo createLookupObject() {
		LookupInfo lookupInfo = new LookupInfo();
		lookupInfo.setLookupCategory("'QUOTE_REASON_BL'");
		lookupInfo.setLookupType("");
		lookupInfo.setCode("");
		lookupInfo.setDescription("");
		return lookupInfo;
	}

}
