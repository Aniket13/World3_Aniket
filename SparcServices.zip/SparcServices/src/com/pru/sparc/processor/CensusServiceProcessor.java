package com.pru.sparc.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.Census;
import com.pru.sparc.bo.model.CensusAllocationLives;
import com.pru.sparc.bo.model.CensusCls;
import com.pru.sparc.common.exception.ValidationException;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.CensusLvsAlloc;

@Component
public class CensusServiceProcessor {

	public CensusDetail mapToCensusDetailRequestObject(
			CensusDetail existingCensusDtl, Census census) throws ValidationException {
		if (StringUtils.contains(census.getCensus_fl_Name(), "\"")) {
			throw new ValidationException("Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.");
		} else {
			existingCensusDtl.setCensusName(census.getCensus_fl_Name());
		}
		if (StringUtils.isNotBlank(census.getCensus_dt()) 
				&& !SparcUtil.isValidDate(census.getCensus_dt())
				&& StringUtils.contains(census.getCensus_dt(), "\"")) {
			throw new ValidationException("'"+census.getCensus_dt() +"'"+ "is an invalid date.\n Dates must be in the form:\n\n mm/dd/yyyy");
		} else {
			existingCensusDtl.setCensusDate(SparcUtil.convertStrToDate(census.getCensus_dt()));
		}
		if (StringUtils.isNotBlank(census.getLast_mod_dt()) 
				&& !SparcUtil.isValidDate(census.getLast_mod_dt())
				&& StringUtils.contains(census.getLast_mod_dt(), "\"")) {
			throw new ValidationException("'"+census.getLast_mod_dt() +"'"+ "is an invalid date.\n Dates must be in the form:\n\n mm/dd/yyyy");
		} else {
			existingCensusDtl.setLastModDate(census.getLast_mod_dt());
		}
		existingCensusDtl.setCreatedBy(census.getCreated_by());
		existingCensusDtl.setTotalLives(census.getNo_of_live());
		if (census.getNotes().length() > 100) {
			throw new ValidationException("Please enter only 100 characters");
		} else {
			existingCensusDtl.setNotes(census.getNotes());
		}
		if (StringUtils.isNotBlank(census.getReceit_dt()) 
				&& !SparcUtil.isValidDate(census.getReceit_dt())
				&& StringUtils.contains(census.getReceit_dt(), "\"")) {
			throw new ValidationException("'"+census.getReceit_dt() +"'"+ "is an invalid date.\n Dates must be in the form:\n\n mm/dd/yyyy");
		} else {
			existingCensusDtl.setReceiptDate(SparcUtil.convertStrToDate(census.getReceit_dt()));
		}
		existingCensusDtl.setSalaryAmount(census.getSal_amt());
		existingCensusDtl.setContainsSalary(census.getSal_info_avia());
		existingCensusDtl.setTimeRecvDate(census.getTime_recv_dt());
		return existingCensusDtl;
	}

	public List<Census> mapResultToCensus(List<CensusDetail> resultList) {
		List<Census> censusList = new ArrayList<Census>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy");
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (CensusDetail result : resultList) {
				Census censusVo = new Census();
				if(result.getCensusDate() != null){
					censusVo.setCensus_dt(dateFormat1.format(result.getCensusDate()));
					censusVo.setCensusDateFormat(dateFormat.format(result.getCensusDate()));
				}
				
				censusVo.setCensus_fl_Name(result.getCensusName());
				censusVo.setCensus_id(result.getCensusId());
				censusVo.setCreated_by(result.getCreatedBy());
				censusVo.setLast_mod_dt(result.getLastModDate());
				censusVo.setNo_of_live(result.getTotalLives());
				censusVo.setNotes(result.getNotes());
				if(result.getReceiptDate() != null){
					censusVo.setReceit_dt(dateFormat1.format(result.getReceiptDate()));
					censusVo.setReceivedDateFormat(dateFormat.format(result.getReceiptDate()));
				}
				censusVo.setSal_amt(result.getSalaryAmount());
				censusVo.setSal_info_avia(result.getContainsSalary());
				censusVo.setTime_recv_dt(result.getTimeRecvDate());
				censusList.add(censusVo);
			}
		}
		return censusList;
	}

	public Census mapToCensus(CensusDetail censusDtl) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		Census census = new Census();
		census.setCensus_fl_Name(censusDtl.getCensusName());
		if(null != censusDtl.getCensusDate()){
			census.setCensus_dt(dateFormat.format(censusDtl.getCensusDate()));
		}
		census.setLast_mod_dt(censusDtl.getLastModDate());
		census.setCreated_by(censusDtl.getCreatedBy());
		census.setNo_of_live(censusDtl.getTotalLives());
		census.setNotes(censusDtl.getNotes());
		if(null != census.getReceit_dt()){
			census.setReceit_dt(dateFormat.format(censusDtl.getReceiptDate()));
		}
		census.setSal_amt(censusDtl.getSalaryAmount());
		census.setSal_info_avia(censusDtl.getContainsSalary());
		census.setTime_recv_dt(censusDtl.getTimeRecvDate());
		return census;
	}

	public CensusCls mapToCensusCls(CensusClass censusClsDtl) {
		CensusCls census = new CensusCls();
		census.setCensusClsId(censusClsDtl.getCensusClsId());
		census.setClassDesc(censusClsDtl.getClassDesc());
		census.setColBargain(charAsBool(censusClsDtl.getCollBargain()));
		census.setExempt(charAsBool(censusClsDtl.getExempt()));
		census.setFulTime(charAsBool(censusClsDtl.getFullTime()));
		census.setGrandFather(charAsBool(censusClsDtl.getGrandFathered()));
		census.setMedicallyUnd(charAsBool(censusClsDtl.getMedicallyUnd()));
		census.setMgmt(charAsBool(censusClsDtl.getManagement()));
		census.setRetire(charAsBool(censusClsDtl.getRetiree()));
		census.setSalaried(charAsBool(censusClsDtl.getSalaried()));
		census.setSmoker(charAsBool(censusClsDtl.getSmoker()));
		return census;
	}

	
	public List<CensusClass> mapToCensusClass(List<CensusCls> censusCls) {
		List<CensusClass> censusClsList = new ArrayList<CensusClass>();
		CensusDetail cls= null;
		//CensusClassEmbadable embdl = null;
		for (CensusCls cenCls : censusCls) {
			CensusClass censusVo = new CensusClass();
			cls = new CensusDetail();
		//	embdl =  new CensusClassEmbadable();
			cls.setCensusId(cenCls.getCensusId());
			censusVo.setCensusDetail(cls);
			censusVo.setCensusClsId(cenCls.getCensusClsId());
			//censusVo.setCensusId(cls);
			//censusVo.setCenClsEmbadable(embdl);
			censusVo.setClassDesc(cenCls.getClassDesc());
			//censusVo.setCensusClsId(cenCls.getCensusClsId());
			censusVo.setCollBargain(boolAsChar(cenCls.isColBargain()));
			censusVo.setExempt(boolAsChar(cenCls.isExempt()));
			censusVo.setFullTime(boolAsChar(cenCls.isFulTime()));
			censusVo.setGrandFathered(boolAsChar(cenCls.isGrandFather()));
			censusVo.setMedicallyUnd(boolAsChar(cenCls.isMedicallyUnd()));
			censusVo.setManagement(boolAsChar(cenCls.isMgmt()));
			censusVo.setRetiree(boolAsChar(cenCls.isRetire()));
			censusVo.setSalaried(boolAsChar(cenCls.isSalaried()));
			censusVo.setSmoker(boolAsChar(cenCls.isSmoker()));
			censusClsList.add(censusVo);
		}
		return censusClsList;
	}

	public CensusClass mapToCensusClass(CensusCls censusCls) {
		CensusClass censusCl = new CensusClass();
		CensusDetail cls= new CensusDetail();
		cls.setCensusId(censusCls.getCensusId());
		//CensusClassEmbadable embdl = new CensusClassEmbadable();
		censusCl.setCensusDetail(cls);
		censusCl.setCensusClsId(censusCls.getCensusClsId());
		//censusCl.setCenClsEmbadable(embdl);
		/*censusCl.setCensusDetail(cls);
		censusCl.setCensusClsId(censusCls.getCensusClsId());*/
		censusCl.setClassDesc(censusCls.getClassDesc());
		censusCl.setCollBargain(boolAsChar(censusCls.isColBargain()));
		censusCl.setExempt(boolAsChar(censusCls.isExempt()));
		censusCl.setFullTime(boolAsChar(censusCls.isFulTime()));
		censusCl.setGrandFathered(boolAsChar(censusCls.isGrandFather()));
		censusCl.setMedicallyUnd(boolAsChar(censusCls.isMedicallyUnd()));
		censusCl.setManagement(boolAsChar(censusCls.isMgmt()));
		censusCl.setRetiree(boolAsChar(censusCls.isRetire()));
		censusCl.setSalaried(boolAsChar(censusCls.isSalaried()));
		censusCl.setSmoker(boolAsChar(censusCls.isSmoker()));
		return censusCl;
	}
	
	/**
	 * 
	 * @param censusAllocLives
	 * @return List<CensusLvsAlloc>
	 */
	/*public List<CensusLvsAlloc> mapToCensusAllocEntity(List<CensusAllocationLives> censusAllocLives){
		List<CensusLvsAlloc> censusLvsAllocs = new ArrayList<CensusLvsAlloc>();
		for (CensusAllocationLives censusAllocationLives : censusAllocLives) {
			censusLvsAllocs.add(mapToCensusLvsAlloc(censusAllocationLives));
		}
		return censusLvsAllocs;
	}*/
	
	/**
	 * 
	 * @param censusAllocationLives
	 * @return CensusLvsAlloc
	 */
	public CensusLvsAlloc mapToCensusLvsAlloc(CensusLvsAlloc cenAlloc , CensusAllocationLives censusAllocationLives){
		if(null == cenAlloc){
			cenAlloc = new CensusLvsAlloc();
			CensusDetail cls= new CensusDetail();
			cls.setCensusId(censusAllocationLives.getCensusId());
			cenAlloc.setCensusDetail(cls);
		}
		
		//CensusAllocationEmbadable embdl = new CensusAllocationEmbadable();
		cenAlloc.setState((censusAllocationLives.getCenState()));
		//cLvsAlloc.setCenAllocEmbadable(embdl);
		//cLvsAlloc.setAllocPerc(censusAllocationLives.getAllocPerc());
		cenAlloc.setNoOfLives(String.valueOf(censusAllocationLives.getNoOfLives()));
		return cenAlloc;
	}
	
		public List<CensusCls> mapToCensusCls(List<CensusClass> censusClass) {
			List<CensusCls> censusClsList = new ArrayList<CensusCls>();
			for (CensusClass cenCls : censusClass) {
				CensusCls censusVo = new CensusCls();
				censusVo.setCensusId(cenCls.getCensusDetail().getCensusId());
				censusVo.setCensusClsId(cenCls.getCensusClsId());
				censusVo.setClassDesc(cenCls.getClassDesc());
				censusVo.setColBargain(charAsBool(cenCls.getCollBargain()));
				censusVo.setExempt(charAsBool(cenCls.getExempt()));
				censusVo.setFulTime(charAsBool(cenCls.getFullTime()));
				censusVo.setGrandFather(charAsBool(cenCls.getGrandFathered()));
				censusVo.setMedicallyUnd(charAsBool(cenCls.getMedicallyUnd()));
				censusVo.setMgmt(charAsBool(cenCls.getManagement()));
				censusVo.setRetire(charAsBool(cenCls.getRetiree()));
				censusVo.setSalaried(charAsBool(cenCls.getSalaried()));
				censusVo.setSmoker(charAsBool(cenCls.getSmoker()));
				censusClsList.add(censusVo);
			}
			return censusClsList;
		}


	// If there is no data in table, it will return as unchecked for all predifined class
	public List<CensusCls> mapToCensusCls_Bl(List<CensusClass> censusClass,CensusCls censuscls) {
		List<CensusCls> censusClsList = new ArrayList<CensusCls>();
		if(null!=censusClass){
			if(censusClass.size() > 0){
		for (CensusClass cenCls : censusClass) {
			CensusCls censusVo = new CensusCls();
			censusVo.setCensusId(cenCls.getCensusDetail().getCensusId());
			censusVo.setCensusClsId(cenCls.getCensusClsId());
			censusVo.setClassDesc(cenCls.getClassDesc());
			censusVo.setColBargain(charAsBool(cenCls.getCollBargain()));
			censusVo.setExempt(charAsBool(cenCls.getExempt()));
			censusVo.setFulTime(charAsBool(cenCls.getFullTime()));
			censusVo.setGrandFather(charAsBool(cenCls.getGrandFathered()));
			censusVo.setMedicallyUnd(charAsBool(cenCls.getMedicallyUnd()));
			censusVo.setMgmt(charAsBool(cenCls.getManagement()));
			censusVo.setRetire(charAsBool(cenCls.getRetiree()));
			censusVo.setSalaried(charAsBool(cenCls.getSalaried()));
			censusVo.setSmoker(charAsBool(cenCls.getSmoker()));
			censusClsList.add(censusVo);
		  }
		}else{
			CensusCls censusVoBlank = new CensusCls();
			censusVoBlank.setCensusId(censuscls.getCensusId());
			censusVoBlank.setCensusClsId(CENSUSCLASSID); 
			censusVoBlank.setClassDesc("");
			censusVoBlank.setColBargain(charAsBool(CENSUSCLASS));
			censusVoBlank.setExempt(charAsBool(CENSUSCLASS));
			censusVoBlank.setFulTime(charAsBool(CENSUSCLASS));
			censusVoBlank.setGrandFather(charAsBool(CENSUSCLASS));
			censusVoBlank.setMedicallyUnd(charAsBool(CENSUSCLASS));
			censusVoBlank.setMgmt(charAsBool(CENSUSCLASS));
			censusVoBlank.setRetire(charAsBool(CENSUSCLASS));
			censusVoBlank.setSalaried(charAsBool(CENSUSCLASS));
			censusVoBlank.setSmoker(charAsBool(CENSUSCLASS));
			censusClsList.add(censusVoBlank);  
		  }
		}else{
			CensusCls censusVoBlank = new CensusCls();
			censusVoBlank.setCensusId(censuscls.getCensusId());
			censusVoBlank.setCensusClsId(CENSUSCLASSID); 
			censusVoBlank.setClassDesc("");
			censusVoBlank.setColBargain(charAsBool(CENSUSCLASS));
			censusVoBlank.setExempt(charAsBool(CENSUSCLASS));
			censusVoBlank.setFulTime(charAsBool(CENSUSCLASS));
			censusVoBlank.setGrandFather(charAsBool(CENSUSCLASS));
			censusVoBlank.setMedicallyUnd(charAsBool(CENSUSCLASS));
			censusVoBlank.setMgmt(charAsBool(CENSUSCLASS));
			censusVoBlank.setRetire(charAsBool(CENSUSCLASS));
			censusVoBlank.setSalaried(charAsBool(CENSUSCLASS));
			censusVoBlank.setSmoker(charAsBool(CENSUSCLASS));
			censusClsList.add(censusVoBlank);
		}
		return censusClsList;
	}
  private final String CENSUSCLASS = "F";
  private final int CENSUSCLASSID = 1;
	public String boolAsChar(boolean b) {

		String result = "";

		if (b == true) {

			result = "T";

		}
		if (b == false) {

			result = "F";

		}

		return result;

	}

	public boolean charAsBool(String str) {

		boolean result = false;

		if ("t".equalsIgnoreCase(str.trim())) {

			result = true;

		}
		if ("f".equalsIgnoreCase(str.trim())) {

			result = false;

		}
		return result;
	}

	/**
	 * 
	 * @param censusAllocLivesList
	 * @return List<CensusAllocationLives>
	 */
	public List<CensusAllocationLives> mapToCensusAllocation(List<CensusLvsAlloc> censusAllocLivesList) {
		List<CensusAllocationLives> censusAllocList = new ArrayList<CensusAllocationLives>();
		for (CensusLvsAlloc cenAlloc : censusAllocLivesList) {
			CensusAllocationLives censusVo = new CensusAllocationLives();
			//censusVo.setAllocPerc(cenAlloc.getAllocPerc());
			censusVo.setCenState(cenAlloc.getState());
			censusVo.setCensusId(cenAlloc.getCensusDetail().getCensusId());
			censusVo.setNoOfLives(cenAlloc.getNoOfLives());
			censusAllocList.add(censusVo);
		}
		return censusAllocList;
	}
}
