package com.pru.sparc.processor;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.Address;
import com.pru.sparc.bo.model.Client;
import com.pru.sparc.bo.model.ClientSearchRequest;
import com.pru.sparc.common.exception.ErrorMessage;
import com.pru.sparc.common.exception.ValidationException;
import com.pru.sparc.common.util.SparcConstants;
import com.pru.sparc.dao.ClientRepository;
import com.pru.sparc.model.AddressDetails;
import com.pru.sparc.model.ClientClass;
import com.pru.sparc.model.SIC;


@Component
public class ClientServiceProcessor {
	@Autowired
	private ClientRepository clientRepository;
	/**
	 * To map the Client object into ClientClass
	 * @param Client
	 * @return ClientClass
	 */
	/*public ClientClass mapToClientRequestObject(Client client){
		ClientClass clientClass = new ClientClass();
		clientClass.setClientName(client.getClientName());
		clientClass.setContactEmail(client.getContactEmail());
		clientClass.setContractState(client.getContractState());
		clientClass.setCreatedBy("admin");
		clientClass.setdAndB(client.getdAndB());
		clientClass.setDba(client.getDba());
		clientClass.setFullLegalName(client.getFullLegalName());
		clientClass.setNatureOfBusiness(client.getNatureOfBusiness());
		clientClass.setNonErisa(client.getNonErisa()+"");
		clientClass.setParentCompany(client.getParentCompany());
		clientClass.setStatus("A");
		clientClass.setTin(client.getTin());
		clientClass.setUpdatedBy("admin");
		clientClass.setCreatedDate(new Date());
		clientClass.setUpdatedDate(new Date());
		clientClass.setAddress(mapToAddressRequestObject(client));
		clientClass.setContactName(client.getContactName());
		clientClass.setSic(client.getSic());
		clientClass.setClientId(Integer.parseInt(client.getClientId()));
		return clientClass;
	}*/
	
	/**
	 * To map the Address object into AddressDetails
	 * @param Client
	 * @return AddressDetails
	 */
	/*private AddressDetails mapToAddressRequestObject(Client client){
		AddressDetails addressDetails = new AddressDetails();
		addressDetails.setAddress(client.getAddress().getAddress());
		addressDetails.setAddress2(client.getAddress().getAddress2());
		addressDetails.setCity(client.getAddress().getCity());
		addressDetails.setCountry(client.getAddress().getCountry());
		addressDetails.setFax(client.getAddress().getFax());
		addressDetails.setPhone(client.getAddress().getPhone());
		addressDetails.setState(client.getAddress().getState());
		addressDetails.setStatus("A");
		addressDetails.setZipcode(client.getAddress().getZipcode());
		addressDetails.setCreatedBy("admin");
		addressDetails.setCreatedDate(new Date());
		addressDetails.setUpdatedBy("admin");
		addressDetails.setUpdatedDate(new Date());
		return addressDetails;
	}*/
	
	/**
	 * To validate the add/edit Client request
	 * @param Client
	 * @return boolean
	 */
	public boolean isRequestValid(Client client, boolean isSicValid) throws Exception {
		ValidationException exceptionObj1 = new ValidationException();
		if(StringUtils.isBlank(client.getSic()) || !isSicValid){
			exceptionObj1.addError("BLANK",SparcConstants.NOT_FOUND_SIC_CODE);
		}
		if(StringUtils.equalsIgnoreCase(SparcConstants.COUNTRY_UNITED_STATES, client.getAddress().get(0).getCountry())) {
			if(StringUtils.isBlank(client.getAddress().get(0).getState())) {
				exceptionObj1.addError("BLANK",SparcConstants.EMPTY_CLIENT_STATE);
			}
			if(StringUtils.isBlank(client.getAddress().get(0).getZipcode()) 
					|| !isValidUSZip(client.getAddress().get(0).getZipcode())) {
				exceptionObj1.addError("BLANK",SparcConstants.EMPTY_CLIENT_US_ZIP);
			}
		} else if(SparcConstants.COUNTRY_CANADA.equalsIgnoreCase(client.getAddress().get(0).getCountry())) {
			if(StringUtils.isBlank(client.getAddress().get(0).getZipcode()) 
					|| !isValidCanadaZip(client.getAddress().get(0).getZipcode())) {
				exceptionObj1.addError("BLANK",SparcConstants.EMPTY_CLIENT_CANADA_ZIP);
			}
		}
		int count = 0;
		List<ErrorMessage> subList = null;
		if (CollectionUtils.isNotEmpty(exceptionObj1.getErrorList())) {
			subList = new ArrayList<ErrorMessage>(exceptionObj1.getErrorList().subList(0,
					exceptionObj1.getErrorList().size()));
			exceptionObj1.getErrorMap().put("BLANK",subList);
			// checkpoint to add the new sublist from below index
			count = exceptionObj1.getErrorList().size();
		}
			if (StringUtils.isBlank(client.getClientName())) {
				exceptionObj1.addError("New Client",
						SparcConstants.EMPTY_CLIENT_NAME);
			}
			if (StringUtils.isBlank(client.getContractState())) {
				exceptionObj1.addError("New Client",
						SparcConstants.EMPTY_CONTRACT_STATE);
			}
			if (StringUtils.isNotBlank(client.getTin()) && !client.getTin().matches(SparcConstants.TIN_REGEX)) {
				exceptionObj1.addError("New Client",
						SparcConstants.INVALID_CLIENT_TIN);
			}
			
			/*Defect # 50 Added additional check for Alphanumeric*/
			if (StringUtils.isBlank(client.getSic()) || !StringUtils.isNumeric(client.getSic())) {
				exceptionObj1.addError("New Client",
						SparcConstants.INVALID_SIC_CODE);
			}

			if (CollectionUtils.isNotEmpty(exceptionObj1.getErrorList())
					&& (exceptionObj1.getErrorList().size() - count > 0)) {
				
				subList = new ArrayList<ErrorMessage>(exceptionObj1.getErrorList().subList(count,
						exceptionObj1.getErrorList().size()));
				
				exceptionObj1.getErrorMap().put("New Client", subList);
			}

			// checkpoint to add the new sublist from below index
			count = exceptionObj1.getErrorList().size();

			if (StringUtils.isBlank(client.getAddress().get(0).getCountry())) {
				exceptionObj1.addError("New Client Address",
						SparcConstants.EMPTY_CLIENT_COUNTRY);
			} else if(StringUtils.equalsIgnoreCase(client.getAddress().get(0).getCountry(),"Other")) {
				if(StringUtils.isBlank(client.getAddress().get(0).getOtherCountryVal())){
					exceptionObj1.addError("New Client Address",
							SparcConstants.EMPTY_CLIENT_COUNTRY);
				}
			}
			if (!StringUtils.isBlank(client.getAddress().get(0).getZipcode()) && !client.getAddress().get(0).getZipcode()
					.matches(SparcConstants.ZIP_REGEX)) {
				exceptionObj1.addError("New Client Address",
						SparcConstants.INVALID_CLIENT_ZIP);
			}
			if (!StringUtils.isBlank(client.getAddress().get(0).getPhone()) && !client.getAddress().get(0).getPhone()
					.matches(SparcConstants.PHONE_REGEX)) {
				exceptionObj1.addError("New Client Address",
						SparcConstants.INVALID_CLIENT_PHONE);
			}
			if (StringUtils.isBlank(client.getAddress().get(0).getCity())) {
				exceptionObj1.addError("New Client Address",
						SparcConstants.EMPTY_CLIENT_CITY);
			}

			if (CollectionUtils.isNotEmpty(exceptionObj1.getErrorList())
					&& (exceptionObj1.getErrorList().size() - count > 0)) {
				subList = new ArrayList<ErrorMessage>(exceptionObj1.getErrorList().subList(count,
						exceptionObj1.getErrorList().size()));
				exceptionObj1.getErrorMap().put(
						"New Client Address",subList);
			}
			if (exceptionObj1 != null && exceptionObj1.getErrorMap().size() > 0) {
				throw exceptionObj1;
			}
		
		return true;
	}
	
	/**
	 * To validate the search Client request
	 * @param ClientSearchRequest
	 * @return boolean
	 */
	public boolean isSearchRequestValid(ClientSearchRequest clientSearchRequest) throws Exception{
		if(StringUtils.isBlank(clientSearchRequest.getClientName()) && StringUtils.isBlank(clientSearchRequest.getDba()) && StringUtils.isBlank(clientSearchRequest.getProposalId()) && StringUtils.isBlank(clientSearchRequest.getControlNo()))
		{
			throw new ValidationException(SparcConstants.EMPTY_MANDATORY_SEARCH_FIELDS);
		}
		return true;
	}

	/**
	 * To generate the map from the details of ClientSearchRequest object
	 * @param ClientSearchRequest
	 * @return Map<String, String>
	 */
	public Map<String, String> mapToRequestMap(ClientSearchRequest clientSearchRequest) {
		Map<String, String> requestMap = new HashMap<String, String>();
		if(clientSearchRequest.getCity() != null){
			requestMap.put("city", clientSearchRequest.getCity());
		}
		if(!StringUtils.isBlank(clientSearchRequest.getControlNo())){
			requestMap.put("controlNo", clientSearchRequest.getControlNo());
		}
		if(!StringUtils.isBlank(clientSearchRequest.getDba())){
			requestMap.put("dba", clientSearchRequest.getDba());
		}
		if(!StringUtils.isBlank(clientSearchRequest.getdAndB())){
			requestMap.put("dAndB", clientSearchRequest.getdAndB());
		}
		if(!StringUtils.isBlank(clientSearchRequest.getClientName())){
			requestMap.put("clientName", clientSearchRequest.getClientName());
		}
		if(!StringUtils.isBlank(clientSearchRequest.getProposalId())){
			requestMap.put("proposalId", clientSearchRequest.getProposalId());
		}
		if(!StringUtils.isBlank(clientSearchRequest.getSic())){
			requestMap.put("sic", clientSearchRequest.getSic());
		}
		if(!StringUtils.isBlank(clientSearchRequest.getState())){
			requestMap.put("state", clientSearchRequest.getState());
		}
		return requestMap;
	}
	
	/**
	 * To map the details of ClientClass object to Client object
	 * @param List<ClientClass>
	 * @return List<Client>
	 * @throws Exception 
	 */
	public List<Client> mapResultListToClientList(List<ClientClass> resultList) throws Exception{
		List<Client> clientList = new ArrayList<Client>();
		for (ClientClass result : resultList) {
			clientList.add(mapResultToClient(result));
		}
		return clientList;
	}
	
	public Client mapResultToClient(ClientClass result) throws Exception{
		Client client = new Client();
		client.setClientId(result.getClientId());
		client.setClientName(result.getClientName());
		client.setContactEmail(result.getContactEmail());
		client.setContactName(result.getContactName());
		client.setContractState(result.getContractState());
		client.setdAndB(result.getdAndB());
		client.setDba(result.getDba());
		client.setFullLegalName(result.getFullLegalName());
		client.setNatureOfBusiness(result.getNatureOfBusiness());
		client.setNonErisa(Boolean.valueOf(result.getNonErisa()));
		client.setParentCompany(result.getParentCompany());
		client.setSic(result.getSic());
		client.setTin(result.getTin());
		client.setAddress(processAddressResponse(result.getAddress()));
		client.setSicDesc(getSicDesc(result.getSic()));
		return client;
	}
	
public String getSicDesc(String sicNo) throws Exception {
		
		String sicDesc= null;
		List<SIC> sic= clientRepository.getValidSICCodes();
		for(SIC sicDes: sic){
			if(null !=sicNo && sicDes.getSicNumber().equalsIgnoreCase(sicNo)){
				sicDesc = (String)sicDes.getDescription();
			}
		}
		 return sicDesc;
	}
	
	/**
	 * To map the details of AddressDetails object to Address object
	 * @param AddressDetails
	 * @return Address
	 */
	private List<Address> processAddressResponse(List<AddressDetails> resultAddressSet){
		List<Address> addressList = new ArrayList<Address>();
		for (AddressDetails address : resultAddressSet) {
			Address resultAddress = new Address();
			resultAddress.setAddress(address.getAddress());
			resultAddress.setAddress2(address.getAddress2());
			resultAddress.setCity(address.getCity());
			resultAddress.setCountry(address.getCountry());
			resultAddress.setOtherCountryVal(address.getOtherCountryVal());
			resultAddress.setFax(address.getFax());
			resultAddress.setPhone(address.getPhone());
			resultAddress.setState(address.getState());
			resultAddress.setZipcode(address.getZipcode());
			addressList.add(resultAddress);
		}
		return addressList;
	}


	/**
	 * To map the details of Client object to ClientClass object
	 * @param ClientClass, Client
	 * @return ClientClass
	 */
	public ClientClass mapToClientRequestObject(ClientClass existingClient,
			Client client) {
		if (existingClient == null){
			existingClient = new ClientClass();
			List<AddressDetails> addressDetailsList = new ArrayList<AddressDetails>();
			addressDetailsList.add(new AddressDetails());
			existingClient.setAddress(addressDetailsList);
		}
		existingClient.setClientName(client.getClientName());
		existingClient.setContactEmail(client.getContactEmail());
		existingClient.setContractState(client.getContractState());
		existingClient.setCreatedBy(SparcConstants.ADMIN);
		existingClient.setdAndB(client.getdAndB());
		existingClient.setDba(client.getDba());
		existingClient.setFullLegalName(client.getFullLegalName());
		existingClient.setNatureOfBusiness(client.getNatureOfBusiness());
		existingClient.setNonErisa(client.getNonErisa()+"");
		existingClient.setParentCompany(client.getParentCompany());
		existingClient.setStatus("A");
		existingClient.setTin(client.getTin());
		existingClient.setUpdatedBy(SparcConstants.ADMIN);
		existingClient.setCreatedDate(new Date());
		existingClient.setUpdatedDate(new Date());
		existingClient.setAddress(mapToAddressRequestObject(existingClient,client));
		existingClient.setContactName(client.getContactName());
		existingClient.setSic(client.getSic());
		existingClient.setClientId(client.getClientId());
		return existingClient;
	}

	/**
	 * To map the Address object into AddressDetails
	 * @param ClientClass, Client
	 * @return AddressDetails
	 */
	private List<AddressDetails> mapToAddressRequestObject(
			ClientClass existingClient, Client client) {
		existingClient.getAddress().get(0).setAddress(client.getAddress().get(0).getAddress());
		existingClient.getAddress().get(0).setAddress2(client.getAddress().get(0).getAddress2());
		existingClient.getAddress().get(0).setCity(client.getAddress().get(0).getCity());
		existingClient.getAddress().get(0).setCountry(client.getAddress().get(0).getCountry());
		existingClient.getAddress().get(0).setOtherCountryVal(client.getAddress().get(0).getOtherCountryVal());
		existingClient.getAddress().get(0).setFax(client.getAddress().get(0).getFax());
		existingClient.getAddress().get(0).setPhone(client.getAddress().get(0).getPhone());
		existingClient.getAddress().get(0).setState(client.getAddress().get(0).getState());
		existingClient.getAddress().get(0).setStatus("A");
		existingClient.getAddress().get(0).setZipcode(client.getAddress().get(0).getZipcode());
		existingClient.getAddress().get(0).setCreatedBy(SparcConstants.ADMIN);
		existingClient.getAddress().get(0).setCreatedDate(new Date());
		existingClient.getAddress().get(0).setUpdatedBy(SparcConstants.ADMIN);
		existingClient.getAddress().get(0).setUpdatedDate(new Date());
		existingClient.getAddress().get(0).setClient(existingClient);
		return existingClient.getAddress();
	}
	
	private boolean isValidUSZip(String zip){
		zip = zip.trim();
		if(zip.length() != 5 && zip.length() != 10){
			return false;
		}
		if(zip.length() == 5){
			try{
				Integer.parseInt(zip);
			}catch(NumberFormatException e){
				return false;
			}
		} else {
			if(zip.indexOf("-") != 5){
				return false;
			}
			try{
				Integer.parseInt(zip.substring(0, zip.indexOf("-")));
				Integer.parseInt(zip.substring(zip.indexOf("-")+1));
			}catch(NumberFormatException e){
				return false;
			}
		}
		return true;
	}
	
	private boolean isValidCanadaZip(String zip){
		zip = zip.trim();
		if(zip.length() != 7){
			return false;
		}
		if(zip.indexOf("-") != 3){
				return false;
		}
		return true;
	}
}
