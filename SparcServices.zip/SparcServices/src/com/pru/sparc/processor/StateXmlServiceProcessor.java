package com.pru.sparc.processor;


import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.StatesXml;
import com.pru.sparc.model.StateXml;
import com.pru.sparc.model.StateXmlEmbeddable;
@Component
public class StateXmlServiceProcessor {
	
	/**
	 * @param statesXml
	 * @return
	 */
	public StateXml mapToStateXml(String currState, String propId, String preCond, String postCond,int StateId,String userId)
	{
		StateXml state = new StateXml();
		StateXmlEmbeddable embdl = null;
		embdl = new StateXmlEmbeddable();
		embdl.setCurrState(currState);
		embdl.setProposalId(propId);
		state.setStateXmlEmbeddable(embdl);
		state.setProposalStatus("OPEN");
		state.setPostCond(preCond);
		state.setPreCond(postCond);
		state.setVersionStatus("Pending Rate Calculation");
		state.setStateStatus("A");
		state.setCrtDt(new java.util.Date().toString());
		state.setModDt(new java.util.Date().toString());
		state.setStateId(StateId);
		state.setUserId(userId);
		state.setModUser(userId);
		return state;
	}
	public StateXml mapToStatesXml(StatesXml statesXml) {
		StateXmlEmbeddable embdl = null;
		StateXml statesEnt = new StateXml();
		embdl = new StateXmlEmbeddable();
		embdl.setCurrState(statesXml.getCurrState());
		embdl.setProposalId(statesXml.getProposalId());
		statesEnt.setStateXmlEmbeddable(embdl);
		statesEnt.setProposalStatus(statesXml.getProposalStatus());
		statesEnt.setPostCond(statesXml.getPostCond());
		statesEnt.setPreCond(statesXml.getPreCond());
		statesEnt.setVersionStatus(statesXml.getVersionStatus());
		statesEnt.setStateStatus(statesXml.getStatestatus());
		statesEnt.setCrtDt(statesXml.getCrtDt());
		statesEnt.setModDt(statesXml.getModDt());
		//statesEnt.setStateId(statesXml.getStateId());
		statesEnt.setUserId(statesXml.getUserId());
		statesEnt.setModUser(statesXml.getUserId());
		return statesEnt;
	}

	public StateXml mapToStatesXml(String currState, String propId) {
		StateXmlEmbeddable embdl = null;
		StateXml stateDtl = new StateXml();
		embdl = new StateXmlEmbeddable();
		embdl.setCurrState(currState);
		embdl.setProposalId(propId);
		stateDtl.setStateXmlEmbeddable(embdl);
		return stateDtl;
	}
	
	public StatesXml mapToStateXml(StateXml stateXml) {
		StatesXml statesBO = new StatesXml();
		statesBO.setCurrState(stateXml.getStateXmlEmbeddable().getCurrState());
		statesBO.setProposalId(stateXml.getStateXmlEmbeddable().getProposalId());
		statesBO.setProposalStatus(stateXml.getProposalStatus());
		statesBO.setPostCond(stateXml.getPostCond());
		statesBO.setPreCond(stateXml.getPreCond());
		statesBO.setVersionStatus(stateXml.getVersionStatus());
		statesBO.setStatestatus(stateXml.getStateStatus());
		statesBO.setCrtDt(stateXml.getCrtDt());
		statesBO.setModDt(stateXml.getModDt());
		statesBO.setStateId(stateXml.getStateId());
		statesBO.setUserId(stateXml.getUserId());
		statesBO.setModUser(stateXml.getUserId());
		return statesBO;
	}
}
