package com.pru.sparc.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.bo.model.SalesOfficeValues;
import com.pru.sparc.bo.model.SalesRegionValues;
import com.pru.sparc.common.constants.ProposalConstants;
import com.pru.sparc.common.exception.ErrorMessage;
import com.pru.sparc.common.exception.ValidationException;
import com.pru.sparc.common.util.SparcConstants;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.common.util.Utility;
import com.pru.sparc.model.CensusMemberDetails;
import com.pru.sparc.model.ClientClass;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.SalesOffice;
import com.pru.sparc.model.SalesRegion;
@Component
public class ProposalServiceProcessor {

	/**
	 * Method is to set entity value in database
	 * @param proposalInformation
	 * @return object
	 */

	public ProposalDetails mapToProposalRequestObject(Proposal proposalInformation, ProposalDetails  proposalDetails, SalesOffice salesOffice){

		
		//ProposalDetails proposalDetails = new ProposalDetails();
		proposalDetails.setProposalId(proposalInformation.getProposalId());
		proposalDetails.setCaseEffectiveDt(SparcUtil.convertStrToDate(proposalInformation.getEffDate()));
		proposalDetails.setSalesOffice(salesOffice);
		proposalDetails.setContractState(proposalInformation.getContStateVal());
		proposalDetails.setProposalStatus(proposalInformation.getProposalStatusVal());
		proposalDetails.setTaskowner(proposalInformation.getTaskOwnerVal());
		proposalDetails.setControlNumber(proposalInformation.getControlNo());
		proposalDetails.setMarketSegmentInd(proposalInformation.getMktSegInd());
		proposalDetails.setSmallBusinessInd(proposalInformation.getSmallBusVal());
		proposalDetails.setFederalContractClient(proposalInformation.getFederalClient());
		proposalDetails.setStateContractClient(proposalInformation.getStateClient());
		proposalDetails.setLocalContractClient(proposalInformation.getLocalClient());
		proposalDetails.setExchangeQuote(proposalInformation.getExchangeQuote());
		proposalDetails.setReceivedFromClientDt(SparcUtil.convertStrToDate(proposalInformation.getDtRecClient()));
		proposalDetails.setDateRequired(SparcUtil.convertStrToDate(proposalInformation.getDtReqClient()));
		proposalDetails.setDateRequiredBroker(SparcUtil.convertStrToDate(proposalInformation.getDtReqBroker()));
		proposalDetails.setProposalComments(proposalInformation.getComments());
		proposalDetails.setProposalDescription(proposalInformation.getDescription());
		proposalDetails.setSmallBusinessInd(proposalInformation.getSmallBusVal());
		proposalDetails.setMultiNationalPooling(proposalInformation.getMultiNational());
		proposalDetails.setCreationDate(new Date());
		proposalDetails.setCreatedBy(SparcConstants.ADMIN);
		proposalDetails.setModifiedBy(null);
		proposalDetails.setModifiedDate(null);
		return proposalDetails;
	}
	/**
	 * Method is used for validation of 
	 * @param proposalInformation
	 * @return boolean
	 * @throws Exception
	 */
	public boolean isRequestValid(Proposal proposalInformation) throws Exception{
		ValidationException exceptionObj1 = new ValidationException();
		if(StringUtils.isBlank(proposalInformation.getLocalClient())){
			exceptionObj1.addError("Proposal Detail 1",SparcConstants.INVALID_LOCAL_CONTRACT);
		}
		if(StringUtils.isBlank(proposalInformation.getSalesOffVal())) {
			exceptionObj1.addError("Proposal Detail 1",SparcConstants.INVALID_PRU_SALES_OFFICE);
		}	
		if(StringUtils.isBlank(proposalInformation.getFederalClient())){
			exceptionObj1.addError("Proposal Detail 1",SparcConstants.INVALID_FEDERAL_CONTRACT);
		}
		if(StringUtils.isBlank(proposalInformation.getEffDate()) || !proposalInformation.getEffDate().matches(SparcConstants.DATE_REGEX)) {
			exceptionObj1.addError("Proposal Detail 1",SparcConstants.INVALID_CASE_EFFECTIVE_DATE);
		}
		if(StringUtils.isBlank(proposalInformation.getStateClient())){
			exceptionObj1.addError("Proposal Detail 1",SparcConstants.INVALID_STATE_CONTRACT);
		}
		
		if (CollectionUtils.isNotEmpty(exceptionObj1.getErrorList())) {
			List<ErrorMessage> subList = new ArrayList<ErrorMessage>(exceptionObj1.getErrorList().subList(0,
					exceptionObj1.getErrorList().size()));
			exceptionObj1.getErrorMap().put("Proposal Detail 1",subList);
		}
		
		//checkpoint to add the new sublist from below index
		int count = exceptionObj1.getErrorList().size();
		List<String> dateErrorList = validateDate(proposalInformation.getDtRecClient(), proposalInformation.getDtReqClient());
		if(CollectionUtils.isNotEmpty(dateErrorList)){
			for (String errMsg : dateErrorList) {
				exceptionObj1.addError("Deliverable Date", errMsg);
			}
		}
		if(proposalInformation.getDtRecClient() == null || !proposalInformation.getDtRecClient().matches(SparcConstants.DATE_REGEX)){
			exceptionObj1.addError("Deliverable Date",SparcConstants.INVALID_RECEIVED_FROM_CLIENT_DATE);
		}
		if(StringUtils.isBlank(proposalInformation.getDtReqClient()) || !proposalInformation.getDtReqClient().matches(SparcConstants.DATE_REGEX)) {
			exceptionObj1.addError("Deliverable Date",SparcConstants.INVALID_REQUIRED_DATE);
		}
		/*if(StringUtils.isBlank(proposalInformation.getDtRecClient())){
			exceptionObj1.addError("Deliverable Date",SparcConstants.EMPTY_RECEIVED_FROM_CLIENT_DATE);
		}*/
		if (CollectionUtils.isNotEmpty(exceptionObj1.getErrorList()) 
				&& (exceptionObj1.getErrorList().size() - count > 0)) {
			List<ErrorMessage> subList = new ArrayList<ErrorMessage>(exceptionObj1.getErrorList().subList(count,
					exceptionObj1.getErrorList().size()));
			exceptionObj1.getErrorMap().put("Deliverable Date", subList);
		}
		if (exceptionObj1 != null && exceptionObj1.getErrorMap().size() > 0) {
			 throw exceptionObj1;
		}
		return true;
	}
	

	public Proposal mapResultProposalToModel(ProposalDetails proposalDetails){
		Proposal proposalInformation = new Proposal();
		SimpleDateFormat sm = new SimpleDateFormat("MMMM dd, yyyy");
		proposalInformation.setClientId(proposalDetails.getClient().getClientId());
		proposalInformation.setClientName(proposalDetails.getClient().getClientName());
		proposalInformation.setComments(proposalDetails.getProposalComments());
		proposalInformation.setControlNo(proposalDetails.getControlNumber());
		proposalInformation.setContStateVal(proposalDetails.getContractState());
		proposalInformation.setDescription(proposalDetails.getProposalDescription());
		if(proposalDetails.getReceivedFromClientDt() != null){
			proposalInformation.setDtRecClient(sm.format(proposalDetails.getReceivedFromClientDt()));
		}
		if(proposalDetails.getDateRequiredBroker()!= null){
			proposalInformation.setDtReqBroker(sm.format(proposalDetails.getDateRequiredBroker()));
		}
		if(proposalDetails.getDateRequired() != null){
			proposalInformation.setDtReqClient(sm.format(proposalDetails.getDateRequired()));
		}
		if(proposalDetails.getSentToClientDt()!= null){
			proposalInformation.setDtSendToClient(sm.format(proposalDetails.getSentToClientDt()));
		}
		if(proposalDetails.getCaseEffectiveDt() != null){
			
			proposalInformation.setEffDate(sm.format(proposalDetails.getCaseEffectiveDt()));
		}
		proposalInformation.setFederalClient(proposalDetails.getFederalContractClient());
		proposalInformation.setLocalClient(proposalDetails.getLocalContractClient());
		proposalInformation.setExchangeQuote(proposalDetails.getExchangeQuote());
		proposalInformation.setMktSegInd(proposalDetails.getMarketSegmentInd());
		proposalInformation.setProposalId(proposalDetails.getProposalId());
		proposalInformation.setProposalStatusVal(proposalDetails.getProposalStatus());
		proposalInformation.setSmallBusVal(proposalDetails.getSmallBusinessInd());
		if(null != proposalDetails.getSalesOffice()){
			proposalInformation.setSalesOffVal(proposalDetails.getSalesOffice().getSalesOfficeId());
		}
		proposalInformation.setMultiNational(proposalDetails.getMultiNationalPooling());
		proposalInformation.setStateClient(proposalDetails.getStateContractClient());
		proposalInformation.setTaskOwnerVal(proposalDetails.getTaskowner());
		return proposalInformation;
	}


	public void validateHeaderDetailsRequest(Proposal proposal) {
		System.out.println(proposal.getProposalId());
		System.out.println(proposal.getClientId());
		
	}


	public Proposal parseHeaderDetails(ProposalDetails proposalHeaderDetails) {
		Proposal proposal = new Proposal();
		
		if (proposalHeaderDetails != null) {
			proposal.setProposalId(proposalHeaderDetails.getProposalId());
			if (proposalHeaderDetails.getClient() != null) {
				proposal.setClientName(proposalHeaderDetails.getClient().getClientName());
			}
			proposal.setProposalStatusVal(proposalHeaderDetails.getProposalStatus());
		}
		return proposal;
	}


	public ProposalDetails mapTocreateNewProposalRequest(ClientClass clientObj, String proposalId) {
		ProposalDetails proposalDetails = new ProposalDetails();
		//Adding Client Details
		proposalDetails.setClient(clientObj);
		proposalDetails.setContractState(clientObj.getContractState());
		proposalDetails.setProposalId(proposalId);
		proposalDetails.setProposalStatus(ProposalConstants.PROPOSAL_STATUS_OPEN);
		proposalDetails.setProposalDescription(ProposalConstants.NEW_PROPOSAL_DESCRIPTION);
		return proposalDetails;
	}


	public Proposal parseNewProposalResponse(ProposalDetails proposalDetails,List<SalesOfficeValues> salesOffVal) {
		Proposal proposal = new Proposal();
		proposal.setClientId(proposalDetails.getClient().getClientId());
		proposal.setClientName(proposalDetails.getClient().getClientName());
		proposal.setProposalId(proposalDetails.getProposalId());
		proposal.setDescription(proposalDetails.getProposalDescription());
		proposal.setProposalStatusVal(proposalDetails.getProposalStatus());
		proposal.setContStateVal(proposalDetails.getClient().getContractState());
		proposal.setSalesOffice(salesOffVal);
		return proposal;
	}
	
	public List<String> validateDate(String strFromDate, String strReqDate){
		Date fromDate = SparcUtil.convertStrToDate(strFromDate);
		Date reqDate =  SparcUtil.convertStrToDate(strReqDate);
		List<String> errorList = new ArrayList<String>();
		Calendar fromCalender = Calendar.getInstance();
		if(fromDate != null) {
			fromCalender.setTime(fromDate);
			if(reqDate != null){
				if(fromDate.after(reqDate)){
					errorList.add("Date Required must be equal or greater than Date Received");
				} else {
					Calendar cal = Calendar.getInstance();
					cal.set(Calendar.YEAR, fromCalender.get(Calendar.YEAR)+1);
					cal.set(Calendar.MONTH, fromCalender.get(Calendar.MONTH));
					cal.set(Calendar.DAY_OF_MONTH, fromCalender.get(Calendar.DATE));
					Date newDate = cal.getTime();
					if(reqDate.after(newDate)){
						errorList.add("Date required must be less than or equal to one year after Date Received From Client.");
					}
				}
			}
		} else {
			errorList.add(SparcConstants.EMPTY_RECEIVED_FROM_CLIENT_DATE);
		}
		return errorList;
	}
	
	
	
	public List<SalesOfficeValues> mapSalesOffice(List<SalesOffice> salesOffLst) {
		List<SalesOfficeValues> salesDtlLst=new ArrayList<SalesOfficeValues>(); 
		
		for(SalesOffice salesDetails:salesOffLst){
			SalesOfficeValues model=new SalesOfficeValues();
			model.setSalesOfficeId(salesDetails.getSalesOfficeId());
			model.setDescription(salesDetails.getSalesOffName());
			model.setSalesRegionValues(mapSalesRegion(salesDetails.getSalesRegion()));
			salesDtlLst.add(model);
		}
		return salesDtlLst;
	}
	
	private SalesRegionValues mapSalesRegion(SalesRegion salesRegion){
		SalesRegionValues salesRegionValues = new SalesRegionValues();
		salesRegionValues.setDivision(salesRegion.getDivision());
		salesRegionValues.setRegionId(salesRegion.getRegionId());
		salesRegionValues.setRegName(salesRegion.getRegName());
		return salesRegionValues;
	}
}
