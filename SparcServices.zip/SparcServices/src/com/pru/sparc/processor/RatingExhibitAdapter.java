package com.pru.sparc.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanPredicate;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.functors.EqualPredicate;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.ProposalVersionDetails;
import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.bo.model.VersionDetails;
import com.pru.sparc.bo.model.VersionPlan;
import com.pru.sparc.common.constants.ProposalConstants;
import com.pru.sparc.common.util.CommonUtils;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.PlanDetailsRepository;
import com.pru.sparc.dao.RatingQuoteDAO;
import com.pru.sparc.dao.impl.PlanDetailsRepositoryImpl;
import com.pru.sparc.drools.model.RatingOutputConstants;
import com.pru.sparc.drools.model.RuleRatingAggregatedCensusGrp;
import com.pru.sparc.drools.model.RuleRatingCensusCompGrp;
import com.pru.sparc.drools.model.RuleRatingModelOverrideGrp;
import com.pru.sparc.drools.model.RuleRatingModelRuleResultGrp;
import com.pru.sparc.drools.model.RuleRatingOutputModelWrapper;
import com.pru.sparc.drools.model.RuleRatingProposalPlanDetails;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.QuotationDetails;
import com.pru.sparc.model.RatingAggregatedCensus;
import com.pru.sparc.model.RatingExhibits;
import com.pru.sparc.model.RatingOverride;
import com.pru.sparc.model.RatingProposalPlanDetails;
import com.pru.sparc.model.RatingQuoteCensus;
import com.pru.sparc.model.RatingRuleResult;

@Component
public class RatingExhibitAdapter {
	
	@Autowired
	private PlanDetailsRepository planDetailsRepository;
	
	@Autowired
	private RatingQuoteDAO ratingQuoteDAO;
	
	public RatingModel parseInvokeRatingResultResponse(RatingExhibits ratingExhibitsRequestObject) {
		RatingModel model = new RatingModel();
		if (ratingExhibitsRequestObject != null) {
			model.setRatingSuccessful(true);
			model.setRateId(ratingExhibitsRequestObject.getRateId());
			if (ratingExhibitsRequestObject.getPlan() != null) {
				model.setPlanId(ratingExhibitsRequestObject.getPlan().getPlanId());
			}
		} else {
			model.setRatingSuccessful(false);
			//TODO: set the errors
		}
		return model;
	}
	
	public RuleRatingOutputModelWrapper parseRatingExhibitsResponse(RatingExhibits ratingExhibitsEntity) {
		RuleRatingOutputModelWrapper wrapper = new RuleRatingOutputModelWrapper();
		if (ratingExhibitsEntity != null) {
			wrapper.setRateId(ratingExhibitsEntity.getRateId());
			wrapper.setPlanRated(true);
			wrapper.setOverriddenPlanRating(CommonUtils.convertStrToBoolean(ratingExhibitsEntity.getOverId()));
			
			if (ratingExhibitsEntity.getPlan() != null) {
				wrapper.setPlanId(ratingExhibitsEntity.getPlan().getPlanId());
			}
			
			if (CollectionUtils.isNotEmpty(ratingExhibitsEntity.getRatingOverride())) {
				List<ArrayList<RuleRatingModelOverrideGrp>> overrideList = setRatingOverride(ratingExhibitsEntity.getRatingOverride());
				wrapper.setRatingModelOverideGrp(overrideList);
				if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(ratingExhibitsEntity.getOverId()), ProposalConstants.RATE_NON_OVERRIDE)) {
					wrapper.setSavedOverrides(this.isOverridesSaved(ratingExhibitsEntity.getRatingOverride()));
				}
			}
			
			if (CollectionUtils.isNotEmpty(ratingExhibitsEntity.getRatingAggregatedCensus())) {
				List<RuleRatingAggregatedCensusGrp> aggregatedCensusList = setRatingAggregatedCensus(ratingExhibitsEntity.getRatingAggregatedCensus());
				wrapper.setRatingAggregatedCensusGrp(aggregatedCensusList);
			}
			
			if (CollectionUtils.isNotEmpty(ratingExhibitsEntity.getRatingQuoteCensus())) {
				List<RuleRatingCensusCompGrp> individualCensusList = setRatingIndCensus(ratingExhibitsEntity.getRatingQuoteCensus());
				wrapper.setRatingCensusCompGrp(individualCensusList);
			}
			
			if (ratingExhibitsEntity.getRatingProposalPlanDetails() != null) {
				RuleRatingProposalPlanDetails proposalPlanDetails = setProposalPlanDetails(ratingExhibitsEntity.getRatingProposalPlanDetails());
				wrapper.setProposalPlanDetails(proposalPlanDetails);
			}
			
			if (CollectionUtils.isNotEmpty(ratingExhibitsEntity.getRatingRuleResult())) {
				List<RuleRatingModelRuleResultGrp> ruleResultList = setRuleResultList(ratingExhibitsEntity.getRatingRuleResult());
				wrapper.setRatingRuleResultGrp(ruleResultList);
			}
			
			
			
			
			
		}
		return wrapper;
	}
	
	private boolean isOverridesSaved(List<RatingOverride> overrideList) {
		if (CollectionUtils.isNotEmpty(overrideList)) {
			for (RatingOverride overrideEntity : overrideList) {
				if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(overrideEntity.getOverrideAllowed()), 
						ProposalConstants.OVERRIDE_ALLOWED)) {
					if (overrideEntity.getOverrideValue() > 0) {
						return true;
					}
				}
			}
		}
		return false;
	}
	

	private List<ArrayList<RuleRatingModelOverrideGrp>> setRatingOverride(List<RatingOverride> ratingOverrideList) {
		List<ArrayList<RuleRatingModelOverrideGrp>> overrideList = new ArrayList<ArrayList<RuleRatingModelOverrideGrp>>();

		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.BL_TABLE_COMPETITIVE_WINDOW_GROUP));
		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.BL_TABLE_UW_ADJUSTMENT_BOX_GROUP));
		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.BL_RENEWAL_TABLE_GROUP));
		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.AGEBRACKET_FINAL_RATE_GROUP));
		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.BL_TABLE_C_GROUP));
		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.BL_TABLE_G_GROUP));
		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.BL_TABLE_H_GROUP));
		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.BL_TABLE_I_GROUP));
		overrideList.add(overridelistByGroupId(ratingOverrideList,"groupId", RatingOutputConstants.BL_REPORT_TABLE_GROUP));

		return overrideList;
	}
	
	
	@SuppressWarnings("unchecked")
	private ArrayList<RuleRatingModelOverrideGrp> overridelistByGroupId(List<RatingOverride> ratingOverrideList, String propertyName, String value) {
		EqualPredicate nameEqlPredicate = new EqualPredicate(value);
		BeanPredicate beanPredicate = new BeanPredicate(propertyName, nameEqlPredicate);
		Collection<RatingOverride> filteredCollection = CollectionUtils.select(ratingOverrideList, beanPredicate);
		//System.out.println("Below are model override group object(s) whose " + propertyName + " is " + value);
		//System.out.println("Matches for entered criteria "CollectionUtils.countMatches(ratingOverrideList, beanPredicate));
		
		ArrayList<RuleRatingModelOverrideGrp> listRating = new ArrayList<RuleRatingModelOverrideGrp>();
		
		for (RatingOverride ratingEntity : filteredCollection) {
			
			RuleRatingModelOverrideGrp modelgrp = new RuleRatingModelOverrideGrp();
			modelgrp.setRuleID(String.valueOf(ratingEntity.getOverrideId()));
			modelgrp.setFieldKey(StringUtils.trimToEmpty(ratingEntity.getFieldKey()));
			modelgrp.setFieldValue(ratingEntity.getFieldValue());
			modelgrp.setGroupId(StringUtils.trimToEmpty(ratingEntity.getGroupId()));
			modelgrp.setOverrideAllowed(CommonUtils.convertStrToBoolean(ratingEntity.getOverrideAllowed()));
			modelgrp.setOverrideIndicator(CommonUtils.convertStrToBoolean(ratingEntity.getOverrideIndicator()));
			modelgrp.setOverrideValue(ratingEntity.getOverrideValue());
			modelgrp.setUwApproval(CommonUtils.convertStrToBoolean(StringUtils.trimToEmpty(ratingEntity.getUwApproval())));
			modelgrp.setApprovingUW(StringUtils.trimToEmpty(ratingEntity.getApprovingUW()));
			modelgrp.setApprovalDate(ratingEntity.getApprovalDate());
			modelgrp.setUwEvaluation(StringUtils.trimToEmpty(ratingEntity.getUwEvalulation()));
			modelgrp.setGroupId(StringUtils.trimToEmpty(ratingEntity.getGroupId()));
			
			listRating.add(modelgrp);			
		}
		//System.out.println("Below are model override group object(s) whose are in one group=" + listRating);
		return listRating;
	}

	private List<RuleRatingAggregatedCensusGrp> setRatingAggregatedCensus(List<RatingAggregatedCensus> ratingAggregatedCensus) {
		List<RuleRatingAggregatedCensusGrp> aggregatedCensusList = new ArrayList<RuleRatingAggregatedCensusGrp>();
		
		for (RatingAggregatedCensus ratingEntity : ratingAggregatedCensus) {
			RuleRatingAggregatedCensusGrp modelgrp = new RuleRatingAggregatedCensusGrp();
			
			modelgrp.setAgeBracket(StringUtils.trimToEmpty(ratingEntity.getAgeBracket()));
			modelgrp.setStatus(StringUtils.trimToEmpty(ratingEntity.getStatus()));
			modelgrp.setGender(StringUtils.trimToEmpty(ratingEntity.getGender()));
			modelgrp.setLives(ratingEntity.getLives());
			modelgrp.setCoveredVolume(ratingEntity.getCoveredVolume());
			modelgrp.setNonPooledVolume(ratingEntity.getNonPooledVolume());
			modelgrp.setPooledVolume(ratingEntity.getPooledVolume());
			modelgrp.setNonPooledManualRate(ratingEntity.getNonPooledManualRate());
			modelgrp.setPooledManualRate(ratingEntity.getPooledManualRate());
			modelgrp.setGroupId(StringUtils.trimToEmpty(ratingEntity.getGroupId()));
			
			aggregatedCensusList.add(modelgrp);
		}
		
		return aggregatedCensusList;
	}
	
	private List<RuleRatingCensusCompGrp> setRatingIndCensus(List<RatingQuoteCensus> ratingQuoteCensus) {
		List<RuleRatingCensusCompGrp> individualCensusList = new ArrayList<RuleRatingCensusCompGrp>();
		
		for (RatingQuoteCensus ratingEntity: ratingQuoteCensus) {
			RuleRatingCensusCompGrp modelgrp = new RuleRatingCensusCompGrp();
			
			modelgrp.setAgeBracket(ratingEntity.getAgeBracket());
			modelgrp.setTotalLives(ratingEntity.getTotalLives());
			modelgrp.setTotalCoveredVolume(ratingEntity.getTotalCoveredVolume());
			modelgrp.setMonthlyPayPremStepRate(ratingEntity.getMonthlyPremiumStepRate());
			modelgrp.setTableIRate(ratingEntity.getTableIRate());
			modelgrp.setCrossTableRate(ratingEntity.getCrossTableI());
			modelgrp.setFinalRate(ratingEntity.getFinalRate());
			modelgrp.setGroupId(StringUtils.trimToEmpty(ratingEntity.getGroupId()));
			
			individualCensusList.add(modelgrp);
		}
		
		return individualCensusList;
	}
	
	private List<RuleRatingModelRuleResultGrp> setRuleResultList(List<RatingRuleResult> ratingRuleResult) {
		List<RuleRatingModelRuleResultGrp> ruleResultList = new ArrayList<RuleRatingModelRuleResultGrp>();
				
		for (RatingRuleResult ratingEntity: ratingRuleResult) {
			RuleRatingModelRuleResultGrp modelgrp = new RuleRatingModelRuleResultGrp();
			modelgrp.setRuleDesc(StringUtils.trimToEmpty(ratingEntity.getRuleDesc()));
			modelgrp.setRuleResult(StringUtils.trimToEmpty(ratingEntity.getRuleResult()));
			modelgrp.setGroupId(StringUtils.trimToEmpty(ratingEntity.getGroupId()));
			
			ruleResultList.add(modelgrp);
		}
	
		return ruleResultList;
	}
	
	private RuleRatingProposalPlanDetails setProposalPlanDetails(RatingProposalPlanDetails ratingEntity) {
		RuleRatingProposalPlanDetails modelgrp = new RuleRatingProposalPlanDetails();
		
		modelgrp.setProposalExhibitLives(ratingEntity.getProposalExhibitLives());
		modelgrp.setProposalExhibitVolume(ratingEntity.getProposalExhibitVolume());
		modelgrp.setProposalExhibitRate(ratingEntity.getProposalExhibitRate());
		modelgrp.setProposalExhibitPremium(ratingEntity.getProposalExhibitPremium());
		modelgrp.setCompositeRate(ratingEntity.getCompositeRate());
		modelgrp.setEstLivesForPlan(ratingEntity.getEstLivesForPlan());
		modelgrp.setEstLivesAllCompositePlan(ratingEntity.getEstLivesAllCompositePlan());
		modelgrp.setEstVolumeForPlan(ratingEntity.getEstVolumeForPlan());
		modelgrp.setEstVolumeAllCompositePlan(ratingEntity.getEstVolumeAllCompositePlan());
		modelgrp.setMonthlyRates(ratingEntity.getMonthlyRates());
		modelgrp.setManualRate(ratingEntity.getManualRate());
		modelgrp.setMonthlyPremiumForPlan(ratingEntity.getMonthlyPremiumForPlan());
		modelgrp.setMonthlyPremiumAllCompositePlan(ratingEntity.getMonthlyPremiumAllCompositePlan());
		modelgrp.setGroupId(StringUtils.trimToEmpty(ratingEntity.getGroupId()));
				
		return modelgrp;
	}

	public ProposalVersionDetails parseVersionPlanDetails(ProposalDetails proposalEntity) throws Exception {
		//PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();
		
		ProposalVersionDetails proposalVersionDetails = new ProposalVersionDetails();		
		proposalVersionDetails.setProposalDesc(proposalEntity.getProposalDescription());
		proposalVersionDetails.setProposalId(proposalEntity.getProposalId());
		
		Set<QuotationDetails> quotationDetails = proposalEntity.getQuotes();
		List<QuotationDetails> quotationDetailsList = new ArrayList<QuotationDetails>(quotationDetails);
		Collections.sort(quotationDetailsList,VERSION_COMPARATOR);
		List<VersionDetails> listOfVersionDetails = new ArrayList<VersionDetails>();
		for (QuotationDetails quotes : quotationDetailsList){
			
			VersionDetails versionDetails = new VersionDetails();
			versionDetails.setVersionNumber(quotes.getVersionNumber());
			versionDetails.setVersionStatus(quotes.getVersionStatus());
			versionDetails.setAttachedCensus(quotes.getCensus().getCensusName());
			versionDetails.setCensusDate(quotes.getCensus().getCensusDate());
			versionDetails.setVersionDesc(quotes.getVersionDesc());
			versionDetails.setProposalId(proposalEntity.getProposalId());
			Set<PlanDetailsClass> plans = quotes.getPlans();
			List<PlanDetailsClass> plansEntityList = new ArrayList<PlanDetailsClass>(plans);
			Collections.sort(plansEntityList,PLAN_COMPARATOR);
			List<VersionPlan> planList = new ArrayList<VersionPlan>();
			 SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			 for (PlanDetailsClass planDetails : plansEntityList) {
				 //Added below condition to display only original plans
				 if (planDetails.getOverId() == 0 &&
						 StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(planDetails.getDisplayPlan()),PlanConfigConstants.PLAN_DISPLAY_YES)) {
					 VersionPlan versionPlan = new VersionPlan();				 
					 versionPlan.setPlanNum(planDetails.getPlanId());
					 versionPlan.setPlanDesc(planDetails.getPlanDescription());
					
					 versionPlan.setPlanEffectiveDate(dateFormat.format(planDetails.getEffectiveDate()));
					 versionPlan.setContractState(planDetails.getContractState());
					 //PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();
					 ProductDetails product = planDetailsRepository.getProductDetails(planDetails.getPlanId());
					 versionPlan.setProductName(product.getProductDescription());
					 versionPlan.setRateInformation(planDetails.getRateExpression());
					 planList.add(versionPlan);
				 }
			 }
			 versionDetails.setPlanList(planList);
			 listOfVersionDetails.add(versionDetails);
		}
		proposalVersionDetails.setVersionDetails(listOfVersionDetails);
				
		return proposalVersionDetails;
	}

	public void updateVersionStatus(int versionNumber, boolean isRatingSuccessful, boolean isPlanReRatingPending) {
		if (isRatingSuccessful) {
			ratingQuoteDAO.updateVersionStatus(versionNumber,ProposalConstants.VERSION_STATUS_ACCEPTED);
		} else if (isPlanReRatingPending) {
			ratingQuoteDAO.updateVersionStatus(versionNumber,ProposalConstants.VERSION_STATUS_PENDING);
		}
	}

	
	public HashMap<String, String> getOverridenUIValuesInMap(RatingExhibits overridenRatingExhibits) {
		HashMap<String,String> overriddenValues = new HashMap<String,String>(); 
		if (CollectionUtils.isNotEmpty(overridenRatingExhibits.getRatingOverride())) {
			for (RatingOverride overrideEntity : overridenRatingExhibits.getRatingOverride()) {
				if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(overrideEntity.getOverrideAllowed()), 
						ProposalConstants.OVERRIDE_ALLOWED)) {
					if (overrideEntity.getOverrideValue() != 0) {
						overriddenValues.put(overrideEntity.getFieldKey(),String.valueOf(overrideEntity.getOverrideValue()));
					}
				}
			}
		}
		return overriddenValues;
	}
	
	public RatingExhibits setOverridenUIValuesInEntity(RatingExhibits ratingExhibitsEntity, 
			HashMap<String, String> overriddenValues) {
		if (overriddenValues != null & overriddenValues.size() > 0) {
			for (RatingOverride overrideEntity : ratingExhibitsEntity.getRatingOverride()) {
				if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(overrideEntity.getOverrideAllowed()), 
						ProposalConstants.OVERRIDE_ALLOWED)) {
					if (overriddenValues.containsKey(String.valueOf(overrideEntity.getFieldKey()))) {
						overrideEntity.setOverrideValue(Double.parseDouble(overriddenValues.get(String.valueOf(overrideEntity.getFieldKey()))));
						overrideEntity.setOverrideIndicator(ProposalConstants.OVERRIDE_Y_INDICATOR);
					}
				}
			}
		}
		return ratingExhibitsEntity;
	}	

	private static Comparator<QuotationDetails> VERSION_COMPARATOR = new Comparator<QuotationDetails>() {
		 public int compare(QuotationDetails s1, QuotationDetails s2) {
			 if (s1 != null && s2 != null &&
					 s1.getVersionNumber() > 0 && s2.getVersionNumber() > 0) {
				 return Integer.valueOf(s1.getVersionNumber()).compareTo(Integer.valueOf(s2.getVersionNumber()));
			 } else {
				 return 0;
			 }

		 }
	 };
	 
	 private static Comparator<PlanDetailsClass> PLAN_COMPARATOR = new Comparator<PlanDetailsClass>() {
		 public int compare(PlanDetailsClass s1, PlanDetailsClass s2) {
			 if (s1 != null && s2 != null &&
					 s1.getPlanId() > 0 && s2.getPlanId() > 0) {
				 return Integer.valueOf(s1.getPlanId()).compareTo(Integer.valueOf(s2.getPlanId()));
			 } else {
				 return 0;
			 }

		 }
	 };
	 
}
