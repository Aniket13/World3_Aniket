package com.pru.sparc.processor;

import java.util.Date;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.pru.sparc.bo.model.PrudentialContact;
import com.pru.sparc.common.util.SparcConstants;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.PrudentialContactDetails;

@Component
public class PrudentialServiceProcessor {
	/**
	 * Method is to set entity value in database
	 * @param Prudential contact 
	 * @return object
	 */
	public PrudentialContactDetails mapToProposalRequestObject(PrudentialContact prudentialContact, ProposalDetails proposalDetails) throws Exception{
		
		PrudentialContactDetails prudentialContactDet = new PrudentialContactDetails();
		prudentialContactDet.setExternalAgent(prudentialContact.getExtAgentName());
		prudentialContactDet.setLdsmName(prudentialContact.getLdsmNameVal());
		prudentialContactDet.setLdsmAssistant(prudentialContact.getLdsmAsstVal());
		prudentialContactDet.setLifeSplAssistant(prudentialContact.getLifeSplAsstVal());
		prudentialContactDet.setLifeSpecialist(prudentialContact.getLifeSplVal());
		prudentialContactDet.setUnderwriter(prudentialContact.getUwVal());
		prudentialContactDet.setRateCalcTechnician(prudentialContact.getRateCalcTechVal());
		prudentialContactDet.setAcctManager(prudentialContact.getAcctManVal());
		prudentialContactDet.setMidMarketAcctManager(prudentialContact.getMidMktAcctMgrVal());
		prudentialContactDet.setRegionalAdminDir(prudentialContact.getRegAdminDirVal());
		prudentialContactDet.setExtAgentOffice(prudentialContact.getExtAgentOffice());
		prudentialContactDet.setExtAgentPhone(prudentialContact.getExtAgentPhone());
		prudentialContactDet.setAcctExecutive(prudentialContact.getAcctExeNameVal());
		prudentialContactDet.setCreationDate(new Date());
		prudentialContactDet.setCreatedBy(SparcConstants.ADMIN);
		prudentialContactDet.setModifiedDate(null);
		prudentialContactDet.setModifiedBy(null);
		prudentialContactDet.setProposalDetails(proposalDetails);
		return prudentialContactDet;
	}
	
	
	/**
	 * Method is used for validation of 
	 * @param proposalInformation
	 * @return boolean
	 * @throws Exception
	 */
	public boolean isRequestValid(PrudentialContact prudentialContact) throws Exception{
		
		/*if(StringUtils.isEmpty(prudentialContact.getLdsmNameVal())){
			throw new Exception(SparcConstants.EMPTY_LDSM);
		}
		if(StringUtils.isEmpty(prudentialContact.getUwVal())){
			throw new Exception(SparcConstants.EMPTY_UW_VALUE);
		}
		if(StringUtils.isEmpty(prudentialContact.getRateCalcTechVal())){
			throw new Exception(SparcConstants.EMPTY_RATE_CALC_TECH);
		}
		if(StringUtils.isEmpty(prudentialContact.getAcctManVal())){
			throw new Exception(SparcConstants.EMPTY_ACCT_MANAGER);
		}*/
		
		return true;
	}
	
}
