package com.pru.sparc.processor;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.bo.model.Quotation;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.QuotationDetails;
import com.pru.sparc.model.QuoteReasonLookup;
@Component
public class ProposalDetailsRequestHelper {

	public QuotationDetails mapToCreateNewQuotationRequestObject(
			Proposal proposal, ProposalDetails proposalDetails, int versionCount) {
		QuotationDetails quotationDetails = new QuotationDetails();
		//quotationDetails.setVersionNumber(versionCount+1);
		quotationDetails.setVersionDesc("Version "+ (versionCount+1));
		quotationDetails.setProposal(proposalDetails);
		quotationDetails.setBasicLife("No");
		quotationDetails.setLtd("No");
		quotationDetails.setContactDocFormat("PDF");
		quotationDetails.setBillMethod("Roster");
		quotationDetails.setBillDeliveryMethod("Mail");
		quotationDetails.setPlans(new HashSet<PlanDetailsClass>());
		quotationDetails.setCreationDate(new Date());
		return quotationDetails;
	}
	
	public QuotationDetails createSaveQuotationRequest(Quotation quotation, List<CensusDetail> selectedCensusList, QuotationDetails quotationDetails, List<ProductDetails> productDetaiList) {
		
		//quotationDetails.setVersionNumber(quotation.getVersionNumber());
		quotationDetails.setVersionDesc(quotation.getVersionDesc());
		if (selectedCensusList != null && selectedCensusList.size() > 0) {
			quotationDetails.setCensus(selectedCensusList.get(0));
		}
		quotationDetails.setBasicLife(quotation.getBasicLife());
		quotationDetails.setLtd(quotation.getLtd());
		quotationDetails.setContactDocFormat(quotation.getDocumentFormat());
		quotationDetails.setBillMethod(quotation.getBillingMethod());
		quotationDetails.setBillDeliveryMethod(quotation.getBillingDeliveryMethod());
		
		quotationDetails.setAtpVoucerPgm(quotation.getAtpVoucher());
		quotationDetails.setVersionStatus(quotation.getVersionStatus());
		quotationDetails.setComment(quotation.getComment());
		quotationDetails.setLifeReason(quotation.getLifeReason());
		quotationDetails.setDisabilityReason(quotation.getDisabilityReason());
		quotationDetails.setDentalReason(quotation.getDentalReason());
		quotationDetails.setRsmComment(quotation.getRsmComment());
		
		List<QuoteReasonLookup> reasons = new ArrayList<QuoteReasonLookup>();
		if (CollectionUtils.isNotEmpty(quotation.getSelectedQuoteReasons())) {
			for (int i = 0; i < quotation.getSelectedQuoteReasons().size(); i++ ) {
				QuoteReasonLookup obj = new QuoteReasonLookup();
				obj.setQuoteDesc(quotation.getSelectedQuoteReasons().get(i));
				reasons.add(obj);
			}
		}
		quotationDetails.setQuoteReasons(reasons);
		
		if(CollectionUtils.isEmpty(quotationDetails.getPlans()))
		{
			//Adding Plan details
			if (CollectionUtils.isNotEmpty(quotation.getSelectedQuoteProducts())) {
				Set<PlanDetailsClass> selectedProductList = new HashSet<PlanDetailsClass>();
				for (ProductDetails productDetails : productDetaiList) {
					PlanDetailsClass selectedProductPlan = new PlanDetailsClass();
					//PlanDetailsEmbadable planDetailsEmbadable = new PlanDetailsEmbadable();
					//overId set to 0 for normal insertion and 1 for overridden values
					selectedProductPlan.setOverId(0);
					//selectedProductPlan.setPlanDetailsEmbadable(planDetailsEmbadable);
					//selectedProductPlan.setPlanId(1);
					selectedProductPlan.setDisplayPlan("N");
					selectedProductPlan.setProductCode(String.valueOf(productDetails.getProductId()));
					//selectedProductPlan.setPlanDescription(productDetails.getProductId() + " Plan");
					selectedProductPlan.setVersion(quotationDetails);
					selectedProductPlan.setProduct(productDetails);
					selectedProductPlan.setContractState(quotationDetails.getProposal().getContractState());
					selectedProductPlan.setEffectiveDate(quotationDetails.getProposal().getCaseEffectiveDt());
					selectedProductList.add(selectedProductPlan);
				}
				quotationDetails.setPlans(selectedProductList);
			}
		}
		//Adding Proposal details
		ProposalDetails proposalDetails = new ProposalDetails();
		proposalDetails.setProposalId(quotation.getProposalId());
		quotationDetails.setProposal(proposalDetails);
		
		return quotationDetails;
	}
}
