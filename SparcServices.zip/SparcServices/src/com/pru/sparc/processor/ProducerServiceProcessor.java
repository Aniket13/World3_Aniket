package com.pru.sparc.processor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.Producer;
import com.pru.sparc.model.BrokerDetails;
import com.pru.sparc.model.ProposalBrokerDetails;

@Component
public class ProducerServiceProcessor {
	/**
	 * To map the details of ProducerDetails object to Producer object
	 * @param List<ProducerDetails>
	 * @return List<Producer>
	 */
	public List<Producer> mapToProducerModel(List<BrokerDetails> producerList){
		List<Producer> producers = new ArrayList<Producer>();
		for (BrokerDetails brokerDetails : producerList) {
			Producer producer = new Producer();
			producer.setBrokerId(brokerDetails.getBrokerId());
			producer.setProducerAdbNo(brokerDetails.getProducerContractId());
			producer.setProducerAgencyCode(brokerDetails.getAgencyCode());
			producer.setProducerName(brokerDetails.getBrokerName());
			producer.setProducerRanking(brokerDetails.getProducerRanking());
			producer.setProducerType(brokerDetails.getProducerType());
			producers.add(producer);
		}
		return producers;
	}

	public ProposalBrokerDetails mapToProposalBrokerDetails(
			Commission commission, BrokerDetails brokerDetails) {
		ProposalBrokerDetails proposalBrokerDetails = new ProposalBrokerDetails();
		proposalBrokerDetails.setBrokerDetails(brokerDetails);
		proposalBrokerDetails.setProPlanId(commission.getProposalPlanID());
		//proposalPlanInd value is set to 1 for proposal and 0 for plan
		proposalBrokerDetails.setProposalPlanInd(1);
		return proposalBrokerDetails;
	}
}
