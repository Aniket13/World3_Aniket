package com.pru.sparc.processor;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.pru.sparc.bo.model.LookupInfo;
import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.model.LookupDetails;
import com.pru.sparc.model.PlanLookupDetails;

@Component
public class MainServiceProcessor {
	
	/**
	 * 
	 * @param statesLookup
	 * @return List<CensusStates>
	 */
	public List<LookupInfo> mapLookupListToLookInfoList(List<LookupDetails> lookupList){
		List<LookupInfo> lookupInfoList = new ArrayList<LookupInfo>();
		for (LookupDetails lookupDetails : lookupList) {
			LookupInfo lookupInfo = new LookupInfo();
			lookupInfo.setCode(lookupDetails.getLookupCode());
			lookupInfo.setDescription(lookupDetails.getLookupValue());
			lookupInfo.setLookupCategory(lookupDetails.getLookupCategory());
			lookupInfoList.add(lookupInfo);
		}
		return lookupInfoList;
	}
	
	/**
	 * 
	 * @param statesLookup
	 * @return List<CensusStates>
	 */
	public LookupDetails mapLookupInfoToLookEntity(LookupInfo lookupInfo){
		LookupDetails lookupDetails = new LookupDetails();
		lookupDetails.setLookupCode(lookupInfo.getCode());
		lookupDetails.setLookupValue(lookupInfo.getDescription());
		lookupDetails.setLookupCategory(lookupInfo.getLookupCategory());
		lookupDetails.setLookupType(lookupInfo.getLookupType());
		return lookupDetails;
	}
	
	public PlanLookupDetails mapPlanConfigLookupToPlanLookEntity(PlanConfigLookup lookupInfo){
		PlanLookupDetails lookupDetails = new PlanLookupDetails();
		lookupDetails.setLookupCode(lookupInfo.getLookupKey());
		lookupDetails.setLookupValue(lookupInfo.getLookupValue());
		lookupDetails.setLookupCategory(lookupInfo.getLookupCategory());
		lookupDetails.setLookupOrder(lookupInfo.getLookupOrder());
		return lookupDetails;
	}
	
	public List<PlanConfigLookup> mapPlanLookupDetailsListToPlanConfigLookupList(List<PlanLookupDetails> lookupList){
		List<PlanConfigLookup> lookupInfoList = new ArrayList<PlanConfigLookup>();
		for (PlanLookupDetails lookupDetails : lookupList) {
			PlanConfigLookup lookupInfo = new PlanConfigLookup();
			lookupInfo.setLookupKey(lookupDetails.getLookupCode());
			lookupInfo.setLookupValue(lookupDetails.getLookupValue());
			lookupInfo.setLookupCategory(lookupDetails.getLookupCategory());
			lookupInfo.setVisibleFlag(lookupDetails.getVisibilityFlag());
			lookupInfo.setLookupOrder(lookupDetails.getLookupOrder());
			lookupInfoList.add(lookupInfo);
		}
		return lookupInfoList;
	}
	
	public PlanConfigLookup convertLookupDetailToPlanConfigLookup(LookupDetails lookupDetails, PlanConfigLookup planConfigLookup){
		planConfigLookup.setLookupCategory(PlanConfigConstants.LOOKUP_CATEGORY_CONTRACT_STATE);
		planConfigLookup.setLookupKey(lookupDetails.getLookupCode());
		planConfigLookup.setLookupOrder(1);
		planConfigLookup.setLookupValue(lookupDetails.getLookupValue());
		planConfigLookup.setVisibleFlag("Yes");
		return planConfigLookup;
	}
}
