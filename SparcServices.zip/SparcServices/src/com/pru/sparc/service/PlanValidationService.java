package com.pru.sparc.service;
import java.util.List;
import java.util.Map;
import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.bo.model.ValidationWrapper;


public interface PlanValidationService {
	
	RatingModel getPlanValidationDetails(
			Map<String, String> map);

}
