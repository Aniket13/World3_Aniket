package com.pru.sparc.service;

import java.util.List;

import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.Producer;

public interface ProducerService {
	public List<Producer> getProducers() throws Exception;

	public void setProposalCommission(Commission commission) throws Exception;
}
