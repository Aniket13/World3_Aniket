package com.pru.sparc.service;

import java.util.List;

import com.pru.sparc.bo.model.Client;
import com.pru.sparc.bo.model.ClientSearchRequest;
import com.pru.sparc.bo.model.Proposal;





//service layer interface for Clients module
public interface ClientService {

	/**
	 * To add new client to database
	 * @param Client
	 * @return Client
	 * @throws Exception Exception
	 */
	Client addClient(final Client client) throws Exception;
	
	
	/**
	 * To search clinets based on selected search criterias
	 * @param ClientSearchRequest
	 * @return List<Client>
	 * @throws Exception Exception
	 */
	List<Client> searchClient(ClientSearchRequest clientSearchRequest)
			throws Exception;
	
	/**
	 * To generate client id for new client creation
	 * @param 
	 * @return int
	 * @throws Exception Exception
	 */
	int getClientId() throws Exception;
	
	/**
	 * To edit client details
	 * @param Client
	 * @return Client
	 * @throws Exception Exception
	 */
	Client editClient(Client client) throws Exception;

	/**
  	 * Method to get the list of proposals associated with the client
  	 * @param Client client
  	 * @return List<Client>
  	 */
	List<Proposal> getProposalActivity(int clientId) throws Exception;

	/**
	 * Method to set the selected client object in session
	 * @param client
	 * @throws Exception
	 */
	void setClientInSession(Client client) throws Exception;


	Client loadClient(int clientId) throws Exception;
	//String getSicDesc(String sicNo)throws Exception;
}
