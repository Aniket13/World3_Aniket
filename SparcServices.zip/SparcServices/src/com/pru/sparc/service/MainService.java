package com.pru.sparc.service;

import java.util.List;
import java.util.Map;

import com.pru.sparc.bo.model.Holding;
import com.pru.sparc.bo.model.LookupInfo;
import com.pru.sparc.bo.model.PlanConfigLookup;

public interface MainService {
	void killSession();
	void newSession();
	Holding getSessionHolding();

	/**
	 * 
	 * @return List<CensusStates>
	 */
	List<LookupInfo> getLookupList(LookupInfo lookupInfo) throws Exception;
	void updateSessionHolding(Holding sessionHolding);
	List<PlanConfigLookup> getPlanLookupList()
			throws Exception;
	Map<String, PlanConfigLookup> getPlanContractState(String stateCode) throws Exception;
}
