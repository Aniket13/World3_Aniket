package com.pru.sparc.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.CensusCls;
import com.pru.sparc.bo.model.CensusMemberDtl;
import com.pru.sparc.common.util.SparcConstants;
import com.pru.sparc.dao.CensusMemberDtlRepository;
import com.pru.sparc.dao.PlanDetailsRepository;
import com.pru.sparc.dao.impl.CensusMemberDtlRepositoryImpl;
import com.pru.sparc.dao.impl.PlanDetailsRepositoryImpl;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.CensusMemberDetails;
import com.pru.sparc.processor.CensusMemberDtlProcessor;
import com.pru.sparc.service.CensusMemberDtlService;
import com.pru.sparc.service.CensusService;

@Service
public class CensusMemberDtlServiceImpl implements CensusMemberDtlService{
	@Autowired
	private CensusMemberDtlRepository censusMemberDtlRepository;
	@Autowired
	private CensusMemberDtlProcessor censusMemberDtlProcessor;
	
	@Autowired
	private PlanDetailsRepository planDetailsRepository;
	@Autowired	
	@Qualifier("censusService")
	private CensusService censusService;
	/* 
	 * @Method is to save prudential contact information
	 */

	@Override
	public void updateCensusMember(CensusMemberDtl model) throws Exception {
		//CensusMemberDetails censusMemberDetails=new CensusMemberDetails();
		CensusDetail censusDetail=new CensusDetail();
		CensusClass censusClass = censusMemberDtlRepository.getCensusMemberClass(model.getCensusId(),model.getMemberClass().getCensusClsId());
		CensusMemberDetails censusMemberDetails= censusMemberDtlProcessor.mapToCensusDtlEntity(model,censusClass,censusDetail);
		censusMemberDtlRepository.updateCensusMember(censusMemberDetails);
	}

	/**
	 * To get all census screen dropDown values
	 * @throws Exception
	 */
	@Override
	public List<CensusMemberDtl> getCensusMembers(int censusId) throws Exception {
	/*	List<CensusMemberDetailsEntity> censusMemberDetailsEntity=new ArrayList<CensusMemberDetailsEntity>();
		censusMemberDetailsEntity=censusMemberDtlRepository.getCensusMembers(censusId);*/
		return censusMemberDtlProcessor.mapCensusMemberObject(censusMemberDtlRepository.getCensusMembers(censusId));
	}
	
	@Override
	public Holding getholdingVal(int versionId) throws Exception {
		Holding holding =new Holding();
		List listOfPlans = new ArrayList<Plan>();
		Plan plan= new Plan();
		Census cs = new Census();
		List<HashMap<String, Object>> peopleList = censusMemberDtlRepository.getDataListByMember();
		ArrayList<Person> listOfPeople = new ArrayList<Person>();
		for (HashMap<String, Object> map : peopleList) {
			Person obj = new Person();
			obj.setPeopleMap(map);
			listOfPeople.add(obj);
		}
		cs.setListOfPeople(listOfPeople);
		plan.setCensus(cs);
		listOfPlans.add(plan);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		List<HashMap<String, Object>> planList= planDetailsRepository.getDataListByPlan(versionId);
		for (HashMap<String, Object> map : planList) {
			planMap.putAll(map);
		}
		holding.setHoldingMap(planMap);
		holding.setListOfPlans(listOfPlans);
		return holding;
	}

	/* 
	 * @Method is used to get Drop down values dynamically for edit census member screen
	 * returns model
	 */
	@Override
	public CensusMemberDtl getCensusFieldVal(CensusMemberDtl census) throws Exception {
		CensusMemberDtl censusDtl=new CensusMemberDtl();
		CensusCls censusCls=new CensusCls();
        censusCls.setCensusId(census.getCensusId());
        List<CensusCls> clsList=censusService.getCensusClass(censusCls);
        censusDtl.setMemberClassList(clsList);
		List<String> oglPart=new ArrayList<String>();
		oglPart.add(SparcConstants.MELLENDORFSTACY);
		oglPart.add(SparcConstants.MELLENDORFSTACY1);
		oglPart.add(SparcConstants.MELLENDORFSTACY2);
		censusDtl.setOglPartList(oglPart);
		
		List<String> dglSpouce=new ArrayList<String>();
		dglSpouce.add(SparcConstants.WILLIAM);
		dglSpouce.add(SparcConstants.JAMES);
		dglSpouce.add(SparcConstants.ANTHONY);
		censusDtl.setDglSpoucePartList(dglSpouce);
		
		List<String> dglChild=new ArrayList<String>();
		dglChild.add(SparcConstants.JACOB);
		dglChild.add(SparcConstants.ETHAN);
		dglChild.add(SparcConstants.LANDON);
		censusDtl.setDglChildPartList(dglChild);
		
		List<String> ooadPart=new ArrayList<String>();
		ooadPart.add(SparcConstants.CHRISTOPHER);
		ooadPart.add(SparcConstants.JOSHUA);
		ooadPart.add(SparcConstants.MICHAEL);
		censusDtl.setOaddPartList(ooadPart);
		
		List<String> rateCalcTechName=new ArrayList<String>();
		rateCalcTechName.add(SparcConstants.ALEXANDER);
		rateCalcTechName.add(SparcConstants.DANIEL);
		rateCalcTechName.add(SparcConstants.LOGAN);
		censusDtl.setOptionalLtdPartList(rateCalcTechName);
		
		List<String> acctManagerName=new ArrayList<String>();
		acctManagerName.add(SparcConstants.WYATT);
		acctManagerName.add(SparcConstants.HUNTER);
		acctManagerName.add(SparcConstants.TYLER);
		censusDtl.setOptionalStdPartList(acctManagerName);
		
		return censusDtl;
	}
	public static void main(String[] args) throws Exception {
		CensusMemberDtlServiceImpl cimpl=new CensusMemberDtlServiceImpl();
		//cimpl.getholdingVal();
		
		//cimpl.getCensusMembers(1);
	}
}
