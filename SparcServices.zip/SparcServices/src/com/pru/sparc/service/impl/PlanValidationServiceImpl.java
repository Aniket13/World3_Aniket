package com.pru.sparc.service.impl;

import java.util.List;
import java.util.Map;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import com.pru.sparc.bo.model.ErrorDetails;
import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.drools.helper.ValidationRules;
import com.pru.sparc.service.PlanValidationService;

@Service("planValidationService")
public class PlanValidationServiceImpl implements PlanValidationService {

	public SessionFactory sessionFactory;

	public RatingModel getPlanValidationDetails(Map<String, String> map) {

		ValidationRules vr = new ValidationRules();
		List<ErrorDetails> detailedErrorList = vr
				.getValidationRulesResponse(map);
		if (CollectionUtils.isEmpty(detailedErrorList)) {

		}

		RatingModel ratingModel = new RatingModel();
		ratingModel.setRatingSuccessful(false);
		ratingModel.setValidationErrors(true);
		ratingModel.setListOfValidationMsgs(detailedErrorList);

		return (ratingModel);

	}

}
