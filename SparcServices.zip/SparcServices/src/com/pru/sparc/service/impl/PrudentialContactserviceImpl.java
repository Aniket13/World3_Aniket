package com.pru.sparc.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.Holding;
import com.pru.sparc.bo.model.PrudentialContact;
import com.pru.sparc.common.util.SparcConstants;
import com.pru.sparc.dao.PrudentialRepository;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.PrudentialContactDetails;
import com.pru.sparc.processor.PrudentialServiceProcessor;
import com.pru.sparc.service.MainService;
import com.pru.sparc.service.PrudentialContactService;

@Service("prudentialContactService")
public class PrudentialContactserviceImpl implements PrudentialContactService{
	@Autowired
	private PrudentialRepository prudentialRepository;
	@Autowired
	private PrudentialServiceProcessor prudentialServiceProcessor;
	@Autowired
	private MainService mainService;
	/* 
	 * @Method is to save prudential contact information
	 */

	public void savePrudentialContact(PrudentialContact model) throws Exception {
		
		if(prudentialServiceProcessor.isRequestValid(model))
		{
			ProposalDetails proposal = prudentialRepository.getProposalById(model.getProposalId());
			if(null != proposal){
				PrudentialContactDetails requestObject = prudentialServiceProcessor.mapToProposalRequestObject(model,proposal);
				prudentialRepository.savePrudentialContact(requestObject);
				setPrudentialContactInfoInSession(model);
			} else {
				throw new Exception();
			}
			
		}
	}
	
	/* 
	 * @Method is used to get Drop down values dynamically for Prudential contact screen
	 * returns model
	 */
	public PrudentialContact getPrudentialContactValues(PrudentialContact prudentialContact){
		
		List<String> ldsmName=new ArrayList<String>();
		ldsmName.add(SparcConstants.CAROLLTILGHMAN);
		ldsmName.add(SparcConstants.LDSMTILGHMAN);
		ldsmName.add(SparcConstants.LDSMNEWTILGHMAN);
		prudentialContact.setLdsmName(ldsmName);
		
		List<String> ldsmAssistantName=new ArrayList<String>();
		ldsmAssistantName.add(SparcConstants.MELLENDORFSTACY);
		ldsmAssistantName.add(SparcConstants.MELLENDORFSTACY1);
		ldsmAssistantName.add(SparcConstants.MELLENDORFSTACY2);
		prudentialContact.setLdsmAsstName(ldsmAssistantName);
		
		List<String> lifeSplName=new ArrayList<String>();
		lifeSplName.add(SparcConstants.WILLIAM);
		lifeSplName.add(SparcConstants.JAMES);
		lifeSplName.add(SparcConstants.ANTHONY);
		prudentialContact.setLifeSplName(lifeSplName);
		
		List<String> lifeSplAssistantName=new ArrayList<String>();
		lifeSplAssistantName.add(SparcConstants.JACOB);
		lifeSplAssistantName.add(SparcConstants.ETHAN);
		lifeSplAssistantName.add(SparcConstants.LANDON);
		prudentialContact.setLifeSplAsstName(lifeSplAssistantName);
		
		List<String> underwriterName=new ArrayList<String>();
		underwriterName.add(SparcConstants.CHRISTOPHER);
		underwriterName.add(SparcConstants.JOSHUA);
		underwriterName.add(SparcConstants.MICHAEL);
		prudentialContact.setUnderwriterName(underwriterName);
		
		List<String> rateCalcTechName=new ArrayList<String>();
		rateCalcTechName.add(SparcConstants.ALEXANDER);
		rateCalcTechName.add(SparcConstants.DANIEL);
		rateCalcTechName.add(SparcConstants.LOGAN);
		prudentialContact.setRateCalcTechName(rateCalcTechName);
		
		List<String> acctManagerName=new ArrayList<String>();
		acctManagerName.add(SparcConstants.WYATT);
		acctManagerName.add(SparcConstants.HUNTER);
		acctManagerName.add(SparcConstants.TYLER);
		prudentialContact.setAcctManagerName(acctManagerName);
		
		List<String> midMktAcctMgrName=new ArrayList<String>();
		midMktAcctMgrName.add(SparcConstants.AIDEN);
		midMktAcctMgrName.add(SparcConstants.GAVIN);
		midMktAcctMgrName.add(SparcConstants.NOAH);
		prudentialContact.setMidMktAcctMgrName(midMktAcctMgrName);
		
		List<String> regAdminDirName=new ArrayList<String>();
		regAdminDirName.add(SparcConstants.KEVIN);
		regAdminDirName.add(SparcConstants.JUAN);
		regAdminDirName.add(SparcConstants.ADRIAN);
		prudentialContact.setRegAdminDirName(regAdminDirName);
		
		List<String> acctExecutiveName=new ArrayList<String>();
		acctExecutiveName.add(SparcConstants.CALEB);
		acctExecutiveName.add(SparcConstants.MATTHEW);
		acctExecutiveName.add(SparcConstants.DAVID);
		prudentialContact.setAcctExeName(acctExecutiveName);
		
		return prudentialContact;
	}
	
	private void setPrudentialContactInfoInSession(PrudentialContact prudentialContact){
		Holding holding = mainService.getSessionHolding();
		//if(holding != null && StringUtils.equalsIgnoreCase(holding.getClientId(), String.valueOf(proposal.getClientId()))) {
			holding.setLdsmName(prudentialContact.getLdsmNameVal());
			holding.setRateCalcTechnitian(prudentialContact.getRateCalcTechVal());
			mainService.updateSessionHolding(holding);
		//} 
	}
}
