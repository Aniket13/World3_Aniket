package com.pru.sparc.service.impl;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.Client;
import com.pru.sparc.bo.model.Holding;
import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.bo.model.SalesOfficeValues;
import com.pru.sparc.common.session.Attribute;
import com.pru.sparc.common.session.SessionManager;
import com.pru.sparc.common.session.SparcCache;
import com.pru.sparc.dao.ClientRepository;
import com.pru.sparc.dao.ProposalRepository;
import com.pru.sparc.model.ClientClass;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.SalesOffice;
import com.pru.sparc.processor.ClientServiceProcessor;
import com.pru.sparc.processor.ProposalServiceProcessor;
import com.pru.sparc.service.MainService;
import com.pru.sparc.service.ProposalInformationService;

@Service("proposalInformationService")
public class ProposalInformationServiceImpl implements ProposalInformationService {

	@Autowired
	private ClientRepository clientRepository;
	@Autowired
	private ProposalRepository proposalRepository;
	@Autowired
	private ProposalServiceProcessor proposalServiceProcessor;
	@Autowired
	private ClientServiceProcessor clientServiceProcessor;
	@Autowired
	private SparcCache sparcCache;
	@Autowired
	private MainService mainService;
	/* (non-Javadoc)
	 * Save proposal basic information
	 */
	@Override
	public void saveBasicInformation(Proposal model) throws Exception {
		if(proposalServiceProcessor.isRequestValid(model)) {
			ClientClass client = clientRepository.getClientById(model.getClientId());
			ProposalDetails  requestObject = proposalRepository.getProposalDetails(model.getProposalId());
			SalesOffice salesOffice = proposalRepository.getSalesOfficeByName(model.getSalesOffVal());
			requestObject = proposalServiceProcessor.mapToProposalRequestObject(model, requestObject, salesOffice);
			requestObject.setClient(client);
			//client.getProposals().add(requestObject);
			//clientRepository.updateClient(client);
			proposalRepository.updateProposal(requestObject);
			setProposalInfoInSession(model);
		}
	}

	@Override
	public String createProposalId() throws Exception {
		return proposalRepository.createPropId();
	}

	/* Below logic is added for caching purpose
	 * @Override
	public Proposal getHeaderDetails(Proposal proposal) {
		proposalServiceProcessor.validateHeaderDetailsRequest(proposal);
		Proposal result = sparcCache.getCachedProposal(proposal.getProposalId(), proposal.getClientId());
		if (result == null) {
			ProposalDetails proposalHeaderDetails = proposalRepository.getHeaderDetails(proposal.getProposalId(),proposal.getClientId());
			result = proposalServiceProcessor.parseHeaderDetails(proposalHeaderDetails);
			sparcCache.setCachedProposal(result);
		}
		return result;
	}*/
	
	@Override
	public Proposal getHeaderDetails(Proposal proposal) {
		Proposal result;
		HttpSession session = SessionManager.getHttpSession();
		Attribute attribute = SessionManager.retriveFromSession(session, SessionManager.DATA_HEADER_ATTR_NAME);
		if(attribute != null && attribute.getAttributeValue() != null 
			&& attribute.getAttributeValue() instanceof Proposal) {
			result = (Proposal)attribute.getAttributeValue();
			if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(result.getProposalId()),
				StringUtils.trimToEmpty(proposal.getProposalId()))
				&& (result.getClientId() == proposal.getClientId())) {
					return result;
			}
		} 
		proposalServiceProcessor.validateHeaderDetailsRequest(proposal);
		ProposalDetails proposalHeaderDetails = proposalRepository.getHeaderDetails(proposal.getProposalId(),proposal.getClientId());
		result = proposalServiceProcessor.parseHeaderDetails(proposalHeaderDetails);
		attribute = new Attribute();
		attribute.setAttributeName(SessionManager.DATA_HEADER_ATTR_NAME);
		attribute.setAttributeValue(result);
		SessionManager.storeInSession(session,attribute);
		return result;
	}

	@Override
	public Client getClientDetailsFromSession(int clientId) throws Exception{
		Client result;
		Holding holding = mainService.getSessionHolding();
		if(holding != null && (holding.getClientId() == clientId)) {
			result = new Client();
			result.setContractState(holding.getContractState());
			result.setClientId(holding.getClientId());
			result.setClientName(holding.getClientName());
			result.setSic(holding.getSic());
		} else {
			ClientClass clientClass = clientRepository.getClientById(Integer.valueOf(clientId));
			result = clientServiceProcessor.mapResultToClient(clientClass);
			holding = new Holding();
			holding.setClientId(result.getClientId());
			holding.setClientName(result.getClientName());
			holding.setContractState(result.getContractState());
			holding.setSic(result.getSic());
			mainService.updateSessionHolding(holding);
		}
		return result;
	}
	
	private void setProposalInfoInSession(Proposal proposal){
		Holding holding = mainService.getSessionHolding();
		//if(holding != null && StringUtils.equalsIgnoreCase(holding.getClientId(), String.valueOf(proposal.getClientId()))) {
			holding.setEffDate(proposal.getEffDate().toString());
			holding.setProposalId(proposal.getProposalId());
			holding.setProposalStatus(proposal.getProposalStatusVal());
			holding.setProrposalDescription(proposal.getDescription());
			mainService.updateSessionHolding(holding);
		//} 
	}

	@Override
	public Proposal createNewProposal(Client client) throws Exception {
		ClientClass clientObj = clientRepository.getClientById(client.getClientId());
		String proposalId = proposalRepository.createPropId();
		ProposalDetails proposalDetails = proposalServiceProcessor.mapTocreateNewProposalRequest(clientObj,proposalId);
		proposalRepository.createNewProposal(proposalDetails);
		proposalDetails = proposalRepository.getProposalDetails(proposalId);
		List<SalesOffice> salesOff =proposalRepository.getSalesOffice();
		List<SalesOfficeValues> salesOffVal=proposalServiceProcessor.mapSalesOffice(salesOff);
		Proposal proposal = proposalServiceProcessor.parseNewProposalResponse(proposalDetails,salesOffVal);
		return proposal;
	}

	@Override
	public Proposal getProposalDetails(String proposalId) throws Exception {
		if(StringUtils.isNotBlank(proposalId)){
			ProposalDetails proposalDetails = proposalRepository.getProposalDetails(proposalId);
			if(null != proposalDetails){
				List<SalesOffice> salesOff =proposalRepository.getSalesOffice();
				List<SalesOfficeValues> salesOffVal=proposalServiceProcessor.mapSalesOffice(salesOff);
				Proposal proposal = proposalServiceProcessor.mapResultProposalToModel(proposalDetails);
				proposal.setSalesOffice(salesOffVal);
				return proposal;
			}
		}
		throw new Exception();
	}
	
}
