package com.pru.sparc.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.Holding;
import com.pru.sparc.bo.model.LookupInfo;
import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.common.session.Attribute;
import com.pru.sparc.common.session.SessionManager;
import com.pru.sparc.dao.MainRepository;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.model.LookupDetails;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.service.MainService;

@Service("mainService")
public class MainServiceImpl implements MainService {
	
	@Autowired
	MainRepository mainRepository;
	
	@Autowired
	MainServiceProcessor mainServiceProcessor;

	@Override
	public void killSession() {
		HttpSession session = SessionManager.getHttpSession();
		SessionManager.killSession(session);
	}

	@Override
	public void newSession() {
		SessionManager.getHttpSession();
	}

	@Override
	public void updateSessionHolding(Holding sessionHolding) {
		HttpSession session = SessionManager.getHttpSession();
		Attribute attribute = SessionManager.retriveFromSession(session, SessionManager.DATA_HOLDER_ATTR_NAME);
		if(null == attribute){
			attribute = new Attribute();
			attribute.setAttributeName(SessionManager.DATA_HOLDER_ATTR_NAME);
		}
		attribute.setAttributeValue(sessionHolding);
		SessionManager.storeInSession(SessionManager.getHttpSession(),attribute);
	}

	@Override
	public Holding getSessionHolding() {
		Holding sessionHolding =  null;
		HttpSession session = SessionManager.getHttpSession();
		Attribute attribute = SessionManager.retriveFromSession(session, SessionManager.DATA_HOLDER_ATTR_NAME);
		if(attribute != null && attribute.getAttributeValue() != null 
				&& attribute.getAttributeValue() instanceof Holding) {
			sessionHolding = (Holding)attribute.getAttributeValue();
		} else {
			sessionHolding = new Holding();
		}
		return sessionHolding;
	}

	/**
	 * Method to get the list of states from database
	 * @return List<CensusStates>
	 * 
	 */
	@Override
	public List<LookupInfo> getLookupList(LookupInfo lookupInfo) throws Exception{
		List<LookupInfo> lookupInfoList = null;
		LookupDetails lookupDetails = mainServiceProcessor.mapLookupInfoToLookEntity(lookupInfo);
		final List<LookupDetails> lookupList = mainRepository.getLookupList(lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapLookupListToLookInfoList(lookupList);
		}
		return lookupInfoList;
	}
	
	/**
	 * Method to get the list of dropdown values for plan fields from database
	 * @return List<PlanConfigLookup>
	 * 
	 */
	@Override
	public List<PlanConfigLookup> getPlanLookupList() throws Exception{
		/*MainRepositoryImpl mainRepository = new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor = new MainServiceProcessor();*/
		
		
		
		List<PlanConfigLookup> lookupInfoList = null;
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		return lookupInfoList;
	}
	
	@Override
	public Map<String, PlanConfigLookup> getPlanContractState(String stateCode) throws Exception {
		/*MainRepositoryImpl mainRepository = new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor = new MainServiceProcessor();*/
		
		
		
		Map<String, PlanConfigLookup> stateAltValues = new HashMap<String, PlanConfigLookup>();
		PlanConfigLookup planConfigLookup = new PlanConfigLookup();
		if(StringUtils.isNotBlank(stateCode)){
			LookupDetails lookupDetails = mainRepository.getPlanContractState(stateCode);
			planConfigLookup = mainServiceProcessor.convertLookupDetailToPlanConfigLookup(lookupDetails, planConfigLookup);
			stateAltValues.put(planConfigLookup.getLookupKey(), planConfigLookup);
		}
		return stateAltValues;
	}
}
