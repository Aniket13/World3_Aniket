package com.pru.sparc.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.CensusCls;
import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsAggregator;
import com.pru.sparc.bo.model.PlanEligibility;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.constants.ProposalConstants;
import com.pru.sparc.common.exception.ValidationException;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.common.util.PlanConfigUtil;
import com.pru.sparc.dao.PlanDetailsRepository;
import com.pru.sparc.dao.ProducerRepository;
import com.pru.sparc.dao.QuotationDao;
import com.pru.sparc.dao.RatingQuoteDAO;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.model.BrokerDetails;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.PlanEligibilityClass;
import com.pru.sparc.model.PlanWrapper;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.QuotationDetails;
import com.pru.sparc.model.RatingExhibits;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.MainService;
import com.pru.sparc.service.PlanDetailsService;

@Service("planDetailsService")
public class PlanDetailsServiceImpl implements PlanDetailsService {
	
	@Autowired
	private PlanDetailsRepository planDetailsRepository;
	
	@Autowired
	private PlanDetailsServiceProcessor planDetailsServiceProcessor;
	
	@Autowired
	private QuotationDao quotationDao;
	
	@Autowired
	private MainService mainService;
	
	@Autowired
	private ProducerRepository producerRepository;
	
	@Autowired
	private RatingQuoteDAO ratingQuoteDAO;
	/*public List<PlanDetailsWrapper> getAllPlans(int versionId) {
		return null;//plansServiceProcessor.getAllPlansMapping(planDetailsRepository.getAllPlansForVersion(versionId));
	}

	public PlanDetailsWrapper getPlan(int planId) {
		
		return planDetailsServiceProcessor.getPlanMapped(planDetailsRepository.getPlanDetails(planId));
	}*/
	
	/**
	 * Method to load default plan fields
	 * @param planData
	 * @return List<PlanField>
	 * @throws Exception
	 */
	@Override
	public PlanDetailsAggregator loadPlanDetails (PlanDetailsAggregator planFieldDetails) throws Exception{
		/*PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();*/
	
		
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		if(CollectionUtils.isNotEmpty(planFieldDetails.getListOfPlanField())){
			planMetadataList = planDetailsServiceProcessor.mergePlanMetaDataLists(planMetadataList, planFieldDetails.getListOfPlanField());
		}
		//method to fetch data from lookup and set into list
		List<PlanConfigLookup> planLookupList = mainService.getPlanLookupList();//planConfigLookup);
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, planLookupList);
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		PlanMetadata planContractState = planMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE);
		planContractState.setAltValues(mainService.getPlanContractState(planContractState.getFieldValue()));
		planMap.put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE, planContractState);
		
		//getting sic code and total lives in plan Map
		String sicCode = planFieldDetails.getSicCode();
		int totalLives = 0;
		if (planFieldDetails.getSelectedCensusId() > 0) {
			totalLives = planDetailsRepository.getCensusTotalLives(planFieldDetails.getSelectedCensusId());
		}
		
		planMap = planHelper.getPlanFieldsForDisplay(planMap,sicCode,totalLives);
		//commenting the filterVisibleRecords() method call as filtering will be handled at UI side
		//planMap = planDetailsServiceProcessor.filterVisibleRecords(planMap);
		planMetadataList = new ArrayList<PlanMetadata>(planMap.values());
		for (PlanMetadata planMetadata : planMetadataList) {
			if(StringUtils.isNotBlank(planMetadata.getFieldValue()) && StringUtils.equalsIgnoreCase("null", planMetadata.getFieldValue())){
				planMetadata.setFieldValue(null);
			}
			
			/*if(StringUtils.equalsIgnoreCase(planMetadata.getFieldType(), "textbox")){
				if(StringUtils.equals(planMetadata.getTabId(), "4")){
					planMetadata.setVisibleFlag("Yes");
					planMetadata.setOverriddenFlag("Y");
				}
				planMetadata.setFieldValue("10");
			}*/
		}
		planFieldDetails.setListOfPlanField(planMetadataList);
		return planFieldDetails;
	}

	/*@Override
	public PlanDetailsAggregator onChangePlanDetails(PlanDetailsAggregator planFieldDetails) {
		//List<PlanMetadata> uiPlanMetadataList = new ArrayList<PlanMetadata>();
		if(CollectionUtils.isNotEmpty(planFieldDetails.getListOfPlanField())) {
			List<PlanMetadata> planMetadataList = planFieldDetails.getListOfPlanField();
			Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
			DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
			planMap = planHelper.onChangePlanDetailsFieldsForDisplay(planMap);
			planMetadataList = new ArrayList<PlanMetadata>(planMap.values());
			
			for (PlanMetadata planMetadata : planMetadataList) {
				if(StringUtils.isNotBlank(planMetadata.getFieldValue()) && 
						StringUtils.equalsIgnoreCase("null", planMetadata.getFieldValue())) {
					planMetadata.setFieldValue(null);
				}	
				//String indicator = StringUtils.trimToEmpty(planMetadata.getFieldIndicator());
				//if (StringUtils.equalsIgnoreCase(indicator, PlanConfigConstants.FIELD_INDICATOR_ADD) ||
					//	StringUtils.equalsIgnoreCase(indicator, PlanConfigConstants.FIELD_INDICATOR_CHANGE) ||
					//	StringUtils.equalsIgnoreCase(indicator, PlanConfigConstants.FIELD_INDICATOR_REMOVE)) {
					//uiPlanMetadataList.add(planMetadata);
				//}
			}
			planFieldDetails.setListOfPlanField(planMetadataList);
		}
		return planFieldDetails;
	}*/
	
	@Override
	public PlanDetailsAggregator onChangePlanDetails(PlanDetailsAggregator planFieldDetails) {
		try {
			
		//getting sic code and total lives in plan Map
		String sicCode = planFieldDetails.getSicCode();
		int totalLives = 0;
		if (planFieldDetails.getSelectedCensusId() > 0) {
			totalLives = planDetailsRepository.getCensusTotalLives(planFieldDetails.getSelectedCensusId());
		}
			
		if(CollectionUtils.isNotEmpty(planFieldDetails.getListOfPlanField())) {
			/*****************  Fetch UI Plan Details Object******************** */
			List<PlanMetadata> planUidataList = planFieldDetails.getListOfPlanField();
			//Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planUidataList);
			DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
			/*****************  Fetch MetaData Object Start******************** */
			List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
			/*****************  Fetch MetaData Object End******************** */
			if(CollectionUtils.isNotEmpty(planUidataList)){
				planMetadataList = planDetailsServiceProcessor.mergePlanMetaDataLists(planMetadataList, planUidataList);
			}
			/*****************  Fetch Lookup  Reference Data from DB******************** */
			List<PlanConfigLookup> planLookupList = mainService.getPlanLookupList();
			/*****************  Merging UI Plan Details  and lookup Ref. Data ******************** */
			planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, planLookupList);
			Map<String, PlanMetadata> updatedPlanMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
			PlanMetadata planContractState = updatedPlanMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE);
			planContractState.setAltValues(mainService.getPlanContractState(planContractState.getFieldValue()));
			updatedPlanMap.put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE, planContractState);
			
			//set overridden flag values for all overridden fields to 'Y'
			if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(planFieldDetails.getCurrentTabId()),"4")) {
				updatedPlanMap = PlanConfigUtil.transferExceptionValue(updatedPlanMap);
			} else if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(planFieldDetails.getCurrentTabId()),"1")) {
				updatedPlanMap = PlanConfigUtil.transferOriginalValue(updatedPlanMap);
			}
			
			updatedPlanMap = planHelper.onChangePlanDetailsFieldsForDisplay(updatedPlanMap,sicCode,totalLives);
			planUidataList = new ArrayList<PlanMetadata>(updatedPlanMap.values());
			
			for (PlanMetadata planMetadata : planUidataList) {
				if(StringUtils.isNotBlank(planMetadata.getFieldValue()) && 
						StringUtils.equalsIgnoreCase("null", planMetadata.getFieldValue())) {
					planMetadata.setFieldValue(null);
				}	
			}
			planFieldDetails.setListOfPlanField(planUidataList);	
			
			
			/*//set overridden flag values for all overridden fields to 'Y'
			Map<String, PlanMetadata> defaultMetadataMap = PlanConfigUtil.setOverriddenFlagToY(planDetailsServiceProcessor.convertToPlanMap(planUidataList));
			List<PlanMetadata> metadataList = new ArrayList<PlanMetadata>(defaultMetadataMap.values());     
			planFieldDetails.setListOfPlanField(metadataList);	
			//planFieldDetails.setListOfPlanField(planUidataList);
*/			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return planFieldDetails;
	}
	/**
	 * Method to save the plan details to database
	 * @param plandetails
	 * @throws Exception
	 */
	/*public PlanDetailsClass processSavePlanDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception{
		if(StringUtils.isBlank(planDetailsAggregator.getProposalId()) || planDetailsAggregator.getProposalVersionId() <= 0 || planDetailsAggregator.getPlanId() <= 0 || planDetailsAggregator.getProdCode() <= 0){
			throw new ValidationException("Save Plan Request Invalid");
		}
		PlanDetailsClass existingPlanObject = planDetailsRepository.getPlanDetails(planDetailsAggregator.getPlanId());
		if(null != existingPlanObject){
			existingPlanObject = planDetailsServiceProcessor.convertToPlanDetailsClass(existingPlanObject, planDetailsAggregator.getListOfPlanField());
			//planDetailsRepository.updatePlanDetails(existingPlanObject);
		}
		return existingPlanObject;
	}*/

	/**
	 * Method to create new plan
	 * @param planDetails
	 * @return PlanDetailsClass
	 * @throws Exception
	 */
	@Override
	public PlanDetailsAggregator createNewPlan(PlanDetailsAggregator planDetailsAggregator) throws Exception {
		if(StringUtils.isBlank(planDetailsAggregator.getProposalId()) || planDetailsAggregator.getProposalVersionId() <= 0 || planDetailsAggregator.getProdCode() <= 0){
			throw new ValidationException("Create New Plan Request Invalid");
		}
		PlanDetailsClass planDetailsClass = null;
		List<PlanDetailsClass> existingPlanObjectsList = planDetailsRepository.getPlanDetailsByProposalVersionProductId(planDetailsAggregator.getProposalVersionId(), planDetailsAggregator.getProdCode());
		if(CollectionUtils.isNotEmpty(existingPlanObjectsList)) {
			if(existingPlanObjectsList.size() == 1 && StringUtils.equalsIgnoreCase(existingPlanObjectsList.get(0).getDisplayPlan(), "N"))
			{
				planDetailsClass = existingPlanObjectsList.get(0);
				planDetailsClass.setDisplayPlan("Y");
				planDetailsRepository.updatePlanDetails(planDetailsClass);
			} else {
				QuotationDetails version = quotationDao.getQuotationDetails(planDetailsAggregator.getProposalId(), planDetailsAggregator.getProposalVersionId());
				List<Integer> selectedProduct = new ArrayList<Integer>();
				selectedProduct.add(planDetailsAggregator.getProdCode());
				List<ProductDetails> product = quotationDao.getSelectedProducts(selectedProduct);
				if(CollectionUtils.isNotEmpty(product)){
					planDetailsClass = planDetailsServiceProcessor.createNewPlanRequest(version, product.get(0));
					planDetailsClass = planDetailsRepository.addPlanDetails(planDetailsClass);
				}
			}
		} else {
			QuotationDetails version = quotationDao.getQuotationDetails(planDetailsAggregator.getProposalId(), planDetailsAggregator.getProposalVersionId());
			List<Integer> selectedProduct = new ArrayList<Integer>();
			selectedProduct.add(planDetailsAggregator.getProdCode());
			List<ProductDetails> product = quotationDao.getSelectedProducts(selectedProduct);
			if(CollectionUtils.isNotEmpty(product)){
				planDetailsClass = planDetailsServiceProcessor.createNewPlanRequest(version, product.get(0));
				planDetailsClass = planDetailsRepository.addPlanDetails(planDetailsClass);
			}
		}
		if(null != planDetailsClass){
			planDetailsAggregator.setListOfPlanField(planDetailsServiceProcessor.convertPlanDetailsToFieldList(planDetailsClass));
			//set overridden fields into list
			planDetailsAggregator.setPlanId(planDetailsClass.getPlanId());
			planDetailsAggregator.setBrokerId(1);
			planDetailsAggregator.setCommission(planDetailsServiceProcessor.createDefaultCommission(null, planDetailsAggregator));
			int censusId = planDetailsRepository.getCensusForPlan(planDetailsAggregator.getPlanId(), planDetailsAggregator.getProposalVersionId());
			List<CensusClass> allocatedCensusClasses = planDetailsRepository.getCensusClassesForPlan(censusId);
			PlanEligibility eligibility = planDetailsServiceProcessor.createDefaultEligibility(planDetailsAggregator, null, censusId, allocatedCensusClasses);
			if(null != eligibility && CollectionUtils.isNotEmpty(allocatedCensusClasses)){
				List<CensusCls> classList = new ArrayList<CensusCls>();
				for (CensusClass censusClass : allocatedCensusClasses) {
					int noOfLives = planDetailsRepository.getNoOfLivesPerClass(censusId, censusClass.getCensusClsId());
					CensusCls censusCls = planDetailsServiceProcessor.getCensusClassDetails(censusClass, noOfLives);
					classList.add(censusCls);
				}
				eligibility.setCensusClassList(classList);
			}
			planDetailsAggregator.setPlanEligibility(eligibility);
			return loadPlanDetails(planDetailsAggregator);
		}
		throw new ValidationException("Error creating new plan");
	}

	/**
	 * Method to get the plan details from database
	 * @param planDetails
	 * @return List<PlanBO>
	 * @throws Exception
	 */
	@Override
	public List<PlanDetailsAggregator> getVersionPlans(PlanDetailsAggregator planDetailsAggregator) throws Exception {
		//dynamicPlanHelper-->getPlanFieldList() can be used for mapping
		if(StringUtils.isBlank(planDetailsAggregator.getProposalId()) || planDetailsAggregator.getProposalVersionId() <= 0 || planDetailsAggregator.getProdCode() <= 0){
			throw new ValidationException("Get Version Plans Request Invalid");
		}
		List<PlanDetailsAggregator> versionPlanList = null;
		List<PlanDetailsClass> plansList = planDetailsRepository.getAllPlansForVersion(planDetailsAggregator.getProposalVersionId(), planDetailsAggregator.getProposalId(), planDetailsAggregator.getProdCode());
		if(CollectionUtils.isNotEmpty(plansList)){
			versionPlanList = new ArrayList<PlanDetailsAggregator>();
			//DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
			for (PlanDetailsClass planDetailsClass : plansList) {
				PlanDetailsAggregator planAggregator = new PlanDetailsAggregator();
				//planAggregator.setListOfPlanField(planHelper.getPlanFieldList(plansServiceProcessor.mapPlanDetailsToPlanBO(planDetailsClass), planHelper.fetchPlanMetaData()));
				planAggregator.setPlanId(planDetailsClass.getPlanId());
				
				ProductDetails product = planDetailsRepository.getProductDetails(planAggregator.getPlanId());
				planAggregator.setProdCode(product.getProductId());
				
				planAggregator.setProposalId(StringUtils.trimToEmpty(planDetailsRepository.getPlanProposalId(planAggregator.getPlanId())));
				//planAggregator.setProposalId(planDetailsClass.getVersion().getProposal().getProposalId());
				planAggregator.setProposalVersionId(planDetailsRepository.getPlanVersionId(planAggregator.getPlanId()));
				planAggregator.setListOfPlanField(planDetailsServiceProcessor.convertPlanDetailsToFieldList(planDetailsClass));
				versionPlanList.add(planAggregator);
			}
		}
		return versionPlanList;
	}

	/**
	 * Method to save plan commission details
	 * @param commission
	 * @throws Exception
	 */
	/*public ProposalBrokerDetails processSavePlanCommission(PlanDetailsAggregator planDetailsAggregator) throws Exception{
		ProposalBrokerDetails proposalBroker = quotationDao.getCommission(commission.getBrokerID(), commission.getProposalPlanID(), commission.getVersionNumber());
		if(proposalBroker != null){
			proposalBroker = planDetailsServiceProcessor.mapToProposalBrokerDetails(commission,proposalBroker.getBrokerDetails(), proposalBroker, proposalBroker.getVersionDetails());
		} else if(commission.getBrokerID() > 0){
			BrokerDetails brokerDetails = producerRepository.getProducerById(commission.getBrokerID());
			QuotationDetails versionDetails = quotationDao.getQuotationDetails(commission.getProposalPlanID(), commission.getVersionNumber());
			proposalBroker = planDetailsServiceProcessor.mapToProposalBrokerDetails(commission,brokerDetails,null,versionDetails);
			//planDetailsRepository.savePlanCommission(proposalBroker);
		}
		return proposalBroker;
	}*/
	
	/**
	 * Method to get the plan commission details
	 * @param commission
	 * @return Commission
	 * @throws Exception
	 */
	@Override
	public PlanDetailsAggregator getPlanCommissionDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception{
		if(planDetailsAggregator.getCommission() != null){
			ProposalBrokerDetails prBrokerDetails = planDetailsRepository.getCommissionDetails(planDetailsAggregator.getCommission().getProposalPlanID(), planDetailsAggregator.getCommission().getBrokerID());
			if(null != prBrokerDetails){
				planDetailsAggregator.setCommission(planDetailsServiceProcessor.parseCommissionResponse(prBrokerDetails));
			}
		}
		return planDetailsAggregator;
	}

	/**
	 * Method to save plan eligibility details
	 * @param planEligibilityList
	 */
	/*public PlanDetailsAggregator processSaveEligibilityDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception{
		List<PlanEligibilityClass> planEligibilityClasslist = null;
		if(null != planDetailsAggregator){
			boolean isUpdate = true;
			planEligibilityClasslist = planDetailsRepository.getEligibilityClasses(planEligibility.getPlanID());
			if (CollectionUtils.isEmpty(planEligibilityClasslist)) {
				planEligibilityClasslist = new ArrayList<PlanEligibilityClass>();
				isUpdate = false;
			}
			if (!isUpdate) {
				for (CensusCls censusCls : planEligibility.getCensusClassList()) {
					if(censusCls.getCensusClsId() > 0){
						PlanDetailsClass planDetailsClass = planDetailsRepository.getPlanDetails(planEligibility.getPlanID());
						CensusClass censusClass = planDetailsRepository.getCensusClassById(censusCls.getCensusClsId());
						planEligibilityClasslist.add(planDetailsServiceProcessor.mapToPlanEligibilityClass(null, planEligibility, censusCls, planDetailsClass, censusClass));
					}
				}
			} else {
				for (PlanEligibilityClass planEligibilityClass : planEligibilityClasslist) {
					PlanDetailsClass planDetailsClass = planEligibilityClass.getPlanDetails();
					CensusClass censusClass = planEligibilityClass.getCensusClass();
					for (CensusCls censusCls : planEligibility.getCensusClassList()) {
						if(censusCls.getCensusClsId() == censusClass.getCensusClsId()){
							planDetailsServiceProcessor.mapToPlanEligibilityClass(planEligibilityClass, planEligibility, censusCls, planDetailsClass, censusClass);
						}
					}
					
				}
			}
			//planDetailsRepository.saveEligibilityClasses(planEligibilityClasslist);
		}
		return planEligibilityClasslist;
	}*/
	
	/**
	 * Method to get plan eligibility details
	 * @param planEligibility
	 * @return List<PlanEligibility>
	 */
	public PlanDetailsAggregator getEligibilityDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception{
		if(planDetailsAggregator.getPlanEligibility().getPlanID() > 0 && planDetailsAggregator.getPlanEligibility().getVersionNumber() > 0){
			List<PlanEligibilityClass> planEligibilityList = planDetailsRepository.getEligibilityClasses(planDetailsAggregator.getPlanEligibility().getPlanID());
			if(CollectionUtils.isNotEmpty(planEligibilityList)){
				//planDetailsAggregator.setPlanEligibility(planDetailsServiceProcessor.mapToPlanEligibility(planEligibilityList, planDetailsAggregator.getPlanEligibility()));
			}
			int censusId = planDetailsRepository.getCensusForPlan(planDetailsAggregator.getPlanEligibility().getPlanID(), planDetailsAggregator.getPlanEligibility().getVersionNumber());
			if(censusId > 0){
				List<CensusClass> allocatedCensusClasses = planDetailsRepository.getCensusClassesForPlan(censusId);
				if(CollectionUtils.isNotEmpty(allocatedCensusClasses)){
					List<CensusCls> classList = new ArrayList<CensusCls>();
					PlanEligibility eligibility = new PlanEligibility();
					eligibility.setCensusID(censusId);
					eligibility.setMinHrsRequired(30F);
					eligibility.setPlanID(planDetailsAggregator.getPlanEligibility().getPlanID());
					eligibility.setVersionNumber(planDetailsAggregator.getPlanEligibility().getVersionNumber());
					for (CensusClass censusClass : allocatedCensusClasses) {
						int noOfLives = planDetailsRepository.getNoOfLivesPerClass(censusId, censusClass.getCensusClsId());
						CensusCls censusCls = new CensusCls();
						censusCls.setCensusClsId(censusClass.getCensusClsId());
						censusCls.setClassDesc(censusClass.getClassDesc());
						censusCls.setClassSelected(false);
						censusCls.setNoOfLives(noOfLives);
						classList.add(censusCls);
					}
					eligibility.setCensusClassList(classList);
					planDetailsAggregator.setPlanEligibility(eligibility);
				}
			}
		}
		return planDetailsAggregator;
	}

	/**
	 * Method to get plan overridden plan details
	 * @param PlanDetailsAggregator
	 * @return PlanDetailsAggregator
	 * @throws Exception
	 */
	public PlanDetailsAggregator getOverriddenPlanDetails(PlanDetailsAggregator planFieldDetails) throws Exception {
		if(planFieldDetails.getPlanId() > 0){
			PlanDetailsClass overriddenPlanDetails = planDetailsRepository.getOverriddenRecordForPlanId(planFieldDetails.getPlanId());
			PlanDetailsClass originalPlanDetails = planDetailsRepository.getPlanDetails(planFieldDetails.getPlanId());
			PlanDetailsClass mergedPlanDetails = planDetailsServiceProcessor.mergePlanDetailsClassObjects(originalPlanDetails, overriddenPlanDetails);
			planFieldDetails.setListOfPlanField(planDetailsServiceProcessor.convertPlanDetailsToFieldList(mergedPlanDetails));
			return loadPlanDetails(planFieldDetails);
		}
		return null;
	}
	
	/**
	 * Method to save overridden plan details
	 * @param PlanDetailsAggregator
	 * @throws Exception
	 */
	/*public PlanDetailsClass processOverridePlanDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception {
		List<PlanMetadata> overriddenFields = new ArrayList<PlanMetadata>();
		Map<String, List<PlanMetadata>> fieldListMap = planDetailsServiceProcessor.filterOverridenFields(planDetailsAggregator.getListOfPlanField(), overriddenFields);
		overriddenFields = fieldListMap.get("overriddenFields");
		//List<PlanMetadata> originalFieldsList = fieldListMap.get("originalValues");
		planDetailsAggregator.setListOfPlanField(overriddenFields);
		PlanDetailsClass overriddenPlanDetails = planDetailsRepository.getOverriddenRecordForPlanId(planDetailsAggregator.getPlanId());
		if(null != overriddenPlanDetails){
			overriddenPlanDetails = planDetailsServiceProcessor.mapToPlanDetailsClass(overriddenPlanDetails, planDetailsAggregator);
			overriddenPlanDetails.setOriginalPlanId(planDetailsAggregator.getPlanId());
			overriddenPlanDetails.setOverId(1);
			overriddenPlanDetails.setOverrideIndicator("Y");
			//planDetailsRepository.updatePlanDetails(overriddenPlanDetails);
		} else {
			overriddenPlanDetails = planDetailsServiceProcessor.mapToPlanDetailsClass(null, planDetailsAggregator);
			overriddenPlanDetails.setOriginalPlanId(planDetailsAggregator.getPlanId());
			overriddenPlanDetails.setOverId(1);
			overriddenPlanDetails.setOverrideIndicator("Y");
			//planDetailsRepository.addPlanDetails(overriddenPlanDetails);
		}
		return overriddenPlanDetails;
		PlanDetailsClass originalPlanDetails = planDetailsRepository.getPlanDetails(planDetailsAggregator.getPlanId());
		PlanDetailsClass mergedPlanDetails = planDetailsServiceProcessor.mergePlanDetailsClassObjects(originalPlanDetails, overriddenPlanDetails);
		planDetailsRepository.updatePlanDetails(mergedPlanDetails);
		
	}*/
	
	/*public PlanDetailsClass updatePlanWithOverridden(PlanDetailsClass originalPlanDetails, PlanDetailsClass overriddenPlanDetails){
		PlanDetailsClass mergedPlanDetails = planDetailsServiceProcessor.mergePlanDetailsClassObjects(originalPlanDetails, overriddenPlanDetails);
		//planDetailsRepository.updatePlanDetails(mergedPlanDetails);
		return mergedPlanDetails;
	}*/
	//common method to save
	
	/*public PlanDetailsAggregator saveAllPlanDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception{
		if(StringUtils.isBlank(planDetailsAggregator.getProposalId()) || planDetailsAggregator.getProposalVersionId() <= 0 || planDetailsAggregator.getPlanId() <= 0 || planDetailsAggregator.getProdCode() <= 0){
			throw new ValidationException("Save All Plan Details Request Invalid");
		}
		//method to validate the commission split value
		planDetailsServiceProcessor.validateCommissionDetails(planDetailsAggregator.getCommission());
		PlanWrapper planWrapper = new PlanWrapper();
		planDetailsAggregator = loadPlanDetails(planDetailsAggregator);
		PlanDetailsClass existingPlanObject = processSavePlanDetails(planDetailsAggregator);
		PlanDetailsClass overriddenDetails = processOverridePlanDetails(planDetailsAggregator);
		existingPlanObject = updatePlanWithOverridden(existingPlanObject, overriddenDetails);
		planWrapper.setOverriddenDetails(overriddenDetails);
		planWrapper.setPlanDetailsClass(existingPlanObject);
		planWrapper.setPlanEligibilityClass(processSaveEligibilityDetails(planDetailsAggregator.getPlanEligibility()));
		planWrapper.setProposalBrokerDetails(processSavePlanCommission(planDetailsAggregator.getCommission()));
		planDetailsRepository.saveAllPlanDetails(planWrapper);
		planDetailsAggregator = planDetailsServiceProcessor.parsePlanResponse(planDetailsAggregator, planWrapper);
		return planDetailsAggregator;
	}
	*/
	@Override
	public PlanDetailsAggregator getAllPlanDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception{
		//--
		/*PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();*/
		//--
		if(planDetailsAggregator.getPlanId() <= 0){
			throw new ValidationException("Get All Plan Details Request Invalid");
		}
		PlanWrapper planWrapper = planDetailsRepository.getAllPlanDetails(planDetailsAggregator.getPlanId(), planDetailsAggregator.getBrokerId());
		if(null != planWrapper){
			planDetailsAggregator.setCommission(planDetailsServiceProcessor.createDefaultCommission(planWrapper.getProposalBrokerDetails(), planDetailsAggregator));
			int censusId = planDetailsRepository.getCensusForPlan(planDetailsAggregator.getPlanId(), planDetailsAggregator.getProposalVersionId());
			List<CensusClass> allocatedCensusClasses = null;
			if(censusId > 0){
				allocatedCensusClasses = planDetailsRepository.getCensusClassesForPlan(censusId);
			}
			PlanEligibility eligibility = planDetailsServiceProcessor.createDefaultEligibility(planDetailsAggregator, planWrapper, censusId, allocatedCensusClasses);
			planDetailsAggregator.setPlanEligibility(eligibility);
			planDetailsAggregator = planDetailsServiceProcessor.parsePlanResponse(planDetailsAggregator, planWrapper/*, allocatedCensusClasses*/);
		} else {
			planDetailsAggregator = null;
		}
		return planDetailsAggregator;
	}

	public static void main(String[] args) {
		PlanDetailsServiceImpl pdsi = new PlanDetailsServiceImpl();
		PlanDetailsAggregator pda = new PlanDetailsAggregator();
		pda.setBrokerId(1);
		pda.setListOfPlanField(new ArrayList<PlanMetadata>());
		pda.setPlanId(1140);
		pda.setProdCode(1);
		pda.setProposalId("2016238001");
		pda.setProposalVersionId(474);
		try {
			pdsi.fetchExistPlanDtlFrmDB(pda);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/*Commission commission = new Commission();
		commission.setAdvaceCommissionOccurs("First Year");
		commission.setAdvanceCommission(10);
		commission.setAdvanceCommissionFlag("true");
		commission.setArrangement("Level Scale");
		commission.setBrokerID(1);
		commission.setCommissionPaidTo("individual");
		commission.setCommissionSplit(100);
		commission.setProposalPlanID("1");
		commission.setVersionNumber(1);
		pda.setCommission(commission);
		PlanEligibility eligibility = new PlanEligibility();
		eligibility.setCensusID(1);
		eligibility.setMinHrsRequired(12);
		eligibility.setPlanID(1);
		eligibility.setVersionNumber(1);
		List<CensusCls> censusClassList = new ArrayList<CensusCls>();
		CensusCls censusCls = new CensusCls();
		censusCls.setCensusClsId(1);
		censusCls.setCensusId(1);
		censusCls.setClassDesc("class 1");
		censusCls.setClassSelected(true);
		censusCls.setColBargain(false);
		censusCls.setNoOfLives(150);
		censusClassList.add(censusCls);
		eligibility.setCensusClassList(censusClassList);
		pda.setPlanEligibility(eligibility);*/
		try {
			//pdsi.overridePlanDetails(pdsi.loadPlanDetails(pda));
			//pdsi.savePlanCommission(pdsi.loadPlanDetails(pda));
			pdsi.loadPlanDetails(pda);
			//pdsi.saveEligibilityDetails(pdsi.loadPlanDetails(pda));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Override
	public PlanDetailsAggregator overridePlanDetails(PlanDetailsAggregator planDetailsAggregator)
			throws Exception {
		//PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		//PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();
		
		List<PlanMetadata> overriddenFields = new ArrayList<PlanMetadata>();
		Map<String, List<PlanMetadata>> fieldListMap = planDetailsServiceProcessor.filterOverridenFields(planDetailsAggregator.getListOfPlanField(), overriddenFields);
		overriddenFields = fieldListMap.get("overriddenFields");
		//List<PlanMetadata> originalFieldsList = fieldListMap.get("originalValues");
		//planDetailsAggregator.setListOfPlanField(overriddenFields);
		PlanDetailsClass overriddenPlanDetails = planDetailsRepository.getOverriddenRecordForPlanId(planDetailsAggregator.getPlanId());
		PlanDetailsClass originalPlanDetails = planDetailsRepository.getPlanDetails(planDetailsAggregator.getPlanId());
		if(null != overriddenPlanDetails){
			//overriddenPlanDetails = planDetailsServiceProcessor.convertToOverriddenPlanDetailsClass(overriddenPlanDetails, overriddenFields);
			
			/*PlanDetailsAggregator overriddenPlanDetailsAggregator = new PlanDetailsAggregator();
			overriddenPlanDetailsAggregator.setListOfPlanField(overriddenFields);
			overriddenPlanDetails = planDetailsServiceProcessor.mapToPlanDetailsClass(overriddenPlanDetails, overriddenPlanDetailsAggregator);*/
			
			overriddenPlanDetails = planDetailsServiceProcessor.convertToOverriddenPlanDetailsClass(overriddenPlanDetails , overriddenFields);
			
			overriddenPlanDetails.setOriginalPlanId(planDetailsAggregator.getPlanId());
			overriddenPlanDetails.setOverId(1);
			overriddenPlanDetails.setOverrideIndicator("Y");
			planDetailsRepository.updatePlanDetails(overriddenPlanDetails);
		} else {
			//adding new overridden plan
			QuotationDetails quotationDetails = quotationDao.getQuotationDetails(planDetailsAggregator.getProposalId(),planDetailsAggregator.getProposalVersionId());
			ProductDetails productDetails = planDetailsRepository.getProductDetails(planDetailsAggregator.getPlanId());
			
			/*PlanDetailsAggregator overriddenPlanDetailsAggregator = new PlanDetailsAggregator();
			overriddenPlanDetailsAggregator.setListOfPlanField(overriddenFields);
			overriddenPlanDetails = planDetailsServiceProcessor.mapToPlanDetailsClass(null, overriddenPlanDetailsAggregator);*/
			
			overriddenPlanDetails = planDetailsServiceProcessor.convertToOverriddenPlanDetailsClass(null , overriddenFields);
			
			overriddenPlanDetails.setOriginalPlanId(planDetailsAggregator.getPlanId());
			overriddenPlanDetails.setOverId(1);
			overriddenPlanDetails.setOverrideIndicator("Y");
			
			overriddenPlanDetails.setDisplayPlan("Y");
			overriddenPlanDetails.setProductCode(String.valueOf(productDetails.getProductId()));
			overriddenPlanDetails.setVersion(quotationDetails);
			overriddenPlanDetails.setProduct(productDetails);
			overriddenPlanDetails.setContractState(quotationDetails.getProposal().getContractState());
			overriddenPlanDetails.setEffectiveDate(quotationDetails.getProposal().getCaseEffectiveDt());
			planDetailsRepository.addPlanDetails(overriddenPlanDetails);
		}
		
		//commented
		PlanDetailsClass mergedPlanDetails = planDetailsServiceProcessor.mergePlanDetailsClassObjects(originalPlanDetails, overriddenPlanDetails);
		mergedPlanDetails = planDetailsRepository.updatePlanDetails(mergedPlanDetails);
		
		
		/*List<PlanMetadata> metadataList = new ArrayList<PlanMetadata>();
		metadataList.addAll(planDetailsServiceProcessor.convertPlanDetailsToFieldList(mergedPlanDetails));
		metadataList.addAll(planDetailsServiceProcessor.convertOverriddenDetailsToFieldList(mergedPlanDetails));*/
		
		//set overridden flag values for all overridden fields to 'Y'
		Map<String, PlanMetadata> defaultMetadataMap = PlanConfigUtil.setOverriddenFlagToY(planDetailsServiceProcessor.convertToPlanMap(planDetailsAggregator.getListOfPlanField()));
		List<PlanMetadata> metadataList = new ArrayList<PlanMetadata>(defaultMetadataMap.values());
				
		//commented
		planDetailsAggregator.setListOfPlanField(planDetailsServiceProcessor.mergePlanlatestValues(metadataList, 
				planDetailsServiceProcessor.convertPlanDetailsToFieldList(mergedPlanDetails)));
		//planDetailsAggregator.setListOfPlanField(metadataList);
		
		
		
		
		//calling getAllPlanDetails for the latest data
        //planDetailsAggregator = getAllPlanDetails(planDetailsAggregator);
		this.validateRatingDetails(planDetailsAggregator.getProposalVersionId(),planDetailsAggregator.getPlanId());
		return planDetailsAggregator;
	}


	@Override
	public PlanDetailsAggregator savePlanCommission(PlanDetailsAggregator planDetailsAggregator) throws Exception {
		/*QuotationDaoImpl quotationDao = new QuotationDaoImpl();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		ProducerRepositoryImpl producerRepository = new ProducerRepositoryImpl();
		PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();*/
		
		
		if(planDetailsAggregator.getCommission() != null && CollectionUtils.isNotEmpty(planDetailsAggregator.getListOfPlanField())){
			planDetailsServiceProcessor.validateCommissionDetails(planDetailsAggregator.getCommission());
			ProposalBrokerDetails proposalBroker = quotationDao.getCommission(planDetailsAggregator.getCommission().getBrokerID(), planDetailsAggregator.getCommission().getProposalPlanID(), planDetailsAggregator.getCommission().getVersionNumber());
			if(proposalBroker != null){
				proposalBroker = planDetailsServiceProcessor.mapToProposalBrokerDetails(planDetailsAggregator.getCommission(),proposalBroker.getBrokerDetails(), proposalBroker, proposalBroker.getVersionDetails());
			} else {
				if(planDetailsAggregator.getBrokerId() > 0){
					BrokerDetails brokerDetails = producerRepository.getProducerById(planDetailsAggregator.getCommission().getBrokerID());
					QuotationDetails versionDetails = quotationDao.getQuotationDetails(planDetailsAggregator.getProposalId(), planDetailsAggregator.getCommission().getVersionNumber());
					proposalBroker = planDetailsServiceProcessor.mapToProposalBrokerDetails(planDetailsAggregator.getCommission(),brokerDetails,null,versionDetails);
				}
			}
			if(null != proposalBroker){
				planDetailsRepository.savePlanCommission(proposalBroker);
				planDetailsAggregator.setCommission(planDetailsServiceProcessor.parseCommissionResponse(proposalBroker));
				planDetailsAggregator.setListOfPlanField((savePlanDetails(planDetailsAggregator)).getListOfPlanField());
			}
		}
		//calling getAllPlanDetails for the latest data
        //planDetailsAggregator = getAllPlanDetails(planDetailsAggregator);
		this.validateRatingDetails(planDetailsAggregator.getProposalVersionId(),planDetailsAggregator.getPlanId());
		return planDetailsAggregator;
	}


	@Override
	public PlanDetailsAggregator saveEligibilityDetails(PlanDetailsAggregator planDetailsAggregator)
			throws Exception {
		
		/*PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();
		*/
		List<PlanEligibilityClass> planEligibilityClasslist = null;
		if(null != planDetailsAggregator.getPlanEligibility() && CollectionUtils.isNotEmpty(planDetailsAggregator.getListOfPlanField())){
			//delete all eligibility records from table for this plan id
			planDetailsRepository.deleteEligibilityRecords(planDetailsAggregator.getPlanId());
			//INSERT ALL CHECKED CLASS RECORDS AGAIN
			planEligibilityClasslist = planDetailsRepository.getEligibilityClasses(planDetailsAggregator.getPlanEligibility().getPlanID());
			if (CollectionUtils.isEmpty(planEligibilityClasslist)) {
				planEligibilityClasslist = new ArrayList<PlanEligibilityClass>();
			}
			PlanDetailsClass planDetailsClass = planDetailsRepository.getPlanDetails(planDetailsAggregator.getPlanEligibility().getPlanID());
			if(CollectionUtils.isNotEmpty(planDetailsAggregator.getPlanEligibility().getCensusClassList())){
				for (CensusCls censusCls : planDetailsAggregator.getPlanEligibility().getCensusClassList()) {
					if(censusCls.getCensusClsId() > 0){
						CensusClass censusClass = planDetailsRepository.getCensusClassById(censusCls.getCensusClsId());
						PlanEligibilityClass planEligibilityClass = planDetailsServiceProcessor.mapToPlanEligibilityClass(null, planDetailsAggregator.getPlanEligibility(), censusCls, planDetailsClass, censusClass);
						if(planEligibilityClass != null){
							planEligibilityClasslist.add(planEligibilityClass);
							planDetailsRepository.updatePlanDetails(planEligibilityClass.getPlanDetails());
						}else{
							planDetailsClass.setMinHrsReqd(planDetailsAggregator.getPlanEligibility().getMinHrsRequired());
							planDetailsRepository.updatePlanDetails(planDetailsClass);
						}
					}
				}
				planDetailsRepository.saveEligibilityClasses(planEligibilityClasslist);
			} else {
				planDetailsClass.setMinHrsReqd(planDetailsAggregator.getPlanEligibility().getMinHrsRequired());
				planDetailsRepository.updatePlanDetails(planDetailsClass);
			}
			planDetailsAggregator.setListOfPlanField((savePlanDetails(planDetailsAggregator)).getListOfPlanField());
		}
		//calling getAllPlanDetails for the latest data
       // planDetailsAggregator = getAllPlanDetails(planDetailsAggregator);
		
		this.validateRatingDetails(planDetailsAggregator.getProposalVersionId(),planDetailsAggregator.getPlanId());
		return planDetailsAggregator;
	}
		
	/**
	 * Method to save the plan details to database
	 * @param plandetails
	 * @throws Exception
	 */
	@Override
	public PlanDetailsAggregator savePlanDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception{
		/*PlanDetailsRepositoryImpl planDetailsRepository = new PlanDetailsRepositoryImpl();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();*/
		
		if(StringUtils.isBlank(planDetailsAggregator.getProposalId()) || planDetailsAggregator.getProposalVersionId() <= 0 || planDetailsAggregator.getPlanId() <= 0 || planDetailsAggregator.getProdCode() <= 0){
			throw new ValidationException("Save Plan Request Invalid");
		}
		PlanDetailsClass existingPlanObject = planDetailsRepository.getPlanDetails(planDetailsAggregator.getPlanId());
		if(null != existingPlanObject){
			existingPlanObject = planDetailsServiceProcessor.convertToPlanDetailsClass(existingPlanObject, planDetailsAggregator.getListOfPlanField());
			existingPlanObject = planDetailsRepository.updatePlanDetails(existingPlanObject);
		}
		planDetailsAggregator.setListOfPlanField(planDetailsServiceProcessor.mergePlanMetaDataLists(planDetailsAggregator.getListOfPlanField(), 
				planDetailsServiceProcessor.convertPlanDetailsToFieldList(existingPlanObject)));
		
		
		//set overridden flag values for all overridden fields to 'Y'
		Map<String, PlanMetadata> defaultMetadataMap = PlanConfigUtil.setOverriddenFlagToY(planDetailsServiceProcessor.convertToPlanMap(planDetailsAggregator.getListOfPlanField()));
		List<PlanMetadata> metadataList = new ArrayList<PlanMetadata>(defaultMetadataMap.values());
		planDetailsAggregator.setListOfPlanField(metadataList);
		
		//calling getAllPlanDetails for the latest data
       // planDetailsAggregator = getAllPlanDetails(planDetailsAggregator);
		
		this.validateRatingDetails(planDetailsAggregator.getProposalVersionId(),planDetailsAggregator.getPlanId());
		return planDetailsAggregator;
	}
	
	//call this method from all 4 plan screens save logic.
	private void validateRatingDetails(int versionNumber,int planId) {
		String versionStatus = ratingQuoteDAO.getVersionStatus(versionNumber);
		if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(versionStatus),ProposalConstants.VERSION_STATUS_ACCEPTED)) {
			//version is already rated - delete existing rating engine records from the database
			List<RatingExhibits> ratingExhibits = ratingQuoteDAO.getAllPlanRatingEngineResults(planId);
			if (CollectionUtils.isNotEmpty(ratingExhibits)) {
				for (RatingExhibits ratingEntity : ratingExhibits) {
					ratingQuoteDAO.deleteRatingResults(ratingEntity);
				}
			}
			ratingQuoteDAO.updateVersionStatus(versionNumber,ProposalConstants.VERSION_STATUS_PENDING);
		}
	}

	@Override
	public PlanDetailsAggregator fetchExistPlanDtlFrmDB(
			PlanDetailsAggregator planData) throws Exception {
		//--
		/*PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();*/
		//----
		String sicCode = planData.getSicCode();
		int totalLives = 0;
		if (planData.getSelectedCensusId() > 0) {
			totalLives = planDetailsRepository.getCensusTotalLives(planData.getSelectedCensusId());
		}
		
		//PlanDetailsClass planDtlCls= new PlanDetailsClass();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		/*****************  Fetch MetaData Object******************** */
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		/*****************  Fetch Existing Plan Details From DB******************** */
		//planDtlCls = planDetailsRepository.fetchExistingPlanDetails(planData.getPlanId());
		planData = getAllPlanDetails(planData);
		// Apply default value from DB to MetaData Object
		//List<PlanMetadata> planFieldsList = planDetailsServiceProcessor.convertPlanDetailsToFieldList(planDtlCls);
		List<PlanMetadata> planFieldsList = planData.getListOfPlanField();
		if(CollectionUtils.isNotEmpty(planFieldsList)){
			planMetadataList = planDetailsServiceProcessor.mergePlanMetaDataLists(planMetadataList, planFieldsList);
		}
		/*****************  Fetch Lookup  Reference Data from DB******************** */
		List<PlanConfigLookup> planLookupList = mainService.getPlanLookupList();
		/*****************  Merging Existing Plan Details  and lookup Ref. Data ******************** */
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, planLookupList);
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		// Commented for Existing Scenario, need to check later....!
		
		PlanMetadata planContractState = planMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE);
		planContractState.setAltValues(mainService.getPlanContractState(planContractState.getFieldValue()));
		planMap.put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE, planContractState); 
		planMap = planHelper.onChangePlanDetailsFieldsForDisplay(planMap,sicCode,totalLives);
		//commenting the filterVisibleRecords() method call as filtering will be handled at UI side
		//planMap = planDetailsServiceProcessor.filterVisibleRecords(planMap);
		planMetadataList = new ArrayList<PlanMetadata>(planMap.values());
		for (PlanMetadata planMetadata : planMetadataList) {
			if(StringUtils.isNotBlank(planMetadata.getFieldValue()) && StringUtils.equalsIgnoreCase("null", planMetadata.getFieldValue())){
				planMetadata.setFieldValue(null);
			}
			
		}
		//set overridden flag values for all overridden fields to 'Y'
		Map<String, PlanMetadata> defaultMetadataMap = PlanConfigUtil.setOverriddenFlagToY(planDetailsServiceProcessor.convertToPlanMap(planMetadataList));
		List<PlanMetadata> metadataList = new ArrayList<PlanMetadata>(defaultMetadataMap.values());
		planData.setListOfPlanField(metadataList);
		return planData;
	}
}
