package com.pru.sparc.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.Holding;
import com.pru.sparc.bo.model.LookupInfo;
import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.bo.model.ProposalVersion;
import com.pru.sparc.bo.model.Quotation;
import com.pru.sparc.dao.ProducerRepository;
import com.pru.sparc.dao.QuotationDao;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.ProductDetails;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.QuotationDetails;
import com.pru.sparc.processor.ProposalDetailsAdapter;
import com.pru.sparc.processor.ProposalDetailsRequestHelper;
import com.pru.sparc.processor.QuotationServiceProcessor;
import com.pru.sparc.service.MainService;
import com.pru.sparc.service.QuotationService;

@Service("quotationService")
public class QuotationServiceImpl implements QuotationService {

	@Autowired
	QuotationServiceProcessor quotationServiceProcessor;
	
	@Autowired
	private ProposalDetailsAdapter proposalDetailsAdapter;
	
	@Autowired
	protected ProposalDetailsRequestHelper proposalDetailsRequestHelper;
	
	@Autowired
	private QuotationDao quotationDao;
	
	@Autowired
	private MainService mainService;
	
	@Autowired
	private ProducerRepository brokerDao;
	
	@Override
	public Quotation createNewQuotation(final Proposal proposal) throws Exception {
		quotationServiceProcessor.processNewQuotationrequest(proposal);
		Map<String, String> searchRequestMap = quotationServiceProcessor.mapToNewQuotationRequestMap(proposal);
		ProposalDetails proposalRequestObject = quotationDao.getProposalDetails(searchRequestMap);
		int versionCount = quotationDao.getProposalVersionsCount(searchRequestMap);
		QuotationDetails quotationDetails = proposalDetailsRequestHelper.mapToCreateNewQuotationRequestObject(proposal,proposalRequestObject,versionCount);
		quotationDetails = quotationDao.createNewQuotation(quotationDetails);
		List<CensusDetail> censusDetailList = quotationDao.getCensusList(proposal.getClientId());
		List<ProductDetails> productDetailList = quotationDao.getProductList();
		LookupInfo lookupInfo = quotationServiceProcessor.createLookupObject();
		List<LookupInfo> lookupList = mainService.getLookupList(lookupInfo);
		Quotation quotation = proposalDetailsAdapter.parseQuotationResponse(quotationDetails,censusDetailList,productDetailList,lookupList);
		quotation.setDisplayVersionNo(versionCount+1);
		return quotation;
	}

	@Override
	public Quotation saveQuotation(Quotation quotation) throws Exception {
		//change: insert in plan
		quotationServiceProcessor.processSaveQuotationrequest(quotation);
		List<CensusDetail> selectedCensusList = new ArrayList<CensusDetail>();
		if (quotation.getSelectedCensus() != null) {
			selectedCensusList = quotationDao.getSelectedCensus(quotation.getSelectedCensus());
		}
		List<ProductDetails> productDetaiList = new ArrayList<ProductDetails>();
		if (CollectionUtils.isNotEmpty(quotation.getSelectedQuoteProducts())) {
			productDetaiList = quotationDao.getSelectedProducts(quotation.getSelectedQuoteProducts());
		}
		QuotationDetails quotationDetails = quotationDao.getQuotationDetails(quotation.getProposalId(),quotation.getVersionNumber());
		quotationDetails = proposalDetailsRequestHelper.createSaveQuotationRequest(quotation,selectedCensusList,quotationDetails,productDetaiList);
		quotationDao.saveQuotation(quotationDetails);
		return quotation;
	}

	@Override
	public List<ProposalVersion> getProposalVersions(Proposal proposal) throws Exception {
		quotationServiceProcessor.processgetProposalVersionsrequest(proposal);
		Map<String, String> searchRequestMap = quotationServiceProcessor.mapToNewQuotationRequestMap(proposal);
		Set<QuotationDetails> quotationDetailsSet = quotationDao.getProposalVersions(searchRequestMap);
		List<ProposalVersion> versionList = proposalDetailsAdapter.parseProposalVersions(quotationDetailsSet);
		return versionList;
	}

	@Override
	public Quotation getVersionDetails(Quotation quotation) throws Exception {
		quotationServiceProcessor.getVersionDetails(quotation);
		QuotationDetails quotationDetails = quotationDao.getQuotationDetails(quotation.getProposalId(),quotation.getVersionNumber());
		List<CensusDetail> CensusDetailList = quotationDao.getCensusList(quotation.getClientId());
		List<ProductDetails> productDetailList = quotationDao.getProductList();
		LookupInfo lookupInfo = quotationServiceProcessor.createLookupObject();
		List<LookupInfo> lookupList = mainService.getLookupList(lookupInfo);
		quotation = proposalDetailsAdapter.parseQuotationResponse(quotationDetails,CensusDetailList,productDetailList,lookupList);
		return quotation;
	}

	@Override
	public int getProposalVersionsCount(Proposal proposal) throws Exception {
		quotationServiceProcessor.getProposalVersionsCount(proposal);
		Map<String, String> searchRequestMap = quotationServiceProcessor.mapToNewQuotationRequestMap(proposal);
		int versionCount = quotationDao.getProposalVersionsCount(searchRequestMap);
		return versionCount;
	}

	

	@Override
	public void setVersionInSession(Map<String, String> versionMap) {
		Holding sessionHolding = mainService.getSessionHolding();
		sessionHolding.setVersionNumber(Integer.parseInt(versionMap.get("versionNumber")));
		sessionHolding.setProductId(Integer.parseInt(versionMap.get("productId")));
		mainService.updateSessionHolding(sessionHolding);
	}

	@Override
	public Commission updateCommission(Commission commission, boolean createNewFlag) throws Exception{
		if(!createNewFlag){
			quotationServiceProcessor.processUpdateCommissionrequest(commission);
		}
		Commission comm = null;
		ProposalBrokerDetails prBrokerDetails = quotationDao.getCommission(commission.getBrokerID(),commission.getProposalPlanID(), commission.getVersionNumber());
		QuotationDetails quotationDetails = quotationDao.getQuotationDetails(commission.getProposalPlanID(), commission.getVersionNumber());
		if(null != prBrokerDetails){
			prBrokerDetails = quotationServiceProcessor.createUpdateCommissionRequest(prBrokerDetails, commission, quotationDetails);
			prBrokerDetails.setProposalPlanInd(1);
			prBrokerDetails = quotationDao.updateCommission(prBrokerDetails);
			comm = proposalDetailsAdapter.parseCommissionResponse(prBrokerDetails);
			return comm;
		} else {
			prBrokerDetails = new ProposalBrokerDetails();
			prBrokerDetails.setProposalPlanInd(1);
			prBrokerDetails.setBrokerDetails(brokerDao.getProducerById(commission.getBrokerID()));
			prBrokerDetails.setProPlanId(commission.getProposalPlanID());
			prBrokerDetails.setVersionDetails(quotationDetails);
			prBrokerDetails = quotationDao.saveCommission(prBrokerDetails);
			comm = proposalDetailsAdapter.parseCommissionResponse(prBrokerDetails);
		}
		return comm;
	}

	@Override
	public Commission getCommission(Commission commission) throws Exception{
		ProposalBrokerDetails prBrokerDetails = quotationDao.getCommission(commission.getBrokerID(),commission.getProposalPlanID(), commission.getVersionNumber());
		if(null != prBrokerDetails){
			return proposalDetailsAdapter.parseCommissionResponse(prBrokerDetails);
		}
		return null;
	}
}
