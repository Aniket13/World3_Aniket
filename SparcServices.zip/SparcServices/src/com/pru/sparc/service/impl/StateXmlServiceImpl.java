package com.pru.sparc.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.StatesXml;
import com.pru.sparc.dao.StateXmlRepository;
import com.pru.sparc.model.StateXml;
import com.pru.sparc.processor.StateXmlServiceProcessor;
import com.pru.sparc.service.StateXmlService;
@Service("stateXmlService")
public class StateXmlServiceImpl implements StateXmlService{
	@Autowired
	private StateXmlServiceProcessor stateXmlServiceProcessor;
	@Autowired
	private StateXmlRepository stateXmlRepository;
	@Override
	public void addUpdateStates(StatesXml states) throws Exception {
			StateXml requestObject = stateXmlServiceProcessor.mapToStatesXml(states);
			StateXml statesResult = stateXmlRepository.addUpdateStates(requestObject);
			/*if(statesResult != null)
				return statesResult;*/
	}
	@Override
	public int getStatesId() throws Exception {
		return stateXmlRepository.getStateId();
	}
	
	
	

}
