package com.pru.sparc.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.ProposalVersionDetails;
import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.common.constants.ProposalConstants;
import com.pru.sparc.dao.PlanDetailsRepository;
import com.pru.sparc.dao.RatingQuoteDAO;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Comission;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.RuleRatingOutputModelWrapper;
import com.pru.sparc.drools.service.RatingDroolsService;
import com.pru.sparc.model.PlanDetailsClass;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.RatingExhibits;
import com.pru.sparc.processor.RatingDisplayProcessor;
import com.pru.sparc.processor.RatingExhibitAdapter;
import com.pru.sparc.processor.RatingExhibitHelper;
import com.pru.sparc.service.RatingDisplayService;

@Service("ratingDisplayService")
public class RatingDisplayServiceImpl implements RatingDisplayService {
	
	final Logger logger = LoggerFactory.getLogger("RatingDisplayServiceImpl.java");
	
	@Autowired
	@Qualifier("ratingDroolsService")
	private RatingDroolsService ratingDroolsService;
	
	@Autowired
	@Qualifier("ratingDisplayProcessor")
	private RatingDisplayProcessor ratingDisplayProcessor;
	
	@Autowired
	private RatingExhibitAdapter ratingExhibitAdapter;
	
	@Autowired
	private RatingExhibitHelper ratingExhibitHelper;
	
	@Autowired
	private RatingQuoteDAO ratingQuoteDAO;
	
	@Autowired
	private PlanDetailsRepository planDetailsRepository;
	
	@Override
	public List<RatingModel> invokeRatingEngine(int versionNumber) throws Exception {
		MDC.put("logFileName", "RE-"+versionNumber);
		MDC.put("VersionNo", ""+versionNumber);
		ratingDisplayProcessor.processInvokeRatingEngineRequest(versionNumber);
		/*//get the version status to decide the insert/delete on original/overridden row
		boolean iStatusOpened = false;
		String versionStatus = ratingQuoteDAO.getVersionStatus(versionNumber);
		if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(versionStatus),ProposalConstants.VERSION_STATUS_OPENED)) {
			iStatusOpened = true;
		}
		*/
		Holding holding = ratingExhibitHelper.createRatingInputData(versionNumber);
		
		logger.debug("**************DISPLAYING INPUT DATA START***********************");
		SparcRatingUtil.showMap(holding.getHoldingMap());
		List plans= (List)(holding.getListOfPlans());
		
		for(int i = 0; i < plans.size(); i++){
			holding.setCount(i);
			Plan plan = (Plan) (holding.getListOfPlans().get(holding.getCount()));
			
			logger.debug("**************DISPLAYING PLAN MAP START***********************");
			SparcRatingUtil.showMap(plan.getPlanMap());
			logger.debug("**************DISPLAYING PLAN MAP END***********************");
			
			logger.debug("**************DISPLAYING PLAN OVERRIDE START***********************");
			SparcRatingUtil.showMap(plan.getOverRideMap());
			logger.debug("**************DISPLAYING PLAN OVERRIDE END***********************");
			
			logger.debug("**************DISPLAYING CENSUS DATA START***********************");
			SparcRatingUtil.showMap(plan.getCensus().getCensusMap());
			logger.debug("**************DISPLAYING CENSUS DATA END***********************");
			
			/*List people= (plan.getCensus().getListOfPeople());
			for(int j=0;j<people.size();j++){
				holding.setPeopleCount(j);
				Person person=(Person) people.get(j);
				logger.debug("**************DISPLAYING PEOPLE DATA START***********************");
				SparcRatingUtil.showMap(person.getPeopleMap());
				logger.debug("**************DISPLAYING PEOPLE DATA END***********************");
			}*/
			
			
			List commissions = (List) (plan.getListOfComission());
			for (int j = 0; j < commissions.size(); j++) {
				plan.setCommisionCount(j);
				Comission commission = (Comission) (plan.getListOfComission().get(j));
				logger.debug("**************DISPLAYING COMMISSION DATA START***********************");
				SparcRatingUtil.showMap(commission.getCommissionMap());
				logger.debug("**************DISPLAYING COMMISSION DATA START***********************");
			}	
		}
		logger.debug("**************DISPLAYING INPUT DATA END***********************");
		
		
		List<RuleRatingOutputModelWrapper> responseList = ratingDroolsService.invokeRatingEngine(holding);
		
		//Holding holding = null;
		
		//method to create input parameters using mock data
		//List<RuleRatingOutputModelWrapper> responseList = ratingDroolsService.invokeRatingEngine(holding,versionNumber);
				
		List<RatingModel> modelList = new ArrayList<RatingModel>();
		for (RuleRatingOutputModelWrapper response : responseList) {
			int planId = response.getPlanId();
			
			/*if (iStatusOpened == true) {
				// delete existing records if plan fields are modified
				List<RatingExhibits> ratingExhibits = ratingQuoteDAO.getAllPlanRatingEngineResults(planId);
				if (CollectionUtils.isNotEmpty(ratingExhibits)) {
					for (RatingExhibits ratingEntity : ratingExhibits) {
						ratingQuoteDAO.deleteRatingResults(ratingEntity);
					}
				}
			}*/
			RatingExhibits ratingExhibitsRequestObject = null;
			if (response.isOverriddenPlanRating()) {
				//if overridden values are passed.
				ratingExhibitsRequestObject = ratingQuoteDAO.getPlanRatingDetails(planId,ProposalConstants.RATE_OVERRIDE);				
			} else {
				//original rating record
				ratingExhibitsRequestObject = ratingQuoteDAO.getPlanRatingDetails(planId,ProposalConstants.RATE_NON_OVERRIDE);
			}
			PlanDetailsClass plan = null;
			if (ratingExhibitsRequestObject == null) {
				plan = planDetailsRepository.getPlanDetails(planId);
			} else {
				plan = ratingExhibitsRequestObject.getPlan();
			}
			ratingExhibitsRequestObject = ratingExhibitHelper.mapToRatingResultObject(response,plan,ratingExhibitsRequestObject);
			ratingExhibitsRequestObject = ratingQuoteDAO.saveRatingEngineResults(ratingExhibitsRequestObject);
			RatingModel model = ratingExhibitAdapter.parseInvokeRatingResultResponse(ratingExhibitsRequestObject);
			ratingExhibitAdapter.updateVersionStatus(versionNumber, model.isRatingSuccessful(), false);
			modelList.add(model);
		}
		MDC.remove("logFileName");
		MDC.remove("VersionNo");
		return modelList;
	}

	@Override
	public RuleRatingOutputModelWrapper loadRatingData(RatingModel model) throws Exception {
		ratingDisplayProcessor.processLoadRatingDataRequest(model);
		RatingExhibits ratingExhibitsEntity = ratingQuoteDAO.getPlanRatingDetails(model.getPlanId(),ProposalConstants.RATE_NON_OVERRIDE);
		RuleRatingOutputModelWrapper wrapper = new RuleRatingOutputModelWrapper();
		if (ratingExhibitsEntity == null) {
			wrapper.setPlanRated(false);
			return wrapper;
		} else {
			String versionStatus = ratingQuoteDAO.getVersionStatus(model.getVersionNumber());
			if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(versionStatus),ProposalConstants.VERSION_STATUS_ACCEPTED)) {
				wrapper.setPlanReRatingPending(false);
			} else {
				wrapper.setPlanReRatingPending(true);
			}
			wrapper = ratingExhibitAdapter.parseRatingExhibitsResponse(ratingExhibitsEntity);
			return wrapper;
		}
	}
	
	@Override
	public ProposalVersionDetails getVersionPlanDetails(String proposalId) throws Exception {
		//RatingQuoteDaoImpl ratingQuoteDAO = new RatingQuoteDaoImpl();
		ProposalDetails proposalEntity = ratingQuoteDAO.getProposalDetails(proposalId);
		//RatingExhibitAdapter ratingExhibitAdapter = new RatingExhibitAdapter();
		ProposalVersionDetails proposalVersionDetails= ratingExhibitAdapter.parseVersionPlanDetails(proposalEntity);
		
		return proposalVersionDetails;
	}

	@Override
	public RuleRatingOutputModelWrapper saveOverrides(RatingModel model) throws Exception {
		ratingDisplayProcessor.processSaveOverridesRequest(model);
		RatingExhibits ratingExhibitsEntity = ratingQuoteDAO.getPlanRatingDetails(model.getPlanId(),ProposalConstants.RATE_NON_OVERRIDE);
		ratingExhibitsEntity = ratingExhibitHelper.createsaveOverridesRequestObject(ratingExhibitsEntity,model);
		ratingQuoteDAO.updateRatingEngineOverrides(ratingExhibitsEntity);
		RuleRatingOutputModelWrapper wrapper = ratingExhibitAdapter.parseRatingExhibitsResponse(ratingExhibitsEntity);
		//indicator for UI to re-rate the current plan
		wrapper.setPlanReRatingPending(true);
		//updated status to Pending Rate Calculation
		ratingExhibitAdapter.updateVersionStatus(model.getVersionNumber(), false, wrapper.isPlanReRatingPending());
		return wrapper;
	}

	@Override
	public RuleRatingOutputModelWrapper viewOriginalRates(RatingModel model) throws Exception {
		RatingExhibits ratingExhibitsEntity = ratingQuoteDAO.getPlanRatingDetails(model.getPlanId(),ProposalConstants.RATE_NON_OVERRIDE);
		RuleRatingOutputModelWrapper wrapper = ratingExhibitAdapter.parseRatingExhibitsResponse(ratingExhibitsEntity);
		return wrapper;
	}

	@Override
	public RuleRatingOutputModelWrapper viewOverrideRates(RatingModel model) throws Exception {
		//fetch overridden record
		RatingExhibits overridenRatingExhibitsEntity = ratingQuoteDAO.getPlanRatingDetails(model.getPlanId(),ProposalConstants.RATE_OVERRIDE);
		//fetch original record
		RatingExhibits originalratingExhibitsEntity = ratingQuoteDAO.getPlanRatingDetails(model.getPlanId(),ProposalConstants.RATE_NON_OVERRIDE);
		HashMap<String, String> overridenUIFields = ratingExhibitAdapter.getOverridenUIValuesInMap(originalratingExhibitsEntity);
		overridenRatingExhibitsEntity = ratingExhibitAdapter.setOverridenUIValuesInEntity(overridenRatingExhibitsEntity, overridenUIFields);
		RuleRatingOutputModelWrapper wrapper = ratingExhibitAdapter.parseRatingExhibitsResponse(overridenRatingExhibitsEntity);
		return wrapper;
	}
}
