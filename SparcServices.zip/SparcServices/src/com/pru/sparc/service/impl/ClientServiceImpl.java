package com.pru.sparc.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.Client;
import com.pru.sparc.bo.model.ClientSearchRequest;
import com.pru.sparc.bo.model.Holding;
import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.dao.ClientRepository;
import com.pru.sparc.dao.StateXmlRepository;
import com.pru.sparc.model.ClientClass;
import com.pru.sparc.model.ProposalDetails;
import com.pru.sparc.model.SIC;
import com.pru.sparc.model.StateXml;
import com.pru.sparc.model.StateXmlEmbeddable;
import com.pru.sparc.processor.ClientServiceProcessor;
import com.pru.sparc.processor.ProposalServiceProcessor;
import com.pru.sparc.processor.StateXmlServiceProcessor;
import com.pru.sparc.service.ClientService;
import com.pru.sparc.service.MainService;


//Service layer implementation of clients module
@Service("clientService")
public class ClientServiceImpl implements ClientService {

	//autowired reference of processor class
	@Autowired
	private ClientServiceProcessor clientServiceProcessor;
	
	//autowired reference of processor class
	@Autowired
	private ProposalServiceProcessor proposalServiceProcessor;
	
	//autowired reference of processor class
	@Autowired
	private StateXmlServiceProcessor stXmlServiceProcessor;
	
	//autowired reference to dao layer interface
	@Autowired
	private ClientRepository clientRepository;
	
	//autowired reference to dao layer interface
	@Autowired
	private StateXmlRepository stateXmlRepository;
	
	@Autowired
	private MainService mainService;
	
	/**
	 * To add new client to database
	 * @param Client
	 * @return Client
	 * @throws Exception Exception
	 */
	@Override
	public Client addClient(Client client) throws Exception {
		boolean isSicValid = validateSIC(client.getSic());
		if(clientServiceProcessor.isRequestValid(client, isSicValid))
		{
			ClientClass requestObject = clientServiceProcessor.mapToClientRequestObject(null, client);
			ClientClass clientResult = clientRepository.addClient(requestObject);
			if(clientResult != null){
				client.setClientId(clientResult.getClientId());
			}
				return client;
		}
		return null;
	}

	
	/**
	 * To search clinets based on selected search criterias
	 * @param ClientSearchRequest
	 * @return List<Client>
	 * @throws Exception Exception
	 */
	@Override
	public List<Client> searchClient(ClientSearchRequest clientSearchRequest) throws Exception {
		if(clientServiceProcessor.isSearchRequestValid(clientSearchRequest)){
			Map<String, String> searchRequestMap = clientServiceProcessor.mapToRequestMap(clientSearchRequest);
			List<ClientClass> clientList = clientRepository.searchClient(searchRequestMap);
			if(clientList != null){
				List<Client> resultClients = clientServiceProcessor.mapResultListToClientList(clientList);
				if(!resultClients.isEmpty()){
					return resultClients;
				}
			}
		}
		return null;
	}
	
	/**
	 * To generate client id for new client creation
	 * @param 
	 * @return int
	 * @throws Exception Exception
	 */
	@Override
	public int getClientId()throws Exception
	{
		return clientRepository.getClientId();
	}

	/**
	 * To generate client id for new client creation
	 * @param 
	 * @return int
	 * @throws Exception Exception
	 */
	@Override
	public Client editClient(Client client) throws Exception {
		boolean isSicValid = validateSIC(client.getSic());
		ClientClass existingClient = clientRepository.getClientById(client.getClientId());
		if(clientServiceProcessor.isRequestValid(clientServiceProcessor.mapResultToClient(existingClient),isSicValid)) {
			ClientClass requestObject = clientServiceProcessor.mapToClientRequestObject(existingClient,client);
			ClientClass clientResult = clientRepository.updateClient(requestObject);
			if(clientResult != null){
				return client;
			}
		}
		return null;
	}

	/**
	 * To get list of proposals associated with given client id 
	 * @param  int clientId
	 * @return List<Proposal>
	 * @throws Exception Exception
	 */
	@Override
	public List<Proposal> getProposalActivity(int clientId)  throws Exception{
		List<ProposalDetails> proposalList =  clientRepository.getAllProposalsForClient(clientId);
		List<Proposal> proposalInfoList =  new ArrayList<Proposal>();
		for (ProposalDetails proposalDetails : proposalList) {
			Proposal proposalInfo = proposalServiceProcessor.mapResultProposalToModel(proposalDetails);
			StateXml stateXmlObj = getStateXmlObject(proposalInfo.getProposalId());
			List<StateXml> stateXml = stateXmlRepository.getPrevStates(stateXmlObj);
			if(!CollectionUtils.isEmpty(stateXml)){
				proposalInfo.setStateXml(stXmlServiceProcessor.mapToStateXml(stateXml.get(0)));
			}
			proposalInfoList.add(proposalInfo);
		}
		return proposalInfoList;
	}

	/**
	 * Method to create StateXml object and set proposalId into it
	 * @param proposalId
	 * @return StateXml
	 */
	private StateXml getStateXmlObject(String proposalId) {
		StateXml stateXml = new StateXml();
		StateXmlEmbeddable stateEmb = new StateXmlEmbeddable();
		stateEmb.setProposalId(proposalId);
		stateXml.setStateXmlEmbeddable(stateEmb);
		return stateXml;
	}

	/**
	 *  Method to set Client object in session
	 * 	@param Client
	 * 	@throws Exception Exception
	 */
	@Override
	public void setClientInSession(Client client) throws Exception {
		Holding holding = mainService.getSessionHolding();
		holding.setClientId(client.getClientId());
		holding.setClientName(client.getClientName());
		holding.setContractState(client.getContractState());
		holding.setSic(client.getSic());
		mainService.updateSessionHolding(holding);
	}
	
	private boolean validateSIC(String sic){
		if(StringUtils.isNotBlank(sic)){
			List<SIC> validSICList = clientRepository.getValidSICCodes();
			if(CollectionUtils.isNotEmpty(validSICList)){
				for (SIC sicValue : validSICList) {
					if(StringUtils.equals(sic, sicValue.getSicNumber())){
						return true;
					}
				}
			}
		}
		return false;
	}


	@Override
	public Client loadClient(int clientId) throws Exception {
		if(clientId > 0){
			ClientClass clientClass = clientRepository.getClientById(clientId);
			if(null != clientClass){
				return clientServiceProcessor.mapResultToClient(clientClass);
			}
		}
		throw new Exception();
	}
}
