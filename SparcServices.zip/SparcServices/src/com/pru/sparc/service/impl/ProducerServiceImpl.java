package com.pru.sparc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.Holding;
import com.pru.sparc.bo.model.Producer;
import com.pru.sparc.dao.ProducerRepository;
import com.pru.sparc.model.BrokerDetails;
import com.pru.sparc.model.ProposalBrokerDetails;
import com.pru.sparc.processor.ProducerServiceProcessor;
import com.pru.sparc.service.MainService;
import com.pru.sparc.service.ProducerService;

@Service("producerService")
public class ProducerServiceImpl implements ProducerService {

	@Autowired
	private ProducerRepository producerRepository;
	
	@Autowired
	private ProducerServiceProcessor producerServiceProcessor;
	
	@Autowired
	private MainService mainService;
	
	@Override
	public List<Producer> getProducers() throws Exception {
		List<BrokerDetails> resultList = producerRepository.getProducers();
		setProducerInfoInSession(resultList.get(0));
		return producerServiceProcessor.mapToProducerModel(resultList);
	}
	
	private void setProducerInfoInSession(BrokerDetails producer){
		Holding holding = mainService.getSessionHolding();
		//if(holding != null && StringUtils.equalsIgnoreCase(holding.getClientId(), String.valueOf(proposal.getClientId()))) {
			holding.setProducerName(producer.getBrokerName());
			mainService.updateSessionHolding(holding);
		//} 
	}

	@Override
	public void setProposalCommission(Commission commission) throws Exception {
		if(commission.getBrokerID() > 0){
			BrokerDetails brokerDetails = producerRepository.getProducerById(commission.getBrokerID());
			ProposalBrokerDetails proposalBroker = producerServiceProcessor.mapToProposalBrokerDetails(commission,brokerDetails);
			producerRepository.saveProposalCommission(proposalBroker);
		}
	}

}
