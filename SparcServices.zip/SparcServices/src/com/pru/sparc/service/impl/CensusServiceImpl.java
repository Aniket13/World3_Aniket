package com.pru.sparc.service.impl;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pru.sparc.bo.model.Census;
import com.pru.sparc.bo.model.CensusAllocationLives;
import com.pru.sparc.bo.model.CensusCls;
import com.pru.sparc.dao.CensusDetailRepository;
import com.pru.sparc.model.CensusClass;
import com.pru.sparc.model.CensusDetail;
import com.pru.sparc.model.CensusLvsAlloc;
import com.pru.sparc.processor.CensusServiceProcessor;
import com.pru.sparc.service.CensusService;

@Service("censusService")
public class CensusServiceImpl implements CensusService {

	private static final Logger SPARCLOGGER = Logger.getLogger(CensusServiceImpl.class);
	
	@Autowired
	private CensusServiceProcessor censusServiceProcessor;
	
	@Autowired
	private CensusDetailRepository censusDtlRepository;
	
	
	@Override
	public void updateCensusDetail(Census census) throws Exception {
		SPARCLOGGER.debug("Start of CensusServiceImpl().updateCensusDetail().....!");
		CensusDetail existingCensusDtl = censusDtlRepository.getCensusDetailById(census.getCensus_id());
		CensusDetail updateObject = censusServiceProcessor.mapToCensusDetailRequestObject(existingCensusDtl,census);
		CensusDetail censusResult = censusDtlRepository.update(updateObject);
		if(censusResult != null){
			Census cen = censusServiceProcessor.mapToCensus(censusResult);
			//return cen;
		}
	//	return null;
		SPARCLOGGER.debug("End of CensusServiceImpl().updateCensusDetail().....!");
	}


	@Override
	public Census getCensusDetail(Census census) throws Exception {
		SPARCLOGGER.debug("End of CensusServiceImpl().getCensusDetail().....!");
		return null;
	}

	@Override
	public List<Census> getCensusDetail(int clientId) throws Exception {
		SPARCLOGGER.debug("End of CensusServiceImpl().getCensusDetail().....!");
			List<CensusDetail> censusDtlList = censusDtlRepository.getCensusDetail(clientId);
			if (CollectionUtils.isNotEmpty(censusDtlList)) {
				List<Census> resultCensusDtl = censusServiceProcessor.mapResultToCensus(censusDtlList);
				if(!resultCensusDtl.isEmpty()) {
					return resultCensusDtl;
				}
			}
			SPARCLOGGER.debug("End of CensusServiceImpl().getCensusDetail().....!");
		return null;
	}

	@Override
	public void addCensusClass(List<CensusCls> censuscls) throws Exception {
			SPARCLOGGER.debug("End of CensusServiceImpl().addCensusClass().....!");
			List<CensusClass> requestObject = censusServiceProcessor.mapToCensusClass(censuscls);
			List<CensusClass> censusResult = censusDtlRepository.addCensusClasses(requestObject);
			SPARCLOGGER.debug("End of CensusServiceImpl().addCensusClass().....!");
			/*if(censusResult != null)
				return censusResult;*/
	}
	
	@Override
	public List<CensusCls> getCensusClass(CensusCls censuscls) throws Exception {
			SPARCLOGGER.debug("End of CensusServiceImpl().getCensusClass().....!");
			CensusClass requestObject = censusServiceProcessor.mapToCensusClass(censuscls);
			List<CensusClass> censusResult = censusDtlRepository.getCensusClasses(requestObject);
			List<CensusCls> responseObject = censusServiceProcessor.mapToCensusCls_Bl(censusResult,censuscls);
			if(responseObject != null)
				return responseObject;
			return null;
	}
	
	/**
	 * Method to get the census allocation of lives details
	 * @param censusId
	 * @return List<CensusAllocationLives>
	 */
	@Override
	public List<CensusAllocationLives> getCensusAllocationLives(String censusId)throws Exception {
		SPARCLOGGER.debug("End of CensusServiceImpl().getCensusAllocationLives().....!");
		final List<CensusLvsAlloc> censusLvsAllocs = censusDtlRepository.getCensusLiveAlloc(censusId);
		return censusServiceProcessor.mapToCensusAllocation(censusLvsAllocs);
	}
	
	/**
	 * Method to save the census allocation of lives details
	 * @param allocationLives
	 * 
	 */
	@Override
	public void saveCensusAllocation(List<CensusAllocationLives> allocationLives)throws Exception {
		SPARCLOGGER.debug("End of CensusServiceImpl().saveCensusAllocation().....!");
		final List<CensusLvsAlloc> censusLvcAlocList = new ArrayList<CensusLvsAlloc>();
		for (CensusAllocationLives censusAllocationLives : allocationLives) {
			CensusLvsAlloc cenAlloc = censusDtlRepository.getCensusLiveAllocByCensusState(censusAllocationLives.getCenState(), censusAllocationLives.getCensusId());
			if(null == cenAlloc){
				cenAlloc = new CensusLvsAlloc();
				cenAlloc.setCensusDetail(censusDtlRepository.getCensusDetailById(censusAllocationLives.getCensusId()));
			}
			cenAlloc = censusServiceProcessor.mapToCensusLvsAlloc(cenAlloc, censusAllocationLives);
			censusLvcAlocList.add(cenAlloc);
		}
		
		//final List<CensusLvsAlloc> censusLvcAlocList = censusServiceProcessor.mapToCensusAllocEntity(allocationLives);
		censusDtlRepository.addCensusLiveAlloc(censusLvcAlocList);
		SPARCLOGGER.debug("End of CensusServiceImpl().saveCensusAllocation().....!");
	}

	/**
	 * Method to delete the census allocation of lives details
	 * @param cLives
	 * 
	 */
	@Override
	public void deleteCensusAllocation(CensusAllocationLives cLives)throws Exception{
		SPARCLOGGER.debug("End of CensusServiceImpl().deleteCensusAllocation().....!");
		CensusLvsAlloc cenAlloc = censusDtlRepository.getCensusLiveAllocByCensusState(cLives.getCenState(), cLives.getCensusId());
		censusServiceProcessor.mapToCensusLvsAlloc(cenAlloc, cLives);
		censusDtlRepository.deleteCensusLiveAlloc(cenAlloc);
		SPARCLOGGER.debug("End of CensusServiceImpl().deleteCensusAllocation().....!");
	}
}
