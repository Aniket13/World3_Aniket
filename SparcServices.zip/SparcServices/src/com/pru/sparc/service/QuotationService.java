package com.pru.sparc.service;

import java.util.List;
import java.util.Map;

import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.bo.model.ProposalVersion;
import com.pru.sparc.bo.model.Quotation;

public interface QuotationService {
	
	/**
	 * @param proposal
	 * @return
	 * @throws Exception 
	 */
	List<ProposalVersion> getProposalVersions(Proposal proposal) throws Exception;
	/**
	 * @param proposal
	 * @return
	 * @throws Exception 
	 */
	Quotation createNewQuotation(Proposal proposal) throws Exception;
	/**
	 * @param quotation
	 * @return
	 * @throws Exception 
	 */
	Quotation saveQuotation(Quotation quotation) throws Exception;
	/**
	 * @param quotation
	 * @return
	 * @throws Exception 
	 */
	Quotation getVersionDetails(Quotation quotation) throws Exception;
	/**
	 * @param proposal
	 * @return
	 * @throws Exception 
	 */
	int getProposalVersionsCount(Proposal proposal) throws Exception;
	
	/**
	 * @param versionMap
	 */
	void setVersionInSession(Map<String, String> versionMap);
	/**
	 * @param Commission
	 * @return Commission
	 * @throws Exception 
	 */
	Commission updateCommission(Commission commission, boolean createNewFlag) throws Exception;
	/**
	 * @param Commission
	 * @return Commission
	 * @throws Exception 
	 */
	Commission getCommission(Commission commission) throws Exception;
}
