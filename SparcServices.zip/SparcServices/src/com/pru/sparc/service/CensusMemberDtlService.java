package com.pru.sparc.service;

import java.util.List;

import com.pru.sparc.bo.model.CensusMemberDtl;
import com.pru.sparc.drools.model.Holding;

public interface CensusMemberDtlService {
	public void updateCensusMember(CensusMemberDtl model)throws Exception;
	public List<CensusMemberDtl> getCensusMembers(int censusId)throws Exception;
	public CensusMemberDtl getCensusFieldVal(CensusMemberDtl census)throws Exception;
	public Holding getholdingVal(int versionId) throws Exception;
}
