package com.pru.sparc.service;
import java.util.List;

import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.bo.model.ProposalVersionDetails;
import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.drools.model.RuleRatingOutputModelWrapper;

public interface RatingDisplayService {
	public  List<RatingModel> invokeRatingEngine(int versionNumber) throws Exception;
	public RuleRatingOutputModelWrapper loadRatingData(RatingModel model) throws Exception;
	public ProposalVersionDetails getVersionPlanDetails(String proposalId) throws Exception;
	public RuleRatingOutputModelWrapper saveOverrides(RatingModel model) throws Exception;
	public RuleRatingOutputModelWrapper viewOriginalRates(RatingModel model) throws Exception;
	public RuleRatingOutputModelWrapper viewOverrideRates(RatingModel model) throws Exception;
}
