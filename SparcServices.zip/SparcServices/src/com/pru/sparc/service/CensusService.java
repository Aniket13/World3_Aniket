package com.pru.sparc.service;

import java.util.List;

import com.pru.sparc.bo.model.Census;
import com.pru.sparc.bo.model.CensusAllocationLives;
import com.pru.sparc.bo.model.CensusCls;


public interface CensusService {

	void updateCensusDetail(Census census) throws Exception;
	Census getCensusDetail(Census censusDtlRequest)
			throws Exception;
	List<Census> getCensusDetail(int clientId) throws Exception;
	void addCensusClass(List<CensusCls> census) throws Exception;
	List<CensusCls> getCensusClass(CensusCls census) throws Exception;
	//void updateCensusClass(List<CensusCls> census) throws Exception;
	/**
	 * 
	 * @param censusId
	 * @return List<CensusAllocationLives>
	 */
	List<CensusAllocationLives> getCensusAllocationLives(String censusId)throws Exception ;
	/**
	 * 
	 * @param censusAllocationLives
	 */
	void saveCensusAllocation(List<CensusAllocationLives> allocationLives)throws Exception ;
	/**
	 * 
	 * @param cLives
	 */
	void deleteCensusAllocation(CensusAllocationLives cLives)throws Exception ;
}
