package com.pru.sparc.service;

import com.pru.sparc.bo.model.PrudentialContact;


public interface PrudentialContactService {
	public void savePrudentialContact(PrudentialContact model) throws Exception;
	public PrudentialContact getPrudentialContactValues(PrudentialContact model) throws Exception;
}
