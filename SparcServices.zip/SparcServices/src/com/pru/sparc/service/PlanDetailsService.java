package com.pru.sparc.service;

import java.util.List;

import com.pru.sparc.bo.model.PlanDetailsAggregator;

public interface PlanDetailsService {
	public PlanDetailsAggregator overridePlanDetails(PlanDetailsAggregator planDetailsAggregator)  throws Exception;
	/*public List<PlanDetailsWrapper> getAllPlans(int versionId);
	public PlanDetailsWrapper getPlan(int planId);*/
	
	public PlanDetailsAggregator savePlanCommission(PlanDetailsAggregator planDetailsAggregator) throws Exception;
	public PlanDetailsAggregator getPlanCommissionDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception;
	public PlanDetailsAggregator saveEligibilityDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception;
	public PlanDetailsAggregator getEligibilityDetails(PlanDetailsAggregator planDetailsAggregatory) throws Exception;
	public PlanDetailsAggregator getOverriddenPlanDetails(PlanDetailsAggregator planFieldDetails) throws Exception;
	public PlanDetailsAggregator loadPlanDetails(PlanDetailsAggregator planData) throws Exception;
	public PlanDetailsAggregator savePlanDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception;
	public PlanDetailsAggregator createNewPlan(PlanDetailsAggregator planDetailsAggregator) throws Exception;
	public List<PlanDetailsAggregator> getVersionPlans(PlanDetailsAggregator planDetailsAggregator) throws Exception;
	public PlanDetailsAggregator getAllPlanDetails(PlanDetailsAggregator planDetailsAggregator) throws Exception;
	public PlanDetailsAggregator onChangePlanDetails(PlanDetailsAggregator planData);
	public PlanDetailsAggregator fetchExistPlanDtlFrmDB(PlanDetailsAggregator planData) throws Exception;
}
