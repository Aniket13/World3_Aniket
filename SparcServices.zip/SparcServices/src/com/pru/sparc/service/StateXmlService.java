package com.pru.sparc.service;

import com.pru.sparc.bo.model.StatesXml;

public interface StateXmlService {
	public void addUpdateStates(StatesXml states) throws Exception;
	public int getStatesId() throws Exception;
}
