package com.pru.sparc.service;

import com.pru.sparc.bo.model.Client;
import com.pru.sparc.bo.model.Proposal;

public interface ProposalInformationService  {
	public void saveBasicInformation(Proposal model) throws Exception;
	public String createProposalId() throws Exception;
	public Proposal getHeaderDetails(Proposal proposal);
	public Client getClientDetailsFromSession(int clientId) throws Exception;
	public Proposal createNewProposal(Client client) throws Exception;
	public Proposal getProposalDetails(String proposalId) throws Exception;
}
