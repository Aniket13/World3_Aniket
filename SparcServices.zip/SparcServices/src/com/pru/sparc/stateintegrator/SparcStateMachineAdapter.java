package com.pru.sparc.stateintegrator;

import java.util.ArrayList;
import java.util.List;

import com.pru.sparc.bo.statexml.StateMacDetails;
import com.pru.sparc.dao.ClientRepository;
import com.pru.sparc.dao.StateXmlRepository;
import com.pru.sparc.model.StateXml;
import com.pru.sparc.processor.ClientServiceProcessor;
import com.pru.sparc.processor.StateXmlServiceProcessor;
import com.pru.sparc.statexml.SparcStateMachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("sparcStateMachineService")
public class SparcStateMachineAdapter {

	@Autowired
	private StateXmlRepository stateXmlRepository;
	
	@Autowired
	private StateXmlServiceProcessor stateXmlServiceProcessor;
		
	public String checkStateByEvent(String fireEvent) throws Exception{
		SparcStateMachine sparcStateServ = new SparcStateMachine();
		String targetState= null;
		try {
			List<String> eventList = new ArrayList<String>();
			// Invokes state machine here state machine will be saved to initial
			// state.
			System.out.println("sparcStMachine.getCurrentState()"
					+ sparcStateServ.getCurrentState());
			eventList = sparcStateServ.getTransitionEventList();
			if(eventList.contains(fireEvent)){ // Check if the invoking event is listed in state machine or not
			sparcStateServ.trigger(fireEvent);
			System.out.println("sparcStMachine.getCurrentState() After Event firing="
					+ sparcStateServ.getCurrentState());
			targetState = sparcStateServ.getCurrentState();
				return targetState;
			}else{
				System.out.println(" This Event is not listed in State Machine="+fireEvent);
				return null;
			}
		} catch (Exception e) {
			System.out.println("Error occured" + e.getMessage());
			return null;
		}
		
	}
	public boolean persistStateInfo(/*StateMacDetails stateMacDetl*/String state,String propId) throws Exception{
		 int stateIdCount= stateXmlRepository.getStateId();
		 int idCount = (stateIdCount > 0 ? stateIdCount+1 : 1 );
		StateXml stateXml = stateXmlServiceProcessor.mapToStateXml(state,propId,"","",idCount,"Bhagabat");
		StateXml stXml = stateXmlRepository.addUpdateStates(stateXml);
		if(null!=stXml)
			return true;
		return false;
		
	}
	public StateXml getPersistStateInfo(String state,String propId) throws Exception{
		StateXml stateXml = stateXmlServiceProcessor.mapToStatesXml(state,propId);
		StateXml stXml = stateXmlRepository.getStates(stateXml);
		if(null!=stXml)
			return stXml;
		return null;
		
	}
}
