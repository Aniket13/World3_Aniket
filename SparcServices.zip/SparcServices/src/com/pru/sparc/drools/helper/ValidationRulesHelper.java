package com.pru.sparc.drools.helper;

import java.util.ArrayList;
import java.util.List;

import com.pru.sparc.bo.model.ErrorDescription;
import com.pru.sparc.bo.model.ErrorDetails;
import com.pru.sparc.bo.model.ValidationWrapper;
import com.pru.sparc.common.util.DroolsPropertyRead;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ValidationRulesHelper {
	Properties prop = new Properties();

	public List<ErrorDetails> mapErrorsToScreens(ValidationWrapper vw) {
		 List<ErrorDescription> listOfErrors = vw.getErrorList();
		List<ErrorDetails> detailedErrorList = new ArrayList();

		for (ErrorDescription ed : listOfErrors) {
			ErrorDetails errorDetails = new ErrorDetails();
			String errorId = ed.getId();
			String screenName = mapFeildIdToScreenName(errorId);
			errorDetails.setScreenName(screenName);
			errorDetails.setFeildId(ed.getId());
			errorDetails.setDescription(ed.getDescription());
			detailedErrorList.add(errorDetails);
		}
		return detailedErrorList;

	}

	public String mapFeildIdToScreenName(String errorId) {
		//PropertyRead();
		DroolsPropertyRead  PropertyRead = new DroolsPropertyRead("screenNameMapping.properties");
		return (PropertyRead.getPropertyValue(errorId));

	}

	public void PropertyRead() {

		InputStream input = null;
		try {
			String filename = "screenNameMapping.properties";
			input = getClass().getResourceAsStream(
					"/com/pru/sparc/resources/screenNameMapping.properties");

			prop.load(input);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		} finally {

			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

	}
}
