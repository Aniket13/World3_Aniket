package com.pru.sparc.drools.helper;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;


import org.apache.log4j.Logger;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.drools.helper.RuleUtility;

public class Testutil {

	
	//final static Logger logger = LoggerFactory.getLogger(Testutil.class);
	final static Logger logger = Logger.getLogger(Testutil.class);
	public static Map<String, PlanMetadata> differenece(
			Map<String, PlanMetadata> map, Map<String, PlanMetadata> map1) {

		Map<String, PlanMetadata> diffBefore = new LinkedHashMap<String, PlanMetadata>();
		Map<String, PlanMetadata> diffAfter = new LinkedHashMap<String, PlanMetadata>();
		Map diff =new HashMap();
		for (Entry<String, PlanMetadata> entry : map.entrySet()) {
			for (Entry<String, PlanMetadata> entry1 : map1.entrySet()) {
				if (null != entry.getKey() && null != entry1.getKey()) {
					if (entry.getKey().equals(entry1.getKey())) {
						if (!entry.getValue().equals(entry1.getValue())) {
							diffAfter.put(entry1.getKey(), entry1.getValue());
							diffBefore.put(entry.getKey(), entry.getValue());
						}
					}

				}
			}
		}

		diff.put("before",diffBefore);
		diff.put("after",diffAfter);
		return diff;

	}

	public static void invokeRules(String fileName, String agenda, String seq,
			PlanDetailsMap plan) {

		HashMap <String, PlanMetadata>before =new HashMap<String, PlanMetadata>();
		for(Entry<String, PlanMetadata> entry : plan.getPlanMap().entrySet())
			before.put(entry.getKey(),PlanMetadata.createCopy(entry.getValue()));
		
		//before1=(HashMap<String, PlanMetadata>) before.clone();
		PlanDetailsMap planReturn =new PlanDetailsMap();
		// RuleUtility.showMap(plan.getPlanMap());
		logger.debug("Agenda  :" + agenda + "File " + fileName + "Rule seq "
				+ seq);
		Object[] obj = (Object[]) RuleUtility.getInitsData("DT", fileName,
				agenda, new Object[] { plan });
		planReturn = (PlanDetailsMap) obj[0];

		Map <String, PlanMetadata> after = planReturn.getPlanMap();
	
		Map diff = differenece(before, after);
		Map beforeMap=(Map) diff.get("before");
		Map afterMap=(Map) diff.get("after");
		if(beforeMap.isEmpty() && afterMap.isEmpty())
		logger.debug("No difference");
		else{
			logger.debug("Found difference...");
			logger.debug("printing before values...");
			RuleUtility.showMap(beforeMap);
			logger.debug("printing after rule update values...");
			RuleUtility.showMap(afterMap);
		}
		
	}

}
