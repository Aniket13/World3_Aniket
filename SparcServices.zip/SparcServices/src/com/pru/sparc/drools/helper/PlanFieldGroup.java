package com.pru.sparc.drools.helper;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class PlanFieldGroup {
	private String id;
	private String description;
	private boolean isOverRidden;
	private String fieldType;
	//private String presentValue;
	//private String defaultValue;
	private String required;
	private String state;
	private List<PlanFieldAllValues> fieldAllVal = new ArrayList<PlanFieldAllValues>();
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public boolean isOverRidden() {
		return isOverRidden;
	}
	public void setOverRidden(boolean isOverRidden) {
		this.isOverRidden = isOverRidden;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
/*	public String getPresentValue() {
		return presentValue;
	}
	public void setPresentValue(String presentValue) {
		this.presentValue = presentValue;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}*/
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@XmlElement(name="PART")  
	public List<PlanFieldAllValues> getFieldAllVal() {
		return fieldAllVal;
	}
	public void setFieldAllVal(List<PlanFieldAllValues> fieldAllVal) {
		this.fieldAllVal = fieldAllVal;
	}
	public String getRequired() {
		return required;
	}
	public void setRequired(String required) {
		this.required = required;
	}
	
}
