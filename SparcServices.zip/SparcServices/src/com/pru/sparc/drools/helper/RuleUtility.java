package com.pru.sparc.drools.helper;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderConfiguration;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.apache.log4j.Logger;

import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigDynaCacheUtil;

public class RuleUtility {

	public static String DRL = "DRL";
	public static String DT = "DT";
	// public static String EXECUTION_MODE = "Standalone"; // for local
		// standalone
	//public static String EXECUTION_MODE = "web"; // for webApplication
	private static HashMap cache;

	static {
		cache = new HashMap();
	}

	//final static Logger logger = LoggerFactory.getLogger(RuleUtility.class);

	 final static Logger logger = Logger.getLogger(RuleUtility.class);

	public static Object getInitData(String fileType, String fileName,
			String agendaGp, Object obj) {
		String executionMode= System.getProperty("web");
		String[] loadFile = { fileName };
		try {
			long start = System.nanoTime();
			StatefulKnowledgeSession kSession;
			KnowledgeBase kbase;
			String key = fileType + fileName;
			if (executionMode.equalsIgnoreCase("web")) {
			//if (!EXECUTION_MODE.equalsIgnoreCase("Standalone")) {
				PlanConfigDynaCacheUtil plnDynaCacheUtil = new PlanConfigDynaCacheUtil();
				if (plnDynaCacheUtil.getValue(key) == null) {
					/*logger.debug(
							"Did not find the file {} in cache,hence putting in cache",
							key);*/
					logger.debug(
							"Did not find the file {} in cache,hence putting in cache"+
							key);
					kbase = readKnowledgeBase(loadFile, fileType);
					kbase.newStatefulKnowledgeSession();
					plnDynaCacheUtil.putValue(key, kbase);
				} else {
					logger.debug("Found the file {} in cache"+key);
					kbase = (KnowledgeBase) plnDynaCacheUtil.getValue(key);
				}
			} else {
				if (cache.get(key) == null) {
					logger.debug(
							"Did not find the file {} in cache,hence putting in cache" +key);
					kbase = readKnowledgeBase(loadFile, fileType); // kSession
					kbase.newStatefulKnowledgeSession();
					cache.put(key, kbase);
				} else {
					logger.debug("Found the file {} in cache" + key);
					kbase = (KnowledgeBase) cache.get(key);
				}

			}
			long endTime = System.nanoTime();
			logger.debug("Time taken for {} I/O & compile(ms):" + fileName +","+
					(endTime - start) / 1000000);
			kSession = kbase.newStatefulKnowledgeSession();
			// kSession.getFactHandle(obj);
			kSession.getAgenda().getAgendaGroup(agendaGp).setFocus();
			kSession.insert(obj);
			kSession.fireAllRules();

			// kSession.execute(obj);

			kSession.dispose();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return obj;
	}

	private static KnowledgeBase readKnowledgeBase(String[] loadFile,
			String ruleType) throws Exception {
		Properties props = new Properties();
		KnowledgeBuilderConfiguration cfg = KnowledgeBuilderFactory
				.newKnowledgeBuilderConfiguration();
		cfg.setProperty("drools.dialect.default", "java");
		cfg.setProperty("drools.dialect.mvel.strict", "false");
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder(cfg);
		String drlinput= System.getProperty("DRLPLANINPUT");
		
		for (int fileCount = 0; fileCount < loadFile.length; fileCount++) {
			if (ruleType.equalsIgnoreCase("dt")) {
				DecisionTableConfiguration config = KnowledgeBuilderFactory
						.newDecisionTableConfiguration();
				config.setInputType(DecisionTableInputType.XLS);

				// for standalone
				/*kbuilder.add(ResourceFactory
						.newClassPathResource(loadFile[fileCount]),
						ResourceType.DTABLE, config);*/
				// for web(cloud)
			
				 kbuilder.add(ResourceFactory
				 .newFileResource(drlinput+loadFile[fileCount]), ResourceType.DTABLE, config);
				 

				// For Cloud Server
				/*kbuilder.add(ResourceFactory
						 .newFileResource("F:\\SPARC\\External_Resources\\PlanConfig\\resources\\"
						 +loadFile[fileCount]), ResourceType.DTABLE, config);*/

			}
			if (ruleType.equalsIgnoreCase("drl")) {
				// for standalone
				/*kbuilder.add(ResourceFactory
						.newClassPathResource(loadFile[fileCount]),
						ResourceType.DRL);*/
				// for web(cloud)
				
				System.out.println("drlinput-----"+drlinput);
				  kbuilder.add(ResourceFactory
				  .newFileResource(drlinput+loadFile[fileCount]), ResourceType.DRL);
				
				// For Cloud Server
				/* kbuilder.add(ResourceFactory
						  .newFileResource("F:\\SPARC\\External_Resources\\PlanConfig\\resources\\"
						  +loadFile[fileCount]), ResourceType.DRL);*/
				
			}
		}
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

	public static StatefulKnowledgeSession readKnowledgeBaseWithCaching(
			String[] loadFile, String ruleType) throws Exception {

		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		PlanConfigDynaCacheUtil plnDynaCacheUtil = new PlanConfigDynaCacheUtil();
		for (int fileCount = 0; fileCount < loadFile.length; fileCount++) {
		}
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
		return ksession;
	}

	public static Object getInitsData(String fileType, String fileName,
			String agendaGp, Object[] obj) {
		String[] loadFile = { fileName };
		String executionMode= System.getProperty("EXECUTIONMODE");
		try {
			long start = System.nanoTime();
			StatefulKnowledgeSession kSession;
			KnowledgeBase kbase;
			String key = fileType + fileName;
		    if (executionMode.equalsIgnoreCase("web")) {
			//if (!EXECUTION_MODE.equalsIgnoreCase("Standalone")) {
				PlanConfigDynaCacheUtil plnDynaCacheUtil = new PlanConfigDynaCacheUtil();
				if (plnDynaCacheUtil.getValue(key) == null) {
					logger.debug(
							"Did not find the file {} in cache,hence putting in cache"+key);
					kbase = readKnowledgeBase(loadFile, fileType);
					kbase.newStatefulKnowledgeSession();
					plnDynaCacheUtil.putValue(key, kbase);
				} else {
					logger.debug("Found the file {} in cache"+ key);
					kbase = (KnowledgeBase) plnDynaCacheUtil.getValue(key);

				}
			} else {
				if (cache.get(key) == null) {
					logger.debug(
							"Did not find the file {} in cache,hence putting in cache"+key);
					kbase = readKnowledgeBase(loadFile, fileType); // kSession =
					kbase.newStatefulKnowledgeSession();
					cache.put(key, kbase);
				} else {
					logger.debug("Found the file {} in cache"+ key);
					kbase = (KnowledgeBase) cache.get(key);
				}
			}
			long endTime = System.nanoTime();
			kSession = kbase.newStatefulKnowledgeSession();
			kSession.getAgenda().getAgendaGroup(agendaGp).setFocus();
			for (int i = 0; i < obj.length; i++) {
				Object fact = obj[i];
				kSession.insert(fact);
			}
			kSession.fireAllRules();
			kSession.dispose();

		} catch (Exception e) {
			logger.error("Error executing the rule: ", e);
		} catch (Throwable th) {
			logger.error("Error executing the rule: ", th);
			th.printStackTrace();
		}

		return obj;
	}

	public static void showMap(Map lookup) {
		System.out.println("->Start printing lookup");
		logger.debug("---------->Start printing lookup---------->");
		if (lookup != null) {
			Iterator it = lookup.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				/*
				 * System.out.println("Key : " + key + "| Value :" +
				 * lookup.get(key));
				 */
				System.out.println("Key :" + key + ",Value:"
						+ ((PlanMetadata) lookup.get(key)).toString());
				logger.debug("Key :" + key + ",Value:"
						+ ((PlanMetadata) lookup.get(key)).toString());
			}
			System.out.println("<-End printing lookup");
			logger.debug("<----------------End printing lookup-------------->");

		} else {
			System.out.println("<-Cannot print as map is null");

		}
	}

}
