package com.pru.sparc.drools.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.bo.model.ErrorDescription;
import com.pru.sparc.bo.model.ErrorDetails;
import com.pru.sparc.bo.model.ValidationWrapper;

public class ValidationRules {

	public List<ErrorDetails> getValidationRulesResponse(Map<String, String> map) {

		ValidationWrapper validationWrapper = new ValidationWrapper();

		validationWrapper.setDuration(map.get("duration"));
		;
		validationWrapper.setPlanEffectiveDate(map.get("planEffectiveDate"));
		validationWrapper.setPlanId(map.get("planId"));
		validationWrapper.setRoundingOccurs(map.get("roundingOccurs"));
		validationWrapper.setTypeOfCase(map.get("typeOfCase"));
		validationWrapper.setProposalId(map.get("proposalId"));
		validationWrapper.setProposalVersion(map.get("proposalVersion"));

		// load up the knowledge base
		KnowledgeBase kbase;
		List<ErrorDetails> detailedErrorList = new ArrayList<ErrorDetails>();
		ErrorDescription errorDescription = new ErrorDescription();
		// DynamicPlanFields dynamicPlanFields = new DynamicPlanFields();
		try {
			// DroolsHelper droolshelper = new DroolsHelper();
			kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();
			ksession.insert(validationWrapper);
			ksession.insert(errorDescription);
			ksession.fireAllRules();

			// temporary

			/*
			 * ErrorDescription ed = new ErrorDescription();
			 * ed.setId("Duration"); ed.setDescription("Cannot be blank");
			 * validationWrapper.addToErrorList(ed);
			 */

			ValidationRulesHelper vrh = new ValidationRulesHelper();
			detailedErrorList = vrh.mapErrorsToScreens(validationWrapper);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return detailedErrorList;
	}

	public static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();

		kbuilder.add(
				ResourceFactory
						.newClassPathResource("com/pru/sparc/ratingengine/DecisionTables/validationRules.drl"),
				ResourceType.DRL);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();

		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

}
