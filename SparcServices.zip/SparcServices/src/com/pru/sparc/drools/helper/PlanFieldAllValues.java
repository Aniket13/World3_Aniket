package com.pru.sparc.drools.helper;

public class PlanFieldAllValues {
	private String groupId;  
	private String description;
	
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}  
	  
}
