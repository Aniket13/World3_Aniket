package com.pru.sparc.drools.helper;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="Basic_Life")  
public class PlanScreenXMLParser {
	
	private List<PlanFieldGroup> group=new ArrayList<PlanFieldGroup>();

	@XmlElement(name="GROUP")  
	public List<PlanFieldGroup> getGroup() {
		return group;
	}

	public void setGroup(List<PlanFieldGroup> group) {
		this.group = group;
	}  
	  
}
