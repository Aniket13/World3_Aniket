package com.pru.sparc.drools.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.bo.model.PlanBO;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.bo.model.User;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.common.util.PlanConfigDynaCacheUtil;

public class DynamicPlanFieldhelper {

	public static SpreadsheetCompiler compiler;
	//public static String EXECUTION_MODE = "web"; // for webApplication
	public static InputStream inputStream;
	/**
	 * @param args
	 * @return
	 * @return
	 */
	private static HashMap cache;
	static {
		cache = new HashMap();
	}
	static Map<String, PlanFieldGroup> planDataMap = new HashMap<String, PlanFieldGroup>();

	public List<PlanMetadata> fetchPlanMetaData() {

		//String excelPath = "com/pru/sparc/ratingengine/DecisionTables/FieldLayout1.xls";
		String excelPath = "basicLife/Metadata/FieldMetaData.xls";

		
		List<PlanMetadata> fieldlayoutList = new ArrayList<PlanMetadata>();
		for (int i = 1; i <= PlanConfigConstants.METADATA_FIELDS_COUNT; i++) // Hardcoded for now. We should always
			// know total display fields
		{
			PlanMetadata fieldLayout = new PlanMetadata();
			String strRule = "Rule-" + i;
			fieldLayout.setRuleId(strRule);
			fieldlayoutList.add(fieldLayout);
		}
		
		// planFields.setPlanMetaDataDetails(fieldlayoutList);

		setAllInfoByRules(fieldlayoutList, excelPath);

		for (PlanMetadata fieldBO : fieldlayoutList) {
			System.out.println("FIELDNAME ####" + fieldBO.getFieldSeqId() + ":"
					+ fieldBO.getFieldName() + ":" + fieldBO.getFieldType());

		}
		return fieldlayoutList;
	}

	private static void setAllInfoByRules(List<PlanMetadata> diffReqBOList,
			String drlExcelPath) {

		try {
			//String drl = getDrlString(drlExcelPath);
			//System.out.println("drl file is" + drl);
			//PackageBuilder builder = new PackageBuilder();
			//builder.addPackageFromDrl(new StringReader(drl));
			KnowledgeBase kbase;
			/*ruleBase.addPackage(builder.getPackage());
			StatefulSession session = ruleBase.newStatefulSession();*/
			String executionMode= System.getProperty("EXECUTIONMODE");
			String key = "DT" + drlExcelPath;
			if (executionMode.equalsIgnoreCase("web")) {
			//if (!EXECUTION_MODE.equalsIgnoreCase("Standalone")) {
				PlanConfigDynaCacheUtil plnDynaCacheUtil = new PlanConfigDynaCacheUtil();
				if (plnDynaCacheUtil.getValue(key) == null) {
					System.out.println("Did not find the file"+key+" in cache,hence putting in cache");
					kbase = readKnowledgeBase(drlExcelPath);
					kbase.newStatefulKnowledgeSession();
					plnDynaCacheUtil.putValue(key, kbase);
				} else {
					System.out.println("Found the file"+ key+"in cache");
					kbase = (KnowledgeBase) plnDynaCacheUtil.getValue(key);

				}
			} else {
				if (cache.get(key) == null) {
					System.out.println("Did not find the file"+key+" in cache,hence putting in cache");
					kbase = readKnowledgeBase(drlExcelPath); // kSession =
					kbase.newStatefulKnowledgeSession();
					cache.put(key, kbase);
				} else {
					System.out.println("Found the file"+ key+"in cache");
					kbase = (KnowledgeBase) cache.get(key);
				}
			}
			StatefulKnowledgeSession session = kbase
					.newStatefulKnowledgeSession();
			for (PlanMetadata reqBo : diffReqBOList) {
				session.insert(reqBo);
			}
			session.fireAllRules();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static String getDrlString(String ruleFilePath) {
		String strDrl = null;
		try {
			compiler = new SpreadsheetCompiler();
			File drlFile = new File(ruleFilePath);
			inputStream = new FileInputStream(drlFile);
			strDrl = compiler.compile(inputStream, InputType.XLS);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		return strDrl;
	}

	public Map<String, PlanMetadata> getPlanFieldsForDisplay(
			Map<String, PlanMetadata> planMap, String sicCode, int totalLives) {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		planDtlMap.setPlanCreationDate("08/09/2016");
		User user = new User();
		user.setUserRole(PlanConfigConstants.RATE_CALC_GATEKEEPER_USER_ROLE);
		//user.setUserRoleAccess(true); //hard coded for now.. need to write condition in future
		user.setIsUserExcepRole("false");
		planDtlMap.setUser(user);
		planDtlMap.setPlanMap(planMap);
		planDtlMap.setSicId(sicCode);
		planDtlMap.setTotalLives(totalLives);
		System.out.println(planDtlMap.toString());
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigRules.drl", "PlanConfig", new Object[] {planDtlMap});
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigRulesOnChange.drl", "PlanConfigOnChange", new Object[] {planDtlMap});
		//planDetailsMap = fetchFieldLevelData(planDetailsMap);
		/*List<PlanField> planFieldList = getPlanFieldList(planFromDrools,planMetadataList);
		for (PlanField planField : planFieldList) {
			System.out.println(planField.getFieldSeqId()+"------"+planField.getVisibleFlag()+"-------"+planField.getDefaultValue()+"-----"+planField.getFieldName()+
					"----------"+(planField.getAltValues()!=null?planField.getAltValues().size():""));
		}*/
		return planDtlMap.getPlanMap();
	}

	public PlanDetailsMap fetchFieldLevelData(PlanDetailsMap planMap) {
		//PlanBO plan = new PlanBO();
		try {

			String excelPath = "com/pru/sparc/ratingengine/DecisionTables/BL_OnLoadPlanFields.xls";
			/*plan.setProduct_Name("BL");
			plan.setPlan_Description("Plan1");
			plan.setContract_State("AL");*/
			KnowledgeBase ruleBase = readKnowledgeBase(excelPath);
			StatefulKnowledgeSession session = ruleBase.newStatefulKnowledgeSession();
			session.insert(planMap);
			session.fireAllRules();
		} catch (Exception e) {
			System.out.println(e.getMessage());

			e.printStackTrace();
		}
		return planMap;
	}

/*	@SuppressWarnings("unchecked")
	public List<PlanField> getPlanFieldList(PlanBO planFromDrools,
			List<PlanMetadata> planMetaDataDetails) {
		List<PlanField> planFieldList = new ArrayList<PlanField>();
		for (PlanMetadata planMetadata : planMetaDataDetails) {
			Map<String, Object> fieldValueMap = getFieldValueMap(getPlanValue(
					planFromDrools, planMetadata.getFieldName()));
			if (null != fieldValueMap && !fieldValueMap.isEmpty()) {
				PlanField planField = new PlanField();
				planField.setDefaultValue((String) fieldValueMap.get("value"));
				planField.setVisibleFlag((String) fieldValueMap
						.get("visibility"));
				planField.setFieldName(planMetadata.getFieldName());
				planField.setAltValues((List<String>) fieldValueMap
						.get("altValues"));
				planField.setFieldSeqId(Integer.parseInt(planMetadata.getFieldSeqId()));
				planField.setFieldType(planMetadata.getFieldType());
				planFieldList.add(planField);
			}
		}
		return planFieldList;
	}*/

	public static String getPlanValue(PlanBO planFromDrools, String fieldName) {
		if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.CONT_STATE)) {
			return planFromDrools.getContractState();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.PLANEFFDT)) {
			return planFromDrools.getEffectiveDate();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.PLAN_DESC)) {
			return planFromDrools.getPlanDescription();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.TYP_OF_CASE)) {
			return planFromDrools.getTypeOFCase();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.PRU_VAL_EXCP)) {
			return planFromDrools.getPruValueExceptions();
		/*} else if (StringUtils.equalsIgnoreCase(fieldName,PlanConfigConstants.FIELD_LVL_EXCP)) {
			return planFromDrools.getFieldLevelExceptions();
		}*/
		} else if (StringUtils.equalsIgnoreCase(fieldName,PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE)) {
			return planFromDrools.getFieldLevelExceptions();
		}	
		else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.CONTRI_ARRANG)) {
			return planFromDrools.getContributionArrangement();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.MIN_PARTCI_PERCEN)) {
			return planFromDrools.getMinimumParticipationPercentage();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.VOLA_CAVEAT_REATING)) {
			return planFromDrools.getVolatilityCaveatPercentage();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.COMP_RATING)) {
			return planFromDrools.getCompositeRating();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.AGE_BANDED_RATING)) {
			return planFromDrools.getAgeBandedRating();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.RATE_GRTY)) {
			return planFromDrools.getRateGuarantee();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.RATE_EXPR)) {
			return planFromDrools.getRateExpression();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.AMT_INSU)) {
			return planFromDrools.getAmountOfInsurance();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.MAX_DOLLAR_AMT)) {
			return planFromDrools.getMaximumDollarAmount();
		} else if (StringUtils.equalsIgnoreCase(fieldName,PlanConfigConstants.MIN_DOLLAR_AMT)) {
			return planFromDrools.getMinimumDollarAmount();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.MULTI_OF_EARN)) {
			return planFromDrools.getMultipleOfAnnualEarning();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.ROUNDING_RULE)) {
			return planFromDrools.getRoundingRule();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.ROUNDING_OCCUR)) {
			return planFromDrools.getRoundingRule();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.AGE_RED_SCH)) {
			return planFromDrools.getAgeReductionSchedule();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.DIASBLE_PROV)) {
			return planFromDrools.getDisabilityProvision();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.DURATION)) {
			return planFromDrools.getDuration();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.VOL_AMT)) {
			return planFromDrools.getVolumeAmounts();
		} else if(StringUtils.equalsIgnoreCase(fieldName,PlanConfigConstants.GURANTEE_ISS_LMT)) {
			return planFromDrools.getGuranteeIssueLimit();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.DOLLAR_AMT)) {
			return planFromDrools.getDollarAmount();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.LIV_BEN_OPN)) {
			return planFromDrools.getLivingBenifitOption();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.LBO_MAX)) {
			return planFromDrools.getlBOMaximum();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.LBO_PCT)) {
			return planFromDrools.getlBOPercentage();
		} else if (StringUtils.equalsIgnoreCase(fieldName,
				PlanConfigConstants.LBO_LIFE_EXPT)) {
			return planFromDrools.getlBOLifeExpectancy();
		} else if (StringUtils.equalsIgnoreCase(fieldName,
				PlanConfigConstants.COV_TERMI_RETI)) {
			return planFromDrools.getCoverageTerminatesAtRetirement();
		} else if (StringUtils.equalsIgnoreCase(fieldName,
				PlanConfigConstants.TRAVEL_ASSISTANCE)) {
			return planFromDrools.getTravelAssistance();
		} else if (StringUtils.equalsIgnoreCase(fieldName, PlanConfigConstants.EARNING_DEF)) {
			return planFromDrools.getEarningDefination();
		} else{
			return "";
		}
	}

	/*private static Map<String, Object> getFieldValueMap(String value) {
		if (StringUtils.isNotBlank(value)) {
			Map<String, Object> valueMap = new HashMap<String, Object>();
			String valueArr[] = value.split("\\|");
			if (valueArr.length > 0
					&& StringUtils.equalsIgnoreCase(valueArr[0], "Y")) {
				for (int i = 0; i < valueArr.length; i++) {
					if (i == 0) {
						valueMap.put("visibility", valueArr[0]);
					}
					if (i == 1) {
						valueMap.put("value", valueArr[1]);
					}
					if (i == 2) {
						valueMap.put("altValues",
								Arrays.asList(valueArr[2].split(",")));
					}
				}
			}
			return valueMap;
		}
		return null;
	}*/
	
	private static KnowledgeBase readKnowledgeBase(String loadFile)
			throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		DecisionTableConfiguration config = KnowledgeBuilderFactory
				.newDecisionTableConfiguration();
		config.setInputType(DecisionTableInputType.XLS);
		String drlinput= System.getProperty("DRLPLANINPUT");
		/*for (int fileCount = 0; fileCount < loadFile.length; fileCount++) {
			kbuilder.add(
					ResourceFactory.newClassPathResource(loadFile[fileCount]),
					ResourceType.DTABLE, config);
		}*/

		//For web
		 kbuilder.add(ResourceFactory
				  .newFileResource(drlinput+loadFile), ResourceType.DTABLE,config);
		
		
		// For cloud Server
	/*	kbuilder.add(ResourceFactory
				  .newFileResource("F:\\SPARC\\External_Resources\\PlanConfig\\resources\\"
				  +loadFile), ResourceType.DTABLE,config);
		*/
		
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		// StatefulKnowledgeSession ksession =
		// kbase.newStatefulKnowledgeSession();
		return kbase;
	}
	
	public Map<String, PlanMetadata> onChangePlanDetailsFieldsForDisplay(Map<String, PlanMetadata> planMap, String sicCode, int totalLives) {

		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		planDtlMap.setPlanCreationDate("08/09/2016");
		User user = new User();
		user.setUserRole(PlanConfigConstants.RATE_CALC_GATEKEEPER_USER_ROLE);
		//user.setUserRoleAccess(true); //hard coded for now.. need to write condition in future
		user.setIsUserExcepRole("false");
		planDtlMap.setUser(user);
		planDtlMap.setPlanMap(planMap);
		planDtlMap.setSicId(sicCode);
		planDtlMap.setTotalLives(totalLives);
		System.out.println(planDtlMap.toString());
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigRulesOnChange.drl", "PlanConfigOnChange", new Object[] {planDtlMap});
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigRulesOnChange.drl", "PlanConfigOnChange", new Object[] {planDtlMap});
		return planDtlMap.getPlanMap();
	}
}
