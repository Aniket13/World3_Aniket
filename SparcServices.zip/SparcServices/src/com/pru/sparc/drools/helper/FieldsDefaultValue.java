package com.pru.sparc.drools.helper;

import java.util.ArrayList;
import java.util.List;

import com.pru.sparc.dao.impl.PlanFieldsDroolsDaoImpl;
import com.pru.sparc.model.PlanfieldsValues;

public class FieldsDefaultValue {

	public List<PlanfieldsValues> getPlanfieldsDetails(List fieldList){
		PlanFieldsDroolsDaoImpl planFieldsDaoImpl = new PlanFieldsDroolsDaoImpl();
		List<PlanfieldsValues> planfieldsValues = new ArrayList<PlanfieldsValues>();
		planfieldsValues = planFieldsDaoImpl.getPlanfieldsDetails(fieldList);
		
		return planfieldsValues;
	}
}
