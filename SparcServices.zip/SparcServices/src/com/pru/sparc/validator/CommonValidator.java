package com.pru.sparc.validator;

public class CommonValidator {

}
