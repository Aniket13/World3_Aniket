package com.pru.sparc.statexml;

import java.net.URL;



import org.apache.commons.scxml.io.SCXMLParser;
import org.apache.commons.scxml.model.SCXML;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;


public class SparcStateMachine extends AbstractSparcStateMachine {
	
	/** the state chart engine. */
	private static SCXML config;
	String printId = null;

	public SparcStateMachine() {
		this(null);
	}

	public SparcStateMachine(String idOfPersistedState) {
		super(config, idOfPersistedState);
	}

	static {
		System.out.println("IN SparcStateMachine");
		try {
			final URL configUrl = SparcStateMachine.class.getClassLoader()
			.getResource("Sparc_StateMachine.xml");
			System.out.println("configUrl" + configUrl);
			config = SCXMLParser.parse(configUrl, new ErrorHandler() {
				public void error(SAXParseException exception)
				throws SAXException {
					System.out.println("Couldn't parse SCXML Config (" + configUrl
							+ ")");
				}

				/**
				 * @see ErrorHandler#fatalError(SAXParseException)
				 */
				public void fatalError(SAXParseException exception)
				throws SAXException {
					System.out.println("Couldn't parse SCXML Config (" + configUrl
							+ ")");
				}

				/**
				 * @see ErrorHandler#warning(SAXParseException)
				 */
				public void warning(SAXParseException exception)
				throws SAXException {
					System.out.println("Couldn't parse SCXML Config (" + configUrl
							+ ")");
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Couldn't parse SCXML Config (" + e.getMessage()+ ")");
		}

	}

	public void rfp() {
		System.out.println("In rfp");

	}

	public void Client() {
		System.out.println("In Client");

	}

	public void Census() {
		System.out.println("In Census");

	}

	public void ClientEdit() {
		System.out.println("In ClientEdit");

	}

	public void ClientAdd() {
		System.out.println("In ClientAdd");
	}

	public void CensusCen() {
		System.out.println("In CensusCen");
	}

	public void CensusCenCls() {
		System.out.println("In CensusCenCls");
	}

	public void CensusCenAl() {
		System.out.println("In CensusCenAl");
	}

	public void CensusCenDet() {
		System.out.println("In CensusCenDet");
	}

	public void trigger(String requiredTransitionEvent) {
		super.trigger(requiredTransitionEvent);
	}
}
