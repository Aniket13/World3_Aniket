package com.pru.sparc.bo.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
@SuppressWarnings("serial")
@Component
public class Proposal implements Serializable{
	/**
	 * 
	 */
	private String proposalId;
	private String clientName;
	private String description;
	private String effDate;
	private List<SalesOfficeValues> salesOffice;
	private String salesOffVal;
	private List<String> contractState;
	private String contStateVal;
	private List<String> proposalStatus;
	private String proposalStatusVal;
	private List<String> taskOwner;
	private String taskOwnerVal;
	private String controlNo;
	private String mktSegInd;
	private List<String> smallBusiness;
	private String smallBusVal;
	private String federalClient;
	private String stateClient;
	private String localClient;
	private String comments;
	private String dtRecClient;
	private String dtReqClient;
	private String dtSendToClient;
	private String dtReqBroker;
	private Set<Quotation> quotes;
	private int clientId;
	private StatesXml stateXml;
	private String multiNational;
	private String exchangeQuote;
	
	public String getMultiNational() {
		return multiNational;
	}
	public void setMultiNational(String multiNational) {
		this.multiNational = multiNational;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEffDate() {
		return effDate;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	public List<SalesOfficeValues> getSalesOffice() {
		return salesOffice;
	}
	public void setSalesOffice(List<SalesOfficeValues> salesOffice) {
		this.salesOffice = salesOffice;
	}
	public String getSalesOffVal() {
		return salesOffVal;
	}
	public void setSalesOffVal(String salesOffVal) {
		this.salesOffVal = salesOffVal;
	}
	public List<String> getContractState() {
		return contractState;
	}
	public void setContractState(List<String> contractState) {
		this.contractState = contractState;
	}
	public String getContStateVal() {
		return contStateVal;
	}
	public void setContStateVal(String contStateVal) {
		this.contStateVal = contStateVal;
	}
	public List<String> getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(List<String> proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	public String getProposalStatusVal() {
		return proposalStatusVal;
	}
	public void setProposalStatusVal(String proposalStatusVal) {
		this.proposalStatusVal = proposalStatusVal;
	}
	public List<String> getTaskOwner() {
		return taskOwner;
	}
	public void setTaskOwner(List<String> taskOwner) {
		this.taskOwner = taskOwner;
	}
	public String getTaskOwnerVal() {
		return taskOwnerVal;
	}
	public void setTaskOwnerVal(String taskOwnerVal) {
		this.taskOwnerVal = taskOwnerVal;
	}
	public String getControlNo() {
		return controlNo;
	}
	public void setControlNo(String controlNo) {
		this.controlNo = controlNo;
	}
	public String getMktSegInd() {
		return mktSegInd;
	}
	public void setMktSegInd(String mktSegInd) {
		this.mktSegInd = mktSegInd;
	}
	public List<String> getSmallBusiness() {
		return smallBusiness;
	}
	public void setSmallBusiness(List<String> smallBusiness) {
		this.smallBusiness = smallBusiness;
	}
	public String getSmallBusVal() {
		return smallBusVal;
	}
	public void setSmallBusVal(String smallBusVal) {
		this.smallBusVal = smallBusVal;
	}
	public String getFederalClient() {
		return federalClient;
	}
	public void setFederalClient(String federalClient) {
		this.federalClient = federalClient;
	}
	public String getStateClient() {
		return stateClient;
	}
	public void setStateClient(String stateClient) {
		this.stateClient = stateClient;
	}
	public String getLocalClient() {
		return localClient;
	}
	public void setLocalClient(String localClient) {
		this.localClient = localClient;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getDtRecClient() {
		return dtRecClient;
	}
	public void setDtRecClient(String dtRecClient) {
		this.dtRecClient = dtRecClient;
	}
	public String getDtReqClient() {
		return dtReqClient;
	}
	public void setDtReqClient(String dtReqClient) {
		this.dtReqClient = dtReqClient;
	}
	public String getDtSendToClient() {
		return dtSendToClient;
	}
	public void setDtSendToClient(String dtSendToClient) {
		this.dtSendToClient = dtSendToClient;
	}
	public String getDtReqBroker() {
		return dtReqBroker;
	}
	public void setDtReqBroker(String dtReqBroker) {
		this.dtReqBroker = dtReqBroker;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public Set<Quotation> getQuotes() {
		return quotes;
	}
	public void setQuotes(Set<Quotation> quotes) {
		this.quotes = quotes;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public StatesXml getStateXml() {
		return stateXml;
	}
	public void setStateXml(StatesXml stateXml) {
		this.stateXml = stateXml;
	}
	public String getExchangeQuote() {
		return exchangeQuote;
	}
	public void setExchangeQuote(String exchangeQuote) {
		this.exchangeQuote = exchangeQuote;
	}
}
