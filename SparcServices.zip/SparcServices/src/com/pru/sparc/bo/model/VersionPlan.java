package com.pru.sparc.bo.model;


public class VersionPlan {
	
	private int planNum;
	private String planDesc;
	private String planEffectiveDate;
	private String contractState;
	private String rateInformation;
	private String productName;
	
	public int getPlanNum() {
		return planNum;
	}
	public void setPlanNum(int planNum) {
		this.planNum = planNum;
	}
	public String getPlanDesc() {
		return planDesc;
	}
	public void setPlanDesc(String planDesc) {
		this.planDesc = planDesc;
	}

	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public String getRateInformation() {
		return rateInformation;
	}
	public void setRateInformation(String rateInformation) {
		this.rateInformation = rateInformation;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPlanEffectiveDate() {
		return planEffectiveDate;
	}
	public void setPlanEffectiveDate(String planEffectiveDate) {
		this.planEffectiveDate = planEffectiveDate;
	}
	
	
	

}
