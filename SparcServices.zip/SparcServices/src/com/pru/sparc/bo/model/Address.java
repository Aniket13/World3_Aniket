package com.pru.sparc.bo.model;

import org.springframework.stereotype.Component;

@Component
public class Address {
	private String address;
	private String address2;
	private String city;
	private String country;
	private String otherCountryVal;
	private String state;
	private String zipcode;
	private String phone;
	private String fax;
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getOtherCountryVal() {
		return otherCountryVal;
	}
	public void setOtherCountryVal(String otherCountryVal) {
		this.otherCountryVal = otherCountryVal;
	}
	
}
