package com.pru.sparc.bo.model;

import java.util.List;

public class PlanField {
	
	
	private int fieldSeqId;
	private String fieldKey;
	private String fieldName;
	private String fieldType;
	private String defaultValue;
	private String visibleFlag; // do we need this field
	private List<String> altValues; // [{code:'',value:''},{code:'',value:''}]
	private String overriddenFlag; // Value like Y or N
	private int maxLength;
	private int minLength;
	private String onFocus; // to pass the function name that needs to invoke from UI e.g functiona1()
	private String onChange; // to pass the function name that needs to invoke from UI
	private String onBlur; // to pass the function name that needs to invoke from UI
	private String fieldIndicator; // A,C and R
	
	public int getFieldSeqId() {
		return fieldSeqId;
	}
	public void setFieldSeqId(int fieldSeqId) {
		this.fieldSeqId = fieldSeqId;
	}
	public String getFieldKey() {
		return fieldKey;
	}
	public void setFieldKey(String fieldKey) {
		this.fieldKey = fieldKey;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public String getVisibleFlag() {
		return visibleFlag;
	}
	public void setVisibleFlag(String visibleFlag) {
		this.visibleFlag = visibleFlag;
	}
	public List<String> getAltValues() {
		return altValues;
	}
	public void setAltValues(List<String> altValues) {
		this.altValues = altValues;
	}
	public String getOverriddenFlag() {
		return overriddenFlag;
	}
	public void setOverriddenFlag(String overriddenFlag) {
		this.overriddenFlag = overriddenFlag;
	}
	public int getMaxLength() {
		return maxLength;
	}
	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}
	public int getMinLength() {
		return minLength;
	}
	public void setMinLength(int minLength) {
		this.minLength = minLength;
	}
	public String getOnFocus() {
		return onFocus;
	}
	public void setOnFocus(String onFocus) {
		this.onFocus = onFocus;
	}
	public String getOnChange() {
		return onChange;
	}
	public void setOnChange(String onChange) {
		this.onChange = onChange;
	}
	public String getOnBlur() {
		return onBlur;
	}
	public void setOnBlur(String onBlur) {
		this.onBlur = onBlur;
	}
	public String getFieldIndicator() {
		return fieldIndicator;
	}
	public void setFieldIndicator(String fieldIndicator) {
		this.fieldIndicator = fieldIndicator;
	}

	
	
}
