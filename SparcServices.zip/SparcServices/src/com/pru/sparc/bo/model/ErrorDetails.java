package com.pru.sparc.bo.model;

public class ErrorDetails {
	
	
	private String feildId;	
	private String description;
	private String screenName;
	public String getFeildId() {
		return feildId;
	}
	public void setFeildId(String feildId) {
		this.feildId = feildId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	
	
	
	
	


	
	
}
