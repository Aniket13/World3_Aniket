package com.pru.sparc.bo.model;

import java.util.List;

public class PlanDetailsWrapper {

	private List<WrapperPlanfieldsValue> planDetailsList;
	private int planId;
	private String planDescription;
	private String effDate;
	private String productCode;
	private int versionNumber;
	public List<WrapperPlanfieldsValue> getPlanDetailsList() {
		return planDetailsList;
	}
	public void setPlanDetailsList(List<WrapperPlanfieldsValue> planDetailsList) {
		this.planDetailsList = planDetailsList;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public String getPlanDescription() {
		return planDescription;
	}
	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}
	public String getEffDate() {
		return effDate;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
}
