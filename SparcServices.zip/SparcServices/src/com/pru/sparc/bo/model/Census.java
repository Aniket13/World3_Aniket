package com.pru.sparc.bo.model;

import org.springframework.stereotype.Component;

@Component
public class Census {

	private int census_id;
	private String census_fl_Name;
	private String census_dt;
	private String receit_dt;
	private String time_recv_dt;
	private String last_mod_dt;
	private int no_of_live;
	private String created_by;
	private String sal_info_avia;
	private double sal_amt;
	private String notes;
	private String censusDateFormat;
	private String receivedDateFormat;
	
	public int getCensus_id() {
		return census_id;
	}
	public void setCensus_id(int census_id) {
		this.census_id = census_id;
	}
	public String getCensus_fl_Name() {
		return census_fl_Name;
	}
	public void setCensus_fl_Name(String census_fl_Name) {
		this.census_fl_Name = census_fl_Name;
	}
	public String getCensus_dt() {
		return census_dt;
	}
	public void setCensus_dt(String census_dt) {
		this.census_dt = census_dt;
	}
	public String getReceit_dt() {
		return receit_dt;
	}
	public void setReceit_dt(String receit_dt) {
		this.receit_dt = receit_dt;
	}
	public String getTime_recv_dt() {
		return time_recv_dt;
	}
	public void setTime_recv_dt(String time_recv_dt) {
		this.time_recv_dt = time_recv_dt;
	}
	public String getLast_mod_dt() {
		return last_mod_dt;
	}
	public void setLast_mod_dt(String last_mod_dt) {
		this.last_mod_dt = last_mod_dt;
	}
	public int getNo_of_live() {
		return no_of_live;
	}
	public void setNo_of_live(int no_of_live) {
		this.no_of_live = no_of_live;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getSal_info_avia() {
		return sal_info_avia;
	}
	public void setSal_info_avia(String sal_info_avia) {
		this.sal_info_avia = sal_info_avia;
	}
	public double getSal_amt() {
		return sal_amt;
	}
	public void setSal_amt(double sal_amt) {
		this.sal_amt = sal_amt;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getCensusDateFormat() {
		return censusDateFormat;
	}
	public void setCensusDateFormat(String censusDateFormat) {
		this.censusDateFormat = censusDateFormat;
	}
	public String getReceivedDateFormat() {
		return receivedDateFormat;
	}
	public void setReceivedDateFormat(String receivedDateFormat) {
		this.receivedDateFormat = receivedDateFormat;
	}
	
	
}
