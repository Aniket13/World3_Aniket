package com.pru.sparc.bo.model;

import java.util.Date;

public class ProposalVersion {
	private String proposalId;
	private int versionNumber;
	private String versionDesc;
	private String rated;
	private String censusDescription;
	private int clonedFrom;
	private Date creationDate;
	private String creationDateStr;
	private Quotation quotation;
	
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getVersionDesc() {
		return versionDesc;
	}
	public void setVersionDesc(String versionDesc) {
		this.versionDesc = versionDesc;
	}
	public String getRated() {
		return rated;
	}
	public void setRated(String rated) {
		this.rated = rated;
	}
	public String getCensusDescription() {
		return censusDescription;
	}
	public void setCensusDescription(String censusDescription) {
		this.censusDescription = censusDescription;
	}
	public int getClonedFrom() {
		return clonedFrom;
	}
	public void setClonedFrom(int clonedFrom) {
		this.clonedFrom = clonedFrom;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Quotation getQuotation() {
		return quotation;
	}
	public void setQuotation(Quotation quotation) {
		this.quotation = quotation;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public String getCreationDateStr() {
		return creationDateStr;
	}
	public void setCreationDateStr(String creationDateStr) {
		this.creationDateStr = creationDateStr;
	}
}
