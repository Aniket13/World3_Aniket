package com.pru.sparc.bo.model;

public class Commission {

	private String proposalPlanID;
	private int brokerID;
	private double commissionSplit;
	private String arrangement;
	private double flatAmount;
	private float flatPercentage;
	private String commissionPaidTo;
	private String advaceCommissionOccurs;
	private double advanceCommission;
	private String advanceCommissionFlag;
	private int versionNumber;
	
	public String getAdvanceCommissionFlag() {
		return advanceCommissionFlag;
	}
	public void setAdvanceCommissionFlag(String advanceCommissionFlag) {
		this.advanceCommissionFlag = advanceCommissionFlag;
	}
	public String getProposalPlanID() {
		return proposalPlanID;
	}
	public void setProposalPlanID(String proposalPlanID) {
		this.proposalPlanID = proposalPlanID;
	}
	public int getBrokerID() {
		return brokerID;
	}
	public void setBrokerID(int brokerID) {
		this.brokerID = brokerID;
	}
	public double getCommissionSplit() {
		return commissionSplit;
	}
	public void setCommissionSplit(double commissionSplit) {
		this.commissionSplit = commissionSplit;
	}
	public String getArrangement() {
		return arrangement;
	}
	public void setArrangement(String arrangement) {
		this.arrangement = arrangement;
	}
	public double getFlatAmount() {
		return flatAmount;
	}
	public void setFlatAmount(double flatAmount) {
		this.flatAmount = flatAmount;
	}
	public float getFlatPercentage() {
		return flatPercentage;
	}
	public void setFlatPercentage(float flatPercentage) {
		this.flatPercentage = flatPercentage;
	}
	public String getCommissionPaidTo() {
		return commissionPaidTo;
	}
	public void setCommissionPaidTo(String commissionPaidTo) {
		this.commissionPaidTo = commissionPaidTo;
	}
	public String getAdvaceCommissionOccurs() {
		return advaceCommissionOccurs;
	}
	public void setAdvaceCommissionOccurs(String advaceCommissionOccurs) {
		this.advaceCommissionOccurs = advaceCommissionOccurs;
	}
	public double getAdvanceCommission() {
		return advanceCommission;
	}
	public void setAdvanceCommission(double advanceCommission) {
		this.advanceCommission = advanceCommission;
	}
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	
}
