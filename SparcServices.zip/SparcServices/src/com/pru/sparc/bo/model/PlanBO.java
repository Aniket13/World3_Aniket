package com.pru.sparc.bo.model;

public class PlanBO {
	private String productName;
	private String rule;
	private String contractState;
	private String effectiveDate;
	private String planDescription;
	private String typeOFCase;
	private String pruValueExceptions;
	private String fieldLevelExceptions;
	private String contributionArrangement;
	private String minimumParticipationPercentage;
	private String volatilityCaveatPercentage;
	private String compositeRating;
	private String ageBandedRating;
	private String rateGuarantee;
	private String rateExpression;
	private String amountOfInsurance;
	private String maximumDollarAmount;
	private String minimumDollarAmount;
	private String multipleOfAnnualEarning;
	private String roundingRule;
	private String roundingOccurs;
	private String ageReductionSchedule;
	private String disabilityProvision;
	private String duration;
	private String volumeAmounts;
	private String guranteeIssueLimit;
	private String dollarAmount;
	private String livingBenifitOption;
	private String lBOMaximum;
	private String lBOPercentage;
	private String lBOLifeExpectancy;
	private String coverageTerminatesAtRetirement;
	private String travelAssistance;
	private String earningDefination;
	private String includeBonusInEarningDefination;
	private String includeCommisionInEarningDefination;
	private String includeOvertimeInEarningDefination;
	private int versionNumber;
	private int planId;
	private int proposalId;
	private int productId;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getRule() {
		return rule;
	}
	public void setRule(String rule) {
		this.rule = rule;
	}
	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getPlanDescription() {
		return planDescription;
	}
	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}
	public String getTypeOFCase() {
		return typeOFCase;
	}
	public void setTypeOFCase(String typeOFCase) {
		this.typeOFCase = typeOFCase;
	}
	public String getPruValueExceptions() {
		return pruValueExceptions;
	}
	public void setPruValueExceptions(String pruValueExceptions) {
		this.pruValueExceptions = pruValueExceptions;
	}
	public String getFieldLevelExceptions() {
		return fieldLevelExceptions;
	}
	public void setFieldLevelExceptions(String fieldLevelExceptions) {
		this.fieldLevelExceptions = fieldLevelExceptions;
	}
	public String getContributionArrangement() {
		return contributionArrangement;
	}
	public void setContributionArrangement(String contributionArrangement) {
		this.contributionArrangement = contributionArrangement;
	}
	public String getMinimumParticipationPercentage() {
		return minimumParticipationPercentage;
	}
	public void setMinimumParticipationPercentage(
			String minimumParticipationPercentage) {
		this.minimumParticipationPercentage = minimumParticipationPercentage;
	}
	public String getVolatilityCaveatPercentage() {
		return volatilityCaveatPercentage;
	}
	public void setVolatilityCaveatPercentage(String volatilityCaveatPercentage) {
		this.volatilityCaveatPercentage = volatilityCaveatPercentage;
	}
	public String getCompositeRating() {
		return compositeRating;
	}
	public void setCompositeRating(String compositeRating) {
		this.compositeRating = compositeRating;
	}
	public String getAgeBandedRating() {
		return ageBandedRating;
	}
	public void setAgeBandedRating(String ageBandedRating) {
		this.ageBandedRating = ageBandedRating;
	}
	public String getRateGuarantee() {
		return rateGuarantee;
	}
	public void setRateGuarantee(String rateGuarantee) {
		this.rateGuarantee = rateGuarantee;
	}
	public String getRateExpression() {
		return rateExpression;
	}
	public void setRateExpression(String rateExpression) {
		this.rateExpression = rateExpression;
	}
	public String getAmountOfInsurance() {
		return amountOfInsurance;
	}
	public void setAmountOfInsurance(String amountOfInsurance) {
		this.amountOfInsurance = amountOfInsurance;
	}
	public String getMaximumDollarAmount() {
		return maximumDollarAmount;
	}
	public void setMaximumDollarAmount(String maximumDollarAmount) {
		this.maximumDollarAmount = maximumDollarAmount;
	}
	public String getMinimumDollarAmount() {
		return minimumDollarAmount;
	}
	public void setMinimumDollarAmount(String minimumDollarAmount) {
		this.minimumDollarAmount = minimumDollarAmount;
	}
	public String getMultipleOfAnnualEarning() {
		return multipleOfAnnualEarning;
	}
	public void setMultipleOfAnnualEarning(String multipleOfAnnualEarning) {
		this.multipleOfAnnualEarning = multipleOfAnnualEarning;
	}
	public String getRoundingRule() {
		return roundingRule;
	}
	public void setRoundingRule(String roundingRule) {
		this.roundingRule = roundingRule;
	}
	public String getRoundingOccurs() {
		return roundingOccurs;
	}
	public void setRoundingOccurs(String roundingOccurs) {
		this.roundingOccurs = roundingOccurs;
	}
	public String getAgeReductionSchedule() {
		return ageReductionSchedule;
	}
	public void setAgeReductionSchedule(String ageReductionSchedule) {
		this.ageReductionSchedule = ageReductionSchedule;
	}
	public String getDisabilityProvision() {
		return disabilityProvision;
	}
	public void setDisabilityProvision(String disabilityProvision) {
		this.disabilityProvision = disabilityProvision;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getVolumeAmounts() {
		return volumeAmounts;
	}
	public void setVolumeAmounts(String volumeAmounts) {
		this.volumeAmounts = volumeAmounts;
	}
	public String getGuranteeIssueLimit() {
		return guranteeIssueLimit;
	}
	public void setGuranteeIssueLimit(String guranteeIssueLimit) {
		this.guranteeIssueLimit = guranteeIssueLimit;
	}
	public String getDollarAmount() {
		return dollarAmount;
	}
	public void setDollarAmount(String dollarAmount) {
		this.dollarAmount = dollarAmount;
	}
	public String getLivingBenifitOption() {
		return livingBenifitOption;
	}
	public void setLivingBenifitOption(String livingBenifitOption) {
		this.livingBenifitOption = livingBenifitOption;
	}
	public String getlBOMaximum() {
		return lBOMaximum;
	}
	public void setlBOMaximum(String lBOMaximum) {
		this.lBOMaximum = lBOMaximum;
	}
	public String getlBOPercentage() {
		return lBOPercentage;
	}
	public void setlBOPercentage(String lBOPercentage) {
		this.lBOPercentage = lBOPercentage;
	}
	public String getlBOLifeExpectancy() {
		return lBOLifeExpectancy;
	}
	public void setlBOLifeExpectancy(String lBOLifeExpectancy) {
		this.lBOLifeExpectancy = lBOLifeExpectancy;
	}
	public String getCoverageTerminatesAtRetirement() {
		return coverageTerminatesAtRetirement;
	}
	public void setCoverageTerminatesAtRetirement(
			String coverageTerminatesAtRetirement) {
		this.coverageTerminatesAtRetirement = coverageTerminatesAtRetirement;
	}
	public String getTravelAssistance() {
		return travelAssistance;
	}
	public void setTravelAssistance(String travelAssistance) {
		this.travelAssistance = travelAssistance;
	}
	public String getEarningDefination() {
		return earningDefination;
	}
	public void setEarningDefination(String earningDefination) {
		this.earningDefination = earningDefination;
	}
	public String getIncludeBonusInEarningDefination() {
		return includeBonusInEarningDefination;
	}
	public void setIncludeBonusInEarningDefination(
			String includeBonusInEarningDefination) {
		this.includeBonusInEarningDefination = includeBonusInEarningDefination;
	}
	public String getIncludeCommisionInEarningDefination() {
		return includeCommisionInEarningDefination;
	}
	public void setIncludeCommisionInEarningDefination(
			String includeCommisionInEarningDefination) {
		this.includeCommisionInEarningDefination = includeCommisionInEarningDefination;
	}
	public String getIncludeOvertimeInEarningDefination() {
		return includeOvertimeInEarningDefination;
	}
	public void setIncludeOvertimeInEarningDefination(
			String includeOvertimeInEarningDefination) {
		this.includeOvertimeInEarningDefination = includeOvertimeInEarningDefination;
	}
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public int getProposalId() {
		return proposalId;
	}
	public void setProposalId(int proposalId) {
		this.proposalId = proposalId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
}
