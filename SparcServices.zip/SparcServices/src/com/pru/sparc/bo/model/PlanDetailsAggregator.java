package com.pru.sparc.bo.model;

import java.util.List;

public class PlanDetailsAggregator {
	
	private List<PlanMetadata> listOfPlanField;
	private String proposalId;
	private int proposalVersionId;
	private int prodCode;// Needs to revisit
	private int planId;
	private int brokerId;
	private Commission commission;
	private PlanEligibility planEligibility;
	//added 3 fields for Plan config input
	private int clientId;
	private String sicCode;
	private int selectedCensusId;
	private String currentTabId; 
	
	
	public List<PlanMetadata> getListOfPlanField() {
		return listOfPlanField;
	}
	public void setListOfPlanField(List<PlanMetadata> listOfPlanField) {
		this.listOfPlanField = listOfPlanField;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public int getProposalVersionId() {
		return proposalVersionId;
	}
	public void setProposalVersionId(int proposalVersionId) {
		this.proposalVersionId = proposalVersionId;
	}
	public int getProdCode() {
		return prodCode;
	}
	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public Commission getCommission() {
		return commission;
	}
	public void setCommission(Commission commission) {
		this.commission = commission;
	}
	public PlanEligibility getPlanEligibility() {
		return planEligibility;
	}
	public void setPlanEligibility(PlanEligibility planEligibility) {
		this.planEligibility = planEligibility;
	}
	public int getBrokerId() {
		return brokerId;
	}
	public void setBrokerId(int brokerId) {
		this.brokerId = brokerId;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getSicCode() {
		return sicCode;
	}
	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}
	public int getSelectedCensusId() {
		return selectedCensusId;
	}
	public void setSelectedCensusId(int selectedCensusId) {
		this.selectedCensusId = selectedCensusId;
	}
	public String getCurrentTabId() {
		return currentTabId;
	}
	public void setCurrentTabId(String currentTabId) {
		this.currentTabId = currentTabId;
	}	
}
