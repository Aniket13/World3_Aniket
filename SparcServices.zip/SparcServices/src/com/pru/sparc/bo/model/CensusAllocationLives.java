package com.pru.sparc.bo.model;

import org.springframework.stereotype.Component;

@Component
public class CensusAllocationLives {

	private int censusId;
	private String cenState;
	private String noOfLives;
	private float allocPerc;
	public int getCensusId() {
		return censusId;
	}
	public void setCensusId(int censusId) {
		this.censusId = censusId;
	}
	public String getCenState() {
		return cenState;
	}
	public void setCenState(String cenState) {
		this.cenState = cenState;
	}
	public String getNoOfLives() {
		return noOfLives;
	}
	public void setNoOfLives(String noOfLives) {
		this.noOfLives = noOfLives;
	}
	public float getAllocPerc() {
		return allocPerc;
	}
	public void setAllocPerc(float allocPerc) {
		this.allocPerc = allocPerc;
	}
	
	
}
