package com.pru.sparc.bo.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class VersionDetails {

	private String versionDesc;	
	private int versionNumber;
	private String proposalId;
	private String versionStatus;
	private Date censusDate;
	//private List<ProductList> productList = new ArrayList<ProductList>();
	private List<VersionPlan> planList = new ArrayList<VersionPlan>();
	private String attachedCensus;
	
	
	public String getVersionDesc() {
		return versionDesc;
	}
	public void setVersionDesc(String versionDesc) {
		this.versionDesc = versionDesc;
	}

	public String getVersionStatus() {
		return versionStatus;
	}
	public void setVersionStatus(String versionStatus) {
		this.versionStatus = versionStatus;
	}
/*	public List<ProductList> getProductList() {
		return productList;
	}
	public void setProductList(List<ProductList> productList) {
		this.productList = productList;
	}*/
	public String getAttachedCensus() {
		return attachedCensus;
	}
	public void setAttachedCensus(String attachedCensus) {
		this.attachedCensus = attachedCensus;
	}
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public List<VersionPlan> getPlanList() {
		return planList;
	}
	public void setPlanList(List<VersionPlan> planList) {
		this.planList = planList;
	}
	public Date getCensusDate() {
		return censusDate;
	}
	public void setCensusDate(Date censusDate) {
		this.censusDate = censusDate;
	}	
	
	
}
