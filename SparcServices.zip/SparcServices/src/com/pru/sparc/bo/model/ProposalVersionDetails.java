package com.pru.sparc.bo.model;

import java.util.ArrayList;
import java.util.List;

public class ProposalVersionDetails {

	private String proposalDesc;	
	private String proposalId;
	private List<VersionDetails> versionDetails = new ArrayList<VersionDetails>();
	
	
	
	
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public String getProposalDesc() {
		return proposalDesc;
	}
	public void setProposalDesc(String proposalDesc) {
		this.proposalDesc = proposalDesc;
	}
	public List<VersionDetails> getVersionDetails() {
		return versionDetails;
	}
	public void setVersionDetails(List<VersionDetails> versionDetails) {
		this.versionDetails = versionDetails;
	}	
	
	
	
}
