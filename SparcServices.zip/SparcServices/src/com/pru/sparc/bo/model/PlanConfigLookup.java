package com.pru.sparc.bo.model;

public class PlanConfigLookup {
	private String lookupCategory;
	private String lookupKey;
	private String lookupValue;
	private int lookupOrder;
	private String visibleFlag;
	public String getLookupCategory() {
		return lookupCategory;
	}
	public void setLookupCategory(String lookupCategory) {
		this.lookupCategory = lookupCategory;
	}
	public String getLookupKey() {
		return lookupKey;
	}
	public void setLookupKey(String lookupKey) {
		this.lookupKey = lookupKey;
	}
	public String getLookupValue() {
		return lookupValue;
	}
	public void setLookupValue(String lookupValue) {
		this.lookupValue = lookupValue;
	}
	public int getLookupOrder() {
		return lookupOrder;
	}
	public void setLookupOrder(int lookupOrder) {
		this.lookupOrder = lookupOrder;
	}
	public String getVisibleFlag() {
		return visibleFlag;
	}
	public void setVisibleFlag(String visibleFlag) {
		this.visibleFlag = visibleFlag;
	}
	@Override
	public String toString() {
		return "PlanConfigLookup [lookupCategory=" + lookupCategory
				+ ", lookupKey=" + lookupKey + ", lookupValue=" + lookupValue
				+ ", lookupOrder=" + lookupOrder + ", visibleFlag="
				+ visibleFlag + "]";
	}
	
	/* For PlanConfig Logging credated on 08/15/2016 */
	
	@Override
	public boolean equals(Object other) {
	  
		if (!(other instanceof PlanConfigLookup)) {
	        return false;
	    }

		PlanConfigLookup that = (PlanConfigLookup) other;
		
		boolean lookupCategoryFlag=false;
		boolean lookupKeyFlag=false;
		boolean lookupValueFlag=false;
		boolean visibleFlagFlag=false;
		
		if(null!=this.lookupCategory && null!=that.lookupCategory)
			lookupCategoryFlag=this.lookupCategory.equals(that.lookupCategory);
		if(null==this.lookupCategory && null==that.lookupCategory)
			lookupCategoryFlag=true;
		
		if(null!=this.lookupKey && null!=that.lookupKey)
			lookupKeyFlag=this.lookupKey.equals(that.lookupKey);
		if(null==this.lookupKey && null==that.lookupKey)
			lookupKeyFlag=true;
		
		if(null!=this.lookupValue && null!=that.lookupValue)
			lookupValueFlag=this.lookupValue.equals(that.lookupValue);
		if(null==this.lookupValue && null==that.lookupValue)
			lookupValueFlag=true;
		
		if(null!=this.visibleFlag && null!=that.visibleFlag)
			visibleFlagFlag=this.visibleFlag.equals(that.visibleFlag);
		if(null==this.visibleFlag && null==that.visibleFlag)
			visibleFlagFlag=true;

	    // Custom equality check here.
	    return lookupCategoryFlag
	        && lookupKeyFlag
	        && lookupValueFlag
	        && this.lookupOrder==that.lookupOrder
	        && visibleFlagFlag;
	    
	}
	
	
	public static Object createCopy(PlanConfigLookup old) {
		
		PlanConfigLookup cloneNew= new PlanConfigLookup();
		cloneNew.lookupCategory = old.lookupCategory;
		cloneNew.lookupKey = old.lookupKey;
		cloneNew.lookupValue = old.lookupValue;
		cloneNew.lookupOrder = old.lookupOrder;
		cloneNew.visibleFlag = old.visibleFlag;
		return cloneNew;
	}
}
