package com.pru.sparc.bo.model;

import java.util.List;

public class Quotation {
	
	private int versionNumber;
	private String proposalId;
	private String versionDesc;
	private String basicLife;
	private String ltd;
	private String businessCase;
	private List<String> docFormatList;
	private String documentFormat;
	private List<String> billMethodList;
	private String billingMethod;
	private List<String> billDeliveryMethodList;
	private String billingDeliveryMethod;
	private List<Census> censusList;
	private String selectedCensus;
	private String atpVoucher;
	private List<String> versionStatusList;
	private String versionStatus;
	private List<String> lifeReasonList;
	private String lifeReason;
	private List<String> disabilityReasonList;
	private String disabilityReason;
	private List<String> dentalReasonList;
	private String dentalReason;
	private String rsmComment;
	private String comment;
	private List<String> quoteReasonOptions; 
	private List<String> selectedQuoteReasons; 
	private List<Product> productList;
	private List<Integer> selectedQuoteProducts;
	private int clientId;
	private int displayVersionNo;
	
	public List<Integer> getSelectedQuoteProducts() {
		return selectedQuoteProducts;
	}
	public void setSelectedQuoteProducts(List<Integer> selectedQuoteProducts) {
		this.selectedQuoteProducts = selectedQuoteProducts;
	}
	public List<String> getSelectedQuoteReasons() {
		return selectedQuoteReasons;
	}
	public void setSelectedQuoteReasons(List<String> selectedQuoteReasons) {
		this.selectedQuoteReasons = selectedQuoteReasons;
	}
	
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getVersionDesc() {
		return versionDesc;
	}
	public void setVersionDesc(String versionDesc) {
		this.versionDesc = versionDesc;
	}
	public String getBasicLife() {
		return basicLife;
	}
	public void setBasicLife(String basicLife) {
		this.basicLife = basicLife;
	}
	public String getLtd() {
		return ltd;
	}
	public void setLtd(String ltd) {
		this.ltd = ltd;
	}
	public List<String> getDocFormatList() {
		return docFormatList;
	}
	public void setDocFormatList(List<String> docFormatList) {
		this.docFormatList = docFormatList;
	}
	public String getDocumentFormat() {
		return documentFormat;
	}
	public void setDocumentFormat(String documentFormat) {
		this.documentFormat = documentFormat;
	}
	public List<String> getBillMethodList() {
		return billMethodList;
	}
	public void setBillMethodList(List<String> billMethodList) {
		this.billMethodList = billMethodList;
	}
	public String getBillingMethod() {
		return billingMethod;
	}
	public void setBillingMethod(String billingMethod) {
		this.billingMethod = billingMethod;
	}
	public List<String> getBillDeliveryMethodList() {
		return billDeliveryMethodList;
	}
	public void setBillDeliveryMethodList(List<String> billDeliveryMethodList) {
		this.billDeliveryMethodList = billDeliveryMethodList;
	}
	public String getBillingDeliveryMethod() {
		return billingDeliveryMethod;
	}
	public void setBillingDeliveryMethod(String billingDeliveryMethod) {
		this.billingDeliveryMethod = billingDeliveryMethod;
	}
	public List<Census> getCensusList() {
		return censusList;
	}
	public void setCensusList(List<Census> censusList) {
		this.censusList = censusList;
	}
	public String getAtpVoucher() {
		return atpVoucher;
	}
	public void setAtpVoucher(String atpVoucher) {
		this.atpVoucher = atpVoucher;
	}
	public String getVersionStatus() {
		return versionStatus;
	}
	public void setVersionStatus(String versionStatus) {
		this.versionStatus = versionStatus;
	}
	public String getRsmComment() {
		return rsmComment;
	}
	public void setRsmComment(String rsmComment) {
		this.rsmComment = rsmComment;
	}
	
	public List<Product> getProductList() {
		return productList;
	}
	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	public String getBusinessCase() {
		return businessCase;
	}
	public void setBusinessCase(String businessCase) {
		this.businessCase = businessCase;
	}
	public List<String> getVersionStatusList() {
		return versionStatusList;
	}
	public void setVersionStatusList(List<String> versionStatusList) {
		this.versionStatusList = versionStatusList;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public List<String> getLifeReasonList() {
		return lifeReasonList;
	}
	public void setLifeReasonList(List<String> lifeReasonList) {
		this.lifeReasonList = lifeReasonList;
	}
	public List<String> getDisabilityReasonList() {
		return disabilityReasonList;
	}
	public void setDisabilityReasonList(List<String> disabilityReasonList) {
		this.disabilityReasonList = disabilityReasonList;
	}
	public List<String> getDentalReasonList() {
		return dentalReasonList;
	}
	public void setDentalReasonList(List<String> dentalReasonList) {
		this.dentalReasonList = dentalReasonList;
	}
	public void setLifeReason(String lifeReason) {
		this.lifeReason = lifeReason;
	}
	public void setDisabilityReason(String disabilityReason) {
		this.disabilityReason = disabilityReason;
	}
	public void setDentalReason(String dentalReason) {
		this.dentalReason = dentalReason;
	}
	public String getLifeReason() {
		return lifeReason;
	}
	public String getDisabilityReason() {
		return disabilityReason;
	}
	public String getDentalReason() {
		return dentalReason;
	}
	public List<String> getQuoteReasonOptions() {
		return quoteReasonOptions;
	}
	public void setQuoteReasonOptions(List<String> quoteReasonOptions) {
		this.quoteReasonOptions = quoteReasonOptions;
	}
	public String getSelectedCensus() {
		return selectedCensus;
	}
	public void setSelectedCensus(String selectedCensus) {
		this.selectedCensus = selectedCensus;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public int getDisplayVersionNo() {
		return displayVersionNo;
	}
	public void setDisplayVersionNo(int displayVersionNo) {
		this.displayVersionNo = displayVersionNo;
	}	
}
