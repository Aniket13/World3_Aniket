package com.pru.sparc.bo.model;

import org.springframework.stereotype.Component;

@Component
 public class StatesXml {
	 private int stateId;
	 private String currState;
	 private String proposalId;	
	 private String versionStatus;	
	 private String proposalStatus;
	 private String statestatus;
	 
	 private String preCond;
	 private String postCond;	
	 private String userId;		
	 private String crtDt;	
	 private String modUser;
	 private String modDt;	
	 public int getStateId() {
			return stateId;
		}
		public void setStateId(int stateId) {
			this.stateId = stateId;
		}
		public String getCurrState() {
			return currState;
		}
		public void setCurrState(String currState) {
			this.currState = currState;
		}
		public String getProposalId() {
			return proposalId;
		}
		public void setProposalId(String proposalId) {
			this.proposalId = proposalId;
		}
		public String getVersionStatus() {
			return versionStatus;
		}
		public void setVersionStatus(String versionStatus) {
			this.versionStatus = versionStatus;
		}
		public String getProposalStatus() {
			return proposalStatus;
		}
		public void setProposalStatus(String proposalStatus) {
			this.proposalStatus = proposalStatus;
		}
		public String getStatestatus() {
			return statestatus;
		}
		public void setStatestatus(String statestatus) {
			this.statestatus = statestatus;
		}
		public String getPreCond() {
			return preCond;
		}
		public void setPreCond(String preCond) {
			this.preCond = preCond;
		}
		public String getPostCond() {
			return postCond;
		}
		public void setPostCond(String postCond) {
			this.postCond = postCond;
		}
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public String getCrtDt() {
			return crtDt;
		}
		public void setCrtDt(String crtDt) {
			this.crtDt = crtDt;
		}
		public String getModUser() {
			return modUser;
		}
		public void setModUser(String modUser) {
			this.modUser = modUser;
		}
		public String getModDt() {
			return modDt;
		}
		public void setModDt(String modDt) {
			this.modDt = modDt;
		}
	
	
}
