package com.pru.sparc.bo.model;


public class SalesOfficeValues {
	private String salesOfficeId;
	private String description;
	private SalesRegionValues salesRegionValues;
	public String getSalesOfficeId() {
		return salesOfficeId;
	}
	public void setSalesOfficeId(String salesOfficeId) {
		this.salesOfficeId = salesOfficeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public SalesRegionValues getSalesRegionValues() {
		return salesRegionValues;
	}
	public void setSalesRegionValues(SalesRegionValues salesRegionValues) {
		this.salesRegionValues = salesRegionValues;
	}
	
}
