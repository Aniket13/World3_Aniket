package com.pru.sparc.bo.model;

import java.util.List;

public class PlanEligibility {

	private int planID;
	private int censusID;
	List<CensusCls> censusClassList;
	private double minHrsRequired;
	private int versionNumber;
	
	public int getCensusID() {
		return censusID;
	}
	public void setCensusID(int censusID) {
		this.censusID = censusID;
	}
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public int getPlanID() {
		return planID;
	}
	public void setPlanID(int planID) {
		this.planID = planID;
	}
	public double getMinHrsRequired() {
		return minHrsRequired;
	}
	public void setMinHrsRequired(double minHrsRequired) {
		this.minHrsRequired = minHrsRequired;
	}
	public List<CensusCls> getCensusClassList() {
		return censusClassList;
	}
	public void setCensusClassList(List<CensusCls> censusClassList) {
		this.censusClassList = censusClassList;
	}
}
