package com.pru.sparc.bo.model;

public class Producer {
	private int brokerId;
	private String producerName;
	private String producerAdbNo;
	private String producerAgencyCode;
	private String producerRanking;
	private String producerType;
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public String getProducerAdbNo() {
		return producerAdbNo;
	}
	public void setProducerAdbNo(String producerAdbNo) {
		this.producerAdbNo = producerAdbNo;
	}
	public String getProducerAgencyCode() {
		return producerAgencyCode;
	}
	public void setProducerAgencyCode(String producerAgencyCode) {
		this.producerAgencyCode = producerAgencyCode;
	}
	public String getProducerRanking() {
		return producerRanking;
	}
	public void setProducerRanking(String producerRanking) {
		this.producerRanking = producerRanking;
	}
	public String getProducerType() {
		return producerType;
	}
	public void setProducerType(String producerType) {
		this.producerType = producerType;
	}
	public int getBrokerId() {
		return brokerId;
	}
	public void setBrokerId(int brokerId) {
		this.brokerId = brokerId;
	}
}
