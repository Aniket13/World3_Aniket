package com.pru.sparc.bo.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class BaseModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** 
	 * @see java.lang.Object#toString()
	 * @return String
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	/**
	 * 
	 * @param date date
	 * @return String
	 */
	protected String dateToString(final Date date) {
		String result = null;
		if (date != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			try {
				result = dateFormat.format(date);
			} catch (Exception e) {
				//TODO 				
			} 
		}
		return result;
	}
}
