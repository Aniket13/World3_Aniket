package com.pru.sparc.bo.model;

import java.io.Serializable;
import java.util.List;

public class WrapperPlanfieldsValue implements Serializable{

	private static final long serialVersionUID = -5286197391608647166L;
	
	private List<String> allValues;
	private String fieldType;
	private String id;
	private String label;
	private boolean isOverRidden;
	private String value;
	private String groupId;
	
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public List<String> getAllValues() {
		return allValues;
	}
	public void setAllValues(List<String> allValues) {
		this.allValues = allValues;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public boolean isOverRidden() {
		return isOverRidden;
	}
	public void setOverRidden(boolean isOverRidden) {
		this.isOverRidden = isOverRidden;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "WrapperPlanfieldsValue [allValues=" + allValues
				+ ", fieldType=" + fieldType + ", id=" + id + ", label="
				+ label + ", isOverRidden=" + isOverRidden + ", value=" + value
				+ ", groupId=" + groupId + "]";
	}
}
