package com.pru.sparc.bo.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RatingModel {

	private boolean validationErrors;
	private boolean ratingSuccessful;
	private List<ErrorDetails> listOfValidationMsgs = new ArrayList<ErrorDetails>();
	private int planId;
	private String proposalId;
	private int versionNumber;
	private int rateId;
	//private boolean overridenRow;
	private HashMap<String,String> overriddenValues = new HashMap<String,String>(); 
	private boolean planRatingPending;
	
	public int getRateId() {
		return rateId;
	}
	public void setRateId(int rateId) {
		this.rateId = rateId;
	}
	
	public boolean isValidationErrors() {
		return validationErrors;
	}
	public void setValidationErrors(boolean validationErrors) {
		this.validationErrors = validationErrors;
	}
	public boolean isRatingSuccessful() {
		return ratingSuccessful;
	}
	public void setRatingSuccessful(boolean ratingSuccessful) {
		this.ratingSuccessful = ratingSuccessful;
	}
	public List<ErrorDetails> getListOfValidationMsgs() {
		return listOfValidationMsgs;
	}
	public void setListOfValidationMsgs(List<ErrorDetails> listOfValidationMsgs) {
		this.listOfValidationMsgs = listOfValidationMsgs;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public HashMap<String, String> getOverriddenValues() {
		return overriddenValues;
	}
	public void setOverriddenValues(HashMap<String, String> overriddenValues) {
		this.overriddenValues = overriddenValues;
	}
	public boolean isPlanRatingPending() {
		return planRatingPending;
	}
	public void setPlanRatingPending(boolean planRatingPending) {
		this.planRatingPending = planRatingPending;
	}
}
