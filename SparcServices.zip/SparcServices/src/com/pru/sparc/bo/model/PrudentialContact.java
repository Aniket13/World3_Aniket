package com.pru.sparc.bo.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class PrudentialContact implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String salesRegion;	
	private String salesOffice;	
	private String ldsmNameVal;
	private String ldsmAsstVal;	
	private String lifeSplVal;	
	private String lifeSplAsstVal;
	private String uwVal;	
	private String rateCalcTechVal;	
	private String acctManVal;	
	private String midMktAcctMgrVal;	
	private String regAdminDirVal;	
	private String acctExeNameVal;
	private List<String> ldsmName;
	private List<String> ldsmAsstName;	
	private List<String> lifeSplName;	
	private List<String> lifeSplAsstName;
	private List<String> underwriterName;	
	private List<String> rateCalcTechName;	
	private List<String> acctManagerName;	
	private List<String> midMktAcctMgrName;	
	private List<String> regAdminDirName;	
	private List<String> acctExeName;
	private String extAgentName;	
	private String extAgentOffice;
	private String extAgentPhone;
	private List<String> salesOfficeList;
	private String proposalId;
	public String getSalesRegion() {
		return salesRegion;
	}
	public void setSalesRegion(String salesRegion) {
		this.salesRegion = salesRegion;
	}
	public String getSalesOffice() {
		return salesOffice;
	}
	public void setSalesOffice(String salesOffice) {
		this.salesOffice = salesOffice;
	}
	public String getLdsmNameVal() {
		return ldsmNameVal;
	}
	public void setLdsmNameVal(String ldsmNameVal) {
		this.ldsmNameVal = ldsmNameVal;
	}
	public String getLdsmAsstVal() {
		return ldsmAsstVal;
	}
	public void setLdsmAsstVal(String ldsmAsstVal) {
		this.ldsmAsstVal = ldsmAsstVal;
	}
	public String getLifeSplVal() {
		return lifeSplVal;
	}
	public void setLifeSplVal(String lifeSplVal) {
		this.lifeSplVal = lifeSplVal;
	}
	public String getLifeSplAsstVal() {
		return lifeSplAsstVal;
	}
	public void setLifeSplAsstVal(String lifeSplAsstVal) {
		this.lifeSplAsstVal = lifeSplAsstVal;
	}
	public String getUwVal() {
		return uwVal;
	}
	public void setUwVal(String uwVal) {
		this.uwVal = uwVal;
	}
	public String getRateCalcTechVal() {
		return rateCalcTechVal;
	}
	public void setRateCalcTechVal(String rateCalcTechVal) {
		this.rateCalcTechVal = rateCalcTechVal;
	}
	public String getAcctManVal() {
		return acctManVal;
	}
	public void setAcctManVal(String acctManVal) {
		this.acctManVal = acctManVal;
	}
	public String getMidMktAcctMgrVal() {
		return midMktAcctMgrVal;
	}
	public void setMidMktAcctMgrVal(String midMktAcctMgrVal) {
		this.midMktAcctMgrVal = midMktAcctMgrVal;
	}
	public String getRegAdminDirVal() {
		return regAdminDirVal;
	}
	public void setRegAdminDirVal(String regAdminDirVal) {
		this.regAdminDirVal = regAdminDirVal;
	}
	public String getAcctExeNameVal() {
		return acctExeNameVal;
	}
	public void setAcctExeNameVal(String acctExeNameVal) {
		this.acctExeNameVal = acctExeNameVal;
	}
	public List<String> getLdsmName() {
		return ldsmName;
	}
	public void setLdsmName(List<String> ldsmName) {
		this.ldsmName = ldsmName;
	}
	public List<String> getLdsmAsstName() {
		return ldsmAsstName;
	}
	public void setLdsmAsstName(List<String> ldsmAsstName) {
		this.ldsmAsstName = ldsmAsstName;
	}
	public List<String> getLifeSplName() {
		return lifeSplName;
	}
	public void setLifeSplName(List<String> lifeSplName) {
		this.lifeSplName = lifeSplName;
	}
	public List<String> getLifeSplAsstName() {
		return lifeSplAsstName;
	}
	public void setLifeSplAsstName(List<String> lifeSplAsstName) {
		this.lifeSplAsstName = lifeSplAsstName;
	}
	public List<String> getUnderwriterName() {
		return underwriterName;
	}
	public void setUnderwriterName(List<String> underwriterName) {
		this.underwriterName = underwriterName;
	}
	public List<String> getRateCalcTechName() {
		return rateCalcTechName;
	}
	public void setRateCalcTechName(List<String> rateCalcTechName) {
		this.rateCalcTechName = rateCalcTechName;
	}
	public List<String> getAcctManagerName() {
		return acctManagerName;
	}
	public void setAcctManagerName(List<String> acctManagerName) {
		this.acctManagerName = acctManagerName;
	}
	public List<String> getMidMktAcctMgrName() {
		return midMktAcctMgrName;
	}
	public void setMidMktAcctMgrName(List<String> midMktAcctMgrName) {
		this.midMktAcctMgrName = midMktAcctMgrName;
	}
	public List<String> getRegAdminDirName() {
		return regAdminDirName;
	}
	public void setRegAdminDirName(List<String> regAdminDirName) {
		this.regAdminDirName = regAdminDirName;
	}
	public List<String> getAcctExeName() {
		return acctExeName;
	}
	public void setAcctExeName(List<String> acctExeName) {
		this.acctExeName = acctExeName;
	}
	public String getExtAgentName() {
		return extAgentName;
	}
	public void setExtAgentName(String extAgentName) {
		this.extAgentName = extAgentName;
	}
	public String getExtAgentOffice() {
		return extAgentOffice;
	}
	public void setExtAgentOffice(String extAgentOffice) {
		this.extAgentOffice = extAgentOffice;
	}
	public String getExtAgentPhone() {
		return extAgentPhone;
	}
	public void setExtAgentPhone(String extAgentPhone) {
		this.extAgentPhone = extAgentPhone;
	}
	public List<String> getSalesOfficeList() {
		return salesOfficeList;
	}
	public void setSalesOfficeList(List<String> salesOfficeList) {
		this.salesOfficeList = salesOfficeList;
	}	
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
}
