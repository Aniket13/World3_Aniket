package com.pru.sparc.bo.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Client {
	private String clientName;
	private String parentCompany;
	private String fullLegalName;
	private String dba;
	private String dAndB;
	private String duns;
	private String sic;
	private String sicDesc;
	private String natureOfBusiness;
	private String contractState;
	private boolean nonErisa;
	private String tin;
	private String contactName;
	private String contactEmail;
	private List<Address> address;
	private int clientId;
	
	public String getSicDesc() {
		return sicDesc;
	}
	public void setSicDesc(String sicDesc) {
		this.sicDesc = sicDesc;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getDba() {
		return dba;
	}
	public void setDba(String dba) {
		this.dba = dba;
	}
	public String getDuns() {
		return duns;
	}
	public void setDuns(String duns) {
		this.duns = duns;
	}
	public String getSic() {
		return sic;
	}
	public void setSic(String sic) {
		this.sic = sic;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getParentCompany() {
		return parentCompany;
	}
	public void setParentCompany(String parentCompany) {
		this.parentCompany = parentCompany;
	}
	public String getFullLegalName() {
		return fullLegalName;
	}
	public void setFullLegalName(String fullLegalName) {
		this.fullLegalName = fullLegalName;
	}
	public String getdAndB() {
		return dAndB;
	}
	public void setdAndB(String dAndB) {
		this.dAndB = dAndB;
	}
	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}
	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}
	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public boolean getNonErisa() {
		return nonErisa;
	}
	public void setNonErisa(boolean nonErisa) {
		this.nonErisa = nonErisa;
	}
	public String getTin() {
		return tin;
	}
	public void setTin(String tin) {
		this.tin = tin;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contacrEmail) {
		this.contactEmail = contacrEmail;
	}
	
	/*public Client (String clientName, String dba, String duns, String sic, Address address){
		this.address = address;
		this.clientName = clientName;
		this.dba = dba;
		this.duns = duns;
		this.sic = sic;
	}
	public Client() {
	}*/
}
