package com.pru.sparc.bo.model;


@SuppressWarnings("serial")
public class Holding extends BaseModel {
	private int clientId;
	private String clientName;
	private String sic;
	private String contractState;
	private String proposalId;
	private String prorposalDescription;
	private String proposalStatus;
	private String ldsmName;
	private String rateCalcTechnitian;
	private String effDate;
	private String producerName;
	private int versionNumber;
	private int productId;
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getSic() {
		return sic;
	}
	public void setSic(String sic) {
		this.sic = sic;
	}
	public String getContractState() {
		return contractState;
	}
	public void setContractState(String contractState) {
		this.contractState = contractState;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public String getProrposalDescription() {
		return prorposalDescription;
	}
	public void setProrposalDescription(String prorposalDescription) {
		this.prorposalDescription = prorposalDescription;
	}
	public String getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	public String getLdsmName() {
		return ldsmName;
	}
	public void setLdsmName(String ldsmName) {
		this.ldsmName = ldsmName;
	}
	public String getRateCalcTechnitian() {
		return rateCalcTechnitian;
	}
	public void setRateCalcTechnitian(String rateCalcTechnitian) {
		this.rateCalcTechnitian = rateCalcTechnitian;
	}
	public String getEffDate() {
		return effDate;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
}
