package com.pru.sparc.bo.model;

public class User {

	private String userId;
	private String userRole;
	private String isUserExcepRole;
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getIsUserExcepRole() {
		return isUserExcepRole;
	}
	public void setIsUserExcepRole(String isUserExcepRole) {
		this.isUserExcepRole = isUserExcepRole;
	}
	
}
