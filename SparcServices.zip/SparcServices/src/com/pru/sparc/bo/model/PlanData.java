package com.pru.sparc.bo.model;

public class PlanData {
	private String constate;
	private String planEffectivDt;
	private String planDesc;
	private String typeOfCase;
	private String pruValExcep;
	private String fieldLevleExcep;
	private String contriArrang;
	private String mimPartiPercent;
	private String volaCaveatPercent;
	private String compositeRating;
	private String ageBandRating;
	private String planId;
	private String prodCode;
	private String overrideInd;
	private String rateGurantee;
	private String rateExpression;
	private String amtOfInsurance;
	private String maxDollarAmt;
	private String minDollarAmt;
	private String multiOfEarning;
	private String roundingRule;
	private String roundingOccurs;
	private String ageRedSchedule;
	private String disabilityProvision;
	private String duration;
	private String volumeAmt;
	private String guranteeIssueLmt;
	private String dollarAmt;
	private String livingBenOptn;
	private String lboMax;
	private String lboPct;
	private String lboLifeExpectancy;
	private String coverageTermiRetire;
	private String travelAssist;
	private String earningDef;
	public String getConstate() {
		return constate;
	}
	public void setConstate(String constate) {
		this.constate = constate;
	}
	public String getPlanEffectivDt() {
		return planEffectivDt;
	}
	public void setPlanEffectivDt(String planEffectivDt) {
		this.planEffectivDt = planEffectivDt;
	}
	public String getPlanDesc() {
		return planDesc;
	}
	public void setPlanDesc(String planDesc) {
		this.planDesc = planDesc;
	}
	public String getTypeOfCase() {
		return typeOfCase;
	}
	public void setTypeOfCase(String typeOfCase) {
		this.typeOfCase = typeOfCase;
	}
	public String getPruValExcep() {
		return pruValExcep;
	}
	public void setPruValExcep(String pruValExcep) {
		this.pruValExcep = pruValExcep;
	}
	public String getFieldLevleExcep() {
		return fieldLevleExcep;
	}
	public void setFieldLevleExcep(String fieldLevleExcep) {
		this.fieldLevleExcep = fieldLevleExcep;
	}
	public String getContriArrang() {
		return contriArrang;
	}
	public void setContriArrang(String contriArrang) {
		this.contriArrang = contriArrang;
	}
	public String getMimPartiPercent() {
		return mimPartiPercent;
	}
	public void setMimPartiPercent(String mimPartiPercent) {
		this.mimPartiPercent = mimPartiPercent;
	}
	public String getVolaCaveatPercent() {
		return volaCaveatPercent;
	}
	public void setVolaCaveatPercent(String volaCaveatPercent) {
		this.volaCaveatPercent = volaCaveatPercent;
	}
	public String getCompositeRating() {
		return compositeRating;
	}
	public void setCompositeRating(String compositeRating) {
		this.compositeRating = compositeRating;
	}
	public String getAgeBandRating() {
		return ageBandRating;
	}
	public void setAgeBandRating(String ageBandRating) {
		this.ageBandRating = ageBandRating;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getProdCode() {
		return prodCode;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public String getOverrideInd() {
		return overrideInd;
	}
	public void setOverrideInd(String overrideInd) {
		this.overrideInd = overrideInd;
	}
	public String getRateGurantee() {
		return rateGurantee;
	}
	public void setRateGurantee(String rateGurantee) {
		this.rateGurantee = rateGurantee;
	}
	public String getRateExpression() {
		return rateExpression;
	}
	public void setRateExpression(String rateExpression) {
		this.rateExpression = rateExpression;
	}
	public String getAmtOfInsurance() {
		return amtOfInsurance;
	}
	public void setAmtOfInsurance(String amtOfInsurance) {
		this.amtOfInsurance = amtOfInsurance;
	}
	public String getMaxDollarAmt() {
		return maxDollarAmt;
	}
	public void setMaxDollarAmt(String maxDollarAmt) {
		this.maxDollarAmt = maxDollarAmt;
	}
	public String getMinDollarAmt() {
		return minDollarAmt;
	}
	public void setMinDollarAmt(String minDollarAmt) {
		this.minDollarAmt = minDollarAmt;
	}
	public String getMultiOfEarning() {
		return multiOfEarning;
	}
	public void setMultiOfEarning(String multiOfEarning) {
		this.multiOfEarning = multiOfEarning;
	}
	public String getRoundingRule() {
		return roundingRule;
	}
	public void setRoundingRule(String roundingRule) {
		this.roundingRule = roundingRule;
	}
	public String getRoundingOccurs() {
		return roundingOccurs;
	}
	public void setRoundingOccurs(String roundingOccurs) {
		this.roundingOccurs = roundingOccurs;
	}
	public String getAgeRedSchedule() {
		return ageRedSchedule;
	}
	public void setAgeRedSchedule(String ageRedSchedule) {
		this.ageRedSchedule = ageRedSchedule;
	}
	public String getDisabilityProvision() {
		return disabilityProvision;
	}
	public void setDisabilityProvision(String disabilityProvision) {
		this.disabilityProvision = disabilityProvision;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getVolumeAmt() {
		return volumeAmt;
	}
	public void setVolumeAmt(String volumeAmt) {
		this.volumeAmt = volumeAmt;
	}
	public String getGuranteeIssueLmt() {
		return guranteeIssueLmt;
	}
	public void setGuranteeIssueLmt(String guranteeIssueLmt) {
		this.guranteeIssueLmt = guranteeIssueLmt;
	}
	public String getDollarAmt() {
		return dollarAmt;
	}
	public void setDollarAmt(String dollarAmt) {
		this.dollarAmt = dollarAmt;
	}
	public String getLivingBenOptn() {
		return livingBenOptn;
	}
	public void setLivingBenOptn(String livingBenOptn) {
		this.livingBenOptn = livingBenOptn;
	}
	public String getLboMax() {
		return lboMax;
	}
	public void setLboMax(String lboMax) {
		this.lboMax = lboMax;
	}
	public String getLboPct() {
		return lboPct;
	}
	public void setLboPct(String lboPct) {
		this.lboPct = lboPct;
	}
	public String getLboLifeExpectancy() {
		return lboLifeExpectancy;
	}
	public void setLboLifeExpectancy(String lboLifeExpectancy) {
		this.lboLifeExpectancy = lboLifeExpectancy;
	}
	public String getCoverageTermiRetire() {
		return coverageTermiRetire;
	}
	public void setCoverageTermiRetire(String coverageTermiRetire) {
		this.coverageTermiRetire = coverageTermiRetire;
	}
	public String getTravelAssist() {
		return travelAssist;
	}
	public void setTravelAssist(String travelAssist) {
		this.travelAssist = travelAssist;
	}
	public String getEarningDef() {
		return earningDef;
	}
	public void setEarningDef(String earningDef) {
		this.earningDef = earningDef;
	}
}
