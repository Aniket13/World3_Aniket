package com.pru.sparc.bo.model;

import java.util.ArrayList;
import java.util.List;

public class ValidationWrapper {
	
	private String RoundingOccurs;
	private String planEffectiveDate;
	private String Duration;
	private String typeOfCase;
	private String proposalId;
	private String proposalVersion;
	private String planId;
	private String error;
	private List<ErrorDescription> errorList = new ArrayList<ErrorDescription>(); 
	
	public String getRoundingOccurs() {
		return RoundingOccurs;
	}
	public void setRoundingOccurs(String roundingOccurs) {
		RoundingOccurs = roundingOccurs;
	}
	public String getPlanEffectiveDate() {
		return planEffectiveDate;
	}
	public void setPlanEffectiveDate(String planEffectiveDate) {
		this.planEffectiveDate = planEffectiveDate;
	}
	public String getDuration() {
		return Duration;
	}
	public void setDuration(String duration) {
		Duration = duration;
	}
	public String getTypeOfCase() {
		return typeOfCase;
	}
	public void setTypeOfCase(String typeOfCase) {
		this.typeOfCase = typeOfCase;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public String getProposalVersion() {
		return proposalVersion;
	}
	public void setProposalVersion(String proposalVersion) {
		this.proposalVersion = proposalVersion;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	public void addToErrorList(ErrorDescription ed) {
		errorList.add(ed);
	}
	public List<ErrorDescription> getErrorList() {
		return errorList;
	}
	
	
	
	

}
