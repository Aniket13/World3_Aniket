package com.pru.sparc.bo.model;


import org.springframework.stereotype.Component;

@Component
public class CensusCls {

	private int censusClsId;
	private int censusId;
	private String classDesc;
	private boolean exempt;
	private boolean mgmt;
	private boolean medicallyUnd;
	private boolean salaried;
	private boolean smoker;
	private boolean retire;
	private boolean grandFather;
	private boolean colBargain;
	private boolean fulTime;
	private boolean classSelected;
	private int noOfLives;
	
	public int getCensusClsId() {
		return censusClsId;
	}
	public void setCensusClsId(int censusClsId) {
		this.censusClsId = censusClsId;
	}
	public int getCensusId() {
		return censusId;
	}
	public void setCensusId(int censusId) {
		this.censusId = censusId;
	}
	public String getClassDesc() {
		return classDesc;
	}
	public void setClassDesc(String classDesc) {
		this.classDesc = classDesc;
	}
	public boolean isExempt() {
		return exempt;
	}
	public void setExempt(boolean exempt) {
		this.exempt = exempt;
	}
	public boolean isMgmt() {
		return mgmt;
	}
	public void setMgmt(boolean mgmt) {
		this.mgmt = mgmt;
	}
	public boolean isMedicallyUnd() {
		return medicallyUnd;
	}
	public void setMedicallyUnd(boolean medicallyUnd) {
		this.medicallyUnd = medicallyUnd;
	}
	public boolean isSalaried() {
		return salaried;
	}
	public void setSalaried(boolean salaried) {
		this.salaried = salaried;
	}
	public boolean isSmoker() {
		return smoker;
	}
	public void setSmoker(boolean smoker) {
		this.smoker = smoker;
	}
	public boolean isRetire() {
		return retire;
	}
	public void setRetire(boolean retire) {
		this.retire = retire;
	}
	public boolean isGrandFather() {
		return grandFather;
	}
	public void setGrandFather(boolean grandFather) {
		this.grandFather = grandFather;
	}
	public boolean isColBargain() {
		return colBargain;
	}
	public void setColBargain(boolean colBargain) {
		this.colBargain = colBargain;
	}
	public boolean isFulTime() {
		return fulTime;
	}
	public void setFulTime(boolean fulTime) {
		this.fulTime = fulTime;
	}
	public boolean isClassSelected() {
		return classSelected;
	}
	public void setClassSelected(boolean classSelected) {
		this.classSelected = classSelected;
	}
	public int getNoOfLives() {
		return noOfLives;
	}
	public void setNoOfLives(int noOfLives) {
		this.noOfLives = noOfLives;
	}
	
	
	
}
