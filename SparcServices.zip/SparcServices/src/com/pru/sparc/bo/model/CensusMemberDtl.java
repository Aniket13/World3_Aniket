package com.pru.sparc.bo.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class CensusMemberDtl implements Serializable {

	private static final long serialVersionUID = 1L;

	private int censusId;
	private int censusMemId;
	private String censusClsId;
	private String addVolume;
	private String age;
	private String basicLifeVol;
	private String birthDate;
	private String city;
	private String dentalChildPart;
	private String dentalPart;
	private String dentalSpoucePart;
	private String dglChildVolume;
	private String dglSpouceVolume;
	private String empID;
	private String firstName;
	private String gender;
	private String govtID;
	private String hireDate;
	private String jobDescription;
	private String lastName;
	private String oaddVolume;
	private String occupationCode;
	private String oglVolume;
	private String residenceZip;
	private String salary;
	private String state;
	private String zipCode;

	private CensusCls memberClass;
	private String oglPart;
	private String dglSpoucePart;
	private String dglChildPart;
	private String oaddPart;
	private String optionalLtdPart;
	private String optionalStdPart;

	private List<CensusCls> memberClassList;
	private List<String> oglPartList;
	private List<String> dglSpoucePartList;
	private List<String> dglChildPartList;
	private List<String> oaddPartList;
	private List<String> optionalLtdPartList;
	private List<String> optionalStdPartList;

	
	public String getCensusClsId() {
		return censusClsId;
	}

	public void setCensusClsId(String censusClsId) {
		this.censusClsId = censusClsId;
	}

	public int getCensusMemId() {
		return censusMemId;
	}

	public void setCensusMemId(int censusMemId) {
		this.censusMemId = censusMemId;
	}

	public int getCensusId() {
		return censusId;
	}

	public void setCensusId(int censusId) {
		this.censusId = censusId;
	}

	public List<String> getOptionalStdPartList() {
		return optionalStdPartList;
	}

	public void setOptionalStdPartList(List<String> optionalStdPartList) {
		this.optionalStdPartList = optionalStdPartList;
	}

	

	public List<CensusCls> getMemberClassList() {
		return memberClassList;
	}

	public void setMemberClassList(List<CensusCls> memberClassList) {
		this.memberClassList = memberClassList;
	}

	public List<String> getOglPartList() {
		return oglPartList;
	}

	public void setOglPartList(List<String> oglPartList) {
		this.oglPartList = oglPartList;
	}

	public List<String> getDglSpoucePartList() {
		return dglSpoucePartList;
	}

	public void setDglSpoucePartList(List<String> dglSpoucePartList) {
		this.dglSpoucePartList = dglSpoucePartList;
	}

	public List<String> getDglChildPartList() {
		return dglChildPartList;
	}

	public void setDglChildPartList(List<String> dglChildPartList) {
		this.dglChildPartList = dglChildPartList;
	}

	public List<String> getOaddPartList() {
		return oaddPartList;
	}

	public void setOaddPartList(List<String> oaddPartList) {
		this.oaddPartList = oaddPartList;
	}

	public List<String> getOptionalLtdPartList() {
		return optionalLtdPartList;
	}

	public void setOptionalLtdPartList(List<String> optionalLtdPartList) {
		this.optionalLtdPartList = optionalLtdPartList;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public CensusCls getMemberClass() {
		return memberClass;
	}

	public void setMemberClass(CensusCls memberClass) {
		this.memberClass = memberClass;
	}

	public String getOglPart() {
		return oglPart;
	}

	public void setOglPart(String oglPart) {
		this.oglPart = oglPart;
	}

	public String getDglSpoucePart() {
		return dglSpoucePart;
	}

	public void setDglSpoucePart(String dglSpoucePart) {
		this.dglSpoucePart = dglSpoucePart;
	}

	public String getDglChildPart() {
		return dglChildPart;
	}

	public void setDglChildPart(String dglChildPart) {
		this.dglChildPart = dglChildPart;
	}

	public String getOaddPart() {
		return oaddPart;
	}

	public void setOaddPart(String oaddPart) {
		this.oaddPart = oaddPart;
	}

	public String getOptionalLtdPart() {
		return optionalLtdPart;
	}

	public void setOptionalLtdPart(String optionalLtdPart) {
		this.optionalLtdPart = optionalLtdPart;
	}

	public String getAddVolume() {
		return addVolume;
	}

	public void setAddVolume(String addVolume) {
		this.addVolume = addVolume;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getBasicLifeVol() {
		return basicLifeVol;
	}

	public void setBasicLifeVol(String basicLifeVol) {
		this.basicLifeVol = basicLifeVol;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDentalChildPart() {
		return dentalChildPart;
	}

	public void setDentalChildPart(String dentalChildPart) {
		this.dentalChildPart = dentalChildPart;
	}

	public String getDentalPart() {
		return dentalPart;
	}

	public void setDentalPart(String dentalPart) {
		this.dentalPart = dentalPart;
	}

	public String getDentalSpoucePart() {
		return dentalSpoucePart;
	}

	public void setDentalSpoucePart(String dentalSpoucePart) {
		this.dentalSpoucePart = dentalSpoucePart;
	}

	public String getDglChildVolume() {
		return dglChildVolume;
	}

	public void setDglChildVolume(String dglChildVolume) {
		this.dglChildVolume = dglChildVolume;
	}

	public String getDglSpouceVolume() {
		return dglSpouceVolume;
	}

	public void setDglSpouceVolume(String dglSpouceVolume) {
		this.dglSpouceVolume = dglSpouceVolume;
	}

	public String getEmpID() {
		return empID;
	}

	public void setEmpID(String empID) {
		this.empID = empID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getGovtID() {
		return govtID;
	}

	public void setGovtID(String govtID) {
		this.govtID = govtID;
	}

	public String getHireDate() {
		return hireDate;
	}

	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOaddVolume() {
		return oaddVolume;
	}

	public void setOaddVolume(String oaddVolume) {
		this.oaddVolume = oaddVolume;
	}

	public String getOccupationCode() {
		return occupationCode;
	}

	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	public String getOglVolume() {
		return oglVolume;
	}

	public void setOglVolume(String oglVolume) {
		this.oglVolume = oglVolume;
	}

	public String getOptionalStdPart() {
		return optionalStdPart;
	}

	public void setOptionalStdPart(String optionalStdPart) {
		this.optionalStdPart = optionalStdPart;
	}

	public String getResidenceZip() {
		return residenceZip;
	}

	public void setResidenceZip(String residenceZip) {
		this.residenceZip = residenceZip;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	@Override
	public String toString() {
		return "CensusMemberDtl [censusId=" + censusId + ", censusMemId="
				+ censusMemId + ", addVolume=" + addVolume + ", age=" + age
				+ ", basicLifeVol=" + basicLifeVol + ", birthDate=" + birthDate
				+ ", city=" + city + ", dentalChildPart=" + dentalChildPart
				+ ", dentalPart=" + dentalPart + ", dentalSpoucePart="
				+ dentalSpoucePart + ", dglChildVolume=" + dglChildVolume
				+ ", dglSpouceVolume=" + dglSpouceVolume + ", empID=" + empID
				+ ", firstName=" + firstName + ", gender=" + gender
				+ ", govtID=" + govtID + ", hireDate=" + hireDate
				+ ", jobDescription=" + jobDescription + ", lastName="
				+ lastName + ", oaddVolume=" + oaddVolume + ", occupationCode="
				+ occupationCode + ", oglVolume=" + oglVolume
				+ ", residenceZip=" + residenceZip + ", salary=" + salary
				+ ", state=" + state + ", zipCode=" + zipCode
				+ ", memberClass=" + memberClass + ", oglPart=" + oglPart
				+ ", dglSpoucePart=" + dglSpoucePart + ", dglChildPart="
				+ dglChildPart + ", oaddPart=" + oaddPart
				+ ", optionalLtdPart=" + optionalLtdPart + ", optionalStdPart="
				+ optionalStdPart + ", memberClassList=" + memberClassList
				+ ", oglPartList=" + oglPartList + ", dglSpoucePartList="
				+ dglSpoucePartList + ", dglChildPartList=" + dglChildPartList
				+ ", oaddPartList=" + oaddPartList + ", optionalLtdPartList="
				+ optionalLtdPartList + ", optionalStdPartList="
				+ optionalStdPartList + "]";
	}


}
