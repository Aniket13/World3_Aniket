package com.pru.sparc.bo.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class PlanDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	public PlanDetails() {
	}
// discuss uses of this class with mayur in his product details class and delete it if not needed
	private List<String> allValues;
	private String fieldType;
	private String id;
	private String label;
	private boolean isOverRidden;
	private String value;
	private boolean isShow;

	
	public boolean isShow() {
		return isShow;
	}
	public void setShow(boolean isShow) {
		this.isShow = isShow;
	}
	public List<String> getAllValues() {
		return allValues;
	}
	public void setAllValues(List<String> allValues) {
		this.allValues = allValues;
	}
	public void setOverRidden(boolean isOverRidden) {
		this.isOverRidden = isOverRidden;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public boolean getIsOverRidden() {
		return isOverRidden;
	}
	public void setIsOverRidden(boolean isOverRidden) {
		this.isOverRidden = isOverRidden;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	

}
