package com.pru.sparc.bo.model;

public class DroolsDynamicPlanFields {
	
	String product;
	String plan;
	String state;
	String constate;
	String planeffdt;
	String plandesc;
	String typeofcase;
	String pruvalexcp;
	String fildlvlexcp;
	String contrarrang;
	String minpartpercn;
	String volcavpercn;
	String comprat;
	String agebndrat;
	
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getConstate() {
		return constate;
	}
	public void setConstate(String constate) {
		this.constate = constate;
	}
	public String getPlaneffdt() {
		return planeffdt;
	}
	public void setPlaneffdt(String planeffdt) {
		this.planeffdt = planeffdt;
	}
	public String getPlandesc() {
		return plandesc;
	}
	public void setPlandesc(String plandesc) {
		this.plandesc = plandesc;
	}
	public String getTypeofcase() {
		return typeofcase;
	}
	public void setTypeofcase(String typeofcase) {
		this.typeofcase = typeofcase;
	}
	public String getPruvalexcp() {
		return pruvalexcp;
	}
	public void setPruvalexcp(String pruvalexcp) {
		this.pruvalexcp = pruvalexcp;
	}
	public String getFildlvlexcp() {
		return fildlvlexcp;
	}
	public void setFildlvlexcp(String fildlvlexcp) {
		this.fildlvlexcp = fildlvlexcp;
	}
	public String getContrarrang() {
		return contrarrang;
	}
	public void setContrarrang(String contrarrang) {
		this.contrarrang = contrarrang;
	}
	public String getMinpartpercn() {
		return minpartpercn;
	}
	public void setMinpartpercn(String minpartpercn) {
		this.minpartpercn = minpartpercn;
	}
	public String getVolcavpercn() {
		return volcavpercn;
	}
	public void setVolcavpercn(String volcavpercn) {
		this.volcavpercn = volcavpercn;
	}
	public String getComprat() {
		return comprat;
	}
	public void setComprat(String comprat) {
		this.comprat = comprat;
	}
	public String getAgebndrat() {
		return agebndrat;
	}
	public void setAgebndrat(String agebndrat) {
		this.agebndrat = agebndrat;
	}
}
