package com.pru.sparc.bo.model;


public class Product {
	private int productId;
	private String productDesc;
	//private Plan plan;
	
	public String getProductDesc() {
		return productDesc;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	/*public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}*/
}
