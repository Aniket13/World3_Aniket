package com.pru.sparc.bo.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class PlanMetadata {
	private String ruleId;
	private int fieldSeqId;
	private String fieldName;
	private String fieldType;
	private String fieldKey;
	private String fieldValue;
	private String visibleFlag;
	//private List<PlanConfigLookup> altValues;
	private Map<String,PlanConfigLookup> altValues;
	private String overriddenFlag; // Value like Y or N
	private String maxLength;
	private String minLength;
	private String onFocus; // to pass the function name that needs to invoke from UI e.g functiona1()
	private String onChange; // to pass the function name that needs to invoke from UI
	private String onBlur; // to pass the function name that needs to invoke from UI
	private String fieldIndicator; // A,C and R
	private String tabId;
	private String fieldInfo;
	private String originalField;
	private String overriddenField;
	
	public int getFieldSeqId() {
		return fieldSeqId;
	}
	public void setFieldSeqId(int fieldSeqId) {
		this.fieldSeqId = fieldSeqId;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public String getFieldKey() {
		return fieldKey;
	}
	public void setFieldKey(String fieldKey) {
		this.fieldKey = fieldKey;
	}
	public String getOverriddenFlag() {
		return overriddenFlag;
	}
	public void setOverriddenFlag(String overriddenFlag) {
		this.overriddenFlag = overriddenFlag;
	}
	public String getMaxLength() {
		return maxLength;
	}
	public void setMaxLength(String maxLength) {
		this.maxLength = maxLength;
	}
	public String getMinLength() {
		return minLength;
	}
	public void setMinLength(String minLength) {
		this.minLength = minLength;
	}
	public String getOnFocus() {
		return onFocus;
	}
	public void setOnFocus(String onFocus) {
		this.onFocus = onFocus;
	}
	public String getOnChange() {
		return onChange;
	}
	public void setOnChange(String onChange) {
		this.onChange = onChange;
	}
	public String getOnBlur() {
		return onBlur;
	}
	public void setOnBlur(String onBlur) {
		this.onBlur = onBlur;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public String getVisibleFlag() {
		return visibleFlag;
	}
	public void setVisibleFlag(String visibleFlag) {
		this.visibleFlag = visibleFlag;
	}
	
	public Map<String, PlanConfigLookup> getAltValues() {
		return altValues;
	}
	public void setAltValues(Map<String, PlanConfigLookup> altValues) {
		this.altValues = altValues;
	}
	public String getFieldIndicator() {
		return fieldIndicator;
	}
	public void setFieldIndicator(String fieldIndicator) {
		this.fieldIndicator = fieldIndicator;
	}
	public String getTabId() {
		return tabId;
	}
	public void setTabId(String tabId) {
		this.tabId = tabId;
	}
	public String getFieldInfo() {
		return fieldInfo;
	}
	public void setFieldInfo(String fieldInfo) {
		this.fieldInfo = fieldInfo;
	}
	
	public String getOriginalField() {
		return originalField;
	}
	public void setOriginalField(String originalField) {
		this.originalField = originalField;
	}
	@Override
	public String toString() {
		return "PlanMetadata [ruleId=" + ruleId + ", fieldSeqId=" + fieldSeqId
				+ ", fieldName=" + fieldName + ", fieldType=" + fieldType
				+ ", fieldKey=" + fieldKey + ", fieldValue=" + fieldValue
				+ ", visibleFlag=" + visibleFlag + ", altValues=" + altValues
				+ ", overriddenFlag=" + overriddenFlag + ", maxLength="
				+ maxLength + ", minLength=" + minLength + ", onFocus="
				+ onFocus + ", onChange=" + onChange + ", onBlur=" + onBlur
				+ ", fieldIndicator=" + fieldIndicator + "]";
	}
	
	/* For PlanConfig Logging credated on 08/15/2016 */
	public static PlanMetadata createCopy(PlanMetadata old) {
		PlanMetadata cloneNew= new PlanMetadata();
		cloneNew.ruleId = old.ruleId;
		cloneNew.fieldSeqId = old.fieldSeqId;
		cloneNew.fieldName = old.fieldName;
		cloneNew.fieldType = old.fieldType;
		cloneNew.fieldKey = old.fieldKey;
		cloneNew.fieldValue = old.fieldValue;
		cloneNew.visibleFlag = old.visibleFlag;
		if(null!= old.altValues)
		{
			Map antValTemp=new HashMap();
			for(Entry<String, PlanConfigLookup> entry :old.getAltValues().entrySet())
				antValTemp.put(entry.getKey(),PlanConfigLookup.createCopy(entry.getValue()));
			
			cloneNew.altValues = antValTemp;
		}
		else
		cloneNew.altValues = old.altValues;
		
		cloneNew.overriddenFlag = old.overriddenFlag;
		cloneNew.maxLength = old.maxLength;
		cloneNew.minLength = old.minLength;
		cloneNew.onFocus = old.onFocus;
		cloneNew.onChange = old.onChange;
		cloneNew.onBlur = old.onBlur;
		cloneNew.fieldIndicator = old.fieldIndicator;
		cloneNew.tabId = old.tabId;
		cloneNew.fieldInfo = old.fieldInfo;
		return cloneNew;
	}
	
	@Override
	public boolean equals(Object other) {
	  
		if (!(other instanceof PlanMetadata)) {
	        return false;
	    }

		PlanMetadata that = (PlanMetadata) other;
		boolean antPlanConfigLkp=false;
		boolean ruleIdFlag=false;
		boolean fieldNameFlag=false;
		boolean fieldTypeFlag=false;
		boolean fieldKeyFlag=false;
		boolean fieldValueFlag=false;
		boolean visibleFlagFlag=false;
		boolean overriddenFlagFlag=false;
		boolean maxLengthFlag=false;
		boolean minLengthFlag=false;
		boolean onFocusFlag=false;
		boolean onChangeFlag=false;
		boolean onBlurFlag=false;
		boolean fieldIndicatorFlag=false;
		
		if(null!=this.altValues && null!=that.altValues)
		antPlanConfigLkp=this.altValues.equals(that.altValues);
		if(null==this.altValues && null==that.altValues)
			antPlanConfigLkp=true;
	    // Custom equality check here.
		if(null!=this.ruleId && null!=that.ruleId)
			ruleIdFlag=this.ruleId.equals(that.ruleId);
		if(null==this.ruleId && null==that.ruleId)
			ruleIdFlag=true;
		
		if(null!=this.fieldName && null!=that.fieldName)
			fieldNameFlag=this.fieldName.equals(that.fieldName);
		if(null==this.fieldName && null==that.fieldName)
			fieldNameFlag=true;
		
		if(null!=this.fieldType && null!=that.fieldType)
			fieldTypeFlag=this.fieldType.equals(that.fieldType);
		if(null==this.fieldType && null==that.fieldType)
			fieldTypeFlag=true;
		
		if(null!=this.fieldKey && null!=that.fieldKey)
			fieldKeyFlag=this.fieldKey.equals(that.fieldKey);
		if(null==this.fieldKey && null==that.fieldKey)
			fieldKeyFlag=true;
		
		if(null!=this.fieldValue && null!=that.fieldValue)
			fieldValueFlag=this.fieldValue.equals(that.fieldValue);
		if(null==this.fieldValue && null==that.fieldValue)
			fieldValueFlag=true;
		
		if(null!=this.visibleFlag && null!=that.visibleFlag)
			visibleFlagFlag=this.visibleFlag.equals(that.visibleFlag);
		if(null==this.visibleFlag && null==that.visibleFlag)
			visibleFlagFlag=true;
		
		if(null!=this.overriddenFlag && null!=that.overriddenFlag)
			overriddenFlagFlag=this.overriddenFlag.equals(that.overriddenFlag);
		if(null==this.overriddenFlag && null==that.overriddenFlag)
			overriddenFlagFlag=true;
		
		if(null!=this.maxLength && null!=that.maxLength)
			maxLengthFlag=this.maxLength.equals(that.maxLength);
		if(null==this.maxLength && null==that.maxLength)
			maxLengthFlag=true;
		
		if(null!=this.minLength && null!=that.minLength)
			minLengthFlag=this.minLength.equals(that.minLength);
		if(null==this.minLength && null==that.minLength)
			minLengthFlag=true;
		
		if(null!=this.onFocus && null!=that.onFocus)
			onFocusFlag=this.onFocus.equals(that.onFocus);
		if(null==this.onFocus && null==that.onFocus)
			onFocusFlag=true;

		if(null!=this.onChange && null!=that.onChange)
			onChangeFlag=this.onChange.equals(that.onChange);
		if(null==this.onChange && null==that.onChange)
			onChangeFlag=true;

		if(null!=this.onBlur && null!=that.onBlur)
			onBlurFlag=this.onBlur.equals(that.onBlur);
		if(null==this.onBlur && null==that.onBlur)
			onBlurFlag=true;

		if(null!=this.fieldIndicator && null!=that.fieldIndicator)
			fieldIndicatorFlag=this.fieldIndicator.equals(that.fieldIndicator);
		if(null==this.fieldIndicator && null==that.fieldIndicator)
			fieldIndicatorFlag=true;
		
	    return antPlanConfigLkp 
	    	&& ruleIdFlag
	        && this.fieldSeqId==that.fieldSeqId
	        && fieldNameFlag
	        && fieldTypeFlag
	        && fieldKeyFlag
	        && fieldValueFlag
	        && visibleFlagFlag
	        && overriddenFlagFlag
	        && maxLengthFlag
	        && minLengthFlag
	        && onFocusFlag
	        && onChangeFlag
	        && onBlurFlag
	        && fieldIndicatorFlag;
	    
	}
	public String getOverriddenField() {
		return overriddenField;
	}
	public void setOverriddenField(String overriddenField) {
		this.overriddenField = overriddenField;
	}
}
