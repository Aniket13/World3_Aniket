package com.pru.sparc.bo.model;

import java.util.Set;

public class PerformanceGuarantee {
	private int versionNumber;
	private String proposalId;
	private int performanceId;
	private String performanceType;
	private String performanceCategory;
	private double flatAmount;
	private Set<String> fieldValues;
	public Set<String> getFieldValues() {
		return fieldValues;
	}
	public void setFieldValues(Set<String> fieldValues) {
		this.fieldValues = fieldValues;
	}
	public int getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public int getPerformanceId() {
		return performanceId;
	}
	public void setPerformanceId(int performanceId) {
		this.performanceId = performanceId;
	}
	public String getPerformanceType() {
		return performanceType;
	}
	public void setPerformanceType(String performanceType) {
		this.performanceType = performanceType;
	}
	public String getPerformanceCategory() {
		return performanceCategory;
	}
	public void setPerformanceCategory(String performanceCategory) {
		this.performanceCategory = performanceCategory;
	}
	public double getFlatAmount() {
		return flatAmount;
	}
	public void setFlatAmount(double flatAmount) {
		this.flatAmount = flatAmount;
	}
}
