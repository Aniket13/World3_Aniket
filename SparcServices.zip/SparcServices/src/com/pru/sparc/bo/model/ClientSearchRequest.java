package com.pru.sparc.bo.model;

import org.springframework.stereotype.Component;

@Component
public class ClientSearchRequest {
	private String clientName;
	private String dba;
	private String city;
	private String proposalId;
	private String controlNo;
	private String state;
	private String dAndB;
	private String sic;
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getDba() {
		return dba;
	}
	public void setDba(String dba) {
		this.dba = dba;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public String getControlNo() {
		return controlNo;
	}
	public void setControlNo(String controlNo) {
		this.controlNo = controlNo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getdAndB() {
		return dAndB;
	}
	public void setdAndB(String dAndB) {
		this.dAndB = dAndB;
	}
	public String getSic() {
		return sic;
	}
	public void setSic(String sic) {
		this.sic = sic;
	}
}
