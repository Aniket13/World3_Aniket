package com.pru.sparc.bo.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.pru.sparc.bo.model.PlanMetadata;

public class PlanDetailsMap {

	Map<String, PlanMetadata> planMap = new HashMap<String, PlanMetadata>();
	public String planCreationDate;
	public User user;
	public String currentDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
	public int totalLives;
	public String sicId;

	public String getCurrentDate() {
		return currentDate;
	}

	public Map<String, PlanMetadata> getPlanMap() {
		return planMap;
	}

	public void setPlanMap(Map<String, PlanMetadata> planMap) {
		this.planMap = planMap;
	}

	
	
	public String getPlanCreationDate() {
		return planCreationDate;
	}

	public void setPlanCreationDate(String planCreationDate) {
		this.planCreationDate = planCreationDate;
	}

	public PlanMetadata get(Object key) {
		return this.getPlanMap().get(key);
	}

	public void put(Object key, PlanMetadata value) {
		this.getPlanMap().put((String) key, value);
	}

	public boolean contains(Object key){
		return this.getPlanMap().containsKey(key);
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}

	public int getTotalLives() {
		return totalLives;
	}

	public void setTotalLives(int totalLives) {
		this.totalLives = totalLives;
	}

	public String getSicId() {
		return sicId;
	}

	public void setSicId(String sicId) {
		this.sicId = sicId;
	}

	
	@Override
	public String toString() {
		return "PlanDetailsMap [planMap=" + planMap + ", planCreationDate="
				+ planCreationDate + ", user=" + user + ", currentDate="
				+ currentDate + ", totalLives=" + totalLives + ", sicId="
				+ sicId + "]";
	}

	
	
	
	
}
