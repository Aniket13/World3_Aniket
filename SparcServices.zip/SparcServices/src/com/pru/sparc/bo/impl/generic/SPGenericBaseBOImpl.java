package com.pru.sparc.bo.impl.generic;

public class SPGenericBaseBOImpl {

}
