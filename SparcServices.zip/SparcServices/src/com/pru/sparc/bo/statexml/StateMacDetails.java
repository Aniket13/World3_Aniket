package com.pru.sparc.bo.statexml;

import org.springframework.stereotype.Component;

@Component
public class StateMacDetails {

	private String currState;
	private String proposalId;
	private String versionStatus;
	private String proposalStatus;
	private String stateStatus;
	private String preCond;
	private String postCond;
	private String userId;
	public String getCurrState() {
		return currState;
	}
	public void setCurrState(String currState) {
		this.currState = currState;
	}
	public String getProposalId() {
		return proposalId;
	}
	public void setProposalId(String proposalId) {
		this.proposalId = proposalId;
	}
	public String getVersionStatus() {
		return versionStatus;
	}
	public void setVersionStatus(String versionStatus) {
		this.versionStatus = versionStatus;
	}
	public String getProposalStatus() {
		return proposalStatus;
	}
	public void setProposalStatus(String proposalStatus) {
		this.proposalStatus = proposalStatus;
	}
	public String getStateStatus() {
		return stateStatus;
	}
	public void setStateStatus(String stateStatus) {
		this.stateStatus = stateStatus;
	}
	public String getPreCond() {
		return preCond;
	}
	public void setPreCond(String preCond) {
		this.preCond = preCond;
	}
	public String getPostCond() {
		return postCond;
	}
	public void setPostCond(String postCond) {
		this.postCond = postCond;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
