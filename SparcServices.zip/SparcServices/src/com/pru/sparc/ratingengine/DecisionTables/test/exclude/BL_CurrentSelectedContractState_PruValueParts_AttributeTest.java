package com.pru.sparc.ratingengine.DecisionTables.test.exclude;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;



public class BL_CurrentSelectedContractState_PruValueParts_AttributeTest {
	
	@Test
	public void test_CurrentSelectedContractStatePruValueParts_Attribute_Rule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		//....Plan Creation Date Start .....
		plan.setPlanCreationDate("12/31/2098");
		
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.PRU_VALUE_PARTS_ATTR);
		planMetaD.setFieldValue("Grandfathering");

		PlanMetadata planMetaDContract = new PlanMetadata();
		planMetaDContract.setFieldKey("Current_Selected_Contract_State_Attribute");
		planMetaDContract.setFieldValue("CT");
		
		
		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_PARTS_ATTR,planMetaD);
		plan.getPlanMap().put(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE,planMetaDContract);
		
		PlanMetadata planMetaLBO = new PlanMetadata();
		planMetaLBO.setFieldKey(PlanConfigConstants.LIVING_BENEFIT_OPTION_ATTR);
		PlanConfigLookup pllkp12= new PlanConfigLookup();
		pllkp12.setLookupKey("Living_Benefit_Option_Attributes__LBO_Maximum");
		pllkp12.setLookupValue("500000.0");
		pllkp12.setLookupOrder(1);
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Living_Benefit_Option_Attributes__LBO_Maximum", pllkp12);
		
		planMetaLBO.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.LIVING_BENEFIT_OPTION_ATTR,planMetaLBO);
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_CurrentSelectedContractState_PruValueParts_Attribute.xls",
						"", new Object[] { plan});
		

		assertTrue(plan.get(PlanConfigConstants.LIVING_BENEFIT_OPTION_ATTR).getAltValues().get("Living_Benefit_Option_Attributes__LBO_Maximum").getVisibleFlag().equals("No"));
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
	}
}
