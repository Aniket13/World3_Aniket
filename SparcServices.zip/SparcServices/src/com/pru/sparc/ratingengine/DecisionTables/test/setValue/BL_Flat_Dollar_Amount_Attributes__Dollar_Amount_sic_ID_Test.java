package com.pru.sparc.ratingengine.DecisionTables.test.setValue;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.common.util.PlanUtil;
import com.pru.sparc.drools.helper.RuleUtility;

public class BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID_Test {

	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("Grandfathering");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		planM2.setFieldValue("7810000");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("100");
		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,
						planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID.xls",
						"", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	/*@Test
	public void test_BL_Percentage_of_Basic_Life_Active_Amount_Attributes__Maximum_Dollar_Amount_990() {
		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2006");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM1.setFieldValue("false");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM2.setFieldValue("RETIREE LIFE");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM3.setFieldValue("1200000.0445454");

		plan.getPlanMap().put(
				PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE,
				planM1);
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, planM2);
		plan.getPlanMap()
				.put(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT,
						planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"basicLife//SetValue//BL_Percentage_of_Basic_Life_Active_Amount_Attributes__Maximum_Dollar_Amount_990.xls",
						"Percentage_of_Basic_Life_Active_Amount_Attributes__Maximum_Dollar_Amount",
						new Object[] { plan });


		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}*/
	
	
	/*@Test
	public void test_BL_Percentage_of_Basic_Life_Active_Amount_Attributes__Minimum_Dollar_Amount_991() {
		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2006");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM1.setFieldValue("false");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM2.setFieldValue("RETIREE LIFE");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT);
		planM3.setFieldValue("144.78744");

		plan.getPlanMap().put(
				PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE,
				planM1);
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, planM2);
		plan.getPlanMap()
				.put(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT,
						planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"basicLife//SetValue//BL_Percentage_of_Basic_Life_Active_Amount_Attributes__Minimum_Dollar_Amount_991.xls",
						"Percentage_of_Basic_Life_Active_Amount_Attributes__Minimum_Dollar_Amount",
						new Object[] { plan });


		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}*/
	
	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID_Not() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");
		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("Grandfathering");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		planM2.setFieldValue("1700000000");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("100");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,
						planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID_Not.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes_Maximum_Dollar_Amount() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue IFS");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM2.setFieldValue("1570000");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.TOTAL_LIVES);
		planM3.setFieldValue("26");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT,
						planM2);
		plan.getPlanMap().put(PlanConfigConstants.TOTAL_LIVES, planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes_Maximum_Dollar_Amount.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Living_Benefit_Option_Attributes__LBO_Maximum() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue IFS");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.LBO_MAX);
		planM2.setFieldValue("1570");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.TOTAL_LIVES);
		planM3.setFieldValue("2");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap().put(PlanConfigConstants.LBO_MAX, planM2);
		plan.getPlanMap().put(PlanConfigConstants.TOTAL_LIVES, planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Living_Benefit_Option_Attributes__LBO_Maximum.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Guarantee_Issue_Limit_Attributes__Maximum_Dollar_Cap() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue GA");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP);
		planM2.setFieldValue("1570000");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.TOTAL_LIVES);
		planM3.setFieldValue("7");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP,
						planM2);
		plan.getPlanMap().put(PlanConfigConstants.TOTAL_LIVES, planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Guarantee_Issue_Limit_Attributes__Maximum_Dollar_Cap.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Guarantee_Issue_Limit_Attributes__Dollar_Amount() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue IFS");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__DOLLAR_AMOUNT);
		planM2.setFieldValue("1000000");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.TOTAL_LIVES);
		planM3.setFieldValue("3");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__DOLLAR_AMOUNT,
						planM2);
		plan.getPlanMap().put(PlanConfigConstants.TOTAL_LIVES, planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Guarantee_Issue_Limit_Attributes__Dollar_Amount.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_Pru() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue GA");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		planM2.setFieldValue("157001111");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.TOTAL_LIVES);
		planM3.setFieldValue("11");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,
						planM2);
		plan.getPlanMap().put(PlanConfigConstants.TOTAL_LIVES, planM3);
		System.out.println(plan.getTotalLives());
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_Pru.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes__Minimum_Dollar_Amount() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue GA");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT);
		planM2.setFieldValue("1400");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT,
						planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes__Minimum_Dollar_Amount.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings_Pru() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("Non-PruValue");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS);
		planM2.setFieldValue("104");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS,
						planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings_Pru.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings_Pru1018() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue IFS");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS);
		planM2.setFieldValue("104");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS,
						planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings_Pru1018.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes__Minimum_Dollar_Amount1015() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("Non-PruValue");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT);
		planM2.setFieldValue("1000000004");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT,
						planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes__Minimum_Dollar_Amount1015.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount1014() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("Non-PruValue");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM2.setFieldValue("1004");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT,
						planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount1014.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Living_Benefit_Option_Attributes__LBO_Percentage_1013() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue IFS");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.LBO_PCT);
		planM2.setFieldValue("14");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap().put(PlanConfigConstants.LBO_PCT, planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Living_Benefit_Option_Attributes__LBO_Percentage_1013.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Living_Benefit_Option_Attributes__LBO_Percentage_1012() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("Non-PruValue");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.LBO_PCT);
		planM2.setFieldValue("14");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap().put(PlanConfigConstants.LBO_PCT, planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Living_Benefit_Option_Attributes__LBO_Percentage_1012.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Living_Benefit_Option_Attributes__LBO_Maximum1011() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue IFS");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.LBO_MAX);
		planM2.setFieldValue("14000000");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap().put(PlanConfigConstants.LBO_MAX, planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Living_Benefit_Option_Attributes__LBO_Maximum1011.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_1008() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2000");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue IFS");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		planM2.setFieldValue("14000000");

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,
						planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_1008.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void BL_Coverage_Terminates_at_Retirement_1006() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2000");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM1.setFieldValue("PruValue GA");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.COV_TERMI_RETI);

		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM1);
		plan.getPlanMap().put(PlanConfigConstants.COV_TERMI_RETI, planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Coverage_Terminates_at_Retirement_1006.xls",
						"", new Object[] { plan });
		System.out.println(plan.getPlanMap()
				.get(PlanConfigConstants.COV_TERMI_RETI).getVisibleFlag());

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void BL_Plan_Contribution_Attributes__Minimum_Participation_Percentage_998() {

		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2000");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE);
		planM1.setFieldValue("707");

		// PlanMetadata planM2 = new PlanMetadata();
		// planM2.setFieldKey(PlanConfigConstants.COV_TERMI_RETI);

		plan.getPlanMap()
				.put(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE,
						planM1);
		// plan.getPlanMap().put(PlanConfigConstants.COV_TERMI_RETI, planM2);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Plan_Contribution_Attributes__Minimum_Participation_Percentage_998.xls",
						"", new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings_982() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2000");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLYATTRIBUTE);
		planM1.setFieldValue("false");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT);
		planM2.setFieldValue("0");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS);
		planM3.setFieldValue("2");

		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS);

		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS__NO_EXCEPTION_MAX);

		plan.getPlanMap().put(
				PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLYATTRIBUTE,
				planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT,
						planM2);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS,
						planM3);

		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS,
						planM4);
		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS__NO_EXCEPTION_MAX,
						planM5);
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings_982.xls",
						"Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings",
						new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void round() {
		PlanDetailsMap plan = new PlanDetailsMap();
		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLYATTRIBUTE);
		planM1.setFieldValue("12.0445454");
		// [RHSParts].floatVaIue << max(0,min((0.05 *
		// Round(([RHSParts].floatvalue / 0.05))), 0.75))
		plan.getPlanMap().put(
				PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLYATTRIBUTE,
				planM1);
		// PlanUtil.roundValue(0.05,
		// Float.parseFloat(plan.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLYATTRIBUTE).getFieldValue()),
		// 0.05);
		PlanUtil.roundValue(0.05f, Float.parseFloat(plan.get(
				PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLYATTRIBUTE)
				.getFieldValue()), 0.05f);
	}

	/*@Test
	public void test_Percentage_of_Basic_Life_Active_Amount_Attributes__Maximum_Dollar_Amount992() {
		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2006");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM1.setFieldValue("false");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM2.setFieldValue("RETIREE LIFE");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_ATTRIBUTES__PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT);
		planM3.setFieldValue("12.0445454");

		plan.getPlanMap().put(
				PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE,
				planM1);
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, planM2);
		plan.getPlanMap()
				.put(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_ATTRIBUTES__PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT,
						planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"basicLife//SetValue//BL_Percentage_of_Basic_Life_Active_Amount_Attributes__Maximum_Dollar_Amount_992.xls",
						"Percentage_of_Basic_Life_Active_Amount_Attributes__Maximum_Dollar_Amount",
						new Object[] { plan });


		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}*/

	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_1003() {
		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2000");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM2.setFieldValue("RETIREE LIFE");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		planM3.setFieldValue("200100.24587");

		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, planM2);
		plan.getPlanMap()
				.put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,
						planM3);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_1003.xls",
						"Flat_Dollar_Amount_Attributes__Dollar_Amount",
						new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount_1035() {
		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2010");
		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM1.setFieldValue("14047845487");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM2.setFieldValue("PruValue IFS");

		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT,
						planM1);
		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM2);

		plan.setTotalLives(26);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount_1035.xls",
						"Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount",
						new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount_1038() {
		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2010");
		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM1.setFieldValue("14");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM2.setFieldValue("PruValue IFS");

		plan.getPlanMap()
				.put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT,
						planM1);
		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM2);

		plan.setTotalLives(11);

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount_1038.xls",
						"Multiple_of_Earnings_Attributes__Maximum_Dollar_Amount",
						new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	@Test
	public void test_BL_Disability_Provision_Premium_Contnuance_Details_Attributes_948() {
		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2010");
		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM1.setFieldValue("true");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.DISABILITY_PROVISION_PREMIUM_CONTNUANCE_DETAILS_ATTRIBUTES__PREMIUM_CONTINUANCE_DETAILS);
		planM2.setFieldValue("1004");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.DISABILITY__PROVISION_PREMIUM_CONTINUANCE_DETAILS_EXCEPTION_ATTRIBUTES);
		planM3.setFieldValue("140");

		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.IS_USER_EXCEPTION_ROLE_ATTRIBUTE);
		planM4.setFieldValue("false");

		plan.getPlanMap().put(
				PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE,
				planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.DISABILITY_PROVISION_PREMIUM_CONTNUANCE_DETAILS_ATTRIBUTES__PREMIUM_CONTINUANCE_DETAILS,
						planM2);

		plan.getPlanMap()
				.put(PlanConfigConstants.DISABILITY__PROVISION_PREMIUM_CONTINUANCE_DETAILS_EXCEPTION_ATTRIBUTES,
						planM3);
		plan.getPlanMap().put(
				PlanConfigConstants.IS_USER_EXCEPTION_ROLE_ATTRIBUTE, planM4);

		RuleUtility
				.getInitsData(
						"DT",
						"basicLife//SetValue//BL_Disability_Provision_Premium_Contnuance_Details_Attributes_948.xls",
						"Disability_Provision_Premium_Contnuance_Details_Attributes948",
						new Object[] { plan });

		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}
}
