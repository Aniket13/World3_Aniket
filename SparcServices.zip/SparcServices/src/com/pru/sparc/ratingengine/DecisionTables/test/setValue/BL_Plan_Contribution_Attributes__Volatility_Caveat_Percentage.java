package com.pru.sparc.ratingengine.DecisionTables.test.setValue;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;




public class BL_Plan_Contribution_Attributes__Volatility_Caveat_Percentage {

	

	@Test
	public void test_BL_Plan_Contribution_Attributes__Volatility_Caveat_Percentage_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		PlanMetadata planObj = new PlanMetadata();
		planObj.setFieldKey(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR);
		
		
		PlanConfigLookup plnConfig1= new PlanConfigLookup();
		plnConfig1.setLookupKey("Plan_Contribution_Attributes__Volatility_Caveat_Percentage");
		plnConfig1.setLookupValue("10.0");
		plnConfig1.setLookupOrder(4);
		
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Plan_Contribution_Attributes__Volatility_Caveat_Percentage", plnConfig1);
		
		planObj.setAltValues(altMap);
		
		
		

		plan.getPlanMap().put(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR,planObj);
		
		/*System.out
				.println("Plan_Contribution_Attributes__Volatility_Caveat_Percentage:="
						+ Float.parseFloat(plan.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR)
								.getAltValues()
								.get("Plan_Contribution_Attributes__Volatility_Caveat_Percentage")
								.getLookupValue()));*/
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Plan_Contribution_Attributes__Volatility_Caveat_Percentage.xls",
						"", new Object[] { plan});

		/*assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue(),
				"Disability_Provision__Admin_Dis_S",
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue());*/
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
