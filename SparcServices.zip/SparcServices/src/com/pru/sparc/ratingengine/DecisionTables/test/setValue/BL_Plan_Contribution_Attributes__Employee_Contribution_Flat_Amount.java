package com.pru.sparc.ratingengine.DecisionTables.test.setValue;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;




public class BL_Plan_Contribution_Attributes__Employee_Contribution_Flat_Amount {

	

	@Test
	public void test_BL_Plan_Contribution_Attributes__Volatility_Caveat_Percentage_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		PlanMetadata planObj = new PlanMetadata();
		
		planObj.setFieldKey(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTR);
		
		
		PlanConfigLookup plnConfig1= new PlanConfigLookup();
		plnConfig1.setLookupKey("Plan__Contribution_Exception_Attributes__Employee_Contribution_Flat_Amount");
		plnConfig1.setLookupValue("0.0");
		plnConfig1.setLookupOrder(1);
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Plan__Contribution_Exception_Attributes__Employee_Contribution_Flat_Amount", plnConfig1);
		
		planObj.setAltValues(altMap);
		plan.getPlanMap().put(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTR,planObj);
		/***************************************/
		PlanMetadata planObj1 = new PlanMetadata();
		planObj1.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTR);
		plan.put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTR,planObj1);
		
		
		/*System.out
				.println("Plan_Contribution_Attributes__Volatility_Caveat_Percentage:="
						+ Float.parseFloat(plan.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR)
								.getAltValues()
								.get("Plan_Contribution_Attributes__Volatility_Caveat_Percentage")
								.getLookupValue()));*/
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Plan Contribution Attributes - Employee Contribution Flat Amount.xls",
						"", new Object[] { plan});

		/*assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue(),
				"Disability_Provision__Admin_Dis_S",
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue());*/
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
