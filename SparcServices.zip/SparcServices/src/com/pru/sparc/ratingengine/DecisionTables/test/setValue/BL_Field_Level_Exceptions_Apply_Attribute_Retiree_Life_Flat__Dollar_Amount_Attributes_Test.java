package com.pru.sparc.ratingengine.DecisionTables.test.setValue;

import static org.junit.Assert.*;

import org.drools.command.assertion.AssertEquals;
import org.junit.Test;

import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;

public class BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes_Test {
	
	@Test
	public void BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes_Rule1_Pass() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM1.setFieldValue("RETIREE LIFE");
		
		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM2.setFieldValue("Grandfathering");


		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("8000");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION);
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM5.setFieldValue("false");
		
		PlanMetadata planM6 = new PlanMetadata();
		planM6.setFieldKey(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX);
		
		
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, planM1);
		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM5);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX, planM6);
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes.xls",
						"BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		assertEquals("200000.0",plan.getPlanMap().get(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX).getFieldValue());
		assertEquals("200000.0",plan.getPlanMap().get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).getFieldValue());

	}

	@Test
	public void BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes_Rule2_Pass() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM1.setFieldValue("RETIREE LIFE");
		
		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM2.setFieldValue("Grandfathering");


		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("8000");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION);
		planM4.setFieldValue("0");
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM5.setFieldValue("true");
		
		PlanMetadata planM6 = new PlanMetadata();
		planM6.setFieldKey(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX);
		
		
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, planM1);
		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM5);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX, planM6);
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes.xls",
						"BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		assertEquals("200000.0",plan.getPlanMap().get(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX).getFieldValue());
		assertEquals("200000.0",plan.getPlanMap().get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).getFieldValue());
	}

	@Test
	public void BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes_Rule2_Fail1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM1.setFieldValue("RETIREE LIFE");
		
		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM2.setFieldValue("Grandfathering1");


		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("8000");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION);
		planM4.setFieldValue("0");
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM5.setFieldValue("true");
		
		PlanMetadata planM6 = new PlanMetadata();
		planM6.setFieldKey(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX);
		
		
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, planM1);
		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM5);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX, planM6);
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes.xls",
						"BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		assertEquals(null,plan.getPlanMap().get(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX).getFieldValue());
		assertEquals("0",plan.getPlanMap().get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).getFieldValue());
	}
	
	@Test
	public void BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes_Rule1_Fail2() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM1.setFieldValue("RETIREE");
		
		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.PRU_VALUE_ATTR);
		planM2.setFieldValue("Grandfathering");


		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("8000");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION);
		planM4.setFieldValue("0");
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM5.setFieldValue("true");
		
		PlanMetadata planM6 = new PlanMetadata();
		planM6.setFieldKey(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX);
		
		
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE, planM1);
		plan.getPlanMap().put(PlanConfigConstants.PRU_VALUE_ATTR, planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM5);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX, planM6);
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes.xls",
						"BL_Field_Level_Exceptions_Apply_Attribute_Retiree_Life_Flat__Dollar_Amount_Attributes", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		assertEquals(null,plan.getPlanMap().get(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX).getFieldValue());
		assertEquals("0",plan.getPlanMap().get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).getFieldValue());
	}
	
}
