package com.pru.sparc.ratingengine.DecisionTables.test.setValue;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;

public class BL_Guarantee_Issue_Limit_Attributes__Maximum_Dollar_Cap_959 {

	//@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP);
		//planM1.setFieldValue("Grandfathering");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP__NO_EXCEPTION_MAX);
		//planM2.setFieldValue("78");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("8705");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP);
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM5.setFieldValue("false");
		//planM3.setFieldValue("true");
		
		
		
		plan.getPlanMap().put(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP, planM1);
		plan.getPlanMap()
				.put(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP__NO_EXCEPTION_MAX,
						planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);
		plan.getPlanMap().put(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM5);
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Guarantee_Issue_Limit_Attributes__Maximum_Dollar_Cap_959.xls",
						"Guarantee_Issue_Limit_Attributes__Maximum_Dollar_Cap959", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}

	
	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_922() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.TOTAL_LIVES);
		planM1.setFieldValue("52");

		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE);
		planM2.setFieldValue("RETIREE LIF");

		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		planM3.setFieldValue("1500000");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX);
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION);
		planM5.setFieldValue("0");
		//planM3.setFieldValue("true");
		
		PlanMetadata planM6 = new PlanMetadata();
		planM6.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM6.setFieldValue("false");
		
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM6);
		plan.getPlanMap().put(PlanConfigConstants.TOTAL_LIVES, planM1);
		plan.getPlanMap().put(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE,planM2);
		plan.getPlanMap().put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT, planM3);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR_AMOUNT_ATTRIBUTES_NO_EXCEPTION_MAX, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION, planM5);
		
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_922.xls",
						"Flat_Dollar_Amount_Attributes__Dollar_Amount_922", new Object[] { plan });
		
		assertEquals(
				new String("500000.0"),plan.get(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT).getFieldValue());
		
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());

	}
	
}
