package com.pru.sparc.ratingengine.DecisionTables.test.setValue;

import static org.junit.Assert.*;

import org.drools.command.assertion.AssertEquals;
import org.junit.Test;

import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;

public class BL_Field_Level_Exceptions_Apply_Attribute_sic_ID_Test {
	
	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM1.setFieldValue("100");
		
		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM2.setFieldValue("1000000");


		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("8000");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX);
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM5.setFieldValue("false");
		//planM3.setFieldValue("true");
		
		
		
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, planM1);
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM5);
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Field_Level_Exceptions_Apply_Attribute_sic_ID.xls",
						"BL_Field_Level_Exceptions_Apply_Attribute_sic_ID", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		assertEquals("500000.0",plan.getPlanMap().get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX).getFieldValue());
		assertEquals("500000.0",plan.getPlanMap().get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).getFieldValue());
		assertEquals("500000.0",plan.getPlanMap().get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).getFieldValue());

	}

	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID_OutOfRange() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		
		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM2.setFieldValue("100");


		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("8115");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX);
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM5.setFieldValue("false");
		
		
		
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, planM1);
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM5);
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Field_Level_Exceptions_Apply_Attribute_sic_ID.xls",
						"BL_Field_Level_Exceptions_Apply_Attribute_sic_ID", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		assertEquals(null,plan.getPlanMap().get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX).getFieldValue());
		assertEquals(null,plan.getPlanMap().get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).getFieldValue());
		assertEquals("100",plan.getPlanMap().get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).getFieldValue());

	}
	
	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_sic_ID_Rule2() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		plan.setPlanCreationDate("08/04/2016");

		PlanMetadata planM1 = new PlanMetadata();
		planM1.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM1.setFieldValue("0");
		
		PlanMetadata planM2 = new PlanMetadata();
		planM2.setFieldKey(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT);
		planM2.setFieldValue("100");


		PlanMetadata planM3 = new PlanMetadata();
		planM3.setFieldKey(PlanConfigConstants.SIC_ID);
		planM3.setFieldValue("6210");
		
		PlanMetadata planM4 = new PlanMetadata();
		planM4.setFieldKey(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX);
		
		PlanMetadata planM5 = new PlanMetadata();
		planM5.setFieldKey(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE);
		planM5.setFieldValue("true");
		
		
		
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, planM1);
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT, planM2);
		plan.getPlanMap().put(PlanConfigConstants.SIC_ID, planM3);
		plan.getPlanMap().put(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX, planM4);
		plan.getPlanMap().put(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE, planM5);
		

		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Field_Level_Exceptions_Apply_Attribute_sic_ID.xls",
						"BL_Field_Level_Exceptions_Apply_Attribute_sic_ID", new Object[] { plan });
		System.out
				.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		assertEquals("500000.0",plan.getPlanMap().get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT__NO_EXCEPTION_MAX).getFieldValue());
		assertEquals("500000.0",plan.getPlanMap().get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).getFieldValue());
		assertEquals("100.0",plan.getPlanMap().get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).getFieldValue());

	}

}
