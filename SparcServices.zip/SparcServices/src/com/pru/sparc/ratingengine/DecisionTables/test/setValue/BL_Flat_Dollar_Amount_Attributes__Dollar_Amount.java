package com.pru.sparc.ratingengine.DecisionTables.test.setValue;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;




public class BL_Flat_Dollar_Amount_Attributes__Dollar_Amount {

	

	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_Rule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		PlanMetadata planObj = new PlanMetadata();
		planObj.setFieldKey(PlanConfigConstants.AMT_INSU);
		planObj.setFieldValue("Flat_Dollar_Amount");
		
		/*PlanConfigLookup plnConfig1= new PlanConfigLookup();
		plnConfig1.setLookupKey("Plan_Contribution_Attributes__Volatility_Caveat_Percentage");
		plnConfig1.setLookupValue("10.0");
		plnConfig1.setLookupOrder(4);*/
		
		
		
		/*Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Plan_Contribution_Attributes__Volatility_Caveat_Percentage", plnConfig1);
		
		planObj.setAltValues(altMap);*/
		
		PlanMetadata planDt1 = new PlanMetadata();
		planDt1.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		//planObj.setFieldValue("Flat_Dollar_Amount");
		
		plan.getPlanMap().put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,planDt1);
		plan.getPlanMap().put(PlanConfigConstants.AMT_INSU,planObj);
		
		/*System.out
				.println("Plan_Contribution_Attributes__Volatility_Caveat_Percentage:="
						+ Float.parseFloat(plan.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR)
								.getAltValues()
								.get("Plan_Contribution_Attributes__Volatility_Caveat_Percentage")
								.getLookupValue()));*/
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount.xls",
						"", new Object[] { plan});

		/*assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue(),
				"Disability_Provision__Admin_Dis_S",
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue());*/
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
	@Test
	public void test_BL_Flat_Dollar_Amount_Attributes__Dollar_Amount_Rule_2() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		PlanMetadata planObj = new PlanMetadata();
		planObj.setFieldKey(PlanConfigConstants.AMT_INSU);
		planObj.setFieldValue("Multiple_of_Earnings__Flat_Dollar_Amount");
		
		/*PlanConfigLookup plnConfig1= new PlanConfigLookup();
		plnConfig1.setLookupKey("Plan_Contribution_Attributes__Volatility_Caveat_Percentage");
		plnConfig1.setLookupValue("10.0");
		plnConfig1.setLookupOrder(4);*/
		
		
		
		/*Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Plan_Contribution_Attributes__Volatility_Caveat_Percentage", plnConfig1);
		
		planObj.setAltValues(altMap);*/
		
		PlanMetadata planDt1 = new PlanMetadata();
		planDt1.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		//planObj.setFieldValue("Flat_Dollar_Amount");
		
		plan.getPlanMap().put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,planDt1);
		plan.getPlanMap().put(PlanConfigConstants.AMT_INSU,planObj);
		
		/*System.out
				.println("Plan_Contribution_Attributes__Volatility_Caveat_Percentage:="
						+ Float.parseFloat(plan.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR)
								.getAltValues()
								.get("Plan_Contribution_Attributes__Volatility_Caveat_Percentage")
								.getLookupValue()));*/
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Flat_Dollar_Amount_Attributes__Dollar_Amount.xls",
						"", new Object[] { plan});

		/*assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue(),
				"Disability_Provision__Admin_Dis_S",
				plan.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).getFieldValue());*/
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
