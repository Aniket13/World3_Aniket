package com.pru.sparc.ratingengine.DecisionTables.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class VolumeAmountsTest {

	

	@Test
	public void test_VolumeAmountsRule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		/*....Plan Composite Rating Start .....*/
		PlanMetadata planCompRat = new PlanMetadata();
		
		
		PlanConfigLookup Volume_Amounts__System_calculated_volume= new PlanConfigLookup();
		Volume_Amounts__System_calculated_volume.setLookupKey("Volume_Amounts__System_calculated_volume");
		Volume_Amounts__System_calculated_volume.setLookupValue("0.0");
		Volume_Amounts__System_calculated_volume.setLookupOrder(1);
		
		PlanConfigLookup Volume_Amounts__Use_census_volume_unaltered= new PlanConfigLookup();
		Volume_Amounts__Use_census_volume_unaltered.setLookupKey("Volume_Amounts__Use_census_volume_unaltered");
		Volume_Amounts__Use_census_volume_unaltered.setLookupValue("0.0");
		Volume_Amounts__Use_census_volume_unaltered.setLookupOrder(2);
		
		PlanConfigLookup Volume_Amounts__Use_census_volumes_within_plan_parameters= new PlanConfigLookup();
		Volume_Amounts__Use_census_volumes_within_plan_parameters.setLookupKey("Volume_Amounts__Use_census_volumes_within_plan_parameters");
		Volume_Amounts__Use_census_volumes_within_plan_parameters.setLookupValue("0.0");
		Volume_Amounts__Use_census_volumes_within_plan_parameters.setLookupOrder(3);
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Volume_Amounts__System_calculated_volume", Volume_Amounts__System_calculated_volume);
		altMap.put("Volume_Amounts__Use_census_volume_unaltered", Volume_Amounts__Use_census_volume_unaltered);
		altMap.put("Volume_Amounts__Use_census_volumes_within_plan_parameters", Volume_Amounts__Use_census_volumes_within_plan_parameters);
		
		planCompRat.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.VOL_AMT,planCompRat);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//BL_Volume_Amounts.xls",
						"", new Object[] { plan});

		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.VOL_AMT).getFieldValue(),
				"Volume_Amounts__System_calculated_volume",
				plan.getPlanMap().get(PlanConfigConstants.VOL_AMT).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
