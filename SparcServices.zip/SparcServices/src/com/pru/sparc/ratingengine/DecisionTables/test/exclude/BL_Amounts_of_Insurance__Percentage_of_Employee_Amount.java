package com.pru.sparc.ratingengine.DecisionTables.test.exclude;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class BL_Amounts_of_Insurance__Percentage_of_Employee_Amount {

	

	@Test
	public void test_BL_Amounts_of_Insurance__Percentage_of_Employee_Amount_Rule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");
		
		
				
		PlanMetadata planMetaD = new PlanMetadata();
		planMetaD.setFieldKey(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR);
		
		PlanConfigLookup pllkp= new PlanConfigLookup();
		pllkp.setLookupKey("Amounts_of_Insurance__Percentage_of_Employee_Amount");
		pllkp.setLookupValue("Percentage of Employee Amount");
		pllkp.setLookupOrder(1);
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Amounts_of_Insurance__Percentage_of_Employee_Amount", pllkp);
		
		planMetaD.setAltValues(altMap);
		
		
		plan.getPlanMap().put(PlanConfigConstants.PLAN_CONTRIBUTION_ATTR,planMetaD);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//Exclude//BL_Amounts_of_Insurance__Percentage_of_Employee_Amount.xls",
						"", new Object[] { plan});

		/*assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.AMT_INSU).getFieldValue(),
				"Yes",
				plan.getPlanMap().get(PlanConfigConstants.AMT_INSU).getFieldValue());*/
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
