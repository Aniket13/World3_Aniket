package com.pru.sparc.ratingengine.DecisionTables.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class BL_Rounding_Rule {

	

	@Test
	public void test_BL_RoundingOccurs_Rule_1() {

		// Initiate PlanDetailsMap object
		PlanDetailsMap plan = new PlanDetailsMap();
		/*....Plan Creation Date Start .....*/
		PlanMetadata planDt = new PlanMetadata();
		plan.setPlanCreationDate("08/04/2016");		
		/*....AGE_RED_SCH Start .....*/
		PlanMetadata planAmtIns = new PlanMetadata();
		
		
		PlanConfigLookup pln= new PlanConfigLookup();
		pln.setLookupKey("Choose_One");
		pln.setLookupValue("Choose One");
		pln.setLookupOrder(1);
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Choose_One", pln);
		
		planAmtIns.setAltValues(altMap);
		
		plan.getPlanMap().put(PlanConfigConstants.ROUNDING_RULE,planAmtIns);
		
		
		
		
		RuleUtility
				.getInitsData(
						"DT",
						"com//pru//sparc//ratingengine//DecisionTables//BL_Rounding_Rule.xls",
						"", new Object[] { plan});

		assertEquals(
				plan.getPlanMap().get(PlanConfigConstants.ROUNDING_RULE).getFieldValue(),
				"Choose_One",
				plan.getPlanMap().get(PlanConfigConstants.ROUNDING_RULE).getFieldValue());
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(plan.getPlanMap());
		

	}
}
