package com.pru.sparc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.PlanDetailsAggregator;
import com.pru.sparc.service.PlanDetailsService;

@Controller
public class PlanController {

	@Autowired
	@Qualifier("planDetailsService")
	private PlanDetailsService planDetailsService;

	/**
	 * Method to load default plan fields
	 * @param planData
	 * @return List<PlanField>
	 * @throws Exception
	 */
	@RequestMapping(value = "loadPlanDetails", method = RequestMethod.POST)
	public @ResponseBody PlanDetailsAggregator loadPlanDetails(@RequestBody PlanDetailsAggregator planData) throws Exception{
		return planDetailsService.loadPlanDetails(planData);
	}
	
	/**
	 * Method on change of Plan fields. This method will return the filtered list of PlanMetaData which has indicator A,C,R
	 * @param planData
	 * @return List<PlanField>
	 * @throws Exception
	 */
	@RequestMapping(value = "onChangePlanDetails", method = RequestMethod.POST)
	public @ResponseBody PlanDetailsAggregator onChangePlanDetails(@RequestBody PlanDetailsAggregator planData) throws Exception{
		return planDetailsService.onChangePlanDetails(planData);
	}
	/**
	 * Method to save the plan details to database
	 * @param plandetails
	 * @return PlanBO
	 * @throws Exception
	 */
	@RequestMapping(value = "savePlanDetails", method = RequestMethod.POST)
	public @ResponseBody PlanDetailsAggregator savePlanDetails(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.savePlanDetails(planDetailsAggregator);
	}
	
	/**
	 * Method to create new plan
	 * @param planDetails
	 * @return PlanDetailsClass
	 * @throws Exception
	 */
	@RequestMapping(value = "createNewPlan", method = RequestMethod.POST)
	public @ResponseBody PlanDetailsAggregator createNewPlan(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.createNewPlan(planDetailsAggregator);
	}

	/**
	 * Method to get all the plans from database
	 * @param planDetails
	 * @return List<PlanBO>
	 * @throws Exception
	 */
	@RequestMapping(value = "getVersionPlans", method = RequestMethod.POST)
	public List<PlanDetailsAggregator> getVersionPlans(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.getVersionPlans(planDetailsAggregator);
	}
	
	/**
	 * Method to get all details of selected plan
	 * @param planDetailsAggregator
	 * @return planDetailsAggregator
	 * @throws Exception
	 */
	@RequestMapping(value = "getAllPlanDetails", method = RequestMethod.POST)
	public @ResponseBody PlanDetailsAggregator getAllPlanDetails(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		//return planDetailsService.getAllPlanDetails(planDetailsAggregator);
		return planDetailsService.fetchExistPlanDtlFrmDB(planDetailsAggregator);
	}
	
	/**
	 * Method to save the plan commission details
	 * @param commission
	 * @throws Exception
	 */
	@RequestMapping(value = "savePlanCommission", method = RequestMethod.POST)
	public PlanDetailsAggregator savePlanCommission(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.savePlanCommission(planDetailsAggregator);
	}
	
	/**
	 * Method to get the plan commission details
	 * @param commission
	 * @return Commission
	 * @throws Exception
	 */
	@RequestMapping(value = "getPlanCommissionDetails", method = RequestMethod.POST)
	public @ResponseBody PlanDetailsAggregator getPlanCommissionDetails(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.getPlanCommissionDetails(planDetailsAggregator);
	}
	
	/**
	 * Method to save plan eligibility details
	 * @param planEligibilityList
	 * @throws Exception
	 */
	@RequestMapping(value = "saveEligibilityDetails", method = RequestMethod.POST)
	public PlanDetailsAggregator saveEligibilityDetails(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.saveEligibilityDetails(planDetailsAggregator);
	}
	
	/**
	 * Method to get plan eligibility details
	 * @param planEligibility
	 * @return List<PlanEligibility>
	 * @throws Exception
	 */
	@RequestMapping(value = "getEligibilityDetails", method = RequestMethod.POST)
	public @ResponseBody PlanDetailsAggregator getEligibilityDetails(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.getEligibilityDetails(planDetailsAggregator);
	}
	
	/**
	 * Method to get overridden plan details
	 * @param planId
	 * @return PlanDetailsAggregator
	 * @throws Exception
	 */
	@RequestMapping(value = "getOverriddenPlanDetails", method = RequestMethod.POST)
	public @ResponseBody PlanDetailsAggregator getOverriddenPlanDetails(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.getOverriddenPlanDetails(planDetailsAggregator);
	}
	
	/**
	 * Method to save overridden plan details
	 * @param planId
	 * @return PlanDetailsAggregator
	 * @throws Exception
	 */
	@RequestMapping(value = "overridePlanDetails", method = RequestMethod.POST)
	public PlanDetailsAggregator overridePlanDetails(@RequestBody PlanDetailsAggregator planDetailsAggregator) throws Exception{
		return planDetailsService.overridePlanDetails(planDetailsAggregator);
	}
}
