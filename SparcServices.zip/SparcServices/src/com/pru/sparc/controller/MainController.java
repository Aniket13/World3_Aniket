package com.pru.sparc.controller;

import java.util.List;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.LookupInfo;
import com.pru.sparc.bo.model.Holding;
import com.pru.sparc.service.MainService;

@Controller
public class MainController {
	//Logger
	//private static final Logger LOGGER = Logger.getLogger(MainController.class);
	
	@Autowired	
	@Qualifier("mainService")
	private MainService mainService;
	
	/**
	 * @throws Exception
	 */
	@RequestMapping(value="killSession", method = RequestMethod.POST)
	public void killSession() throws Exception{
		mainService.killSession();
	}
	
	/**
	 * @throws Exception
	 */
	@RequestMapping(value="newSession", method = RequestMethod.POST)
	public void newSession() throws Exception{
		mainService.newSession();
	}
	
	/**
	 * @param attributeNames
	 * @throws Exception
	 */
	@RequestMapping(value="storeInSession", method = RequestMethod.POST)
	public void storeInSession(@RequestBody Map<String,String> attributeNames) throws Exception{
		mainService.newSession();
	}
	
	/**
	 * @param attributeNames
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="retriveFromSession", method = RequestMethod.POST)
	public @ResponseBody Holding retriveFromSession() throws Exception{
		return null;
	}
	
	/**
	 * @param attributeNames
	 * @throws Exception
	 */
	@RequestMapping(value="removeFromSession", method = RequestMethod.POST)
	public void removeFromSession(@RequestBody Map<String,String> attributeNames) throws Exception{
		
	}
	
	/**
	 * Method to get the list of states from database
	 * @return List<CensusStates>
	 * @throws Exception
	 */
	@RequestMapping(value="getLookupDetails", method = RequestMethod.POST)
	public @ResponseBody List<LookupInfo> getCensusStates(@RequestBody LookupInfo lookupInfo) throws Exception{
		return mainService.getLookupList(lookupInfo);
	}
}
