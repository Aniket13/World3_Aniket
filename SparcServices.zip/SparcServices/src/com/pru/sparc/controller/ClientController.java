package com.pru.sparc.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.pru.sparc.bo.model.Client;
import com.pru.sparc.bo.model.ClientSearchRequest;
import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.model.StateXml;
import com.pru.sparc.service.ClientService;
import com.pru.sparc.stateintegrator.SparcStateMachineAdapter;


@Controller
public class ClientController {
	//Logger
	private static final Logger LOGGER = Logger.getLogger(ClientController.class);
	
	@Autowired	
	@Qualifier("clientService")
	private ClientService clientService;
	
	@Autowired
	@Qualifier("sparcStateMachineService")
	private SparcStateMachineAdapter sparcStateMachineService;
	
	/**
  	 * To add new client record to database
  	 * @param Client client
  	 * @return AddUpdateResult
  	 * @throws Exception Exception
  	 */
	@RequestMapping(value="addClient", method = RequestMethod.POST)
	public @ResponseBody Client addClient(@RequestBody Client client,@RequestParam("event")  String event) throws Exception{
		long start = System.currentTimeMillis();
		
		/* Integration of State Machine start here..! */
		String targetState = null;
		boolean statePersist = false;
		Client clientResult = null;
		if (null != event) {
			targetState = sparcStateMachineService.checkStateByEvent(event);
			if (null != targetState) {
				String propId = "2016124003"; // Temporary prop id assignment,
												// needs to remove
				clientResult = clientService.addClient(client);
				if (null != clientResult) {
					StateXml stXml = sparcStateMachineService
							.getPersistStateInfo(targetState, propId);
					statePersist = sparcStateMachineService.persistStateInfo(
							targetState, propId);
					if (statePersist) {
						System.out.println("State Persisted into DB...!");
					}else{
						System.out.println("State info not Persisted into DB...!");
					}
				}
			}else {
				System.out.println("State & Event both are doesn`t exist: "
						+ targetState);
			}
		}
		/* Integration of State Machine end here..! */
		
		LOGGER.info(SparcUtil.getTimeLog("addClient.json", false, start));
		return clientResult;
	}
	
	/**
  	 * 
  	 * @param Client client
  	 * @return AddUpdateResult
  	 * @throws Exception Exception
  	 */
	@RequestMapping(value="editClient", method = RequestMethod.POST)
	public @ResponseBody Client editClient(@RequestBody Client client) throws Exception{
		return clientService.editClient(client);
	}
	
	/**
  	 * 
  	 * @param Client client
  	 * @return List<Client>
  	 * @throws Exception Exception
  	 */
	@RequestMapping(value="searchClient", method = RequestMethod.POST)
	public @ResponseBody List<Client> searchClient(@RequestBody ClientSearchRequest clientSearchRequest) throws Exception{
		return clientService.searchClient(clientSearchRequest);
	}
	
	/**
	 * Method to get the client id 
	 * @return int
	 * @throws Exception
	 */
	@RequestMapping(value="getClientId", method = RequestMethod.POST)
	public @ResponseBody int getClientId() throws Exception{
		return clientService.getClientId();
	}
	
	/**
  	 * Method to get the list of proposals associated with the client
  	 * @param Client client
  	 * @return List<Client>
  	 * @throws Exception Exception
  	 */
	@RequestMapping(value="proposalActivity", method = RequestMethod.POST)
	public @ResponseBody List<Proposal> getProposalActivity(@RequestBody int clientId) throws Exception{
		return clientService.getProposalActivity(clientId);
	}
	
	/**
	 * Method to set the selected client object in session
	 * @param client
	 * @throws Exception
	 */
	@RequestMapping(value="selectClient", method = RequestMethod.POST)
	public void setClientInSession(@RequestBody Client client) throws Exception {
		clientService.setClientInSession(client);
	}
	
	/**
	 * Method to get Sic Description
	 * @param client
	 * @throws Exception
	 *//*
	@RequestMapping(value="getDesc", method = RequestMethod.POST)
	public @ResponseBody String getSicValue(@RequestBody String sicNo) throws Exception {
		return clientService.getSicDesc(sicNo);
	}*/
	/**
	 * Method to load the selected client details on load
	 * @param clientId
	 * @return Client
	 * @throws Exception
	 */
	@RequestMapping(value="loadClient", method = RequestMethod.POST)
	public @ResponseBody Client loadClient (@RequestBody int clientId) throws Exception {
		return clientService.loadClient(clientId);
	}
}
