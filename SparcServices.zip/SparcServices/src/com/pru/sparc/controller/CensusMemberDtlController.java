package com.pru.sparc.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.CensusMemberDtl;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.service.CensusMemberDtlService;

@Controller
public class CensusMemberDtlController {
	@Autowired
	private CensusMemberDtlService censusMemberDtlService;
	
	private static final Logger LOGGER = Logger.getLogger(CensusMemberDtlController.class);
	/**
	 * Census member details Controller (edit census member details Screen)
	 * @param CensusMemberDtl
	 * @throws Exception
	 */
	@RequestMapping(value="updateCensus", method = RequestMethod.POST)
	public void updateCensusMember(@RequestBody CensusMemberDtl model) throws Exception{
		final long start = System.currentTimeMillis();
		LOGGER.info(SparcUtil.getTimeLog("censusMember.json", false, start));
		censusMemberDtlService.updateCensusMember(model);
	}
	

	/**
	 * To get all census member list 
	 * @throws Exception
	 */
	@RequestMapping(value="getCensus", method = RequestMethod.POST)
	public @ResponseBody List<CensusMemberDtl> getCensusMembers(@RequestBody CensusMemberDtl census) throws Exception{
		final long start = System.currentTimeMillis();
		LOGGER.info(SparcUtil.getTimeLog("censusMember.json", false, start));
		return censusMemberDtlService.getCensusMembers(census.getCensusId());
	}
	
	/**
	 * To get all census screen dropDown values
	 * @throws Exception
	 */
	@RequestMapping(value="getCensusFieldValue", method = RequestMethod.POST)

    public @ResponseBody CensusMemberDtl getCensusFieldVal(@RequestBody CensusMemberDtl census) throws Exception{

            final long start = System.currentTimeMillis();

            LOGGER.info(SparcUtil.getTimeLog("censusMember.json", false, start));

            return censusMemberDtlService.getCensusFieldVal(census);

    }


	
}
