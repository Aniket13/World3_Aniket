package com.pru.sparc.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.ProposalVersionDetails;
import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.drools.model.RuleRatingOutputModelWrapper;
import com.pru.sparc.service.RatingDisplayService;
@Controller
public class RatingController {
	
	@Autowired
	@Qualifier("ratingDisplayService")
	private RatingDisplayService ratingDisplayService; 
	/*
	@RequestMapping(value = "/ratingDisplayKey")
	public @ResponseBody  List<String> getRatingDisplayKey() throws Exception {
		return ratingDisplayService.getRatingScreenKey();
		//return null;
	}
	
	@RequestMapping(value = "/ratingDisplayVal")
	public @ResponseBody  String getRatingDisplayVal(@RequestBody String key) throws Exception {
		return ratingDisplayService.getRatingScreenVal(key);
		//return null;
	}
	*/
	@RequestMapping(value = "/getVersionPlanDetails")
	public @ResponseBody ProposalVersionDetails getVersionPlanDetails(@RequestBody String  proposalId) throws Exception {
		return ratingDisplayService.getVersionPlanDetails(proposalId);
		
	}
	
	@RequestMapping(value = "/invokeRatingEngine")
	public @ResponseBody List<RatingModel> invokeRatingEngine(@RequestBody int versionNumber) throws Exception {
		return ratingDisplayService.invokeRatingEngine(versionNumber);
	}
		
	@RequestMapping(value = "/loadRatingData")
	public @ResponseBody RuleRatingOutputModelWrapper loadRatingData(@RequestBody RatingModel model) throws Exception {
		return ratingDisplayService.loadRatingData(model);
	}
	
	@RequestMapping(value = "/saveOverrides")
	public @ResponseBody RuleRatingOutputModelWrapper saveOverrides(@RequestBody RatingModel model) throws Exception {
		return ratingDisplayService.saveOverrides(model);
	}
	
	@RequestMapping(value = "/viewOriginalRates")
	public @ResponseBody RuleRatingOutputModelWrapper viewOriginalRates(@RequestBody RatingModel model) throws Exception {
		return ratingDisplayService.viewOriginalRates(model);
	}
	
	@RequestMapping(value = "/viewOverrideRates")
	public @ResponseBody RuleRatingOutputModelWrapper viewOverrideRates(@RequestBody RatingModel model) throws Exception {
		return ratingDisplayService.viewOverrideRates(model);
	}

}
