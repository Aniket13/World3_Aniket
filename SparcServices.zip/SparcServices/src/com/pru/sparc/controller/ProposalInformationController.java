package com.pru.sparc.controller;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.Client;
import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.service.ProposalInformationService;

@Controller
public class ProposalInformationController {
	
	private static final Logger LOGGER = Logger.getLogger(ProposalInformationController.class);
	
	@Autowired
	@Qualifier("proposalInformationService")
	private ProposalInformationService proposalInformationService;
	
	/**
	 * to add Proposal information to database
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="addProposal", method = RequestMethod.POST)
	public void addProposal(@RequestBody Proposal model) throws Exception{
		final long start = System.currentTimeMillis();
		proposalInformationService.saveBasicInformation(model);
		LOGGER.info(SparcUtil.getTimeLog("addProposal.json", false, start));
	}
	
	/**
	 * to create proposal id for new proposal
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping(value="createProposalId", method = RequestMethod.POST)
	public @ResponseBody String createProposalId() throws Exception {
		return proposalInformationService.createProposalId();
	}
	
	
	/**
	 * @param client
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="createNewProposal", method = RequestMethod.POST)
	public @ResponseBody Proposal createNewProposal(@RequestBody Client client) throws Exception {
		return proposalInformationService.createNewProposal(client);
	}
	
	@RequestMapping(value="getHeaderDetails", method = RequestMethod.POST)
	public @ResponseBody Proposal getHeaderDetails(@RequestBody Proposal proposal) throws Exception{
		return proposalInformationService.getHeaderDetails(proposal);
	}
	
	/**
	 * Method to get the client details from session
	 * @return Client
	 * @throws Exception
	 */
	@RequestMapping(value = "getClientDataFromSession", method = RequestMethod.POST)
	public @ResponseBody Client getClientDataFromSession(@RequestBody int clientId) throws Exception{
		return proposalInformationService.getClientDetailsFromSession(clientId);
	}
	
	/**
	 * Method to get the Proposal details on load
	 * @param proposalId
	 * @return Proposal
	 * @throws Exception
	 */
	@RequestMapping(value = "getProposalDetails", method = RequestMethod.POST)
	public @ResponseBody Proposal getProposalDetails(@RequestBody String proposalId) throws Exception{
		return proposalInformationService.getProposalDetails(proposalId);
	}
}
