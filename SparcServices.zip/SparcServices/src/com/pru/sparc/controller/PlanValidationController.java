package com.pru.sparc.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.RatingModel;
import com.pru.sparc.service.PlanValidationService;


@Controller
@RequestMapping(value = "/Validations")
public class PlanValidationController {

	@Autowired
	@Qualifier("planValidationService")
	private PlanValidationService planValidationService;

	/*@RequestMapping(value = "planValidation", method = RequestMethod.POST)
	public @ResponseBody
	List<PlanValidationModel> planValidation(
			@RequestBody final Map<String, String> map) throws Exception {

		return (planValidationService.getPlanValidationDetails(map));
	}*/
	
	@RequestMapping(value = "/planValidation")
	public @ResponseBody RatingModel getDetails(@RequestBody final Map<String, String> map) throws Exception {
		
		return planValidationService.getPlanValidationDetails(map);
	}

}
