package com.pru.sparc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.pru.sparc.bo.model.StatesXml;
import com.pru.sparc.service.StateXmlService;
@Controller
public class StateXmlController {
	@Autowired	
	@Qualifier("stateXmlService")
	private StateXmlService stateXmlService;
	
	@RequestMapping(value="addUpdateStates", method = RequestMethod.POST)
	public void addUpdateStates(@RequestBody StatesXml states) throws Exception{
		stateXmlService.addUpdateStates(states);
	}
}
