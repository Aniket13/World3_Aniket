package com.pru.sparc.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.Producer;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.service.ProducerService;

@Controller
public class ProducerController {
	//Logger
	private static final Logger LOGGER = Logger.getLogger(ClientController.class);

	@Autowired	
	@Qualifier("producerService")
	private ProducerService producerService;
	
	/**
  	 * To get producer records from database
  	 * @return List<Producer>
  	 * @throws Exception Exception
  	 */
	@RequestMapping(value="getProducer", method = RequestMethod.POST)
	public @ResponseBody List<Producer> getProducers()throws Exception{
		long start = System.currentTimeMillis();
		LOGGER.info(SparcUtil.getTimeLog("getProducers.json", false, start));
		return producerService.getProducers();
	}
	
	/**
  	 * To save proposal level commission data to database
  	 * @param Commission commission
  	 * @throws Exception Exception
  	 */
	@RequestMapping(value="setProposalCommission", method = RequestMethod.POST)
	public void setProposalCommission(@RequestBody Commission commission)throws Exception{
		long start = System.currentTimeMillis();
		LOGGER.info(SparcUtil.getTimeLog("setProposalCommission.json", false, start));
		producerService.setProposalCommission(commission);
	}
}
