package com.pru.sparc.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.PrudentialContact;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.service.PrudentialContactService;



@Controller
public class PrudentialContactController {
	@Autowired
	@Qualifier("prudentialContactService")
	private PrudentialContactService prudentialContactService;
	
	private static final Logger LOGGER = Logger.getLogger(PrudentialContactController.class);
	/**
	 * Prudential Contact Controller (Rfp contact Screen)
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="addRfpContact", method = RequestMethod.POST)
	public void addRfpContact(@RequestBody PrudentialContact model) throws Exception{
		final long start = System.currentTimeMillis();
		prudentialContactService.savePrudentialContact(model);
		LOGGER.info(SparcUtil.getTimeLog("addRfpContact.json", false, start));
	}
	

	/**
	 * To get dynamic drop down values for Prudential contact screen
	 * @param model
	 * @throws Exception
	 */
	@RequestMapping(value="getRfpValues", method = RequestMethod.POST)
	public @ResponseBody PrudentialContact getRfpValues() throws Exception{
		PrudentialContact model = new PrudentialContact();
		final long start = System.currentTimeMillis();
		PrudentialContact prudentialContact = prudentialContactService.getPrudentialContactValues(model);
		LOGGER.info(SparcUtil.getTimeLog("getRfpValues.json", false, start));
		return prudentialContact;
	}
	
}
