package com.pru.sparc.controller;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.Commission;
import com.pru.sparc.bo.model.Proposal;
import com.pru.sparc.bo.model.ProposalVersion;
import com.pru.sparc.bo.model.Quotation;
import com.pru.sparc.common.util.SparcUtil;
import com.pru.sparc.service.QuotationService;

@Controller
public class QuotationController {
	private static final Logger LOGGER = Logger.getLogger(QuotationController.class);
	
	@Autowired	
	@Qualifier("quotationService")
	private QuotationService quotationService;
	
	/**
	 * @param proposal
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/getProposalVersions", method = RequestMethod.POST)
	public @ResponseBody List<ProposalVersion> getProposalVersions(@RequestBody Proposal proposal) throws Exception {
		long start = System.currentTimeMillis();
		List<ProposalVersion> proposalVersions = quotationService.getProposalVersions(proposal);
		LOGGER.info(SparcUtil.getTimeLog("getProposalVersions.json", false, start));
		return proposalVersions;
	}
	
	
	/**
	 * @param quotation
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/getVersionDetails", method = RequestMethod.POST)
	public @ResponseBody Quotation getVersionDetails(@RequestBody Quotation quotation) throws Exception {
		long start = System.currentTimeMillis();
		Quotation quote = quotationService.getVersionDetails(quotation);
		LOGGER.info(SparcUtil.getTimeLog("getVersionDetails.json", false, start));
		return quote;
	}
	
	
	/**
	 * @param proposal
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/createNewQuotation", method = RequestMethod.POST)
	public @ResponseBody Quotation createNewQuotation(@RequestBody Proposal proposal) throws Exception {
		long start = System.currentTimeMillis();
		Quotation quote = quotationService.createNewQuotation(proposal);
		LOGGER.info(SparcUtil.getTimeLog("createNewQuotation.json", false, start));
		return quote;
	}
	/**
	 * @param quotation
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/saveQuotation", method = RequestMethod.POST)
	public @ResponseBody Quotation saveQuotation(@RequestBody Quotation quotation) throws Exception {
		long start = System.currentTimeMillis();
		Quotation quote = quotationService.saveQuotation(quotation);
		LOGGER.info(SparcUtil.getTimeLog("saveQuotation.json", false, start));
		return quote;
	}
		
	/**
	 * @param proposal
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/getProposalVersionsCount", method = RequestMethod.POST)
	public @ResponseBody int getProposalVersionsCount(@RequestBody Proposal proposal) throws Exception {
		long start = System.currentTimeMillis();
		int versionsCount = quotationService.getProposalVersionsCount(proposal);
		LOGGER.info(SparcUtil.getTimeLog("getProposalVersionsCount.json", false, start));
		return versionsCount;
	}
	
	@RequestMapping(value="/setVersionInSession", method = RequestMethod.POST)
	public void setVersionInSession(@RequestBody Map<String, String> versionMap) throws Exception{
		quotationService.setVersionInSession(versionMap);
	}
	
	/**
	 * @param Commission
	 * @return Commission
	 * @throws Exception
	 */
	@RequestMapping(value="/saveCommission", method = RequestMethod.POST)
	public @ResponseBody Commission saveCommission(@RequestBody Commission commission) throws Exception {
		long start = System.currentTimeMillis();
		Commission comm = quotationService.updateCommission(commission, false);
		LOGGER.info(SparcUtil.getTimeLog("updateCommission.json", false, start));
		return comm;
	}
	
	/**
	 * @param Commission
	 * @return Commission
	 * @throws Exception
	 */
	@RequestMapping(value="/createNewCommission", method = RequestMethod.POST)
	public @ResponseBody Commission createNewCommission(@RequestBody Commission commission) throws Exception {
		long start = System.currentTimeMillis();
		Commission comm = quotationService.updateCommission(commission, true);
		LOGGER.info(SparcUtil.getTimeLog("updateCommission.json", false, start));
		return comm;
	}
	
	/**
	 * @param Commission
	 * @return Commission
	 * @throws Exception
	 */
	@RequestMapping(value="/getCommission", method = RequestMethod.POST)
	public @ResponseBody Commission getCommission(@RequestBody Commission commission) throws Exception {
		long start = System.currentTimeMillis();
		Commission comm = quotationService.getCommission(commission);
		LOGGER.info(SparcUtil.getTimeLog("getCommission.json", false, start));
		return comm;
	}
}
