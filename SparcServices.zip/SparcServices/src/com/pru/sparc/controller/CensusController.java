package com.pru.sparc.controller;


import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pru.sparc.bo.model.Census;
import com.pru.sparc.bo.model.CensusAllocationLives;
import com.pru.sparc.bo.model.CensusCls;
import com.pru.sparc.service.CensusService;

@Controller
public class CensusController {

	private static final Logger SPARCLOGGER = Logger.getLogger(ClientController.class);
	
	@Autowired	
	@Qualifier("censusService")
	private CensusService censusService;
	
	@RequestMapping(value="getCensusDetail", method = RequestMethod.POST)
	public @ResponseBody List<Census> getCensusDetail(@RequestBody int clientId) throws Exception{
		SPARCLOGGER.debug("Start of CensusController().getCensusDetail().....!");
		return (List<Census>)censusService.getCensusDetail(clientId);
	}
	
	@RequestMapping(value="updateCensusDetail", method = RequestMethod.POST)
	public void updateCensusDetail(@RequestBody Census census) throws Exception{
		SPARCLOGGER.debug("Start of CensusController().updateCensusDetail().....!");
		 censusService.updateCensusDetail(census);
	}
	
	@RequestMapping(value="addCensusClass", method = RequestMethod.POST)
	public void addCensusClass(@RequestBody List<CensusCls> census) throws Exception{
		SPARCLOGGER.debug("Start of CensusController().addCensusClass().....!");
		 censusService.addCensusClass(census);
	}
	
	@RequestMapping(value="getCensusClass", method = RequestMethod.POST)
	public @ResponseBody List<CensusCls> getCensusClass(@RequestBody CensusCls census) throws Exception{
		SPARCLOGGER.debug("Start of CensusController().getCensusClass().....!");
		return (List<CensusCls>)censusService.getCensusClass(census);
	}
	
	/*@RequestMapping(value="updateCensusClass", method = RequestMethod.POST)
	public void updateCensusClass(@RequestBody List<CensusCls> census) throws Exception{
		censusService.updateCensusClass(census);
	}*/
	
	/**
	 * Method to get the census allocation of lives details
	 * @param cLives
	 * @return List<CensusAllocationLives>
	 * @throws Exception
	 */
	@RequestMapping(value="getLivesAllocation", method = RequestMethod.POST)
	public @ResponseBody List<CensusAllocationLives> getCensusAllocationLives(@RequestBody String censusId) throws Exception{
		SPARCLOGGER.debug("Start of CensusController().getCensusAllocationLives().....!");
		return censusService.getCensusAllocationLives(censusId);
	}
	
	/**
	 * Method to save the census allocation of lives details
	 * @param cLives
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="addLivesAllocation", method = RequestMethod.POST)
	public void saveCensusAllocationLives(@RequestBody List<CensusAllocationLives> cLives) throws Exception{
		SPARCLOGGER.debug("Start of CensusController().saveCensusAllocationLives().....!");
		censusService.saveCensusAllocation(cLives);
	}
	
	/**
	 * Method to delete the census allocation of lives details
	 * @param cLives
	 * @throws Exception
	 */
	@RequestMapping(value="deleteLivesAllocation", method = RequestMethod.POST)
	public void deleteCensusAllocationLives(@RequestBody CensusAllocationLives cLives) throws Exception{
		SPARCLOGGER.debug("Start of CensusController().deleteCensusAllocationLives().....!");
		censusService.deleteCensusAllocation(cLives);
	}
}
