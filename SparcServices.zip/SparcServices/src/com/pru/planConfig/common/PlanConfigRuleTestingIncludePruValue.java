package com.pru.planConfig.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.impl.MainServiceImpl;

public class PlanConfigRuleTestingIncludePruValue {

	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();
		MainRepositoryImpl mainRepository = new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor = new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;

		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();

		final List<PlanLookupDetails> lookupList = mainRepository
				.getPlanLookupList();// lookupDetails);
		if (CollectionUtils.isNotEmpty(lookupList)) {
			lookupInfoList = mainServiceProcessor
					.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}

		planMetadataList = planDetailsServiceProcessor
				.setLookupValuesInFieldList(planMetadataList, lookupInfoList);

		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor
				.convertToPlanMap(planMetadataList);

		planDtlMap.setPlanMap(planMap);

		// 1
		PlanConfigLookup plnConfig1 = new PlanConfigLookup();
		plnConfig1.setLookupKey("Qualifying_Age__Prior_to_Age_60");
		plnConfig1.setLookupValue("Prior_to_Age_60");
		plnConfig1.setLookupOrder(1);

		PlanMetadata pln = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap = new HashMap<String, PlanConfigLookup>();
		altMap.put("Qualifying_Age__Prior_to_Age_60", plnConfig1);

		pln.setAltValues(altMap);

		planDtlMap.getPlanMap().put(PlanConfigConstants.QUALIFYING_AGE, pln);

		// 2
		PlanConfigLookup plnConfig2 = new PlanConfigLookup();
		plnConfig2.setLookupKey("Dis_S_Time_Submission_Period__1_Year");
		plnConfig2.setLookupValue("Period__1_Year");
		plnConfig2.setLookupOrder(1);

		PlanMetadata pln2 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap2 = new HashMap<String, PlanConfigLookup>();
		altMap2.put("Dis_S_Time_Submission_Period__1_Year", plnConfig2);

		pln2.setAltValues(altMap2);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.DIS_S_TIME_SUBMISSION_PERIOD, pln2);

		// 3

		PlanConfigLookup plnConfig3 = new PlanConfigLookup();
		plnConfig3.setLookupKey("Elimination_Period__9_Months");
		plnConfig3.setLookupValue("Period__9_Months");
		plnConfig3.setLookupOrder(1);

		PlanMetadata pln3 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap3 = new HashMap<String, PlanConfigLookup>();
		altMap3.put("Elimination_Period__9_Months", plnConfig3);

		pln3.setAltValues(altMap3);

		planDtlMap.getPlanMap().put(PlanConfigConstants.ELIMINATION_PERIOD,
				pln3);

		// 4

		PlanConfigLookup plnConfig4 = new PlanConfigLookup();
		plnConfig4.setLookupKey("Duration__Age_65");
		plnConfig4.setLookupValue("Age_65");
		plnConfig4.setLookupOrder(1);

		PlanMetadata pln4 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap4 = new HashMap<String, PlanConfigLookup>();
		altMap4.put("Duration__Age_65", plnConfig4);

		pln4.setAltValues(altMap4);

		planDtlMap.getPlanMap().put(PlanConfigConstants.DURATION, pln4);

		// 5

		PlanConfigLookup plnConfig5 = new PlanConfigLookup();
		plnConfig5.setLookupKey("Conversion_Privilege_Applies__No");
		plnConfig5.setLookupValue("Conversion_Privilege_Applies__No");
		plnConfig5.setLookupOrder(1);

		PlanMetadata pln5 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap5 = new HashMap<String, PlanConfigLookup>();
		altMap5.put("Conversion_Privilege_Applies__No", plnConfig5);

		pln5.setAltValues(altMap5);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.CONVERSION_PRIVILEGE_APPLIES, pln5);

		// 6

		PlanConfigLookup plnConfig6 = new PlanConfigLookup();
		plnConfig6
				.setLookupKey("Are_Late_Entrants_rules_waived_with_change_in_Family_Status__Yes");
		plnConfig6
				.setLookupValue("Are_Late_Entrants_rules_waived_with_change_in_Family_Status__Yes");
		plnConfig6.setLookupOrder(1);

		PlanMetadata pln6 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap6 = new HashMap<String, PlanConfigLookup>();
		altMap6.put(
				"Are_Late_Entrants_rules_waived_with_change_in_Family_Status__Yes",
				plnConfig6);

		pln6.setAltValues(altMap6);

		planDtlMap
				.getPlanMap()
				.put(PlanConfigConstants.ARE_LATE_ENTRANTS_RULES_WAIVED_WITH_CHANGE_IN_FAMILY_STATUS,
						pln6);
		// 7

		PlanConfigLookup plnConfig7 = new PlanConfigLookup();
		plnConfig7
				.setLookupKey("What_are_the_limits_without_Medical_Evidence_Annual_Enrollment__Dollar");
		plnConfig7
				.setLookupValue("What_are_the_limits_without_Medical_Evidence_Annual_Enrollment__Dollar");
		plnConfig7.setLookupOrder(1);

		PlanMetadata pln7 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap7 = new HashMap<String, PlanConfigLookup>();
		altMap7.put(
				"What_are_the_limits_without_Medical_Evidence_Annual_Enrollment__Dollar",
				plnConfig7);

		pln7.setAltValues(altMap7);

		planDtlMap
				.getPlanMap()
				.put(PlanConfigConstants.WHAT_ARE_THE_LIMITS_WITHOUT_MEDICAL_EVIDENCE_ANNUAL_ENROLLMENT,
						pln7);
		// 8

		PlanConfigLookup plnConfig8 = new PlanConfigLookup();
		plnConfig8.setLookupKey("LBO_Life_Expectancy__12_months");
		plnConfig8.setLookupValue("LBO_Life_Expectancy__12_months");
		plnConfig8.setLookupOrder(1);

		PlanMetadata pln8 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap8 = new HashMap<String, PlanConfigLookup>();
		altMap8.put("LBO_Life_Expectancy__12_months", plnConfig8);

		pln8.setAltValues(altMap8);

		planDtlMap.getPlanMap().put(PlanConfigConstants.LBO_LIFE_EXPT, pln8);

		// 9

		PlanConfigLookup plnConfig9 = new PlanConfigLookup();
		plnConfig9.setLookupKey("Retirement_Reduction__No");
		plnConfig9.setLookupValue("Retirement_Reduction__No");
		plnConfig9.setLookupOrder(1);

		PlanMetadata pln9 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap9 = new HashMap<String, PlanConfigLookup>();
		altMap9.put("Retirement_Reduction__No", plnConfig9);

		pln9.setAltValues(altMap9);

		planDtlMap.getPlanMap().put(PlanConfigConstants.RETIREMENT_REDUCTION,
				pln9);

		// 10

		PlanConfigLookup plnConfig10 = new PlanConfigLookup();
		plnConfig10.setLookupKey("Earnings_Definition__Standard");
		plnConfig10.setLookupValue("Earnings_Definition__Standard");
		plnConfig10.setLookupOrder(1);

		PlanMetadata pln10 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap10 = new HashMap<String, PlanConfigLookup>();
		altMap10.put("Earnings_Definition__Standard", plnConfig10);

		pln10.setAltValues(altMap10);

		planDtlMap.getPlanMap().put(PlanConfigConstants.EARNING_DEF, pln10);

		// 11
		PlanConfigLookup plnConfig11 = new PlanConfigLookup();
		plnConfig11.setLookupKey("Rounding_Rule__NA");
		plnConfig11.setLookupValue("10.0");
		plnConfig11.setLookupOrder(1);

		PlanMetadata pln11 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap11 = new HashMap<String, PlanConfigLookup>();
		altMap11.put("Rounding_Rule__NA", plnConfig11);

		pln11.setAltValues(altMap11);

		planDtlMap.getPlanMap().put(PlanConfigConstants.ROUNDING_RULE, pln11);

		// 12
		PlanConfigLookup plnConfig12 = new PlanConfigLookup();
		plnConfig12.setLookupKey("Medical_Underwriting_Form__Short_form");
		plnConfig12.setLookupValue("Medical_Underwriting_Form__Short_form");
		plnConfig12.setLookupOrder(1);

		PlanMetadata pln12 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap12 = new HashMap<String, PlanConfigLookup>();
		altMap12.put("Medical_Underwriting_Form__Short_form", plnConfig12);

		pln12.setAltValues(altMap12);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.MEDICAL_UNDERWRITING_FORM, pln12);

		// 13
		PlanConfigLookup plnConfig13 = new PlanConfigLookup();
		plnConfig13
				.setLookupKey("LBO_Applies_to__Basic_Life_and_Optional_Life");
		plnConfig13
				.setLookupValue("LBO_Applies_to__Basic_Life_and_Optional_Life");
		plnConfig13.setLookupOrder(1);

		PlanMetadata pln13 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap13 = new HashMap<String, PlanConfigLookup>();
		altMap13.put("LBO_Applies_to__Basic_Life_and_Optional_Life",
				plnConfig13);

		pln13.setAltValues(altMap13);

		planDtlMap.getPlanMap().put(PlanConfigConstants.LBO_APPLIES_TO, pln13);

		// 14
		PlanConfigLookup plnConfig14 = new PlanConfigLookup();
		plnConfig14
				.setLookupKey("Order_of_Priority_for_LBO_Claim_Payment__Basic_Life_First_Optional_Life_Second");
		plnConfig14
				.setLookupValue("Order_of_Priority_for_LBO_Claim_Payment__Basic_Life_First_Optional_Life_Second");
		plnConfig14.setLookupOrder(1);

		PlanMetadata pln14 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap14 = new HashMap<String, PlanConfigLookup>();
		altMap14.put(
				"Order_of_Priority_for_LBO_Claim_Payment__Basic_Life_First_Optional_Life_Second",
				plnConfig14);

		pln14.setAltValues(altMap14);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.ORDER_OF_PRIORITY_FOR_LBO_CLAIM_PAYMENT,
				pln14);

		// 15
		PlanConfigLookup plnConfig15 = new PlanConfigLookup();
		plnConfig15
				.setLookupKey("Are_Retirees_eligible_to_Port_Basic_Life__No");
		plnConfig15
				.setLookupValue("Are_Retirees_eligible_to_Port_Basic_Life__No");
		plnConfig15.setLookupOrder(1);

		PlanMetadata pln15 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap15 = new HashMap<String, PlanConfigLookup>();
		altMap15.put("Are_Retirees_eligible_to_Port_Basic_Life__No",
				plnConfig15);

		pln15.setAltValues(altMap15);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.ARE_RETIREES_ELIGIBLE_TO_PORT_BASIC_LIFE,
				pln15);
		// 16
		PlanConfigLookup plnConfig16 = new PlanConfigLookup();
		plnConfig16
				.setLookupKey("What_are_the_limits_without_Medical_Evidence_Late_Entrants__Dollar");
		plnConfig16
				.setLookupValue("What_are_the_limits_without_Medical_Evidence_Late_Entrants__Dollar");
		plnConfig16.setLookupOrder(1);

		PlanMetadata pln16 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap16 = new HashMap<String, PlanConfigLookup>();
		altMap16.put(
				"What_are_the_limits_without_Medical_Evidence_Late_Entrants__Dollar",
				plnConfig16);

		pln16.setAltValues(altMap16);

		planDtlMap
				.getPlanMap()
				.put(PlanConfigConstants.WHAT_ARE_THE_LIMITS_WITHOUT_MEDICAL_EVIDENCE_LATE_ENTRANTS,
						pln16);

		// 17
		PlanConfigLookup plnConfig17 = new PlanConfigLookup();
		plnConfig17.setLookupKey("Continuity_of_Coverage_No_Loss_No_Gain__Yes");
		plnConfig17
				.setLookupValue("Continuity_of_Coverage_No_Loss_No_Gain__Yes");
		plnConfig17.setLookupOrder(1);

		PlanMetadata pln17 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap17 = new HashMap<String, PlanConfigLookup>();
		altMap17.put("Continuity_of_Coverage_No_Loss_No_Gain__Yes", plnConfig17);

		pln17.setAltValues(altMap17);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.CONTINUITY_OF_COVERAGE_NO_LOSS_NO_GAIN,
				pln17);

		// 18
		PlanConfigLookup plnConfig18 = new PlanConfigLookup();
		plnConfig18.setLookupKey("Rehire_Waiting_Period__6_Months");
		plnConfig18.setLookupValue("Rehire_Waiting_Period__6_Months");
		plnConfig18.setLookupOrder(1);

		PlanMetadata pln18 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap18 = new HashMap<String, PlanConfigLookup>();
		altMap18.put("Rehire_Waiting_Period__6_Months", plnConfig18);

		pln18.setAltValues(altMap18);

		planDtlMap.getPlanMap().put(PlanConfigConstants.REHIRE_WAITING_PERIOD,
				pln18);
		// 19
		PlanConfigLookup plnConfig19 = new PlanConfigLookup();
		plnConfig19.setLookupKey("Specific_Employee_Waiting_Period__Days");
		plnConfig19.setLookupValue("Specific_Employee_Waiting_Period__Days");
		plnConfig19.setLookupOrder(1);

		PlanMetadata pln19 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap19 = new HashMap<String, PlanConfigLookup>();
		altMap19.put("Specific_Employee_Waiting_Period__Days", plnConfig19);

		pln19.setAltValues(altMap19);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.SPECIFIC_EMPLOYEE_WAITING_PERIOD, pln19);

		// 20
		PlanConfigLookup plnConfig20 = new PlanConfigLookup();
		plnConfig20.setLookupKey("Coverage_begins__First_of_the_month_on_or_after_completion_of_employee_waiting_period");
		plnConfig20.setLookupValue("Coverage_begins__First_of_the_month_on_or_after_completion_of_employee_waiting_period");
		plnConfig20.setLookupOrder(1);

		PlanMetadata pln20 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap20 = new HashMap<String, PlanConfigLookup>();
		altMap20.put("Coverage_begins__First_of_the_month_on_or_after_completion_of_employee_waiting_period", plnConfig20);

		pln20.setAltValues(altMap20);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.COVERAGE_BEGINS, pln20);

		// 21
		PlanConfigLookup plnConfig21 = new PlanConfigLookup();
		plnConfig21.setLookupKey("Travel_Assistance__No");
		plnConfig21.setLookupValue("Travel_Assistance__No");
		plnConfig21.setLookupOrder(1);

		PlanMetadata pln21 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap21 = new HashMap<String, PlanConfigLookup>();
		altMap21.put("Travel_Assistance__No", plnConfig21);

		pln21.setAltValues(altMap21);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.TRAVEL_ASSISTANCE, pln21);
		
		
		// 22
		PlanConfigLookup plnConfig22 = new PlanConfigLookup();
		plnConfig22.setLookupKey("Age_Reduction_Schedule__35__65_50__70");
		plnConfig22.setLookupValue("Age_Reduction_Schedule__35__65_50__70");
		plnConfig22.setLookupOrder(1);

		PlanMetadata pln22 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap22 = new HashMap<String, PlanConfigLookup>();
		altMap22.put("Age_Reduction_Schedule__35__65_50__70", plnConfig22);

		pln22.setAltValues(altMap22);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.AGE_RED_SCH, pln22);
		
		
		// 23
		PlanConfigLookup plnConfig23 = new PlanConfigLookup();
		plnConfig23.setLookupKey("Amount_Reductions_take_effect__On_the_first_of_the_month_following_birthday");
		plnConfig23.setLookupValue("Amount_Reductions_take_effect__On_the_first_of_the_month_following_birthday");
		plnConfig23.setLookupOrder(1);

		PlanMetadata pln23 = new PlanMetadata();

		Map<String, PlanConfigLookup> altMap23 = new HashMap<String, PlanConfigLookup>();
		altMap23.put("Amount_Reductions_take_effect__On_the_first_of_the_month_following_birthday", plnConfig23);

		pln23.setAltValues(altMap23);

		planDtlMap.getPlanMap().put(
				PlanConfigConstants.AMOUNT_REDUCTIONS_TAKE_EFFECT, pln23);

		// BL_PlanConfigInclude.drl call
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigPruValue.drl",
				"PlanConfigPruValue", new Object[] { planDtlMap });
	}

	public static void main(String[] args) throws Exception {
		PlanConfigRuleTestingIncludePruValue plnConf = new PlanConfigRuleTestingIncludePruValue();
		plnConf.firePlanConfigRuleEngine();

	}

}
