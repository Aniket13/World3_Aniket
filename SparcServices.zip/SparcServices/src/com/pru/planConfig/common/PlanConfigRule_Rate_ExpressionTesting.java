package com.pru.planConfig.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;

public class PlanConfigRule_Rate_ExpressionTesting {

	//static final String[] ROUNDING_VALUES = {"Choose_One", "Rounding_Occurs__After_Amount_is_Multiplied", "Rounding_Occurs__Before_Amount_is_Multiplied"};
	//static final String DOES_NOT_APPLY = "Rounding_Rule__NA";
	//static final String FLAT_DOLLAR_AMOUNT = "Amounts_of_Insurance__Flat_Dollar_Amount";
	
	
	@Test
	public void firePlanConfigRuleEngine_Rounding() throws Exception{
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		
		//PlanConfigRuleExecution executor = new PlanConfigRuleExecution();
		//executor.setPlanDtlMockUpData(planDtlMap);
		//callDroolFile(planDtlMap);
		//testRoundingOccur(planDtlMap);
		
		
		//check for type 1
		planDtlMap = buildRateExpressionRuleValue(planDtlMap, "Rate_Expression__Per_1000_of_coverage_per_month");
		callDroolFile(planDtlMap);
		testAge_Banded_RatingFieldValueNo(planDtlMap);
		
		
		//check for type 2
		planDtlMap = buildRateExpressionRuleValue(planDtlMap, "Rate_Expression__Per_1000_of_coverage_per_month");
		//callDroolFile(planDtlMap);
		testAge_Banded_RatingYes(planDtlMap);
		
		
		//check for type 3
		planDtlMap = buildRateExpressionRuleValue(planDtlMap, "Rate_Expression__Per_Individual");
		callDroolFile(planDtlMap);
		testAge_Banded_RatingPer_Individual(planDtlMap);
		
		
	}
	
	
	public  void testAge_Banded_RatingYes(PlanDetailsMap planDetailsMap){
		planDetailsMap = buildAge_Banded_RatingValue(planDetailsMap, "Age_Banded_Rating__Yes");
		callDroolFile(planDetailsMap);
		testRate_ExpressionSubField(planDetailsMap);
	}
	
	public  void testAge_Banded_RatingFieldValueNo(PlanDetailsMap planDetailsMap){
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.AGE_BANDED_RATING).getVisibleFlag());
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.AGE_BANDED_RATING).getAltValues().get("Age_Banded_Rating__No").getVisibleFlag());
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.AGE_BANDED_RATING).getAltValues().get("Age_Banded_Rating__Yes").getVisibleFlag());
	}
	
	
	public  void testRate_ExpressionSubField(PlanDetailsMap planDetailsMap){
		//Rate_Expression__Per_Individual
		Assert.assertEquals("Age_Banded_Rating__Yes",  planDetailsMap.get(PlanConfigConstants.AGE_BANDED_RATING).getFieldValue());
		Assert.assertEquals("No",  planDetailsMap.get(PlanConfigConstants.RATE_EXPR).getAltValues().get("Rate_Expression__Per_Individual").getVisibleFlag());
		Assert.assertEquals("C",  planDetailsMap.get(PlanConfigConstants.RATE_EXPR).getFieldIndicator());
	}
	
	
	public  void testAge_Banded_RatingPer_Individual(PlanDetailsMap planDetailsMap){
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.AGE_BANDED_RATING).getVisibleFlag());
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.AGE_BANDED_RATING).getAltValues().get("Age_Banded_Rating__No").getVisibleFlag());
		Assert.assertEquals("No",  planDetailsMap.get(PlanConfigConstants.AGE_BANDED_RATING).getAltValues().get("Age_Banded_Rating__Yes").getVisibleFlag());
	}
	
	
	public  void callDroolFile(PlanDetailsMap planDetailsMap){
		
		RuleUtility.getInitsData("DRL", "..\\resources\\basicLife\\BL_PlanConfigRulesOnChange.drl", "PlanConfig", new Object[] {planDetailsMap});
	}
	
	public static PlanDetailsMap buildAge_Banded_RatingValue(PlanDetailsMap planDtlMap, String Value){
		planDtlMap.get(PlanConfigConstants.AGE_BANDED_RATING).setFieldValue(Value);
		return planDtlMap;
	}
	
	public static PlanDetailsMap buildRateExpressionRuleValue(PlanDetailsMap planDtlMap, String Value){
		planDtlMap.get(PlanConfigConstants.RATE_EXPR).setFieldValue(Value);
		return planDtlMap;
	}
}
