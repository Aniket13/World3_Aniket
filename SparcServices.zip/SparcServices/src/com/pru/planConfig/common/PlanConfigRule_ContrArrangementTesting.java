package com.pru.planConfig.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.bo.model.User;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;

public class PlanConfigRule_ContrArrangementTesting {

	static final String[] ALL_CONTR_VALUES =  {"Contribution_Arrangement__NonContributory_Employer_Paid","Contribution_Arrangement__Contributory_Shared"};

	public void firePlanConfigRuleEngine_ContrArrangement() throws Exception{
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;

		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();

		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}

		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);

		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);

		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		User usr = new User();
		planDtlMap.setUser(usr);
		planDtlMap.getUser().setIsUserExcepRole("true");
		planDtlMap.setSicId("10");
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("12000");// rule-1043
		planDtlMap.setTotalLives(28);
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_GA"); // rule-1043
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_IFS"); // rule-1034
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("4520"); // rule-1034
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("1245");// rule-1027
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).setFieldValue("20");//rule-1029
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue("426");
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("Non-PruValue"); // rule-1017
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue("52140000000"); // rule-1016,1015
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("12444");//rule-1014
		planDtlMap.get(PlanConfigConstants.LBO_PCT).setFieldValue("52");//rule-1013
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("251789"); //rule-1011,10
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_LDSM");
		PlanDetailsMap modifiedPlanDtlMap = planDtlMap;
		System.out.println(planDtlMap.get(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE));
		modifiedPlanDtlMap.get(PlanConfigConstants.CONTRI_ARRANG).setFieldValue("Contribution_Arrangement__NonContributory_Employer_Paid");
		callDroolFile(planDtlMap);
		
		//modifiedPlanDtlMap.get(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE).setFieldValue(null);
		//modifiedPlanDtlMap.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT).setFieldValue(null);

		/*modifiedPlanDtlMap.get(PlanConfigConstants.CONTRI_ARRANG).setFieldValue("Contribution_Arrangement__Contributory_Shared");*/




		modifiedPlanDtlMap.get(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE).setFieldValue("Employee_Contribution_Type__Flat_Amount");

		modifiedPlanDtlMap.get(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE).setFieldValue("Employee_Contribution_Type__Percentage");

		modifiedPlanDtlMap.get(PlanConfigConstants.CONTRI_ARRANG).setFieldValue("Contribution_Arrangement__NonContributory_Employer_Paid");

	}


	public  void callDroolFile(PlanDetailsMap planDetailsMap){
		/* For Choice Rule DRL File Invoking*/
		RuleUtility.getInitsData("DRL", "..\\resources\\basicLife\\BL_PlanConfigRulesOnChange.drl", "PlanConfig", new Object[] {planDetailsMap});
	}


}
