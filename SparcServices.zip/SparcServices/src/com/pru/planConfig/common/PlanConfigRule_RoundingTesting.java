package com.pru.planConfig.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.bo.model.User;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;

public class PlanConfigRule_RoundingTesting {

	static final String[] ROUNDING_VALUES = {"Choose_One", "Rounding_Occurs__After_Amount_is_Multiplied", "Rounding_Occurs__Before_Amount_is_Multiplied"};
	
	
	public void firePlanConfigRuleEngine_Rounding() throws Exception{
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		User usr = new User();
		planDtlMap.setUser(usr);
		planDtlMap.getUser().setIsUserExcepRole("true");
		planDtlMap.setSicId("10");
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("12000");// rule-1043
		planDtlMap.setTotalLives(28);
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_GA"); // rule-1043
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_IFS"); // rule-1034
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("4520"); // rule-1034
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("1245");// rule-1027
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).setFieldValue("20");//rule-1029
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue("426");
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("Non-PruValue"); // rule-1017
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue("52140000000"); // rule-1016,1015
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("12444");//rule-1014
		planDtlMap.get(PlanConfigConstants.LBO_PCT).setFieldValue("52");//rule-1013
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("251789"); //rule-1011,10
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_LDSM");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__NA");
		callDroolFile(planDtlMap);
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Higher_1");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Higher_10");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Higher_100");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Higher_1000");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Lower_1");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Lower_100");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Lower_1000");
	
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__NA");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Nearer_1000_Round_Down");
		
		planDtlMap = buildRoundingRuleValue(planDtlMap, "Rounding_Rule__Nearer_1000_Round_Up");
	}
	
	
	
	
	
	public  void callDroolFile(PlanDetailsMap planDetailsMap){
		/* For Choice Rule DRL File Invoking*/
		RuleUtility.getInitsData("DRL", "..\\resources\\basicLife\\BL_PlanConfigRulesOnChange.drl", "PlanConfig", new Object[] {planDetailsMap});
	}
	
	public static PlanDetailsMap buildRoundingOccurValue(PlanDetailsMap planDtlMap, String Value){
		planDtlMap.get(PlanConfigConstants.ROUNDING_OCCUR).setFieldValue(Value);
		return planDtlMap;
	}
	
	public static PlanDetailsMap buildRoundingRuleValue(PlanDetailsMap planDtlMap, String Value){
		planDtlMap.get(PlanConfigConstants.ROUNDING_RULE).setFieldValue(Value);
		return planDtlMap;
	}
}
