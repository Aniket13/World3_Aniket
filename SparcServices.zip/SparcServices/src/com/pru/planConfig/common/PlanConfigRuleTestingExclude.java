package com.pru.planConfig.common;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;












import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.impl.MainServiceImpl;

public class PlanConfigRuleTestingExclude {

	
	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		//System.out.println("Map="+planMap.toString());
		
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		
		//Exclude inputs starts
		
		//planDtlMap.getPlanMap().put(PlanConfigConstants.PRUVALUEPARTS_ATTRIBUTE, new PlanMetadata());// added for 21 condition check
		planDtlMap.getPlanMap().get(PlanConfigConstants.PRUVALUEPARTS_ATTRIBUTE).setFieldValue("Grandfathering"); // added for 21 condition check
		
		//start 132
		/*PlanConfigLookup plnConfig1= new PlanConfigLookup();
		plnConfig1.setLookupKey("Employee_Contribution_Type__Employee_Choice");
		plnConfig1.setLookupValue("10.0");
		plnConfig1.setLookupOrder(1);
		
		PlanMetadata pln1 = new PlanMetadata();
		
		
		Map<String,PlanConfigLookup> altMap1 = new HashMap<String,PlanConfigLookup>();
		altMap1.put("Employee_Contribution_Type__Employee_Choice", plnConfig1);
		
		pln1.setAltValues(altMap1);
		
		planDtlMap.getPlanMap().put(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE, pln1);*/
		//ends 132
		
		//start 133
		/*PlanConfigLookup plnConfig2= new PlanConfigLookup();
		plnConfig2.setLookupKey("Employee_Contribution_Type__PostTax");
		plnConfig2.setLookupValue("20.0");
		plnConfig2.setLookupOrder(2);
		
		PlanMetadata pln2 = new PlanMetadata();
		
		
		Map<String,PlanConfigLookup> altMap2 = new HashMap<String,PlanConfigLookup>();
		altMap2.put("Employee_Contribution_Type__PostTax", plnConfig2);
		
		pln2.setAltValues(altMap2);
		
		planDtlMap.getPlanMap().put(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE, pln2);*/
		//ends 133
		
		//start 134
		/*PlanConfigLookup plnConfig3= new PlanConfigLookup();
		plnConfig3.setLookupKey("Employee_Contribution_Type__PreTax");
		plnConfig3.setLookupValue("30.0");
		plnConfig3.setLookupOrder(3);
		
		PlanMetadata pln3 = new PlanMetadata();
		
		
		Map<String,PlanConfigLookup> altMap3 = new HashMap<String,PlanConfigLookup>();
		altMap3.put("Employee_Contribution_Type__PreTax", plnConfig3);
		
		pln3.setAltValues(altMap3);
		
		planDtlMap.getPlanMap().put(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE, pln3);*/
		//ends 134
		
		//planDtlMap.getPlanMap().put("Enrollment_Assumption", new PlanMetadata());
		
		
		planDtlMap.getPlanMap().get("Amounts_of_Insurance").setFieldValue("Amounts_of_Insurance__Flat_Dollar_Amount");
		
		//planDtlMap.getPlanMap().get("Type_OF_Case").setFieldValue("PruValue_GA_IFS");
		
		planDtlMap.getPlanMap().get("Contribution_Arrangement").setFieldValue("Contribution_Arrangement__NonContributory_Employer_Paid");
		
		
		//planDtlMap.getPlanMap().put("Field_Level_Exceptions_Apply_Attribute", new PlanMetadata());
		planDtlMap.getPlanMap().get("Field_Level_Exceptions_Apply_Attribute").setFieldValue("false");
		
		
		//planDtlMap.getPlanMap().get("Type_OF_Case").setFieldValue("Grandfathering");
		
		//planDtlMap.getPlanMap().get("Type_OF_Case").setFieldValue("PruValue_GA");
		planDtlMap.getPlanMap().get("Type_OF_Case").setFieldValue("PruValue_GA");
		
		planDtlMap.getPlanMap().get("Rounding_Rule").setFieldValue("Rounding_Rule__NA");
		
		planDtlMap.getPlanMap().get("Amounts_of_Insurance").setFieldValue("Amounts_of_Insurance__Grandfathered_Amounts");
		
		planDtlMap.getPlanMap().get("Amounts_of_Insurance").setFieldValue("Amounts_of_Insurance_Percentage_of_Basic_Life_Active_Amount");
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE).setFieldValue("RETIREE LIFE");
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("FL");// 723
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("NJ");//724
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("TX");//725
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("WA");//734
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("MA");//735,736,737,738,739
		
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.PRU_VALUE_PARTS_ATTR).setFieldValue("Grandfathering");//747
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("CT");//747
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("MA");//748
		
		//planDtlMap.getPlanMap().get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_LDSM");//748
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).setFieldValue("Disability_Provision__Dis_A");//761
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).setFieldValue("Disability_Provision__Exception_of_Disability");//764
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.DIASBLE_PROV).setFieldValue("Disability_Provision__None");//767
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.GRANDFATHERING_GROUP).setFieldValue("Grandfathering_Group__Retirees");//788,789,791,792,794,795,796
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.LIFE_BENEFIT_OPTION).setFieldValue("Living_Benefit_Option__No");//824,825
		
		//planDtlMap.getPlanMap().get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_GA");//829,830,837,840
		
		//planDtlMap.getPlanMap().get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_GA");
		
		//planDtlMap.getPlanMap().get(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE).setFieldValue("ACTIVE LIFE");
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_NPV");
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.RATE_EXPR).setFieldValue("Rate_Expression__Per_Individual");//870
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE).setFieldValue("RETIREE LIFE");
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");
		
		planDtlMap.setTotalLives(25);
		
		planDtlMap.getPlanMap().get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_IFS");
		/*PlanMetadata plnMet = new PlanMetadata();
		plnMet.setFieldKey(PlanConfigConstants.TOTAL_LIVES);
		plnMet.setFieldValue(25);*/
		
		// BL_PlanConfigExclude.drl call
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigExclude.drl", "PlanConfigExclude", new Object[] {planDtlMap});
	}
	
	public static void main(String[] args) throws Exception {
		PlanConfigRuleTestingExclude plnConf= new PlanConfigRuleTestingExclude();
		plnConf.firePlanConfigRuleEngine();

	}

}
