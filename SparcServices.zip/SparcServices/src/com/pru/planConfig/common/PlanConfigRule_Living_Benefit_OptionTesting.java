package com.pru.planConfig.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;

public class PlanConfigRule_Living_Benefit_OptionTesting {
	
	@Test
	public void firePlanConfigRuleEngine_Rounding() throws Exception{
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		
		PlanConfigRuleExecution executor = new PlanConfigRuleExecution();
		executor.setPlanDtlMockUpData(planDtlMap);
		
		//simulate dropdown value selecting Living_Benefit_Option__Yes
		planDtlMap = buildRLivingBenefit_OptionRuleValue(planDtlMap, "Living_Benefit_Option__Yes");
		callDroolFile(planDtlMap);
		testLBO_MaximumFieldVisibility(planDtlMap);
		testLBO_PercentageFieldVisibility(planDtlMap);
		testLBO_Life_ExpectancyFieldVisibility(planDtlMap);
		testLBO_Life_ExpectancyAltValuesVisibility(planDtlMap);
		
	}
	
	
	public  void testLBO_MaximumFieldVisibility(PlanDetailsMap planDetailsMap){
		
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.LBO_MAX).getVisibleFlag());
		//Assert.assertEquals("C",  planDetailsMap.get(PlanConfigConstants.RATE_EXPR).getFieldIndicator());
	}
	
	public  void testLBO_PercentageFieldVisibility(PlanDetailsMap planDetailsMap){
		
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.LBO_PCT).getVisibleFlag());
		//Assert.assertEquals("C",  planDetailsMap.get(PlanConfigConstants.RATE_EXPR).getFieldIndicator());
	}
	
public  void testLBO_Life_ExpectancyFieldVisibility(PlanDetailsMap planDetailsMap){
		
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.LBO_LIFE_EXPECTANCY).getVisibleFlag());
		//Assert.assertEquals("C",  planDetailsMap.get(PlanConfigConstants.RATE_EXPR).getFieldIndicator());
	}
	
	public  void testLBO_Life_ExpectancyAltValuesVisibility(PlanDetailsMap planDetailsMap){
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.LBO_LIFE_EXPECTANCY).getAltValues().get("Choose_One").getVisibleFlag());
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.LBO_LIFE_EXPECTANCY).getAltValues().get("LBO_Life_Expectancy__12_months").getVisibleFlag());
		Assert.assertEquals("Yes",  planDetailsMap.get(PlanConfigConstants.LBO_LIFE_EXPECTANCY).getAltValues().get("LBO_Life_Expectancy__6_months").getVisibleFlag());
	}
	
	public  void callDroolFile(PlanDetailsMap planDetailsMap){
		RuleUtility.getInitsData("DRL", "..\\resources\\basicLife\\BL_PlanConfigRulesOnChange.drl", "PlanConfig", new Object[] {planDetailsMap});
	}
	
	
	public static PlanDetailsMap buildRLivingBenefit_OptionRuleValue(PlanDetailsMap planDtlMap, String Value){
		planDtlMap.get(PlanConfigConstants.LIV_BEN_OPN).setFieldValue(Value);
		return planDtlMap;
	}
}
