package com.pru.planConfig.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.impl.MainServiceImpl;

public class PlanConfigRuleTestingSetValuePruValue {

	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();
		MainRepositoryImpl mainRepository = new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor = new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;

		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();

		final List<PlanLookupDetails> lookupList = mainRepository
				.getPlanLookupList();// lookupDetails);
		if (CollectionUtils.isNotEmpty(lookupList)) {
			lookupInfoList = mainServiceProcessor
					.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}

		planMetadataList = planDetailsServiceProcessor
				.setLookupValuesInFieldList(planMetadataList, lookupInfoList);

		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor
				.convertToPlanMap(planMetadataList);

		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy")
				.format(new Date()));
		planDtlMap.setPlanMap(planMap);

		PlanDetailsMap modifiedPlanDtlMap = setPlanDtlMockUpData(planDtlMap);

		/* For SetValue Rule DRL File Invoking */
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigPruValue.drl",
				"PlanConfigPruValue", new Object[] { modifiedPlanDtlMap });
	}

	public PlanDetailsMap setPlanDtlMockUpData(PlanDetailsMap planDtlMap) {
	
		return planDtlMap;
	}

	public static void main(String[] args) throws Exception {
		PlanConfigRuleTestingSetValuePruValue plnConf = new PlanConfigRuleTestingSetValuePruValue();
		plnConf.firePlanConfigRuleEngine();

	}

}
