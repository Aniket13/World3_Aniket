package com.pru.planConfig.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;

public class PlanConfigRule_AgeReductionScheduleTesting {

	static final String[] AGE_REDUCTION_SCHEDULE_VALUES = {"Choose_One", "Age_Reduction_Schedule__35__65", "Age_Reduction_Schedule__35__65_50__70", "Age_Reduction_Schedule__35__70_50__75",
		"Age_Reduction_Schedule__40__65", "Age_Reduction_Schedule__40__65_60__70", "Age_Reduction_Schedule__40__65_60__70_75__75_85__80", "Age_Reduction_Schedule__50__Age_70",
	"Age_Reduction_Schedule__8_per_year_beginning__age_65_to_a_cumulative_reduction_of_40__70"};

	@Test
	public void firePlanConfigRuleEngine_AgeSchedule() throws Exception{
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;

		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();

		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}

		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);

		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);

		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);

		//PlanConfigRuleExecution executor = new PlanConfigRuleExecution();
		//PlanDetailsMap modifiedPlanDtlMap = executor.setPlanDtlMockUpData(planDtlMap);
		//callDroolFile(modifiedPlanDtlMap);
		//testAllAgeScheduleValues(modifiedPlanDtlMap);
		
		callDroolFile(planDtlMap);
		testAllAgeScheduleValues(planDtlMap);
		
		

	}

	public  void testAllAgeScheduleValues(PlanDetailsMap planDetailsMap){
		for(String ageReduction : AGE_REDUCTION_SCHEDULE_VALUES){
			Assert.assertEquals("Yes", planDetailsMap.get(PlanConfigConstants.AGE_RED_SCH).getAltValues().get(ageReduction).getVisibleFlag());
			//Assert.assertEquals(9, planDetailsMap.get(PlanConfigConstants.AGE_RED_SCH).getAltValues().size());
		}
	}

	public  void callDroolFile(PlanDetailsMap planDetailsMap){
		/* For Choice Rule DRL File Invoking*/
		RuleUtility.getInitsData("DRL", "..\\resources\\basicLife\\BL_PlanConfigRulesOnChange.drl", "PlanConfig", new Object[] {planDetailsMap});
	}


}
