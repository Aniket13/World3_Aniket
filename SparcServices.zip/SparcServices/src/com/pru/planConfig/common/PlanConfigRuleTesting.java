package com.pru.planConfig.common;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;










import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.impl.MainServiceImpl;

public class PlanConfigRuleTesting {

	
	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		
		
		
		
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		
		
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		
		PlanDetailsMap modifiedPlanDtlMap = setPlanDtlMockUpData(planDtlMap);
		
		
		/* For Choice Rule DRL File Invoking*/
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfig_SetValue.drl", "PlanConfig", new Object[] {planDtlMap});
		
		/* For Include Rule DRL File Invoking*/
		//RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigInclude.drl", "PlanConfigInclude", new Object[] {modifiedPlanDtlMap});
		
		/* For invloking Main consolidate DRL File*/
		//RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfig_Final_ShowMap.drl", "PlanConfig", new Object[] {modifiedPlanDtlMap});
		
		
		
		/* For SetValue Rule DRL File Invoking*/
		//RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfig_SetValue.drl", "PlanConfig", new Object[] {planDtlMap});
	}
	
	public PlanDetailsMap setPlanDtlMockUpData(PlanDetailsMap planDtlMap){
		//planDtlMap.get(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE).setFieldValue("Employee_Contribution_Type__Flat_Amount"); // rule-253
		planDtlMap.get(PlanConfigConstants.EMPLOYEE_CONTRIBUTION_TYPE).setFieldValue("Employee_Contribution_Type__Percentage");  // rule-254
		planDtlMap.get(PlanConfigConstants.GURARNTEE_ISSUE_LIMIT).setFieldValue("Guarantee_Issue_Limit__Multiple_of_Earnings");  // rule-906
		planDtlMap.get(PlanConfigConstants.GURARNTEE_ISSUE_LIMIT).setFieldValue("Guarantee_Issue_Limit__Lesser_of_Dollar_and_Multiple_of_Earnings");  // rule-905
		planDtlMap.get(PlanConfigConstants.GURARNTEE_ISSUE_LIMIT).setFieldValue("Guarantee_Issue_Limit__Greater_of_Dollar_and_Multiple_of_Earnings");  // rule-904
		planDtlMap.get(PlanConfigConstants.GURARNTEE_ISSUE_LIMIT).setFieldValue("Guarantee_Issue_Limit__Dollar");  // rule-903
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("Guarantee_Issue_Limit__Dollar");  // rule-902
		planDtlMap.setTotalLives(50); // rule-902
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false"); // rule-902
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue("2");// rule-902
		planDtlMap.get(PlanConfigConstants.DURATION).setFieldValue("Duration__Other");  // rule-900
		planDtlMap.get(PlanConfigConstants.DIASBLE_PROV).setFieldValue("Disability_Provision__Premium_Continuance");  // rule-899
		planDtlMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("CT");  // rule-898
		planDtlMap.get(PlanConfigConstants.LIFE_BENEFIT_OPTION).setFieldValue("Living_Benefit_Option__Yes");  // rule-898
		planDtlMap.get(PlanConfigConstants.AMT_INSU).setFieldValue("Amounts_of_Insurance_Percentage_of_Basic_Life_Active_Amount");  // rule-896
		
		planDtlMap.get(PlanConfigConstants.AGE_RED_SCH).setFieldValue("Age_Reduction_Schedule__Other");  // rule-895
		planDtlMap.get(PlanConfigConstants.ROUNDING_RULE).setFieldValue("Rounding_Rule__Other");  // rule-265
		planDtlMap.get(PlanConfigConstants.RATE_EXPR).setFieldValue("Rate_Expression__Other");  // rule-262
		planDtlMap.get(PlanConfigConstants.PRUVALUE_TYPE_ATTRIBUTE).setFieldValue("Grandfathering");  // rule-261
		
		
		return planDtlMap;
	}
	public static void main(String[] args) throws Exception {
		PlanConfigRuleTesting plnConf= new PlanConfigRuleTesting();
		plnConf.firePlanConfigRuleEngine();

	}

}
