package com.pru.planConfig.common;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;











import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.bo.model.User;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.impl.MainServiceImpl;

public class PlanConfigRuleTestingSetValue {

	
	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		
		
		
		
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		
		
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		
		PlanDetailsMap modifiedPlanDtlMap = setPlanDtlMockUpData(planDtlMap);
		
		
		
		/* For SetValue Rule DRL File Invoking*/
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfig_SetValue.drl", "PlanConfig", new Object[] {modifiedPlanDtlMap});
	}
	
	public PlanDetailsMap setPlanDtlMockUpData(PlanDetailsMap planDtlMap){
		planDtlMap.get(PlanConfigConstants.PRUVALUE_TYPE_ATTRIBUTE).setFieldValue("Grandfathering");  // rule-1045
		planDtlMap.setSicId("8715"); // rule-1045
		PlanMetadata plnM1= new PlanMetadata();
		plnM1.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		plnM1.setFieldValue("200000");
		planDtlMap.put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,plnM1); // rule-1045
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("12000");// rule-1043
		planDtlMap.setTotalLives(28);
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_GA"); // rule-1043
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_IFS"); // rule-1034
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("4520"); // rule-1034
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).setFieldValue("20");
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("1245");
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue("426");
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("Non-PruValue"); // rule-1017
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue("52140000000"); // rule-1016,1015
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("12444");//rule-1014
		
		planDtlMap.get(PlanConfigConstants.LBO_PCT).setFieldValue("52");//rule-1013
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("251789"); //rule-1011,1010,1009
		
		planDtlMap.get(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("2000");// rule-1008
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true"); //rule-976
		
		planDtlMap.get(PlanConfigConstants.LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTES__LBO_MAXIMUM).setFieldValue("0"); // rule-976
		
		//planDtlMap.get(PlanConfigConstants.IS_USER_EXCEPTION_ROLE_ATTRIBUTE).setFieldValue("false"); // rule-973
		planDtlMap.get(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT).setFieldValue("542");// rule-973
		planDtlMap.get(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT).setFieldValue("152"); // rule-973
		
		planDtlMap.get(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNTATTRIBUTES_MINIMUM_DOLLAR_AMOUNT).setFieldValue("12548");// rule-972
		planDtlMap.get(PlanConfigConstants.PERCENTAGE_OF_BASIC_LIFE_ACTIVE_AMOUNT_EXCEPTION_ATTRIBUTES_MINIMUM_DOLLAR_AMOUNT).setFieldValue("542"); // rule-972
		User usr = new User();
		planDtlMap.setUser(usr);
		planDtlMap.getUser().setIsUserExcepRole("true");
		
		planDtlMap.get(PlanConfigConstants.LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTE__LBO_PERCENTAGE).setFieldValue("121"); // rule-969
		planDtlMap.get(PlanConfigConstants.LBO_PCT).setFieldValue("25"); // rule-969
		
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("124"); // rule-968
		planDtlMap.get(PlanConfigConstants.LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTE__LBO_MAXIMUM).setFieldValue("66"); // rule-968
		
		planDtlMap.get(PlanConfigConstants.LBO_LIFE_EXPECTANCY_ATTRIBUTES__OTHER).setFieldValue("22");
		planDtlMap.get(PlanConfigConstants.LBO_LIFE_EXPECTANCY_EXCEPTION_ATTRIBUTES__OTHER).setFieldValue("11");
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MULTIPLE_OF_EARNINGS).setFieldValue("10");//rule-964
		planDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_EARNINGS).setFieldValue("20"); //rule-964
		
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).setFieldValue("125");//rule-963
		
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_EXCEPTION_ATTRIBUTES_DOLLAR_AMOUNT).setFieldValue("111");//rule-962
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_EARNINGS__NO_EXCEPTION_MAX).setFieldValue("5");//rule-961
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).setFieldValue("0");//rule-960
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__DOLLAR_AMOUNT__NO_EXCEPTION_MAX).setFieldValue("1021");//rule-958
		
		planDtlMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("IN");// rule-941 
		planDtlMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("UT");// rule-942
		
		planDtlMap.get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).setFieldValue("0");//rule-937
		
		planDtlMap.get(PlanConfigConstants.DURATION_ATTRIBUTES__OTHER).setFieldValue("57"); //rule-937
		
		return planDtlMap;
	}
	public static void main(String[] args) throws Exception {
		PlanConfigRuleTestingSetValue plnConf= new PlanConfigRuleTestingSetValue();
		plnConf.firePlanConfigRuleEngine();

	}

}
