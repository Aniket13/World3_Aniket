package com.pru.planConfig.common;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;

public class PlanConfigRuleTestingSetCompFieldValue {

	@Test
	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;

		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();

		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}

		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);

		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);



		planDtlMap.setPlanCreationDate("08/09/2016");
		//planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);

		PlanDetailsMap modifiedPlanDtlMap = setPlanDtlMockUpData(planDtlMap);

		RuleUtility
		.getInitsData(
				"DT",
				"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Guarantee_Issue_Limit_Attributes__Maximum_Dollar_Cap_960_SetCompFieldValue.xls",
				"Guarantee_Issue_Limit_Attributes__Maximum_Dollar_Cap960", new Object[] { modifiedPlanDtlMap });
		
		RuleUtility
		.getInitsData(
				"DT",
				"com//pru//sparc//ratingengine//DecisionTables//SetValue//BL_Living_Benefit_Option_Attributes__LBO_Percentage_942.xls",
				"Living_Benefit_Option_Attributes__LBO_Percentage_942", new Object[] { modifiedPlanDtlMap });
		
		System.out.println("-----------------PlanDetailsMap Map--------------------");
		RuleUtility.showMap(modifiedPlanDtlMap.getPlanMap());
		
		assertEquals("C", modifiedPlanDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).getFieldIndicator() );
		assertEquals("C", modifiedPlanDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP__NO_EXCEPTION_MAX).getFieldIndicator() );
		assertEquals("C", modifiedPlanDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).getFieldIndicator() );
		assertEquals("Yes", modifiedPlanDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).getVisibleFlag() );
		assertEquals("Yes", modifiedPlanDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).getVisibleFlag() );
		assertEquals("Yes", modifiedPlanDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP__NO_EXCEPTION_MAX).getVisibleFlag() );
		
		
		assertEquals("C", modifiedPlanDtlMap.get(PlanConfigConstants.LBO_PCT).getFieldIndicator() );
		assertEquals("Yes", modifiedPlanDtlMap.get(PlanConfigConstants.LBO_PCT).getVisibleFlag() );
	}

	public PlanDetailsMap setPlanDtlMockUpData(PlanDetailsMap planDtlMap){
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).setFieldValue("20");//960
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false"); //960
		planDtlMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("WV"); //942
		planDtlMap.get(PlanConfigConstants.LBO_PCT).setFieldValue("20"); //942
		return planDtlMap;
	}


}
