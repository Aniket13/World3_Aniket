package com.pru.planConfig.common;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;











import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.bo.model.User;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.impl.MainServiceImpl;

public class PlanConfigRuleTestingSetValueRanjay {

	
	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		
		
		
		
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		
		
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		
		PlanDetailsMap modifiedPlanDtlMap = setPlanDtlMockUpData(planDtlMap);
		
		
		
		/* For SetValue Rule DRL File Invoking*/
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfig_SetValueRanjay.drl", "PlanConfig", new Object[] {modifiedPlanDtlMap});
	}
	
	public PlanDetailsMap setPlanDtlMockUpData(PlanDetailsMap planDtlMap){
		planDtlMap.get(PlanConfigConstants.PRUVALUE_TYPE_ATTRIBUTE).setFieldValue("Grandfathering");  // rule-1045
		planDtlMap.setSicId("8715"); // rule-1045
		PlanMetadata plnM1= new PlanMetadata();
		plnM1.setFieldKey(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT);
		plnM1.setFieldValue("200000");
		planDtlMap.put(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT,plnM1); // rule-1045
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("12000");// rule-1043
		planDtlMap.setTotalLives(8);
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_GA"); // rule-1043
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_IFS"); // rule-1034
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("4520"); // rule-1034
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).setFieldValue("20");
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("1245");
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue("426");
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("Non-PruValue"); // rule-1017
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue("52140000000"); // rule-1016,1015
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("12444");//rule-1014
		
		planDtlMap.get(PlanConfigConstants.LBO_PCT).setFieldValue("52");//rule-1013
		planDtlMap.get(PlanConfigConstants.LBO_MAX).setFieldValue("251789"); //rule-1011,1010,1009
		
		planDtlMap.get(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("2000");// rule-1008
		
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//rule-50
		
		planDtlMap.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT).setFieldValue("66");//rule-50
		planDtlMap.get(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT).setFieldValue("0");//rule-50
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//rule-50
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue("100");//rule-267
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//rule-274
		
		planDtlMap.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE).setFieldValue("0");//rule-274
		
		planDtlMap.setTotalLives(25);//rule-274
		
		
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//
		
		User usr = new User();
		planDtlMap.setUser(usr);
		planDtlMap.getUser().setIsUserExcepRole("false");
		System.out.println("User Obj-"+planDtlMap.getUser());
		
		planDtlMap.get(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("100");//
		planDtlMap.get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).setFieldValue("200");//
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("300");//
		planDtlMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("400");//
		
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue("500");//
		planDtlMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue("600");//
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue("700");//
		planDtlMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MULTIPLE_OF_ANNUAL_EARNINGS).setFieldValue("800");//
		
		planDtlMap.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT).setFieldValue("450");//
		planDtlMap.get(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_FLAT_AMOUNT).setFieldValue("550");//
		
		
		planDtlMap.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE).setFieldValue("440");//
		planDtlMap.get(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE).setFieldValue("540");//
		
		planDtlMap.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE).setFieldValue("340");//
		planDtlMap.get(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE).setFieldValue("540");//
		
		planDtlMap.get(PlanConfigConstants.RATE_EXPRESSION_ATTRIBUTES__OTHER).setFieldValue("240");//
		planDtlMap.get(PlanConfigConstants.RATE__EXPRESSION_EXCEPTION_ATTRIBUTES__OTHER).setFieldValue("250");//
		
		
		planDtlMap.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE).setFieldValue("0");//rule-294
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//295
		
		planDtlMap.get(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__MINIMUM_PARTICIPATION_PERCENTAGE).setFieldValue("90");//295
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__MULTIPLE_OF_EARNINGS).setFieldValue("100");//920
		
		planDtlMap.get(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE).setFieldValue("ACTIVE LIFE");//922
		
		planDtlMap.get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).setFieldValue("0");//922
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//922
		
		planDtlMap.get(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("2003");// rule-923
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//923
		
		planDtlMap.get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).setFieldValue("0");//923
		
		
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//280
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setOnChange("allowsNegative()");//280
		
		planDtlMap.get(PlanConfigConstants.AMT_INSU).setFieldValue("Amounts_of_Insurance__Flat_Dollar_Amount");//270
		planDtlMap.get(PlanConfigConstants.AMT_INSU).setFieldValue("Amounts_of_Insurance__Multiple_of_Earnings__Flat_Dollar_Amount");//271
		
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_IFS");//1038
		planDtlMap.setTotalLives(23);//1038
		
		planDtlMap.setSicId("6210");
		planDtlMap.get(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE).setFieldValue("RETIREE LIFE");//954
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_EXCEPTION_ATTRIBUTES_DOLLAR_AMOUNT).setFieldValue("0");//954
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//954
		
		planDtlMap.get(PlanConfigConstants.GUARANTEE__ISSUE_LIMIT_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_CAP).setFieldValue("0");//959
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MAXIMUM_DOLLAR_AMOUNT).setFieldValue("0");//979
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//979
		
		
		planDtlMap.get(PlanConfigConstants.FLAT__DOLLAR__AMOUNT__ATTRIBUTES__DOLLAR_AMOUNT_EXCEPTION).setFieldValue("0");//989
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//989
		planDtlMap.get(PlanConfigConstants.SUBPRODUCT_ATTRIBUTE).setFieldValue("RETIREE LIFE");//989
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("Grandfathering"); //989
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//989
		
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//950
		planDtlMap.get(PlanConfigConstants.DURATION_ATTRIBUTES__OTHER).setFieldValue("250");//950
		
		
		
		planDtlMap.get(PlanConfigConstants.DURATION__EXCEPTION_ATTRIBUTES__OTHER).setFieldValue("0");//950
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//950
		
		planDtlMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue("TX");//945
		planDtlMap.get(PlanConfigConstants.LBO_PCT).setFieldValue("555");//945
		
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue("666");//981
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//981
		
		planDtlMap.get(PlanConfigConstants.MULTIPLE__OF_EARNINGS_EXCEPTION_ATTRIBUTES__MINIMUM_DOLLAR_AMOUNT).setFieldValue("0");//981
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//981
		
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("false");//987
		
		planDtlMap.get(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE).setFieldValue("0");//987
		
		
		planDtlMap.get(PlanConfigConstants.PLAN__CONTRIBUTION_EXCEPTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE__NO_EXCEPTION_MAX).setFieldValue("0");//988
		planDtlMap.setTotalLives(25);//988
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//988
		planDtlMap.get(PlanConfigConstants.PLAN_CONTRIBUTION_ATTRIBUTES__EMPLOYEE_CONTRIBUTION_PERCENTAGE).setFieldValue("20");//988
		
		
		planDtlMap.get(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("77");//1007
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("PruValue_GA"); //1007
		planDtlMap.get(PlanConfigConstants.FLAT_DOLLAR_AMOUNT_ATTRIBUTES__DOLLAR_AMOUNT).setOnFocus("allowsNegative");//1007
		
		
		planDtlMap.get(PlanConfigConstants.PRU_VALUE_ATTR).setFieldValue("Grandfathering"); //996
		planDtlMap.get(PlanConfigConstants.LBO_PCT).setFieldValue("30"); //996
		
		
		planDtlMap.setSicId("6210");//956
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_EXCEPTION_ATTRIBUTES_DOLLAR_AMOUNT).setFieldValue("0"); //956
		planDtlMap.get(PlanConfigConstants.FIELD_LEVEL_EXCEPTIONS_APPLY_ATTRIBUTE).setFieldValue("true");//956
		planDtlMap.get(PlanConfigConstants.GUARANTEE_ISSUE_LIMIT_ATTRIBUTES__DOLLAR_AMOUNT).setFieldValue("656"); //956
		
		
		planDtlMap.get(PlanConfigConstants.LIVING__BENEFIT_OPTION_EXCEPTION_ATTRIBUTE__LBO_PERCENTAGE).setFieldValue("0"); //978
		
		
		
		
		return planDtlMap;
	}
	public static void main(String[] args) throws Exception {
		PlanConfigRuleTestingSetValueRanjay plnConf= new PlanConfigRuleTestingSetValueRanjay();
		plnConf.firePlanConfigRuleEngine();

	}

}
