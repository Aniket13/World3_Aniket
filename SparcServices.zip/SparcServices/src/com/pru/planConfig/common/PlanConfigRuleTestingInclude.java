package com.pru.planConfig.common;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;











import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.impl.MainServiceImpl;

public class PlanConfigRuleTestingInclude {

	
	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();
		MainRepositoryImpl mainRepository= new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor= new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		
		final List<PlanLookupDetails> lookupList = mainRepository.getPlanLookupList();//lookupDetails);
		if(CollectionUtils.isNotEmpty(lookupList)){
			lookupInfoList = mainServiceProcessor.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}
		
		planMetadataList = planDetailsServiceProcessor.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor.convertToPlanMap(planMetadataList);
		
		//System.out.println("Map="+planMap.toString());
		
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
		planDtlMap.setPlanMap(planMap);
		
		//planDtlMap.getPlanMap().get("Amounts_Of_Insurance").setFieldValue("Amounts_of_Insurance__Flat_Dollar_Amount"); added hard code for rule 249 to execute
		//planDtlMap.getPlanMap().get("Amounts_Of_Insurance").setFieldValue("Amounts_of_Insurance__Incremental_Flat_Dollar_Amounts"); //added hard code for rule 250 to execute
		//planDtlMap.getPlanMap().get("Amounts_Of_Insurance").setFieldValue("Amounts_of_Insurance__Multiple_of_Earnings__Flat_Dollar_Amount"); //added hard code for rule 251 to execute
		//planDtlMap.getPlanMap().get("Amounts_Of_Insurance").setFieldValue("Amounts_of_Insurance__Multiple_of_Earnings"); //added hard code for rule 252 to execute
		
		//planDtlMap.getPlanMap().put("Employee_Contribution_Type__Flat_Amount", new PlanMetadata());//added hard code for rule 253 to execute
		//planDtlMap.getPlanMap().get("Employee_Contribution_Type__Flat_Amount").setFieldValue("Employee_Contribution_Type__Flat_Amount"); //added hard code for rule 253 to execute
		//planDtlMap.getPlanMap().get("Employee_Contribution_Type__Flat_Amount").setFieldValue("Employee_Contribution_Type__Percentage"); //added hard code for rule 254 to execute
		
		//added hard code for rule 261 to execute starts
		planDtlMap.getPlanMap().put("PruValue_Type_Attribute", new PlanMetadata());
		planDtlMap.getPlanMap().get("PruValue_Type_Attribute").setFieldValue("Grandfathering"); 
		
		
		PlanConfigLookup plnConfig1= new PlanConfigLookup();
		plnConfig1.setLookupKey("Grandfathering");
		plnConfig1.setLookupValue("10.0");
		plnConfig1.setLookupOrder(1);
		
		PlanMetadata pln = new PlanMetadata();
		
		
		Map<String,PlanConfigLookup> altMap = new HashMap<String,PlanConfigLookup>();
		altMap.put("Grandfathering", plnConfig1);
		
		pln.setAltValues(altMap);
		
		planDtlMap.getPlanMap().put("PruValueParts_Attribute", pln);
		//added hard code for rule 261 to execute ends
		
		
		planDtlMap.getPlanMap().put("Rate_Expression", new PlanMetadata());//added hard code for rule 262 to execute
		planDtlMap.getPlanMap().get("Rate_Expression").setFieldValue("Rate_Expression__Other"); //added hard code for rule 262 to execute
		
		planDtlMap.getPlanMap().put("Rounding_Rule", new PlanMetadata());//added hard code for rule 265 to execute
		planDtlMap.getPlanMap().get("Rounding_Rule").setFieldValue("Rounding_Rule__Other"); //added hard code for rule 265 to execute
		
		
		planDtlMap.getPlanMap().put("Age_Reduction_Schedule", new PlanMetadata());//added hard code for rule 895 to execute
		planDtlMap.getPlanMap().get("Age_Reduction_Schedule").setFieldValue("Age_Reduction_Schedule__Other"); //added hard code for rule 895 to execute
		
		planDtlMap.getPlanMap().get("Amounts_of_Insurance").setFieldValue("Amounts_of_Insurance_Percentage_of_Basic_Life_Active_Amount"); //added hard code for rule 896 to execute
		
		planDtlMap.getPlanMap().put("Current_Contract_State_Attribute", new PlanMetadata());//added hard code for rule 898 to execute
		planDtlMap.getPlanMap().get("Current_Contract_State_Attribute").setFieldValue("NY"); //added hard code for rule 898 to execute
		
		planDtlMap.getPlanMap().put("Living_Benefit_Option", new PlanMetadata());//added hard code for rule 898 to execute
		planDtlMap.getPlanMap().get("Living_Benefit_Option").setFieldValue("Living_Benefit_Option__Yes"); //added hard code for rule 898 to execute
		
		
		planDtlMap.getPlanMap().get("Disability_Provision").setFieldValue("Disability_Provision__Premium_Continuance"); //added hard code for rule 899 to execute
		planDtlMap.getPlanMap().get("Duration").setFieldValue("Duration__Other"); //added hard code for rule 900 to execute
		//planDtlMap.getPlanMap().get("Guarantee_Issue_Limit").setFieldValue("Guarantee_Issue_Limit__Dollar"); //added hard code for rule 903 to execute
		
		//planDtlMap.getPlanMap().get("Guarantee_Issue_Limit").setFieldValue("Guarantee_Issue_Limit__Greater_of_Dollar_and_Multiple_of_Earnings"); //added hard code for rule 904 to execute
		
		//planDtlMap.getPlanMap().get("Guarantee_Issue_Limit").setFieldValue("Guarantee_Issue_Limit__Lesser_of_Dollar_and_Multiple_of_Earnings"); //added hard code for rule 905 to execute
		
		planDtlMap.getPlanMap().get("Guarantee_Issue_Limit").setFieldValue("Guarantee_Issue_Limit__Multiple_of_Earnings"); //added hard code for rule 906 to execute
		
		planDtlMap.getPlanMap().get("LBO_Life_Expectancy").setFieldValue("LBO_Life_Expectancy__Other"); //added hard code for rule 907 to execute
		
		planDtlMap.getPlanMap().get("Living_Benefit_Option").setFieldValue("Living_Benefit_Option__Yes"); //added hard code for rule 908 to execute
		
		
		planDtlMap.getPlanMap().put("Multinational_Pooling_Attribute", new PlanMetadata());//added hard code for rule 909 to execute
		planDtlMap.getPlanMap().get("Multinational_Pooling_Attribute").setFieldValue("true"); //added hard code for rule 909 to execute
		
		//added hard code for rule 909 to execute starts
		PlanConfigLookup plnConfig2= new PlanConfigLookup();
		plnConfig2.setLookupKey("Experience_Arrangement__Participating");
		plnConfig2.setLookupValue("22.0");
		plnConfig2.setLookupOrder(1);
		
		PlanMetadata pln1 = new PlanMetadata();
		
		
		Map<String,PlanConfigLookup> altMap1 = new HashMap<String,PlanConfigLookup>();
		altMap1.put("Experience_Arrangement__Participating", plnConfig2);
		
		pln1.setAltValues(altMap1);
		
		planDtlMap.getPlanMap().put("Experience_Arrangement", pln1);
		//added hard code for rule 909 to execute ends
		
		
		
		planDtlMap.getPlanMap().put("Field_Level_Exceptions_Apply_Attribute", new PlanMetadata());//added hard code for rule 902 to execute
		planDtlMap.getPlanMap().get("Field_Level_Exceptions_Apply_Attribute").setFieldValue("false"); //added hard code for rule 902 to execute
		
		planDtlMap.getPlanMap().put("Total_Lives", new PlanMetadata());//added hard code for rule 902 to execute
		planDtlMap.getPlanMap().get("Total_Lives").setFieldValue("25"); //added hard code for rule 902 to execute
		
		planDtlMap.getPlanMap().put("Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings", new PlanMetadata());//added hard code for rule 902 to execute
		planDtlMap.getPlanMap().get("Multiple_of_Earnings_Attributes__Multiple_of_Annual_Earnings").setFieldValue("4"); //added hard code for rule 902 to execute
		
		planDtlMap.getPlanMap().put(PlanConfigConstants.MULTIPLE_OF_EARNINGS_ATTRIBUTES_MULTIPLE_OF_ANNUAL_EARNINGS_NO_EXCEPTION_MAX, new PlanMetadata());//added hard code for rule 902 to execute
		
		
		// BL_PlanConfigInclude.drl call
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigInclude.drl", "PlanConfigInclude", new Object[] {planDtlMap});
	}
	
	public static void main(String[] args) throws Exception {
		PlanConfigRuleTestingInclude plnConf= new PlanConfigRuleTestingInclude();
		plnConf.firePlanConfigRuleEngine();

	}

}
