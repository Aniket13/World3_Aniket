package com.pru.planConfig.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.pru.sparc.bo.model.PlanConfigLookup;
import com.pru.sparc.bo.model.PlanDetailsMap;
import com.pru.sparc.bo.model.PlanMetadata;
import com.pru.sparc.common.util.PlanConfigConstants;
import com.pru.sparc.dao.impl.MainRepositoryImpl;
import com.pru.sparc.drools.helper.DynamicPlanFieldhelper;
import com.pru.sparc.drools.helper.RuleUtility;
import com.pru.sparc.model.PlanLookupDetails;
import com.pru.sparc.processor.MainServiceProcessor;
import com.pru.sparc.processor.PlanDetailsServiceProcessor;
import com.pru.sparc.service.impl.MainServiceImpl;

public class PlanConfigRuleTesting_AD {

	public void firePlanConfigRuleEngine() throws Exception {
		PlanDetailsMap planDtlMap = new PlanDetailsMap();
		DynamicPlanFieldhelper planHelper = new DynamicPlanFieldhelper();
		PlanDetailsServiceProcessor planDetailsServiceProcessor = new PlanDetailsServiceProcessor();
		MainServiceImpl mainService = new MainServiceImpl();
		MainRepositoryImpl mainRepository = new MainRepositoryImpl();
		MainServiceProcessor mainServiceProcessor = new MainServiceProcessor();
		List<PlanConfigLookup> lookupInfoList = null;
		List<PlanMetadata> planMetadataList = planHelper.fetchPlanMetaData();
		final List<PlanLookupDetails> lookupList = mainRepository
				.getPlanLookupList();// lookupDetails);
		if (CollectionUtils.isNotEmpty(lookupList)) {
			lookupInfoList = mainServiceProcessor
					.mapPlanLookupDetailsListToPlanConfigLookupList(lookupList);
		}

		planMetadataList = planDetailsServiceProcessor
				.setLookupValuesInFieldList(planMetadataList, lookupInfoList);
		Map<String, PlanMetadata> planMap = planDetailsServiceProcessor
				.convertToPlanMap(planMetadataList);

	
		planDtlMap.setPlanCreationDate("08/09/2016");
		planDtlMap.setCurrentDate(new SimpleDateFormat("MM/dd/yyyy")
				.format(new Date()));
		planDtlMap.setPlanMap(planMap);

		// PlanDetailsMap modifiedPlanDtlMap =
		// setAmounts_of_Insurance_Flat_Dollar_Amount_Rule_270(planDtlMap); //
		// rule-270

		// PlanDetailsMap modifiedPlanDtlMap1 =
		// setAmounts_of_Insurance_Multiple_of_Earnings(planDtlMap);

		// PlanDetailsMap modifiedPlanDtlMap2 =
		// setAmounts_of_Insurance_Multiple_of_Earnings_Flat_Dollar_Amount(planDtlMap);
		PlanDetailsMap modifiedPlanDtlMap = setAmounts_of_Insurance_Flat_Dollar_Amount_Rule_270(planDtlMap);

		/* For Rule DRL File Invoking */
		RuleUtility.getInitsData("DRL", "basicLife\\BL_PlanConfigRulesOnChange.drl",
				"PlanConfig", new Object[] { modifiedPlanDtlMap });
	}

	public PlanDetailsMap setAmounts_of_Insurance_Flat_Dollar_Amount_Rule_270(
			PlanDetailsMap planDtlMap) {

		planDtlMap.get(PlanConfigConstants.AMT_INSU).setFieldValue(
				PlanConfigConstants.AMOUNTS_OF_INSURANCE_FLAT_DOLLAR_AMOUNT);

		return planDtlMap;
	}

	public PlanDetailsMap setAmounts_of_Insurance_Multiple_of_Earnings(
			PlanDetailsMap planDtlMap) {

		planDtlMap.get(PlanConfigConstants.AMT_INSU).setFieldValue(
				"Amounts_of_Insurance__Multiple_of_Earnings");

		return planDtlMap;
	}

	public PlanDetailsMap setAmounts_of_Insurance_Multiple_of_Earnings_Flat_Dollar_Amount(
			PlanDetailsMap planDtlMap) {

		planDtlMap
				.get(PlanConfigConstants.AMT_INSU)
				.setFieldValue(
						"Amounts_of_Insurance__Multiple_of_Earnings__Flat_Dollar_Amount");

		return planDtlMap;
	}

	public PlanDetailsMap setContract_State(PlanDetailsMap planDtlMap) {
		planDtlMap.get(PlanConfigConstants.CURRENT_SELECTED_CONTRACT_STATE_ATTRIBUTE).setFieldValue(
				"CT");

		return planDtlMap;
	}
	public PlanDetailsMap setcon(PlanDetailsMap planDtlMap) {
		planDtlMap.get(PlanConfigConstants.CONTRI_ARRANG).setFieldValue(
				"Contribution_Arrangement__NonContributory_Employer_Paid");

		return planDtlMap;
	}
	
	public PlanDetailsMap setRate_Expression(PlanDetailsMap planDtlMap) {
		planDtlMap.get(PlanConfigConstants.RATE_EXPR).setFieldValue(
				"Rate_Expression__Per_1000_of_coverage_per_month");
		planDtlMap.get(PlanConfigConstants.AGE_BANDED_RATING).setFieldValue("Age_Banded_Rating__Yes");
		return planDtlMap;
	}


	public static void main(String[] args) throws Exception {
		PlanConfigRuleTesting_AD plnConf = new PlanConfigRuleTesting_AD();
		plnConf.firePlanConfigRuleEngine();

	}

}
