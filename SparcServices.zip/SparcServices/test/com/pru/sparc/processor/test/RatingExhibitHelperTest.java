package com.pru.sparc.processor.test;

import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Comission;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.processor.RatingExhibitHelper;

public class RatingExhibitHelperTest {

	@Test
	public void createRatingInputDataTest(){
		final Logger logger = LoggerFactory.getLogger("RatingExhibitHelperTest.java");
		int proposalVersionId = 348;
		
		RatingExhibitHelper ratingExhibitHelper = new RatingExhibitHelper();
		
		Holding holding = ratingExhibitHelper.createRatingInputData(proposalVersionId);
		
		logger.debug("**************DISPLAYING INPUT DATA START***********************");
		SparcRatingUtil.showMap(holding.getHoldingMap());
		List plans= (List)(holding.getListOfPlans());
		
		for(int i = 0; i < plans.size(); i++){
			holding.setCount(i);
			Plan plan = (Plan) (holding.getListOfPlans().get(holding.getCount()));
			
			logger.debug("**************DISPLAYING PLAN MAP START***********************");
			SparcRatingUtil.showMap(plan.getPlanMap());
			logger.debug("**************DISPLAYING PLAN MAP END***********************");
			
			logger.debug("**************DISPLAYING CENSUS DATA START***********************");
			SparcRatingUtil.showMap(plan.getCensus().getCensusMap());
			logger.debug("**************DISPLAYING CENSUS DATA END***********************");
			
			List people= (plan.getCensus().getListOfPeople());
			/*for(int j=0;j<people.size();j++){
				holding.setPeopleCount(j);
				Person person=(Person) people.get(j);
				logger.debug("**************DISPLAYING PEOPLE DATA START***********************");
				SparcRatingUtil.showMap(person.getPeopleMap());
				logger.debug("**************DISPLAYING PEOPLE DATA END***********************");
			}*/
			
			
			/*List commissions = (List) (plan.getListOfComission());
			for (int j = 0; j < commissions.size(); j++) {
				plan.setCommisionCount(j);
				Comission commission = (Comission) (plan.getListOfComission().get(j));
				logger.debug("**************DISPLAYING COMMISSION DATA START***********************");
				SparcRatingUtil.showMap(commission.getCommissionMap());
				logger.debug("**************DISPLAYING COMMISSION DATA START***********************");
			}	*/
			
			
		}
		logger.debug("**************DISPLAYING INPUT DATA END***********************");
		
		
		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop1\\BL_Plan_Loop1.drl", "plan-loop1",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop2\\BL_Plan_Loop2.drl", "plan-loop2",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop3\\BL_Plan_Loop3.drl", "plan-loop3",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop4\\BL_Plan_Loop4.drl", "plan-loop4",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop5\\BL_Plan_Loop5.drl", "plan-loop5",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop6\\BL_Plan_Loop6.drl", "plan-loop6",
				new Object[] { holding });
		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop7\\BL_Plan_Loop7.drl", "plan-loop7",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop7a\\BL_Plan_Loop7a.drl", "plan-loop7a",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop7b\\BL_Plan_Loop7b.drl", "plan-loop7b",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop8\\BL_Plan_Loop8.drl", "plan-loop8",
				new Object[] { holding });
	}
}
