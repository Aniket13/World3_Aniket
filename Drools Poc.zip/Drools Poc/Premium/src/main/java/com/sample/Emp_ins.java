package com.sample;

public class Emp_ins {
	int empno;
	String ename;
	int dept;
	float sal;
	String insurance;
	float ins_amt;

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getDept() {
		return dept;
	}

	public void setDept(int dept) {
		this.dept = dept;
	}

	public float getSal() {
		return sal;
	}

	public void setSal(float sal) {
		this.sal = sal;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public float getIns_amt() {
		return ins_amt;
	}

	public void setIns_amt(float insAmt) {
		ins_amt = insAmt;
	}
}
