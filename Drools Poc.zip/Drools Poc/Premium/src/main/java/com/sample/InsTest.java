package com.sample;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatelessKnowledgeSession;

public class InsTest {

	public static final void main(String[] args) {
		try {
			// load up the knowledge base
			KnowledgeBase kbase = readKnowledgeBase();

			StatelessKnowledgeSession ksession = kbase
					.newStatelessKnowledgeSession();
			KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory
					.newFileLogger(ksession, "log");

			Emp_ins e1 = new Emp_ins();

			BufferedReader br = new BufferedReader(new InputStreamReader(
					System.in));

			System.out.println("Enter your Empid");
			e1.setEmpno(Integer.parseInt(br.readLine()));
			// e1.setSal(10000);
			System.out.println("Enter your Sal");
			e1.setSal(Float.parseFloat(br.readLine()));
			System.out
					.println("Enter The type of Insurance You want Life/Health/Accident");
			e1.setInsurance(br.readLine());

			System.out.println("Processing employee with data :");

			ksession.execute(e1);
			

			// ksession.insert(e1);

			// "fire all rules"
			// ksession.fireAllRules();

			System.out
					.println("The Employee has to pay an insurance amount of "
							+ e1.getIns_amt());
			logger.close();
			// ksession.dispose();

		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();

		DecisionTableConfiguration config = KnowledgeBuilderFactory
				.newDecisionTableConfiguration();
		config.setInputType(DecisionTableInputType.XLS);
		kbuilder.add(ResourceFactory.newClassPathResource("Premium_Calculation.xls"),
				ResourceType.DTABLE, config);

		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}
}
