package com.sample;

import java.util.concurrent.TimeUnit;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

public class AgendaGroupClient {

	public static void main(String args[]) throws Exception {

		KnowledgeBase kbase = readKnowledgeBase();
		StatefulKnowledgeSession knowledgeSession = kbase
				.newStatefulKnowledgeSession();
		try {
			LoanAmount loanAmount = new LoanAmount();
			loanAmount.setBankBalance(10000);
			loanAmount.setMonthlyInstallment(18000);
			loanAmount.setAccountId("ACC013867");
			Customer customer = new Customer();
			customer.setCustId("C1500564");

			// Performance Check
			long prgStartime = System.nanoTime();

			knowledgeSession.insert(customer);
			knowledgeSession.insert(loanAmount);

		

			knowledgeSession.getAgenda().getAgendaGroup("Thanks").setFocus();
			
			knowledgeSession.fireAllRules();
			/*
			 * long prgEndTime=System.nanoTime(); long
			 * totalExecutionTimeInNanoSeconds=(prgEndTime-prgStartime); double
			 * totalExecutionTimeInMilliSeconds
			 * =(totalExecutionTimeInNanoSeconds)/10000000;
			 * TimeUnit.SECONDS.convert(totalExecutionTimeInNanoSeconds,
			 * TimeUnit.NANOSECONDS); double
			 * totalTimeInSeconds=totalExecutionTimeInMilliSeconds/1000;
			 * System.out.println("totalExecution time in nano Seconds  : "
			 * +totalExecutionTimeInNanoSeconds);
			 * System.out.println("totalExecution time in millisecond  : " +
			 * totalExecutionTimeInMilliSeconds);
			 * System.out.println("totalExecution time in seconds :  " +
			 * TimeUnit.SECONDS.convert(totalExecutionTimeInNanoSeconds,
			 * TimeUnit.NANOSECONDS));
			 */

		} finally {

			knowledgeSession.dispose();
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		
		kbuilder.add(ResourceFactory.newClassPathResource("AgendaGroupD1.xls"),
				ResourceType.DTABLE);
		

		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}

		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}
}