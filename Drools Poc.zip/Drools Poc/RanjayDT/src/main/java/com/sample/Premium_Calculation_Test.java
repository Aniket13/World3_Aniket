package com.sample;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;

/**
 * Premium Calculation based on Member Coverage Amount
 * 
 * @author anikedes
 * 
 */
public class Premium_Calculation_Test {

	public static final void main(String[] args) {
		try {
			// load up the knowledRdge base
			KnowledgeBase kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();
			KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory
					.newFileLogger(ksession, "test");

			ESBPolicyBean esb = new ESBPolicyBean();

			esb.getHmpUserDtls().put("Member_Coverage_amount", "4000.00");

			esb.getHmpUserDtls().put("unitFrequency", "monthly");
			ksession.insert(esb);
			ksession.fireAllRules();
			System.out.println("Member Premium Calculations");
			System.out.println("Annual Premium: "
					+ esb.getHmpUserDtls().get("Total_Premium_Annual"));
			System.out.println("Semi-Annual Premium: "
					+ esb.getHmpUserDtls().get("Total_Premium_SemiAnnual"));

			System.out.println("Quaterly Premium: "
					+ esb.getHmpUserDtls().get("Total_Premium_Quarterly"));
			System.out.println("Monthly Premium: "
					+ esb.getHmpUserDtls().get("Total_Premium_Monthly"));

			logger.close();
			ksession.dispose();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		kbuilder.add(ResourceFactory
				.newClassPathResource("Vision_Premium_Calculation.xls"),
				ResourceType.DTABLE);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

}
