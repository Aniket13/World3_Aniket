package com.sample;

import java.util.HashMap;

public class ESBPolicyBean {
	private static final long serialVersionUID = 1L;

	public HashMap<String, String> hmpUserDtls = new HashMap<String, String>();

	public HashMap<String, String> getHmpUserDtls() {
		return hmpUserDtls;
	}

	public void setHmpUserDtls(HashMap<String, String> hmpUserDtls) {
		this.hmpUserDtls = hmpUserDtls;
	}

}
