package com.sample;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;

/**
 * Premium Calculation based on Member Coverage Amount
 * 
 * @author anikedes
 * 
 */
public class BrokerInfoTest {

	public static final void main(String[] args) {
		try {
			// load up the knowledRdge base
			KnowledgeBase kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();
			KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory
					.newFileLogger(ksession, "test");

			ESBPolicyBean esb = new ESBPolicyBean();

			esb.getHmpUserDtls().put("RuleType", "CAT01-RLST0006-RL007");
			esb.getHmpUserDtls().put("riskAssessmentDroolsCheck", "Y");
			esb.getHmpUserDtls().put("DirectSaleInd", "N");
			ksession.insert(esb);
			ksession.fireAllRules();
			System.out.println("Status"
					+esb.getHmpUserDtls().get("status"));
			System.out.println("Error Code: "
					+ esb.getHmpUserDtls().get("errorCode"));
			System.out.println("Error Desc: "
					+ esb.getHmpUserDtls().get("errorDesc"));
			
			logger.close();
			ksession.dispose();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		kbuilder.add(ResourceFactory
				.newClassPathResource("brokerInfo_riskAssessment.xls"),
				ResourceType.DTABLE);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

}
