package com.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

public class GenerateCommission {

	public static void main(String[] args) {
		CommissionDTO commissionDTO = new CommissionDTO();
		commissionDTO.setPolicyType("Basic Life");
		commissionDTO.setPremiumYear(2);
		commissionDTO = getCommission(commissionDTO);
		System.out.println("current commission - "
				+ commissionDTO.getCurrentCommission());
		System.out.println("total commission - "
				+ commissionDTO.getTotalCommission());
	}

	private static CommissionDTO getCommission(CommissionDTO commissionDTO) {
		try {
			// load up the knowledge base
			KnowledgeBase kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();
			System.out.println("befor loading excel");
			String dtpath = "D:\\Poc_Workspace\\GenerateCommission\\src\\main\\rules\\CommissionTable.xls";
			testSpreadsheet(dtpath);
			System.out.println("after loading excel");

			ksession.insert(commissionDTO);
			ksession.fireAllRules();

		} catch (Throwable t) {
			t.printStackTrace();
		}

		return commissionDTO;
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		DecisionTableConfiguration config = KnowledgeBuilderFactory
				.newDecisionTableConfiguration();
		config.setInputType(DecisionTableInputType.XLS);
		kbuilder.add(
				ResourceFactory.newClassPathResource("CommissionTable.xls"),
				ResourceType.DTABLE, config);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

	public static class CommissionDTO {
		public static final double premiumYearlyAmount = 10000.00;
		private double totalCommission;
		private double currentCommission;
		private String PolicyType;
		private int premiumYear = 0;
		private boolean exitStatus = false;

		public boolean isExitStatus() {
			return exitStatus;
		}

		public void setExitStatus(boolean exitStatus) {
			this.exitStatus = exitStatus;
		}

		public double getTotalCommission() {
			return totalCommission;
		}

		public void setTotalCommission(double totalCommission) {
			this.totalCommission = totalCommission;
		}

		public double getCurrentCommission() {
			return currentCommission;
		}

		public void setCurrentCommission(double currentCommission) {
			this.currentCommission = currentCommission;
		}

		public String getPolicyType() {
			return PolicyType;
		}

		public void setPolicyType(String policyType) {
			PolicyType = policyType;
		}

		public int getPremiumYear() {
			return premiumYear;
		}

		public void setPremiumYear(int premiumYear) {
			this.premiumYear = premiumYear;
		}

	}
	
	private static void testSpreadsheet(String dtpath) {
		File dtf = new File(dtpath);
		InputStream is;
		try {
			is = new FileInputStream(dtf);
			SpreadsheetCompiler ssComp = new SpreadsheetCompiler();
			String s = ssComp.compile(is, InputType.XLS);
			System.out.println("=== Begin generated DRL ===");
			System.out.println(s);
			System.out.println("=== End generated DRL ===");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
