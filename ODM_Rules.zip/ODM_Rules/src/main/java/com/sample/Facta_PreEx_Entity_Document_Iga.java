package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Facta_PreEx_Entity_Document_Iga {

	public static void main(String[] args) {
		try {

			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-fatca-preex-entity-document-iga");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			q.setFATCAIsKey("PASSIVE REPORTABLE");
			q.setProcessFlowType("IGA");
			qd.setPyLabel("FATCA_PreExEntityDocument");
			kSession.getAgenda()
					.getAgendaGroup("FATCA_PreEx_Entity_Document_iga_Pre")
					.setFocus();
			kSession.insert(q);
			kSession.insert(qd);

			kSession.fireAllRules();
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
