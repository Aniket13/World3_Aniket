package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Region_In_Crs_Country {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-region-in-crs-country");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			q.setHomeCountryCode("AI");
			kSession.getAgenda().getAgendaGroup("Region_In_Crs_Country_Pre")
					.setFocus();
			kSession.insert(q);

			kSession.fireAllRules();

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
