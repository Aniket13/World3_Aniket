package com.sample;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "QuestionaireRequest")
@XmlType(propOrder={"transactionId","scope", "caseType","caseStatus","customerType","DDPurpose","processFlowType",
		"USStatusEvalCodeTemp","USIndicia","homeCountryCode","previousCaseStatus","industryCode","leCode","CRSIsKey",
		"FATCAIsKey","crsApplicable","allTaxIdPresent","customer","GIIN","TIIN","fCountryCode1","fCountryCode2","nif1","nif2",
		"dependency","uBranchCode","duediligenceClosureDate","proceedWithInCoherence","question"})
public class QuestionaireRequest {
	private String transactionId;
	private String scope;
	private String caseType;
	private String caseStatus;
	private String customerType;
	private String DDPurpose;
	private String processFlowType;
	private String USStatusEvalCodeTemp;
	private String USIndicia;
	private String homeCountryCode;
	private String previousCaseStatus;
	private String industryCode;
	private String leCode;
	private String CRSIsKey;
	private String FATCAIsKey;
	private String crsApplicable;
	private String allTaxIdPresent;
	private List<Customer> customer;
	private String GIIN;
	private String TIIN;
    private String fCountryCode1;
    private String nif1;
    private String nif2;
    private String fCountryCode2;
	private String dependency;
	private String uBranchCode;
	private String duediligenceClosureDate;
	private String proceedWithInCoherence;
	private List<RequestQuestion> question;
	
	
	public List<RequestQuestion> getQuestion() {
		return question;
	}
	public void setQuestion(List<RequestQuestion> question) {
		this.question = question;
	}
	public String getfCountryCode1() {
		return fCountryCode1;
	}
	public void setfCountryCode1(String fCountryCode1) {
		this.fCountryCode1 = fCountryCode1;
	}
	public String getNif1() {
		return nif1;
	}
	public void setNif1(String nif1) {
		this.nif1 = nif1;
	}
	public String getfCountryCode2() {
		return fCountryCode2;
	}
	public void setfCountryCode2(String fCountryCode2) {
		this.fCountryCode2 = fCountryCode2;
	}
	public String getNif2() {
		return nif2;
	}
	public void setNif2(String nif2) {
		this.nif2 = nif2;
	}

	
	public String getGIIN() {
		return GIIN;
	}
	public void setGIIN(String gIIN) {
		GIIN = gIIN;
	}
	public String getTIIN() {
		return TIIN;
	}
	public void setTIIN(String tIIN) {
		TIIN = tIIN;
	}
	public String getDependency() {
		return dependency;
	}
	public void setDependency(String dependency) {
		this.dependency = dependency;
	}
	public List<Customer> getCustomer() {
		return customer;
	}
	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getCrsApplicable() {
		return crsApplicable;
	}
	public void setCrsApplicable(String crsApplicable) {
		this.crsApplicable = crsApplicable;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getAllTaxIdPresent() {
		return allTaxIdPresent;
	}
	public void setAllTaxIdPresent(String allTaxIdPresent) {
		this.allTaxIdPresent = allTaxIdPresent;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getCRSIsKey() {
		return CRSIsKey;
	}
	public void setCRSIsKey(String cRSIsKey) {
		CRSIsKey = cRSIsKey;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getFATCAIsKey() {
		return FATCAIsKey;
	}
	public void setFATCAIsKey(String fATCAIsKey) {
		FATCAIsKey = fATCAIsKey;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getLeCode() {
		return leCode;
	}
	public void setLeCode(String leCode) {
		this.leCode = leCode;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getIndustryCode() {
		return industryCode;
	}
	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}
	@XmlElement(required = true, nillable = false)
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getPreviousCaseStatus() {
		return previousCaseStatus;
	}
	public void setPreviousCaseStatus(String previousCaseStatus) {
		this.previousCaseStatus = previousCaseStatus;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getProcessFlowType() {
		return processFlowType;
	}
	public void setProcessFlowType(String processFlowType) {
		this.processFlowType = processFlowType;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getDDPurpose() {
		return DDPurpose;
	}
	public void setDDPurpose(String dDPurpose) {
		DDPurpose = dDPurpose;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getCaseStatus() {
		return caseStatus;
	}
	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}
	
	
	@XmlElement(required = true, nillable = false)
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getUSStatusEvalCodeTemp() {
		return USStatusEvalCodeTemp;
	}
	public void setUSStatusEvalCodeTemp(String uSStatusEvalCodeTemp) {
		USStatusEvalCodeTemp = uSStatusEvalCodeTemp;
	}
	
	@XmlElement(required = true, nillable = false)
	public String getUSIndicia() {
		return USIndicia;
	}
	public void setUSIndicia(String uSIndicia) {
		USIndicia = uSIndicia;
	}
	@XmlElement(required = true, nillable = false)
	public String getHomeCountryCode() {
		return homeCountryCode;
	}
	public void setHomeCountryCode(String homeCountryCode) {
		this.homeCountryCode = homeCountryCode;
	}
	public String getuBranchCode() {
		return uBranchCode;
	}
	public void setuBranchCode(String uBranchCode) {
		this.uBranchCode = uBranchCode;
	}
	public String getDuediligenceClosureDate() {
		return duediligenceClosureDate;
	}
	public void setDuediligenceClosureDate(String duediligenceClosureDate) {
		this.duediligenceClosureDate = duediligenceClosureDate;
	}
	public String getProceedWithInCoherence() {
		return proceedWithInCoherence;
	}
	public void setProceedWithInCoherence(String proceedWithInCoherence) {
		this.proceedWithInCoherence = proceedWithInCoherence;
	}

	
}
