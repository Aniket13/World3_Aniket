package com.sample;

import java.util.ArrayList;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Populate_Complex_Type_With_Customer {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-populate-complex-type-with-customer");

			System.out.println();
			// go !
			Question qe = new Question();
			qe.setComplexType("true");
			ArrayList<Question> QueList = new ArrayList<Question>();
			QueList.add(qe);
			Customer cust=new Customer();
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireResponse qr = new QuestionaireResponse();
			QuestionaireRuleData qd=new QuestionaireRuleData();
			NameValuePair n=new NameValuePair();
			ComplexType c=new ComplexType();
			qr.setQuestion(QueList);
			qd.setPyLabel("CRS_Entity");
			qe.setQuestionIdentifier("RelatedDataParty");
			kSession.getAgenda()
					.getAgendaGroup("Populate_Complex_Type_With_Customer_Pre")
					.setFocus();

			kSession.insert(q);
			kSession.insert(qr);
			kSession.insert(QueList);
			kSession.insert(qe);
			kSession.insert(cust);
			kSession.insert(c);
			kSession.insert(n);
			kSession.insert(qd);
			kSession.fireAllRules();
			System.out.println(n.getName());
			System.out.println(n.getValueType());
			System.out.println(n.getValue());
			System.out.println(c.getCanDelete());
			System.out.println(n.getCanEdit());

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
