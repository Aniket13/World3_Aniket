package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class SAEFFI_Check {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-saeffi-check");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			q.setIndustryCode("1");
		
			kSession.getAgenda().getAgendaGroup("SAEFFI_Check_Pre").setFocus();
			kSession.insert(q);
			kSession.fireAllRules();

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
