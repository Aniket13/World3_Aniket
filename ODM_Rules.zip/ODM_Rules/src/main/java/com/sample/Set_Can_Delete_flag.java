package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Set_Can_Delete_flag {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-set-can-delete-flag");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireResponse qr = new QuestionaireResponse();
			q.setScope("11");

			kSession.getAgenda().getAgendaGroup("Validate_Scope").setFocus();
			kSession.insert(q);

			kSession.insert(qr);
			kSession.fireAllRules();
			System.out.println(qr.getResponseCode());
			System.out.println(qr.getResponseDescription());

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
