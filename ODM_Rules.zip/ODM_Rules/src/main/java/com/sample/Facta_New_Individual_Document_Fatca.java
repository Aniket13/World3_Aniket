package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Facta_New_Individual_Document_Fatca {

	public static void main(String[] args) {
		try {

			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-fatca-new-individual-document-fatca");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			Question qe=new Question();
			q.setFATCAIsKey("NON US (US BORN)");
			q.setProcessFlowType("FATCA");
			qd.setPyLabel("FATCA_NewIndividualDocument");
			kSession.getAgenda()
					.getAgendaGroup("FATCA_New_Individual_Document_Fatca_Pre")
					.setFocus();
			kSession.insert(q);
			kSession.insert(qd);
			kSession.insert(qe);
			kSession.fireAllRules();
			System.out.println(qe.getQuestionIdentifier());
			System.out.println(qe.getEnDescription());
			System.out.println(qe.getItDescription());
			System.out.println(qe.getValue());
			System.out.println(qe.getValueType());
			System.out.println(qe.getComplexType());
			System.out.println(qe.getExpiryDate());
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
