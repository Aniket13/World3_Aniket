package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Cocffi_Check {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-cocffi-check");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireResponse qr=new QuestionaireResponse();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			q.setCaseType("Change Of Circumstance");
			q.setCustomerType("Entity");
			q.setDDPurpose("CRS1");
			qd.setSAEFFIStatus(true);
			kSession.getAgenda().getAgendaGroup("Cocffi_Check").setFocus();
			kSession.insert(q);
			kSession.insert(qd);
			kSession.insert(qr);
			kSession.fireAllRules();
			System.out.println(qr.getCaseType());

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
