package com.sample;

import java.util.List;

public class DependencyType {
	
	private List<DependencyQuestion> dependencyQuestionList;
	
	public List<DependencyQuestion> getDependencyQuestionList() {
		return dependencyQuestionList;
	}

	public void setDependencyQuestionList(List<DependencyQuestion> dependencyQuestionList) {
		this.dependencyQuestionList = dependencyQuestionList;
	}

}
