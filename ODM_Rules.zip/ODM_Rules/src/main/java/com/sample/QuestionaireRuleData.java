package com.sample;

public class QuestionaireRuleData {
	
	private String pyLabel;
	private String kycTypeClass;
	private String caseType;
	private String customerType;
	private String customerSubType;
	private boolean regInCRSCountry;
	private boolean SAEFFIStatus;
	private String leApplicableForFATCA;
	private String leApplicableForCRS;
	private String GIIN;
	private String ISBDCRSWithHV;
	private String ISBDCRSWithHV_AllTax;
	private String ISBDUSWithHV;
	private String ISBDUSWithHV_AllTax;
	private String RMICRS;
	private String RMICRSAllTax;
	private String RMIUS;
	private String RMIUSAllTax;
	private String TaxIDNbr;
	
	public String getGIIN() {
		return GIIN;
	}
	public void setGIIN(String gIIN) {
		GIIN = gIIN;
	}
	public String getISBDCRSWithHV() {
		return ISBDCRSWithHV;
	}
	public void setISBDCRSWithHV(String iSBDCRSWithHV) {
		ISBDCRSWithHV = iSBDCRSWithHV;
	}
	public String getISBDCRSWithHV_AllTax() {
		return ISBDCRSWithHV_AllTax;
	}
	public void setISBDCRSWithHV_AllTax(String iSBDCRSWithHV_AllTax) {
		ISBDCRSWithHV_AllTax = iSBDCRSWithHV_AllTax;
	}
	public String getISBDUSWithHV() {
		return ISBDUSWithHV;
	}
	public void setISBDUSWithHV(String iSBDUSWithHV) {
		ISBDUSWithHV = iSBDUSWithHV;
	}
	public String getISBDUSWithHV_AllTax() {
		return ISBDUSWithHV_AllTax;
	}
	public void setISBDUSWithHV_AllTax(String iSBDUSWithHV_AllTax) {
		ISBDUSWithHV_AllTax = iSBDUSWithHV_AllTax;
	}
	public String getRMICRS() {
		return RMICRS;
	}
	public void setRMICRS(String rMICRS) {
		RMICRS = rMICRS;
	}
	public String getRMICRSAllTax() {
		return RMICRSAllTax;
	}
	public void setRMICRSAllTax(String rMICRSAllTax) {
		RMICRSAllTax = rMICRSAllTax;
	}
	public String getRMIUS() {
		return RMIUS;
	}
	public void setRMIUS(String rMIUS) {
		RMIUS = rMIUS;
	}
	public String getRMIUSAllTax() {
		return RMIUSAllTax;
	}
	public void setRMIUSAllTax(String rMIUSAllTax) {
		RMIUSAllTax = rMIUSAllTax;
	}
	public String getTaxIDNbr() {
		return TaxIDNbr;
	}
	public void setTaxIDNbr(String taxIDNbr) {
		TaxIDNbr = taxIDNbr;
	}
	public String getLeApplicableForFATCA() {
		return leApplicableForFATCA;
	}
	public void setLeApplicableForFATCA(String leApplicableForFATCA) {
		this.leApplicableForFATCA = leApplicableForFATCA;
	}
	public String getLeApplicableForCRS() {
		return leApplicableForCRS;
	}
	public void setLeApplicableForCRS(String leApplicableForCRS) {
		this.leApplicableForCRS = leApplicableForCRS;
	}
	public boolean isSAEFFIStatus() {
		return SAEFFIStatus;
	}
	public void setSAEFFIStatus(boolean sAEFFIStatus) {
		SAEFFIStatus = sAEFFIStatus;
	}
	public String getPyLabel() {
		return pyLabel;
	}
	public void setPyLabel(String pyLabel) {
		this.pyLabel = pyLabel;
	}
	public String getKycTypeClass() {
		return kycTypeClass;
	}
	public void setKycTypeClass(String kycTypeClass) {
		this.kycTypeClass = kycTypeClass;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getCustomerSubType() {
		return customerSubType;
	}
	public void setCustomerSubType(String customerSubType) {
		this.customerSubType = customerSubType;
	}
	public boolean isRegInCRSCountry() {
		return regInCRSCountry;
	}
	public void setRegInCRSCountry(boolean regInCRSCountry) {
		this.regInCRSCountry = regInCRSCountry;
	}
}
