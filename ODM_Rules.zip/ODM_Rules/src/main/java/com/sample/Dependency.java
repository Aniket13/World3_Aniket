package com.sample;

import java.util.List;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder={"dependencyType","questionIdentifier"})
public class Dependency {
	
	private String questionIdentifier;
	private List<DependencyType> dependencyType;

	public List<DependencyType> getDependencyType() {
		return dependencyType;
	}
	public void setDependencyType(List<DependencyType> dependencyType) {
		this.dependencyType = dependencyType;
	}
	public String getQuestionIdentifier() {
		return questionIdentifier;
	}
	public void setQuestionIdentifier(String questionIdentifier) {
		this.questionIdentifier = questionIdentifier;
	}
}
