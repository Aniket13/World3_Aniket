package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class CRS_Individual_PreExisting {

	public static void main(String[] args) {
		try {
			String ISBD_Crs="Y";
			String ISBD_Facta="";
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-crs-individual-pre-existing");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireRuleData qd=new QuestionaireRuleData();
			q.setProcessFlowType("FATCA");
			qd.setPyLabel("CRS_Individual_PreExisting");
			kSession.getAgenda().getAgendaGroup("CRS_Individual_PreExisting_pre").setFocus();
			kSession.insert(q);
			kSession.insert(qd);
			kSession.insert(ISBD_Facta);
			kSession.insert(ISBD_Crs);
			kSession.fireAllRules();
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
