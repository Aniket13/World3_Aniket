package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class ISBD_Check {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-isbd-check");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			q.setLeCode("0CIBH");
			kSession.getAgenda().getAgendaGroup("ISBD_Check_Pre").setFocus();
			kSession.insert(q);
			kSession.fireAllRules();

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
