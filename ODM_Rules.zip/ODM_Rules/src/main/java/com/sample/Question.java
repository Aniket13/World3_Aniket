package com.sample;

import java.util.List;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "enDescription", "itDescription", "questionIdentifier",
		"value", "valueType", "expiryDate", "canAdd", "complexType",
		"complexTypeList" })
public class Question {

	private String enDescription;
	private String itDescription;
	private String questionIdentifier;
	private String value;
	private String valueType;
	private String complexType;
	private String expiryDate;
	private String canAdd;
	List<ComplexType> complexTypeList;

	public String toString() {// overriding the toString() method
		return enDescription;
	}

	public String getComplexType() {
		return complexType;
	}

	public void setComplexType(String complexType) {
		this.complexType = complexType;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getCanAdd() {
		return canAdd;
	}

	public void setCanAdd(String canAdd) {
		this.canAdd = canAdd;
	}

	public String getEnDescription() {
		return enDescription;
	}

	public void setEnDescription(String enDescription) {
		this.enDescription = enDescription;
	}

	public String getQuestionIdentifier() {
		return questionIdentifier;
	}

	public void setQuestionIdentifier(String questionIdentifier) {
		this.questionIdentifier = questionIdentifier;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValueType() {
		return valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public List<ComplexType> getComplexTypeList() {
		return complexTypeList;
	}

	public void setComplexTypeList(List<ComplexType> complexTypeList) {
		this.complexTypeList = complexTypeList;
	}

	public String getItDescription() {
		return itDescription;
	}

	public void setItDescription(String itDescription) {
		this.itDescription = itDescription;
	}
}
