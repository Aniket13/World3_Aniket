package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Crs_Individual_Document_IGA {

	public static void main(String[] args) {
		try {
			final String ENABLED = "true";
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-crs-individual-document-iga");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			Question qe = new Question();
			q.setFATCAIsKey("NON US (OTHER US INDICIA)");
			q.setProcessFlowType("IGA");
			qd.setPyLabel("CRS_IndividualDocument");
			q.setProceedWithInCoherence("false");
			kSession.getAgenda()
					.getAgendaGroup("Crs_Individual_Document_IGA_pre")
					.setFocus();
			kSession.insert(q);
			kSession.insert(qe);
			kSession.insert(qd);
			kSession.insert(ENABLED);
			kSession.fireAllRules();
			System.out.println(qe.getQuestionIdentifier());
			System.out.println(qe.getEnDescription());
			System.out.println(qe.getItDescription());
			System.out.println(qe.getValueType());
			System.out.println(qe.getValue());
			System.out.println(qe.getComplexType());
			System.out.println(qe.getExpiryDate());

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
