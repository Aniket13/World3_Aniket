package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Populate_Case_Type {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-populate-case-type");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireResponse qr = new QuestionaireResponse();
			q.setCaseType("Change Of Circumstance");
			q.setDDPurpose("CRS");

			kSession.getAgenda().getAgendaGroup("Populate_Case_Type_Pre").setFocus();
			kSession.insert(q);

			kSession.insert(qr);
			kSession.fireAllRules();
			System.out.println(qr.getCaseType());

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
