package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class KYC_Check {

	public static void main(String[] args) {
		try {
			String Saeffi="false";
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-kyc-check");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();

			q.setScope("00");
			q.setCaseType("Change Of Circumstance");
			q.setCustomerType("Entity");
			q.setDDPurpose("CRS1");
			kSession.getAgenda().getAgendaGroup("KYC_Check_Pre").setFocus();
			kSession.insert(q);
			kSession.insert(Saeffi);
			kSession.fireAllRules();

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
