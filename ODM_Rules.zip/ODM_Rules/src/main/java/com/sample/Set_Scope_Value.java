package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Set_Scope_Value {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-set-scope-value");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireResponse qr = new QuestionaireResponse();
			q.setScope("01");

			kSession.getAgenda().getAgendaGroup("Set_Scope_Value").setFocus();
			kSession.insert(q);

			kSession.insert(qr);
			kSession.fireAllRules();
			

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
