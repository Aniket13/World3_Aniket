package com.sample;

import java.util.List;

public class DependencyList {
	
	private List<Dependency> dependency;

	public List<Dependency> getDependency() {
		return dependency;
	}

	public void setDependency(List<Dependency> dependency) {
		this.dependency = dependency;
	}
}
