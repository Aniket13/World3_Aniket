package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Set_Can_Add_Flag {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-set-can-add-flag");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			Question qe=new Question();
			q.setProcessFlowType("IGA");

			kSession.getAgenda().getAgendaGroup("Set_Can_Add_Flag").setFocus();
			kSession.insert(q);
			kSession.insert(qe);
			kSession.fireAllRules();
			System.out.println(qe.getCanAdd());
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
