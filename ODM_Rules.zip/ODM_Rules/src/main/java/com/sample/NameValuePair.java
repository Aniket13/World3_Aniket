package com.sample;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder={"name", "value","valueType","canEdit"})
public class NameValuePair {
	
	private String name;
	private String value;
	private String valueType;
	private String canEdit;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getCanEdit() {
		return canEdit;
	}
	public void setCanEdit(String canEdit) {
		this.canEdit = canEdit;
	}
	
}
