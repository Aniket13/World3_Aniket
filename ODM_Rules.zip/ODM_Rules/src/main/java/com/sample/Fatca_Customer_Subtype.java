package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Fatca_Customer_Subtype {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-fatca-customer-subtype");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireResponse qr = new QuestionaireResponse();
			q.setUSStatusEvalCodeTemp("19");
			q.setUSIndicia("WEAK");
			q.setCaseType("Existing Customer");
			kSession.getAgenda().getAgendaGroup("Fatca_Customer_Subtype_Pre")
					.setFocus();
			kSession.insert(q);
			kSession.insert(qr);
			kSession.fireAllRules();
			System.out.println(qr.getCustomerSubType());

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
