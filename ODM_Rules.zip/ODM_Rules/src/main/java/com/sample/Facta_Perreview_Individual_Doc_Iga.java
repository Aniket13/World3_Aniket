package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Facta_Perreview_Individual_Doc_Iga {

	public static void main(String[] args) {
		try {

			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-fatca-perreview-individual-doc-iga");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			q.setFATCAIsKey("NON US (US CITIZENSHIP/RESIDENCE)");
			q.setProcessFlowType("IGA");
			qd.setPyLabel("FATCA_PerReviewIndividualDoc");
			kSession.getAgenda()
					.getAgendaGroup("FATCA_PerReview_Individual_Doc_Iga_Pre")
					.setFocus();
			kSession.insert(q);
			kSession.insert(qd);

			kSession.fireAllRules();
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
