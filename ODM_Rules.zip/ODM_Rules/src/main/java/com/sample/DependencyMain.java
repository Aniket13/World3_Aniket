package com.sample;

public class DependencyMain {
	
	private DependencyList dependencyList;

	public DependencyList getDependencyList() {
		return dependencyList;
	}

	public void setDependencyList(DependencyList dependencyList) {
		this.dependencyList = dependencyList;
	}
}
