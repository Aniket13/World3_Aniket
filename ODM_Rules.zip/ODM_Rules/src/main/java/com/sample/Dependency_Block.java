package com.sample;

import java.util.ArrayList;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Dependency_Block {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-dependancy-block");

			System.out.println();
			// go !
			Question qe = new Question();
			ArrayList<Question> QueList = new ArrayList<Question>();
			QueList.add(qe);
			Customer cust = new Customer();
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireResponse qr = new QuestionaireResponse();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			DependencyQuestion d = new DependencyQuestion();
			qr.setQuestion(QueList);
			qd.setPyLabel("CRS_Entity");
			qe.setQuestionIdentifier("TaxIdTwo");
			q.setGIIN("");
			q.setTIIN("");
			d.setDependency("true");

			kSession.getAgenda().getAgendaGroup("Dependency_Block_pre")
					.setFocus();

			kSession.insert(q);
			kSession.insert(qr);
			kSession.insert(QueList);
			kSession.insert(qe);
			kSession.insert(cust);
			kSession.insert(d);

			kSession.insert(qd);
			kSession.fireAllRules();
			System.out.println(d.getDependency());
			System.out.println(d.getDependentQuestion());
			System.out.println(d.getDependentValue());
			System.out.println(d.getLogicalOperation());
	

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
