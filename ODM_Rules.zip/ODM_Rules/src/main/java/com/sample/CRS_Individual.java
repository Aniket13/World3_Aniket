package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class CRS_Individual {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-crs-individual");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			Question qe=new Question();
			q.setProcessFlowType("IGA");
			qd.setPyLabel("CRS_Individual");
			kSession.getAgenda().getAgendaGroup("Crs_Individual_Pre")
					.setFocus();
			kSession.insert(q);
			kSession.insert(qd);
			kSession.insert(qe);
			kSession.fireAllRules();
			System.out.println(qe.getQuestionIdentifier());
			System.out.println(qe.getEnDescription());
			System.out.println(qe.getItDescription());
			System.out.println(qe.getValue());
			System.out.println(qe.getValueType());
			System.out.println(qe.getComplexType());
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
