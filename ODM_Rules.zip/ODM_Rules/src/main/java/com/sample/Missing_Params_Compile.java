package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Missing_Params_Compile {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-missing-params-compile");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireResponse qr = new QuestionaireResponse();
			q.setTransactionId("");
			q.setCaseType("");
			q.setCustomerType("");
			q.setDDPurpose("");
			q.setLeCode(null);
			q.setIndustryCode(null);
			q.setProcessFlowType("d");
			q.setCRSIsKey(null);
			q.setFATCAIsKey(null);
			
			
			kSession.getAgenda().getAgendaGroup("MPC").setFocus();
				
			kSession.insert(q);
			kSession.insert(qr);
			kSession.fireAllRules();
			System.out.println(qr.getResponseCode());
			System.out.println(qr.getResponseDescription());

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
