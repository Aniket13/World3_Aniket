package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class Facta_PreEx_Entity_Document_Fatca {

	public static void main(String[] args) {
		try {

			// load up the knowledge base
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-fatca-preex-entity-document-fatca");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			q.setFATCAIsKey("US NON DOCUMENTED");
			q.setProcessFlowType("FATCA");
			qd.setPyLabel("FATCA_PreExEntityDocument");
			kSession.getAgenda()
					.getAgendaGroup("FATCA_PreEx_Entity_Document_Fatca_Pre")
					.setFocus();
			kSession.insert(q);
			kSession.insert(qd);

			kSession.fireAllRules();
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
