package com.sample;

import java.util.List;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "customerId", "canDelete", "nameValuePairList" })
public class ComplexType {

	private String canDelete;

	List<NameValuePair> nameValuePairList;
	private String customerId;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCanDelete() {
		return canDelete;
	}

	public void setCanDelete(String canDelete) {
		this.canDelete = canDelete;
	}

	public List<NameValuePair> getNameValuePairList() {
		return nameValuePairList;
	}

	public void setNameValuePairList(List<NameValuePair> nameValuePairList) {
		this.nameValuePairList = nameValuePairList;
	}
}
