package com.sample;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder={"dependentQuestion","dependentValue", "logicalOperation","dependency"})
public class DependencyQuestion {
	
	private String dependentQuestion;
	private String dependentValue;
	private String logicalOperation;
	private String dependency;
	
	public String getDependency() {
		return dependency;
	}
	public void setDependency(String dependency) {
		this.dependency = dependency;
	}
	
	public String getDependentQuestion() {
		return dependentQuestion;
	}
	public void setDependentQuestion(String dependentQuestion) {
		this.dependentQuestion = dependentQuestion;
	}
	public String getDependentValue() {
		return dependentValue;
	}
	public void setDependentValue(String dependentValue) {
		this.dependentValue = dependentValue;
	}
	public String getLogicalOperation() {
		return logicalOperation;
	}
	public void setLogicalOperation(String logicalOperation) {
		this.logicalOperation = logicalOperation;
	}
}
