package com.sample;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder={"id", "firstName","lastName","birthCountryCode","dateOfBirth","citizenship","homeCountryCode","fCountryCode1","nif1","nif2","fCountryCode2","tin"})
public class Customer {
	
	private String id;
	private String firstName;
	private String lastName;
	private String birthCountryCode;
	private String dateOfBirth;
	private String citizenship;
	private String homeCountryCode;
    private String fCountryCode1;
	private String nif1;
	private String nif2;
	private String fCountryCode2;
	private String tin;
	
	public String getBirthCountryCode() {
		return birthCountryCode;
	}
	public void setBirthCountryCode(String birthCountryCode) {
		this.birthCountryCode = birthCountryCode;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getCitizenship() {
		return citizenship;
	}
	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}
	public String getHomeCountryCode() {
		return homeCountryCode;
	}
	public void setHomeCountryCode(String homeCountryCode) {
		this.homeCountryCode = homeCountryCode;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getfCountryCode1() {
		return fCountryCode1;
	}
	public void setfCountryCode1(String fCountryCode1) {
		this.fCountryCode1 = fCountryCode1;
	}
	public String getNif1() {
		return nif1;
	}
	public void setNif1(String nif1) {
		this.nif1 = nif1;
	}
	public String getNif2() {
		return nif2;
	}
	public void setNif2(String nif2) {
		this.nif2 = nif2;
	}
	public String getfCountryCode2() {
		return fCountryCode2;
	}
	public void setfCountryCode2(String fCountryCode2) {
		this.fCountryCode2 = fCountryCode2;
	}
	public String getTin() {
		return tin;
	}
	public void setTin(String tin) {
		this.tin = tin;
	}
	
}
