package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class FATCA_PreEx_Individual {

	public static void main(String[] args) {
		try {
			// load up the knowledge base
			String ISBD_Facta = "Y";
			KieServices ks = KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer
					.newKieSession("ksession-fatca-preex-individual");

			// go !
			QuestionaireRequest q = new QuestionaireRequest();
			QuestionaireRuleData qd = new QuestionaireRuleData();
			q.setProcessFlowType("IGA");
			qd.setPyLabel("FATCA_PreExIndividual");
			kSession.getAgenda().getAgendaGroup("FATCA_PreEx_Individual_Pre")
					.setFocus();
			kSession.insert(q);
			kSession.insert(qd);
			kSession.insert(ISBD_Facta);
			kSession.fireAllRules();
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
