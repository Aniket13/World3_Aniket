package com.sample;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "QuestionaireResponse")
@XmlType(propOrder={"transactionId","responseCode", "responseDescription","customerType","customerSubType",
		"caseType","caseStatus","question","dependencyMain"})
public class QuestionaireResponse {
	private String transactionId;
	private String responseCode;
	private String responseDescription;
	private String customerType;
	private String customerSubType;
	private String caseType;
	private String caseStatus;
	List<Question> question;
	//set question to a question in the questions of 'the response' 
	private DependencyMain dependencyMain;
	
	public DependencyMain getDependencyMain() {
		return dependencyMain;
	}
	public void setDependencyMain(DependencyMain dependencyMain) {
		this.dependencyMain = dependencyMain;
	}
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getCustomerSubType() {
		return customerSubType;
	}
	public void setCustomerSubType(String customerSubType) {
		this.customerSubType = customerSubType;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getCaseStatus() {
		return caseStatus;
	}
	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}
	public List<Question> getQuestion() {
		return question;
	}
	public void setQuestion(List<Question> question) {
		this.question = question;
	}
}
