package com.sample;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder={"questionIdentifier","value"})

public class RequestQuestion {
	
	
	private String questionIdentifier;
	private String value;

	
	public String getQuestionIdentifier() {
		return questionIdentifier;
	}
	public void setQuestionIdentifier(String questionIdentifier) {
		this.questionIdentifier = questionIdentifier;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

}
