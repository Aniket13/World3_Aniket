package com.pru.sparc.drools.aggregator;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.model.MasterFactorBean;
import com.pru.sparc.drools.model.RuleRatingCensusCompGrp;
import com.pru.sparc.drools.model.RuleRatingModelOverrideGrp;
import com.pru.sparc.drools.model.RuleRatingModelRuleResultGrp;
import com.pru.sparc.drools.model.RuleRatingModelWrapper;
/*
import com.pru.sparc.dao.CensusMemberDtlRepository;*/
/*import com.pru.sparc.model.CensusMemberDetails;*/

public class RatingEngine {
	public static void main(String[] args) {
		RuleRatingModelWrapper ruleRatingModelWrapper=new RuleRatingModelWrapper();
		ruleRatingModelWrapper=getRatingResult(ruleRatingModelWrapper,"");
	}
	
	public static RuleRatingModelWrapper getRatingResult(RuleRatingModelWrapper ruleRatingModelWrapper,String censusId){
		
			System.out.println("Starting--");
			String[] loadFile={"decisiontables//MasterFactorTable.xls"};
		
			StatefulKnowledgeSession ksession;
			try {
				ksession = readKnowledgeBase(loadFile);
				MasterFactorBean factorBean=new MasterFactorBean();
			//Loading master decision table to load decision file for particular product type and effective year range	
				String target = "02/02/2013";
			    Date date = new SimpleDateFormat("dd/MM/yyyy").parse(target);
			    
			    factorBean.setEffectiveDate(date);
				factorBean.setCity("NY");
				factorBean.setProductType("BL");
				ksession.insert(factorBean);
				ksession.fireAllRules();
				System.out.println("table-"+factorBean.getFactorTable());
				ksession.dispose();
				System.out.println("loading facts default");
		//Loading Facts default values		
				String[] loadFile1={"decisiontables//2013_FACT_NY.xls"};
				ksession = readKnowledgeBase(loadFile1);
				List<RuleRatingModelOverrideGrp> ruleRatingModelOverrideGrpList=new ArrayList<RuleRatingModelOverrideGrp>();
				RuleRatingModelOverrideGrp ruleRatingModelOverrideGrp=null;
				for(int ruleCount=1;ruleCount<=RuleRatingConstants.maxCommonRatingRuleCount;ruleCount++){
					ruleRatingModelOverrideGrp=new RuleRatingModelOverrideGrp();
					ruleRatingModelOverrideGrp.setRuleID("Rule-"+ ruleCount);
					ruleRatingModelOverrideGrpList.add(ruleRatingModelOverrideGrp);
				}
				ksession.insert(ruleRatingModelOverrideGrpList);
				ksession.fireAllRules();
				
				ksession.dispose();
				
				System.out.println("loading calculated val");
		//Loading calculated values
				String[] loadFile2={"decisiontables//2013_Compute_NY.xls"};
				ksession = readKnowledgeBase(loadFile2);
				ksession.insert(ruleRatingModelOverrideGrpList);
				ksession.fireAllRules();
				for(RuleRatingModelOverrideGrp ruleRatingModelOverrideGrp1:ruleRatingModelOverrideGrpList){
					//System.out.println(ruleRatingModelOverrideGrp1.getFieldKey()+ " - "+ruleRatingModelOverrideGrp1.getFieldValue()+" - "+ruleRatingModelOverrideGrp1.getOverride());
				}
				ruleRatingModelWrapper.setRuleRatingModelOverrideGrp(ruleRatingModelOverrideGrpList);
		//Loading Census data		
				System.out.println("loading census data");
				//loading Dts for Rating as per year selection
				String[] loadFile3={"decisiontables//2013_AgeBrack_NY.xls"};
				ksession = readKnowledgeBase(loadFile3);
				
				
				List<RuleRatingCensusCompGrp> ratingCensusAgeRangeList=new ArrayList<RuleRatingCensusCompGrp>();
				RuleRatingCensusCompGrp ruleRatingCensusCompGrp=null;
				for(int ruleCount=1;ruleCount<=RuleRatingConstants.maxCommonCensusAgeRange;ruleCount++){
					ruleRatingCensusCompGrp=new RuleRatingCensusCompGrp();
					ruleRatingCensusCompGrp.setAgeBracket("0 to 19");
					//ruleRatingCensusCompGrp.setState("NY");
					//ruleRatingCensusCompGrp.setProductType("BL");
					ratingCensusAgeRangeList.add(ruleRatingCensusCompGrp);
				}
				ksession.insert(ratingCensusAgeRangeList);
				ksession.fireAllRules();
				for(RuleRatingCensusCompGrp acknowledgeGrpList1:ratingCensusAgeRangeList){
					System.out.println(acknowledgeGrpList1.getAgeBracket()+" "+acknowledgeGrpList1.getCrossTableRate());
				}
				ksession.dispose();
				
				ruleRatingModelWrapper.setRuleRatingCensusCompGrp(ratingCensusAgeRangeList);
				
				String[] loadFile4={"decisiontables//2013_Rule_BL.xls"};
				ksession = readKnowledgeBase(loadFile4);
				List<RuleRatingModelRuleResultGrp> ruleRatingModelRuleResultGrpList=new ArrayList<RuleRatingModelRuleResultGrp>();
				RuleRatingModelRuleResultGrp ruleRatingModelRuleResultGrp=null;
				for(int ruleCount=1;ruleCount<=RuleRatingConstants.maxCommonRuleCount;ruleCount++){
					ruleRatingModelRuleResultGrp=new RuleRatingModelRuleResultGrp();
					//ruleRatingModelRuleResultGrp.setRuleId("Rule "+ruleCount);
					ruleRatingModelRuleResultGrpList.add(ruleRatingModelRuleResultGrp);
				}
				//ksession.insert(ruleRatingModelRuleResultGrpList);
				ruleRatingModelWrapper.setRuleRatingModelRuleResultGrp(ruleRatingModelRuleResultGrpList);
				//ksession.insert(ruleRatingCensusCompGrp);
				//ksession.insert(ruleRatingModelOverrideGrpList);
				//ksession.insert(ruleRatingModelRuleResultGrpList);
				ksession.insert(ruleRatingModelWrapper);
				ksession.fireAllRules();
				for(RuleRatingModelRuleResultGrp ruleRatingModelRuleResultGrp1:ruleRatingModelRuleResultGrpList){
					//System.out.println(ruleRatingModelRuleResultGrp1.getRuleId()+" "+ruleRatingModelRuleResultGrp1.getRuleName()+" result-"+ruleRatingModelRuleResultGrp1.getRuleResult());
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	
		return ruleRatingModelWrapper;
	}
	private static StatefulKnowledgeSession readKnowledgeBase(String[] loadFile) throws Exception {
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
        DecisionTableConfiguration config = KnowledgeBuilderFactory.newDecisionTableConfiguration();
        config.setInputType(DecisionTableInputType.XLS);
        for(int fileCount=0;fileCount<loadFile.length;fileCount++){
        	 kbuilder.add(ResourceFactory.newClassPathResource(loadFile[fileCount]), ResourceType.DTABLE, config);
        }
       
        KnowledgeBuilderErrors errors = kbuilder.getErrors();
        if (errors.size() > 0) {
            for (KnowledgeBuilderError error: errors) {
                System.err.println(error);
            }
            throw new IllegalArgumentException("Could not parse knowledge.");
        }
        KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
        StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
        return ksession;
    }
}
