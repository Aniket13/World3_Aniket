package com.pru.sparc.drools.aggregator;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;

public class Plan_Pooling_Point {
	Holding hold = new Holding();

	public void invokeRatingEngine(Holding hold) {
		try {

			KnowledgeBase kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();

			ksession.insert(hold);

			ksession.getAgenda().getAgendaGroup("grossvolume").setFocus();

			ksession.fireAllRules();

			List plans = (List) (hold.getListOfPlans());
			List people = hold.getCensus().getListOfPeople();

			for (int i = 0; i < plans.size(); i++) {
				showMap(((Plan) hold.getListOfPlans().get(i)).getPlanMap());
			}

			showMap(hold.getCensus().getCensusMap());
			
			/*
			 * for (int i = 0; i < people.size(); i++) { showMap(((Person)
			 * holding.getCensus().getListOfPeople().get(i)) .getPeopleMap()); }
			 */
			
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public static void showMap(Map lookup) {
		System.out.println("->Start printing lookup");
		if (lookup != null) {
			Iterator it = lookup.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				System.out.println("Key : " + key + "| Value :"
						+ lookup.get(key));
			}
			System.out.println("<-End printing lookup");

		} else {
			System.out.println("<-Cannot print as map is null");
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		kbuilder.add(ResourceFactory
				.newClassPathResource("rulefiles//drls//Holding.drl"),
				ResourceType.DRL);

		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}

		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

}
