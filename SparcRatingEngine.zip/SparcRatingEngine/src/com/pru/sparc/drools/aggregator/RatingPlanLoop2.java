package com.pru.sparc.drools.aggregator;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;

public class RatingPlanLoop2 {

	public static void invokeRatingEngine(Holding holding) {
		try {
			// load up the knowledRdge base
			KnowledgeBase kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();

			ksession.insert(holding);
			System.out.println("In RatingPlanLoop2");
			ksession.getAgenda().getAgendaGroup("plan-loop2").setFocus();
			ksession.fireAllRules();

			List plans = (List) (holding.getListOfPlans());
			List people = holding.getCensus().getListOfPeople();

		/*	for (int i = 0; i < plans.size(); i++) {
				showMap(((Plan) holding.getListOfPlans().get(i)).getPlanMap());
			}*/
			System.out.println("**************Holding Map**************");
			showMap(holding.getHoldingMap());
			//showMap(holding.getCensus().getCensusMap());

			/*
			 * for (int i = 0; i < people.size(); i++) { showMap(((Person)
			 * holding.getCensus().getListOfPeople().get(i)) .getPeopleMap()); }
			 */

			ksession.dispose();

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

	public static void showMap(Map lookup) {
		System.out.println("->Start printing lookup");
		if (lookup != null) {
			Iterator it = lookup.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				System.out.println("Key : " + key + "| Value :"
						+ lookup.get(key));
			}
			System.out.println("<-End printing lookup");

		} else {
			System.out.println("<-Cannot print as map is null");
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		long start = System.nanoTime();
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		kbuilder.add(ResourceFactory
				.newClassPathResource("rulefiles//drls//BL_Plan_Loop2.drl"),
				ResourceType.DRL);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}

		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		long end = System.nanoTime();
		// System.out.println("KnowledgeBase Time taken (ms):"+(end-start)/1000000);
		return kbase;
	}

}
