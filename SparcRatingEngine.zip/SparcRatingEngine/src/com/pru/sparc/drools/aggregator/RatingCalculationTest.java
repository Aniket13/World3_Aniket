package com.pru.sparc.drools.aggregator;

import java.util.Iterator;
import java.util.Map;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.drools.common.util.DynaCacheUtil;

public class RatingCalculationTest {

	public static void invokeRatingEngine(Object holding, String fileName,
			String agendaGroup) {
		try {
			// load up the knowledRdge base
			KnowledgeBase kbase;
			kbase = readKnowledgeBase(fileName);
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();
			ksession.insert(holding);
			ksession.getAgenda().getAgendaGroup(agendaGroup).setFocus();
			ksession.fireAllRules();
			ksession.dispose();

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

	/**
	 * Use the showMap method from SparcRatingUtil.java instead
	 * @param lookup
	 */
	@Deprecated
		public static void showMap(Map lookup) {
		System.out.println("->Start printing lookup");
		if (lookup != null) {
			Iterator it = lookup.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				System.out.println("Key : " + key + "| Value :"
						+ lookup.get(key));
			}
			System.out.println("<-End printing lookup");

		} else {
			System.out.println("<-Cannot print as map is null");
		}
	}

	public static void invokeRatingEngineServer(Object holding,
			String fileName, String agendaGroup) {/*

		try {
			// load up the knowledRdge base
			String cacheKey = fileName;
			DynaCacheUtil dynaCacheUtil = new DynaCacheUtil();
			KnowledgeBase kbase;

			if (dynaCacheUtil.getValue(cacheKey) == null) {
				System.out
						.println("Did not find the file in cache,hence putting in cache ");
				kbase = readKnowledgeBase(fileName);
				dynaCacheUtil.putValue(cacheKey, kbase);
			} else {
				System.out.println("Found the file in cache");
				kbase = (KnowledgeBase) dynaCacheUtil.getValue(cacheKey);
			}
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();
			// ksession.execute(holding);

			ksession.insert(holding);
			ksession.getAgenda().getAgendaGroup(agendaGroup).setFocus();
			ksession.fireAllRules();
			ksession.dispose();

		} catch (Throwable t) {
			t.printStackTrace();
		}

	
	*/}

	private static KnowledgeBase readKnowledgeBase(String fileName)
			throws Exception {
		long start = System.nanoTime();
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		kbuilder.add(ResourceFactory.newClassPathResource(fileName),
				ResourceType.DRL);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}

		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		long end = System.nanoTime();
		System.out.println("KnowledgeBase Time taken (ms):" + (end - start)
				/ 1000000);
		return kbase;
	}

}
