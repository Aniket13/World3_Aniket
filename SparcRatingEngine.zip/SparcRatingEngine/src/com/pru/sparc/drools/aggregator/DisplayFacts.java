package com.pru.sparc.drools.aggregator;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.drools.model.Commission;
import com.pru.sparc.drools.model.FactorBean;

public class DisplayFacts {

	public static void main(String[] args) {
		System.out.println("start");
		FactorBean factorBean=new FactorBean();
		factorBean.setCity("NY");
		factorBean.setEffectiveDate("test");
		factorBean.setProductType("BS");
		FactorBean bean=getFactor(factorBean);
		System.out.println(bean.getProductDesc());
		System.out.println(bean.getRate());

	}
	
	private static FactorBean getFactor(FactorBean factorBean){
		try {
            // load up the knowledge base
            KnowledgeBase kbase = readKnowledgeBase();
            StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
            //KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "test");
            // go !
          
        	ksession.insert(factorBean);
        	ksession.fireAllRules();
          
            //logger.close();
        } catch (Throwable t) {
            t.printStackTrace();
        }
		
		return factorBean;
	}
	 private static KnowledgeBase readKnowledgeBase() throws Exception {
	        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
	        DecisionTableConfiguration config = KnowledgeBuilderFactory.newDecisionTableConfiguration();
	        config.setInputType(DecisionTableInputType.XLS);
	        kbuilder.add(ResourceFactory.newClassPathResource("decisiontables//Fact-2.xls"), ResourceType.DTABLE, config);
	        KnowledgeBuilderErrors errors = kbuilder.getErrors();
	        if (errors.size() > 0) {
	            for (KnowledgeBuilderError error: errors) {
	                System.err.println(error);
	            }
	            throw new IllegalArgumentException("Could not parse knowledge.");
	        }
	        KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
	        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
	        return kbase;
	    }
}
