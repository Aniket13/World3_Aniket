package com.pru.sparc.drools.aggregator;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.drools.model.Commission;

public class GenerateCommission {

	public static void main(String[] args) {
		Commission commissionDTO=new Commission();
	 	commissionDTO.setPolicyType("Basic Life");
	   	commissionDTO.setPremiumYear(5);  
	   	
	   	commissionDTO = getCommission(commissionDTO);
	    System.out.println("current commission - "+commissionDTO.getCurrentCommission());
	    System.out.println("total commission - "+commissionDTO.getTotalCommission());

	}
	private static Commission getCommission(Commission commissionDTO){
		try {
            // load up the knowledge base
            KnowledgeBase kbase = readKnowledgeBase();
            StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
            KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory.newFileLogger(ksession, "test");
            // go !
          
        	ksession.insert(commissionDTO);
        	ksession.fireAllRules();
          
            logger.close();
        } catch (Throwable t) {
            t.printStackTrace();
        }
		
		return commissionDTO;
	}
	 private static KnowledgeBase readKnowledgeBase() throws Exception {
	        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
	        DecisionTableConfiguration config = KnowledgeBuilderFactory.newDecisionTableConfiguration();
	        config.setInputType(DecisionTableInputType.XLS);
	        kbuilder.add(ResourceFactory.newClassPathResource("decisiontables//CommissionTable.xls"), ResourceType.DTABLE, config);
	        KnowledgeBuilderErrors errors = kbuilder.getErrors();
	        if (errors.size() > 0) {
	            for (KnowledgeBuilderError error: errors) {
	                System.err.println(error);
	            }
	            throw new IllegalArgumentException("Could not parse knowledge.");
	        }
	        KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
	        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
	        return kbase;
	    }
}
