package com.pru.sparc.drools.aggregator;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.drools.common.util.RuleRunner;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.MemberDTO;

public class RetireeVolumeStatus {

	public static void main(String[] args) {
		MemberDTO members=new MemberDTO();
		/*members.setCensus(new Census[]{new Census("Retiree",2000.00,23),
				new Census("Active",2000.00,22),
				new Census("Retiree",2000.00,20),
				new Census("Retiree",2000.00,24),
				new Census("Retiree",2000.00,39)});
		
		MemberDTO memberUpdated=getretireeVolumeStatus(members);
		System.out.println("retiree exceeds 40% limit- "+memberUpdated.getResult());
		
		Census[] sensus1=memberUpdated.getCensus();
		for(Census census2:sensus1){
			System.out.println(census2.getMemberSalary()+"  "+census2.getMemberCoveredVolume()+"  "+census2.getMemberAge());
		}*/
	}
	
	public static MemberDTO getretireeVolumeStatus(MemberDTO members){
		try {
			String[] loadFile={"decisiontables//RetireeLifeVolumeValidation.xls"};
            StatefulKnowledgeSession ksession = readKnowledgeBase(loadFile);
            ksession.insert(members);
        	ksession.fireAllRules();
        	System.out.println("total covered-"+members.getMemberTotalCoveredVolume());
        	System.out.println("retiree-"+members.getMemberTotalRetireeCoveredVolume());
        	ksession.dispose();
        } catch (Throwable t) {
            t.printStackTrace();
        }
		
		return members;
	}
	
	 private static StatefulKnowledgeSession readKnowledgeBase(String[] loadFile) throws Exception {
	        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
	        DecisionTableConfiguration config = KnowledgeBuilderFactory.newDecisionTableConfiguration();
	        config.setInputType(DecisionTableInputType.XLS);
	        for(int fileCount=0;fileCount<loadFile.length;fileCount++){
	        	 kbuilder.add(ResourceFactory.newClassPathResource(loadFile[fileCount]), ResourceType.DTABLE, config);
	        }
	       
	        KnowledgeBuilderErrors errors = kbuilder.getErrors();
	        if (errors.size() > 0) {
	            for (KnowledgeBuilderError error: errors) {
	                System.err.println(error);
	            }
	            throw new IllegalArgumentException("Could not parse knowledge.");
	        }
	        KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
	        kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
	        StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
	        return ksession;
	    }

}
