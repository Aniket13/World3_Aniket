package com.pru.sparc.drools.aggregator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;

public class RatingCalculation {

	public static void main(String[] args) {
		
		long start = System.nanoTime();
		
		Holding holding = new Holding();

		HashMap<String, Object> planMap = new HashMap<String, Object>();

		planMap.put("plan/VolumeType", "CensusVolumeUnaltered");
		planMap.put("plan/PlanType/FlatAmt", 1001.0);
		planMap.put("plan/CaseFlatAmt", 1001.0);
		planMap.put("plan/PlanType/MultipleEarnings ", "Y");
		planMap.put("plan/EarningsFactor", 111.0);
		planMap.put("plan/ContractState", "OtherProvinces");
		planMap.put("plan/MAX", 10.0);
		planMap.put("plan/MIN", 1.0);
		planMap.put("RoundingSelection", 100.0);
		//planMap.put("Contract_State", "OtherProvinces");
		planMap.put("EffectiveDate", "01/01/2016");
		
		

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();

		planMap1.put("plan/VolumeType", "CensusVolumeUnaltered");
		planMap1.put("plan/PlanType/FlatAmt", 1001.0);
		planMap1.put("plan/CaseFlatAmt", 1001.0);
		planMap1.put("plan/PlanType/MultipleEarnings ", "N");
		planMap1.put("plan/EarningsFactor", 111.0);
		planMap1.put("plan/ContractState", "AB");
		planMap1.put("plan/MAX", 10.0);
		planMap1.put("plan/MIN", 1.0);
		planMap1.put("RoundingSelection", 100.0);
		planMap1.put("EffectiveDate", "01/01/2015");

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap);
		Plan plan2 = new Plan();
		plan2.setPlanMap(planMap1);

		List listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		//listOfPlans.add(plan2);

		// hardcoded list of plans
		holding.setListOfPlans(listOfPlans);

		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", 10000.00);

		/*
		 * HashMap<String, Object> censusMap1 = new HashMap<String, Object>();
		 * censusMap1.put("SalarySetForAll", "SalarySetForAll_Y");
		 * censusMap1.put("SalaryEstimate",20000.00);
		 */

		Census census = new Census();
		census.setCensusMap(censusMap);

		Double d = new Double("0.0");
		

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Salary",0.0);
		peopleMap1.put("people/BasicAmt", 130000.00);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put("people/Salary", 30000.00);
		peopleMap2.put("people/BasicAmt", 150000.00);
		ArrayList<Person> peopleList = new ArrayList<Person>();
		Person person = new Person();
		person.setPeopleMap(peopleMap1);

		Person person1 = new Person();
		person1.setPeopleMap(peopleMap2);

		peopleList.add(person);
		peopleList.add(person1);

		census.setListOfPeople(peopleList);
		holding.setCensus(census);
		
		
		try {
			// load up the knowledRdge base
			KnowledgeBase kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();

			ksession.insert(holding);

			ksession.getAgenda().getAgendaGroup("grossvolume").setFocus();
			// ksession.getAgenda().getAgendaGroup("Initialization").setFocus();
			ksession.fireAllRules();

			List plans = (List) (holding.getListOfPlans());
			List people = holding.getCensus().getListOfPeople();
			//List people = (List) (holding.getListOfPeople());

			// System.out.print("outside loop");

			for (int i = 0; i < plans.size(); i++) {
				showMap(((Plan) holding.getListOfPlans().get(i)).getPlanMap());
			}

			showMap(holding.getCensus().getCensusMap());

			for (int i = 0; i < people.size(); i++) {
				showMap(((Person) holding.getCensus().getListOfPeople().get(i))
						.getPeopleMap());
			}
			
			ksession.dispose();
			
			
			long end = System.nanoTime();
			System.out.println("Time taken (ms):"+(end-start)/1000000);
			
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

	public static void showMap(Map lookup) {
		System.out.println("->Start printing lookup");
		if (lookup != null) {
			Iterator it = lookup.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				System.out.println("Key : " + key + "| Value :"
						+ lookup.get(key));
			}
			System.out.println("<-End printing lookup");

		} else {
			System.out.println("<-Cannot print as map is null");
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		kbuilder.add(ResourceFactory
				.newClassPathResource("rulefiles//drls//Holding.drl"),
				ResourceType.DRL);

		// kbuilder.add(ResourceFactory.newClassPathResource("GrossVolumeCondition.xls"),
		// ResourceType.DTABLE);

		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}

		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

}
