package com.pru.sparc.drools.aggregator;


public class BackwardChaining {

	public static void main(String[] args) {/*
		new RuleRunner().runRules(new String[]{"drls//backwardChain.drl"}, new Object[]{new Location("Office", "House"),
				new Location("Kitchen", "House"),
				new Location("Knife", "Kitchen"),
				new Location("Cheese", "Kitchen"),
				new Location("Desk", "Office"),
				new Location("Chair", "Office"),
				new Location("Computer", "Desk"),
				new Location("Draw", "Desk"),
				new Location("Key", "Draw"),
				"go1","go2","go3","go4","go"});
		
		
	*/}

}
