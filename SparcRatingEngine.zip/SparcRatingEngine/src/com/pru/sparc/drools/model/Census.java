package com.pru.sparc.drools.model;
import java.util.ArrayList;
import java.util.HashMap;


public class Census{
	public HashMap<String, Object> censusMap = new HashMap<String, Object>();

	ArrayList<Person> listOfPeople = new ArrayList<Person>();
	
	ArrayList<State> listOfStates = new ArrayList<State>();
	
	public ArrayList<State> getListOfStates() {
		return listOfStates;
	}

	public void setListOfStates(ArrayList<State> listOfStates) {
		this.listOfStates = listOfStates;
	}

	public ArrayList<Person> getListOfPeople() {
		return listOfPeople;
	}

	public void setListOfPeople(ArrayList<Person> listOfPeople) {
		this.listOfPeople = listOfPeople;
	}

	public HashMap<String, Object> getCensusMap() {
		return censusMap;
	}

	public void setCensusMap(HashMap<String, Object> censusMap) {
		this.censusMap = censusMap;
	}
	
	public Object get(Object key){		
		return this.getCensusMap().get(key);
	}
	
	public void put(Object key, Object value){		
		this.getCensusMap().put((String)key, value);
	}
	
}
