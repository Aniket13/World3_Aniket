package com.pru.sparc.drools.model;

public class MemberDTO {
	private Census[] census;
	private double memberTotalCoveredVolume;
	private double memberTotalRetireeCoveredVolume;
	private String result;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public Census[] getCensus() {
		return census;
	}
	public void setCensus(Census[] census) {
		this.census = census;
	}
	public double getMemberTotalCoveredVolume() {
		return memberTotalCoveredVolume;
	}
	public void setMemberTotalCoveredVolume(double memberTotalCoveredVolume) {
		this.memberTotalCoveredVolume = memberTotalCoveredVolume;
	}
	public double getMemberTotalRetireeCoveredVolume() {
		return memberTotalRetireeCoveredVolume;
	}
	public void setMemberTotalRetireeCoveredVolume(
			double memberTotalRetireeCoveredVolume) {
		this.memberTotalRetireeCoveredVolume = memberTotalRetireeCoveredVolume;
	}
	
}
