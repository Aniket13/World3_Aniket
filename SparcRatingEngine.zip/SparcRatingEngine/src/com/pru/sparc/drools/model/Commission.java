package com.pru.sparc.drools.model;

public class Commission {
  	public static final double premiumYearlyAmount=10000.00;
	private double totalCommission;
	private double currentCommission;
	private String PolicyType;
	private int premiumYear=0;
	private boolean exitStatus=false;
	
	public boolean isExitStatus() {
		return exitStatus;
	}
	public void setExitStatus(boolean exitStatus) {
		this.exitStatus = exitStatus;
	}
	public double getTotalCommission() {
		return totalCommission;
	}
	public void setTotalCommission(double totalCommission) {
		this.totalCommission = totalCommission;
	}
	public double getCurrentCommission() {
		return currentCommission;
	}
	public void setCurrentCommission(double currentCommission) {
		this.currentCommission = currentCommission;
	}
	public String getPolicyType() {
		return PolicyType;
	}
	public void setPolicyType(String policyType) {
		PolicyType = policyType;
	}
	public int getPremiumYear() {
		return premiumYear;
	}
	public void setPremiumYear(int premiumYear) {
		this.premiumYear = premiumYear;
	}
}
