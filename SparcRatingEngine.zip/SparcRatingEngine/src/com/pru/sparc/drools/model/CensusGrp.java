package com.pru.sparc.drools.model;

public class CensusGrp {
	private double propExhLivesCen;
	private double propExhVolCen;
	private double propExhRateCen;
	private double propExhPremCen;
	private double compRate;
	private double estLivesPlan;
	private double estLivesCompPlan;
	private double estVolPlan;
	private double estVolCompPlan;
	private double monRatePlan;
	private double manRate;
	private double monPremPlan;
	public double getPropExhLivesCen() {
		return propExhLivesCen;
	}
	public void setPropExhLivesCen(double propExhLivesCen) {
		this.propExhLivesCen = propExhLivesCen;
	}
	public double getPropExhVolCen() {
		return propExhVolCen;
	}
	public void setPropExhVolCen(double propExhVolCen) {
		this.propExhVolCen = propExhVolCen;
	}
	public double getPropExhRateCen() {
		return propExhRateCen;
	}
	public void setPropExhRateCen(double propExhRateCen) {
		this.propExhRateCen = propExhRateCen;
	}
	public double getPropExhPremCen() {
		return propExhPremCen;
	}
	public void setPropExhPremCen(double propExhPremCen) {
		this.propExhPremCen = propExhPremCen;
	}
	public double getCompRate() {
		return compRate;
	}
	public void setCompRate(double compRate) {
		this.compRate = compRate;
	}
	public double getEstLivesPlan() {
		return estLivesPlan;
	}
	public void setEstLivesPlan(double estLivesPlan) {
		this.estLivesPlan = estLivesPlan;
	}
	public double getEstLivesCompPlan() {
		return estLivesCompPlan;
	}
	public void setEstLivesCompPlan(double estLivesCompPlan) {
		this.estLivesCompPlan = estLivesCompPlan;
	}
	public double getEstVolPlan() {
		return estVolPlan;
	}
	public void setEstVolPlan(double estVolPlan) {
		this.estVolPlan = estVolPlan;
	}
	public double getEstVolCompPlan() {
		return estVolCompPlan;
	}
	public void setEstVolCompPlan(double estVolCompPlan) {
		this.estVolCompPlan = estVolCompPlan;
	}
	public double getMonRatePlan() {
		return monRatePlan;
	}
	public void setMonRatePlan(double monRatePlan) {
		this.monRatePlan = monRatePlan;
	}
	public double getManRate() {
		return manRate;
	}
	public void setManRate(double manRate) {
		this.manRate = manRate;
	}
	public double getMonPremPlan() {
		return monPremPlan;
	}
	public void setMonPremPlan(double monPremPlan) {
		this.monPremPlan = monPremPlan;
	}
	
}
