package com.pru.sparc.drools.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Plan {

	public HashMap<String, Object> planMap = new HashMap<String, Object>();
	HashMap<String,Object> overRideMap = new HashMap<String,Object>();
	
	Census census = new Census();
	
	// TODO: This needs to be corrected, Commission Obj revisit as it should not used outside rating engine.
	
	List listOfComission = new ArrayList<Comission>();
	int commisionCount;//Commission count
	private int peopleCounter;
	private String ageBracket;
	//We will use status_gender_ageB_age_AggregationMap for all purposes to avoid discrepancy
	//private HashMap<Object, Object> statusAggregationMap = new HashMap<Object, Object>();
	private HashMap<Object, Object> genderAggregationMap = new HashMap<Object, Object>();
	private HashMap<Object, Object> ageBracketAggregationMap = new HashMap<Object, Object>();
	private HashMap<Object, Object> ageAggregationMap = new HashMap<Object, Object>();
	private HashMap<Object, Object> status_gender_ageB_age_AggregationMap = new HashMap<Object, Object>();

	public String getAgeBracket() {
		return ageBracket;
	}

	public void setAgeBracket(String ageBracket) {
		this.ageBracket = ageBracket;
	}

	public List getListOfComission() {
		return listOfComission;
	}

	public void setListOfComission(List listOfComission) {
		this.listOfComission = listOfComission;
	}
	
	

	public int getCommisionCount() {
		return commisionCount;
	}

	public void setCommisionCount(int commisionCount) {
		this.commisionCount = commisionCount;
	}

	public HashMap<String, Object> getPlanMap() {
		return planMap;
	}

	public void setPlanMap(HashMap<String, Object> planMap) {
		this.planMap = planMap;
	}

	public Census getCensus() {
		return census;
	}

	public void setCensus(Census census) {
		this.census = census;
	}

	/**
	 * Need to use getStatus_gender_ageB_age_AggregationMap going forward to avoid duplicate status maps
	 * @return
	 */
	@Deprecated
	public HashMap<Object, Object> getStatusAggregationMap() {
		return status_gender_ageB_age_AggregationMap;
	}


	public HashMap<Object, Object> getGenderAggregationMap() {
		return genderAggregationMap;
	}

	public void setGenderAggregationMap(
			HashMap<Object, Object> genderAggregationMap) {
		this.genderAggregationMap = genderAggregationMap;
	}

	public HashMap<Object, Object> getAgeBracketAggregationMap() {
		return ageBracketAggregationMap;
	}

	public void setAgeBracketAggregationMap(
			HashMap<Object, Object> ageBracketAggregationMap) {
		this.ageBracketAggregationMap = ageBracketAggregationMap;
	}

	public HashMap<Object, Object> getAgeAggregationMap() {
		return ageAggregationMap;
	}

	public void setAgeAggregationMap(HashMap<Object, Object> ageAggregationMap) {
		this.ageAggregationMap = ageAggregationMap;
	}

	public HashMap<Object, Object> getStatus_gender_ageB_age_AggregationMap() {
		return status_gender_ageB_age_AggregationMap;
	}

	public void setStatus_gender_ageB_age_AggregationMap(
			HashMap<Object, Object> status_gender_ageB_age_AggregationMap) {
		this.status_gender_ageB_age_AggregationMap = status_gender_ageB_age_AggregationMap;
	}

	public int getPeopleCounter() {
		return peopleCounter;
	}

	public void setPeopleCounter(int peopleCounter) {
		this.peopleCounter = peopleCounter;
	}
	public Object get(Object key){		
		return this.getPlanMap().get(key);
	}
	
	public void put(Object key, Object value){		
		this.getPlanMap().put((String)key, value);
	}
	
	public HashMap<String, Object> getOverRideMap() {
		return overRideMap;
	}

	public void setOverRideMap(HashMap<String, Object> overRideMap) {
		this.overRideMap = overRideMap;
	}
}
