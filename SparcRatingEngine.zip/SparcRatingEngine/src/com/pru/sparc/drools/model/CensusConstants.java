package com.pru.sparc.drools.model;

public  final class  CensusConstants {
	
	
	public static final String SALARY_SET_FOR_ALL = "SalarySetForAll";
	public static final String SALARY_ESTIMATE = "SalaryEstimate";
	
	
	public static final String AGEBRACKET_FINAL_RATE_CALC = "agebracket_Final_Rate_calc";
	public static final String AGEBRACKET_PRELIMINARY_RATE_ADJUSTED_FOR_TABLEI_CALC = "agebracket_Preliminary_Rate_Adjusted_for_TableI_calc";
	public static final String AGEBRACKET_TOTAL_LIVES = "agebracket_Total_Lives";
	public static final String AGEBRACKET_TOTAL_LIVES_CALC = "agebracket_Total_Lives_calc";
	public static final String AGEBRACKET_TOTAL_COVERED_VOLUME = "agebracket_Total_Covered_Volume";
	public static final String AGEBRACKET_TOTAL_COVERED_VOLUME_CALC = "agebracket_Total_Covered_Volume_calc";
	public static final String AGEBRACKET_TABLEIRATE = "agebracket_TableIRate";
	public static final String AGEBRACKET_TABLEIRATE_CALC = "agebracket_TableIRate_calc";
	public static final String AGEBRACKET_CROSSTABLEI = "agebracket_CrossTableI";
	public static final String AGEBRACKET_CROSSTABLEI_CALC = "agebracket_CrossTableI_calc";
	public static final String AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED = "agebracket_Initial_Inforce_Premium_AgeBanded";
	
	
	public static final String AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED_STEP_1 = "agebracket_Initial_Manual_Premium_AgeBanded_step_1";
	public static final String AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED_STEP_2 = "agebracket_Initial_Manual_Premium_AgeBanded_step_2";
	public static final String AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED_STEP_2 = "agebracket_Initial_Inforce_Premium_AgeBanded_Step_2";
	public static final String AGEBRACKET_PRELIMINARY_RATE = "agebracket_Preliminary_Rate";
	public static final String AGEBRACKET_INITIAL_INFORCE_VOLUME_AGEBANDED_STEP_1 = "agebracket_Initial_Inforce_Volume_AgeBanded_Step_1";
	public static final String AGEBRACKET_INITIAL_INFORCE_RATE_AGEBANDED_STEP_1 = "agebracket_Initial_Inforce_Rate_AgeBanded_Step_1";
	public static final String AGEBRACKET_INITIAL_INFORCE_RATE_AGEBANDED = "agebracket_Initial_Inforce_Rate_AgeBanded";
	public static final String AGEBRACKET_INITIAL_INFORCE_VOLUME_AGEBANDED = "agebracket_Initial_Inforce_Volume_AgeBanded";
	public static final String AGEBRACKET_INITIAL_MANUAL_RATE_AGEBANDED = "agebracket_Initial_Manual_Rate_AgeBanded";
	public static final String AGEBRACKET_FINAL_RATE_STEP_1 = "agebracket_Final_Rate_Step_1";
	public static final String AGEBRACKET_PRELIMINARY_RATE_CALC = "agebracket_Preliminary_Rate_calc";
	public static final String AGEBRACKET_PRELIMINARY_RATE_ADJUSTED_FOR_TABLE_I = "agebracket_Preliminary_Rate_Adjusted_for_Table_I";
	
	public static final String AGEBRACKET_FINAL_PREMIUM = "agebracket_Final_Premium";
	public static final String AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED = "agebracket_Initial_Manual_Premium_AgeBanded";
	public static final String AGEBRACKET_RENEWAL_INFORCE_PREMIUM_COMPOSITE = "agebracket_Renewal_Inforce_Premium_Composite";
	public static final String AGEBRACKET_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE = "agebracket_Renewal_Inforce_Premium_Non_Composite";
	
	
	
	public static final String AGEBRACKET_0_19_PRELIMINARY_RATE_STEP2C =   "agebracket_0_19_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_20_24_PRELIMINARY_RATE_STEP2C =  "agebracket_20_24_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_25_29_PRELIMINARY_RATE_STEP2C =  "agebracket_25_29_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_30_34_PRELIMINARY_RATE_STEP2C =  "agebracket_30_34_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_35_39_PRELIMINARY_RATE_STEP2C =  "agebracket_35_39_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_40_44_PRELIMINARY_RATE_STEP2C =  "agebracket_40_44_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_45_49_PRELIMINARY_RATE_STEP2C =  "agebracket_45_49_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_50_54_PRELIMINARY_RATE_STEP2C =  "agebracket_50_54_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_55_59_PRELIMINARY_RATE_STEP2C =  "agebracket_55_59_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_60_64_PRELIMINARY_RATE_STEP2C =  "agebracket_60_64_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_65_69_PRELIMINARY_RATE_STEP2C =  "agebracket_65_69_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_70_74_PRELIMINARY_RATE_STEP2C =  "agebracket_70_74_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_75_79_PRELIMINARY_RATE_STEP2C =  "agebracket_75_79_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_80_84_PRELIMINARY_RATE_STEP2C =  "agebracket_80_84_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_85_100_PRELIMINARY_RATE_STEP2C = "agebracket_85_100_Preliminary_Rate_Step2c";
	
	public static final String AGEBRACKET_0_19_ADJUSTMENT_RATIO =   "agebracket_0_19_Adjustment_Ratio";
	public static final String AGEBRACKET_20_24_ADJUSTMENT_RATIO =  "agebracket_20_24_Adjustment_Ratio";
	public static final String AGEBRACKET_25_29_ADJUSTMENT_RATIO =  "agebracket_25_29_Adjustment_Ratio";
	public static final String AGEBRACKET_30_34_AADJUSTMENT_RATIO =  "agebracket_30_34_aAdjustment_Ratio";
	public static final String AGEBRACKET_35_39_ADJUSTMENT_RATIO =  "agebracket_35_39_Adjustment_Ratio";
	public static final String AGEBRACKET_40_44_ADJUSTMENT_RATIO =  "agebracket_40_44_Adjustment_Ratio";
	public static final String AGEBRACKET_45_49_ADJUSTMENT_RATIO =  "agebracket_45_49_Adjustment_Ratio";
	public static final String AGEBRACKET_50_54_ADJUSTMENT_RATIO =  "agebracket_50_54_Adjustment_Ratio";
	public static final String AGEBRACKET_55_59_ADJUSTMENT_RATIO =  "agebracket_55_59_Adjustment_Ratio";
	public static final String AGEBRACKET_60_64_ADJUSTMENT_RATIO =  "agebracket_60_64_Adjustment_Ratio";
	public static final String AGEBRACKET_65_69_ADJUSTMENT_RATIO =  "agebracket_65_69_Adjustment_Ratio";
	public static final String AGEBRACKET_70_74_ADJUSTMENT_RATIO =  "agebracket_70_74_Adjustment_Ratio";
	public static final String AGEBRACKET_75_79_ADJUSTMENT_RATIO =  "agebracket_75_79_Adjustment_Ratio";
	public static final String AGEBRACKET_80_84_ADJUSTMENT_RATIO =  "agebracket_80_84_Adjustment_Ratio";
	public static final String AGEBRACKET_85_100_ADJUSTMENT_RATIO = "agebracket_85_100_Adjustment_Ratio";
	
	
	public static final String AGEBRACKET_0_19_PRELIMINARY_RATE_CALC =   "agebracket_0_19_Preliminary_Rate_calc";
	public static final String AGEBRACKET_20_24_PRELIMINARY_RATE_CALC =  "agebracket_20_24_Preliminary_Rate_calc";
	public static final String AGEBRACKET_25_29_PRELIMINARY_RATE_CALC =  "agebracket_25_29_Preliminary_Rate_calc";
	public static final String AGEBRACKET_30_34_PRELIMINARY_RATE_CALC =  "agebracket_30_34_Preliminary_Rate_calc";
	public static final String AGEBRACKET_35_39_PRELIMINARY_RATE_CALC =  "agebracket_35_39_Preliminary_Rate_calc";
	public static final String AGEBRACKET_40_44_PRELIMINARY_RATE_CALC =  "agebracket_40_44_Preliminary_Rate_calc";
	public static final String AGEBRACKET_45_49_PRELIMINARY_RATE_CALC =  "agebracket_45_49_Preliminary_Rate_calc";
	public static final String AGEBRACKET_50_54_PRELIMINARY_RATE_CALC =  "agebracket_50_54_Preliminary_Rate_calc";
	public static final String AGEBRACKET_55_59_PRELIMINARY_RATE_CALC =  "agebracket_55_59_Preliminary_Rate_calc";
	public static final String AGEBRACKET_60_64_PRELIMINARY_RATE_CALC =  "agebracket_60_64_Preliminary_Rate_calc";
	public static final String AGEBRACKET_65_69_PRELIMINARY_RATE_CALC =  "agebracket_65_69_Preliminary_Rate_calc";
	public static final String AGEBRACKET_70_74_PRELIMINARY_RATE_CALC =  "agebracket_70_74_Preliminary_Rate_calc";
	public static final String AGEBRACKET_75_79_PRELIMINARY_RATE_CALC =  "agebracket_75_79_Preliminary_Rate_calc";
	public static final String AGEBRACKET_80_84_PRELIMINARY_RATE_CALC =  "agebracket_80_84_Preliminary_Rate_calc";
	public static final String AGEBRACKET_85_100_PRELIMINARY_RATE_CALC = "agebracket_85_100_Preliminary_Rate_calc";
	
	
	public static final String  AGEBRACKET_0_19_COMPOSITE_PRELIMINARY_RATE_STEP1  =   "agebracket_0_19_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_20_24_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_20_24_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_25_29_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_25_29_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_30_34_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_30_34_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_35_39_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_35_39_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_40_44_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_40_44_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_45_49_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_45_49_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_50_54_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_50_54_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_55_59_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_55_59_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_60_64_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_60_64_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_65_69_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_65_69_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_70_74_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_70_74_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_75_79_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_75_79_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_80_84_COMPOSITE_PRELIMINARY_RATE_STEP1  =  "agebracket_80_84_Composite_Preliminary_Rate_Step1";
	public static final String  AGEBRACKET_85_100_COMPOSITE_PRELIMINARY_RATE_STEP1 = "agebracket_85_100_Composite_Preliminary_Rate_Step1";

	
}
