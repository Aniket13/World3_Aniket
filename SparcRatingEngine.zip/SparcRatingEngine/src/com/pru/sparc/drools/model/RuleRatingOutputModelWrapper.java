package com.pru.sparc.drools.model;

import java.util.ArrayList;
import java.util.List;

import com.pru.sparc.drools.model.RuleRatingCensusCompGrp;
import com.pru.sparc.drools.model.RuleRatingModelOverrideGrp;
import com.pru.sparc.drools.model.RuleRatingModelRuleResultGrp;

public class RuleRatingOutputModelWrapper {
	
	private List<ArrayList<RuleRatingModelOverrideGrp>> ratingModelOverideGrp;
	private List<RuleRatingCensusCompGrp> ratingCensusCompGrp;
	private List<RuleRatingModelRuleResultGrp> ratingRuleResultGrp;
	private List<RuleRatingAggregatedCensusGrp> ratingAggregatedCensusGrp;
	private RuleRatingProposalPlanDetails proposalPlanDetails;
	private int planId;
	//required to set once persisted in DB
	private int rateId;
	private boolean overriddenPlanRating;
	private boolean planReRatingPending;
	private boolean planRated;
	private boolean savedOverrides;
	
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public RuleRatingProposalPlanDetails getProposalPlanDetails() {
		return proposalPlanDetails;
	}
	public void setProposalPlanDetails(
			RuleRatingProposalPlanDetails proposalPlanDetails) {
		this.proposalPlanDetails = proposalPlanDetails;
	}
	public List<RuleRatingAggregatedCensusGrp> getRatingAggregatedCensusGrp() {
		return ratingAggregatedCensusGrp;
	}
	public void setRatingAggregatedCensusGrp(
			List<RuleRatingAggregatedCensusGrp> ratingAggregatedCensusGrp) {
		this.ratingAggregatedCensusGrp = ratingAggregatedCensusGrp;
	}
	public List<ArrayList<RuleRatingModelOverrideGrp>> getRatingModelOverideGrp() {
		return ratingModelOverideGrp;
	}
	public void setRatingModelOverideGrp(
			List<ArrayList<RuleRatingModelOverrideGrp>> ratingModelOverideGrp) {
		this.ratingModelOverideGrp = ratingModelOverideGrp;
	}
	public List<RuleRatingCensusCompGrp> getRatingCensusCompGrp() {
		return ratingCensusCompGrp;
	}
	public void setRatingCensusCompGrp(
			List<RuleRatingCensusCompGrp> ratingCensusCompGrp) {
		this.ratingCensusCompGrp = ratingCensusCompGrp;
	}
	public List<RuleRatingModelRuleResultGrp> getRatingRuleResultGrp() {
		return ratingRuleResultGrp;
	}
	public void setRatingRuleResultGrp(
			List<RuleRatingModelRuleResultGrp> ratingRuleResultGrp) {
		this.ratingRuleResultGrp = ratingRuleResultGrp;
	}
	public int getRateId() {
		return rateId;
	}
	public void setRateId(int rateId) {
		this.rateId = rateId;
	}
	public boolean isOverriddenPlanRating() {
		return overriddenPlanRating;
	}
	public void setOverriddenPlanRating(boolean overriddenPlanRating) {
		this.overriddenPlanRating = overriddenPlanRating;
	}
	public boolean isPlanReRatingPending() {
		return planReRatingPending;
	}
	public void setPlanReRatingPending(boolean planReRatingPending) {
		this.planReRatingPending = planReRatingPending;
	}
	public boolean isPlanRated() {
		return planRated;
	}
	public void setPlanRated(boolean planRated) {
		this.planRated = planRated;
	}
	public boolean isSavedOverrides() {
		return savedOverrides;
	}
	public void setSavedOverrides(boolean savedOverrides) {
		this.savedOverrides = savedOverrides;
	}
	

}
