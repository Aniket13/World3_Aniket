package com.pru.sparc.drools.model;

import com.pru.sparc.drools.common.util.RuleRatingConstants;

public final class PlanConstants {
	
	
	public static final String PLAN_ID = "planId"; //unique key to identify the person plan
	public static final String PLANCREDIBILITY = "plan_Credibility";
	public static final String PLANMARGIN = "plan_Margin";
	public static final String PLAN_TYPE = "plan_PlanType";
	public static final String VOLUME_TYPE = "plan_VolumeType";
	public static final String CASE_FLAT_AMT = "plan_CaseFlatAmt";
	public static final String MULTIPLE_EARNINGS_FLAT_AMT = "MultipleEarnings_FlatAmt";
	public static final String FLAT_AMT = "FlatAmt";
	public static final String GRAND_FATHERED_AMOUNTS = "Grandfathered_Amounts";
	public static final String PLAN_EARNINGS_FACTOR = "EarningsFactor";
	public static final String PLAN_CONTRACT_STATE = "plan_ContractState";
	public static final String PLAN_MAX = "plan_MAX";
	public static final String PLAN_MIN = "plan_MIN";
	public static final String PLAN_ROUNDING_OCCURS = "plan_RoundingOccurs";
	public static final String PLAN_AGE_REDUCTION_SCHEDULE = "plan_AgeReductionSchedule";
	public static final String PLAN_EFFECTIVEDATE = "EffectiveDate";
	public static final String PLAN_EFFECTIVEDATE_TIMESTAMP = "EffectiveDate_timestamp";
	public static final String PLAN_CONSTANT = "plan_DateConstant";
	public static final String PLAN_CREDIBILITY = "plan_Credibility";
	public static final String PLAN_MARGIN = "plan_Margin";
	public static final String PLAN_TOTAL_BENEFIT_CHARGES_STEP1 = "plan_Total_Benefit_Charges__Step_1";
	public static final String PLAN_DAC_TAX = "plan_DAC_Tax";
	public static final String PLAN_MISCELLANEOUS_TAX = "plan_Miscellaneous_Tax";
	public static final String PLAN_ADDITIONAL_ADMINISTRATION_STEP2 = "plan_Additional_Administration_Step2";
	public static final String PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2 = "Plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2";
	public static final String PLAN_EST_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2__INVERSE = "plan_Plan_Est_Annual_Premium_For_All_Plans__Step_2__Inverse";
	public static final String PLAN_COMPOSITE = "plan_Composite";
	public static final String PLAN_COMPSYCH_PREMIUM = "plan_Compsych_Premium";
	public static final String ORIGINAL_PLAN_EFFECTIVE_DATE = "OriginalPlanEffectiveDate";
	public static final String PLAN_LIVINGBENEFITOPTIONTYPE = "plan_LivingBenefitOptionType";
	public static final String PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS = "plan_Plan_Estimated_Annual_Premium_For_All_Plans";
	public static final String PLAN_EST_ANNUAL_PREMIUM_FOR_ALL_PLANS__INVERSE = "plan_Plan_Est_Annual_Premium_For_All_Plans__Inverse";
	public static final String PLAN_DISABILITYDURATION = "plan_DisabilityDuration";
	public static final String PLANDISABILITYDURATION = "Duration";
	public static final String PLAN_COMMISSION_DATE_CHECK = "plan_Commission_Date_Check";
	public static final String PLAN_TOTAL_LIVES = "plan_Total_Lives";
	public static final String PLAN_AVERAGE_ANNUAL_SALARY = "plan_Average_Annual_Salary";
	public static final String AVG_PEOPLE_AVERAGE_SALARY_FACTOR_STEP_1 = RuleRatingConstants.AVG_OPERATOR_KEY + PersonConstants.PEOPLE_AVERAGE_SALARY_FACTOR_STEP_1;
	public static final String PLAN_TOTAL_COVERED_VOLUME = "plan_Total_Covered_Volume";
	public static final String SUM_PEOPLE_COVERED_VOLUME = RuleRatingConstants.ADD_OPERATOR_KEY + PersonConstants.PEOPLE_COVERED_VOLUME;
	public static final String PLAN_RETIREE_COVERED_VOLUME = "plan_Retiree_Covered_Volume";
	public static final String PLAN_RETIREE_LIVES = "plan_Retiree_Lives";
	public static final String PLAN_ADD_DISCOUNT = "plan_ADD_Discount";
	//public static final String SUM_STATUS_ADD_DISCOUNT_ACTIVE_ONLY = RuleRatingConstants.ADD_OPERATOR_KEY + PersonConstants.STATUS_ADD_DISCOUNT_ACTIVE_ONLY;
		

	public static final String PLAN_PAYABLE_RATE = "plan_Payable_Rate";
	public static final String PLAN_CLIENT_POOLING_POINT__STEP_1 = "plan_Client_Pooling_Point__Step_1";
	public static final String PLAN_CLIENT_POOLING_POINT = "plan_Client_Pooling_Point";
	public static final String PLAN_POOLING_POINT = "plan_Pooling_Point";
	public static final String AGEBRACKET_0_19_TOTAL_COVERED_VOLUME_CALC = "plan_age_0_19_people_covered_Volume";
	public static final String AGEBRACKET_20_24_TOTAL_COVERED_VOLUME_CALC = "plan_age_20_24_people_covered_Volume";
	public static final String AGEBRACKET_25_29_TOTAL_COVERED_VOLUME_CALC = "plan_age_25_29_people_covered_Volume";
	public static final String AGEBRACKET_30_34_TOTAL_COVERED_VOLUME_CALC = "plan_age_30_34_people_covered_Volume";
	public static final String AGEBRACKET_35_39_TOTAL_COVERED_VOLUME_CALC = "plan_age_35_39_people_covered_Volume";
	public static final String AGEBRACKET_40_44_TOTAL_COVERED_VOLUME_CALC = "plan_age_40_44_people_covered_Volume";
	public static final String AGEBRACKET_45_49_TOTAL_COVERED_VOLUME_CALC = "plan_age_45_49_people_covered_Volume";
	public static final String AGEBRACKET_50_54_TOTAL_COVERED_VOLUME_CALC = "plan_age_50_54_people_covered_Volume";
	public static final String AGEBRACKET_55_59_TOTAL_COVERED_VOLUME_CALC = "plan_age_55_59_people_covered_Volume";
	public static final String AGEBRACKET_60_64_TOTAL_COVERED_VOLUME_CALC = "plan_age_60_64_people_covered_Volume";
	public static final String AGEBRACKET_65_69_TOTAL_COVERED_VOLUME_CALC = "plan_age_65_69_people_covered_Volume";
	public static final String AGEBRACKET_70_74_TOTAL_COVERED_VOLUME_CALC = "plan_age_70_74_people_covered_Volume";
	public static final String AGEBRACKET_75_79_TOTAL_COVERED_VOLUME_CALC = "plan_age_75_79_people_covered_Volume";
	public static final String AGEBRACKET_80_84_TOTAL_COVERED_VOLUME_CALC = "plan_age_80_84_people_covered_Volume";
	public static final String AGEBRACKET_85_100_TOTAL_COVERED_VOLUME_CALC = "plan_age_85_100_people_covered_Volume";
	public static final String PLAN_RATE_FILING_EXPENSES = "Plan_Rate_Filing_Expenses";
	public static final String PLAN_FEMALE_NON_POOLED_VOLUME = "plan_Female_Non_Pooled_Volume";
	public static final String PLAN_MALE_NON_POOLED_VOLUME = "plan_Male_Non_Pooled_Volume";
	public static final String PLAN_ACTIVE_NON_POOLED_VOLUME = "plan_Active_Non_Pooled_Volume";
	public static final String PLAN_RETIREE_NON_POOLED_VOLUME = "plan_Retiree_Non_Pooled_Volume";
	public static final String PLAN_AGE_0_19_PEOPLE_NON_POOLED_VOLUME= "plan_Age_0_19_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_20_24_PEOPLE_NON_POOLED_VOLUME= "plan_Age_20_24_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_25_29_PEOPLE_NON_POOLED_VOLUME= "plan_Age_25_29_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_30_34_PEOPLE_NON_POOLED_VOLUME= "plan_Age_30_34_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_35_39_PEOPLE_NON_POOLED_VOLUME= "plan_Age_35_39_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_40_44_PEOPLE_NON_POOLED_VOLUME= "plan_Age_40_44_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_45_49_PEOPLE_NON_POOLED_VOLUME= "plan_Age_45_49_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_50_54_PEOPLE_NON_POOLED_VOLUME= "plan_Age_50_54_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_55_59_PEOPLE_NON_POOLED_VOLUME= "plan_Age_55_59_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_60_64_PEOPLE_NON_POOLED_VOLUME= "plan_Age_60_64_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_65_69_PEOPLE_NON_POOLED_VOLUME= "plan_Age_65_69_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_70_74_PEOPLE_NON_POOLED_VOLUME= "plan_Age_70_74_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_75_79_PEOPLE_NON_POOLED_VOLUME= "plan_Age_75_79_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_80_84_PEOPLE_NON_POOLED_VOLUME= "plan_Age_80_84_People_Non_Pooled_Volume";
	public static final String PLAN_AGE_85_89_PEOPLE_NON_POOLED_VOLUME= "plan_Age_85_89_People_Non_Pooled_Volume";
	public static final String PLAN_FEMALE_POOLED_VOLUME = "plan_Female_Pooled_Volume";
	public static final String PLAN_MALE_POOLED_VOLUME ="plan_Male_Pooled_Volume";
	public static final String PLAN_ACTIVE_POOLED_VOLUME = "plan_Active_Pooled_Volume";
	public static final String PLAN_RETIREE_POOLED_VOLUME = "plan_Retiree_Pooled_Volume";
	public static final String PLAN_AGE_0_19_PEOPLE_POOLED_VOLUME= "plan_Age_0_19_People_Pooled_Volume";
	public static final String PLAN_AGE_20_24_PEOPLE_POOLED_VOLUME= "plan_Age_20_24_People_Pooled_Volume";
	public static final String PLAN_AGE_25_29_PEOPLE_POOLED_VOLUME= "plan_Age_25_29_People_Pooled_Volume";
	public static final String PLAN_AGE_30_34_PEOPLE_POOLED_VOLUME= "plan_Age_30_34_People_Pooled_Volume";
	public static final String PLAN_AGE_35_39_PEOPLE_POOLED_VOLUME= "plan_Age_35_39_People_Pooled_Volume";
	public static final String PLAN_AGE_40_44_PEOPLE_POOLED_VOLUME= "plan_Age_40_44_People_Pooled_Volume";
	public static final String PLAN_AGE_45_49_PEOPLE_POOLED_VOLUME= "plan_Age_45_49_People_Pooled_Volume";
	public static final String PLAN_AGE_50_54_PEOPLE_POOLED_VOLUME= "plan_Age_50_54_People_Pooled_Volume";
	public static final String PLAN_AGE_55_59_PEOPLE_POOLED_VOLUME= "plan_Age_55_59_People_Pooled_Volume";
	public static final String PLAN_AGE_60_64_PEOPLE_POOLED_VOLUME= "plan_Age_60_64_People_Pooled_Volume";
	public static final String PLAN_AGE_65_69_PEOPLE_POOLED_VOLUME= "plan_Age_65_69_People_Pooled_Volume";
	public static final String PLAN_AGE_70_74_PEOPLE_POOLED_VOLUME= "plan_Age_70_74_People_Pooled_Volume";
	public static final String PLAN_AGE_75_79_PEOPLE_POOLED_VOLUME= "plan_Age_75_79_People_Pooled_Volume";
	public static final String PLAN_AGE_80_84_PEOPLE_POOLED_VOLUME= "plan_Age_80_84_People_Pooled_Volume";
	public static final String PLAN_AGE_85_89_PEOPLE_POOLED_VOLUME= "plan_Age_85_89_People_Pooled_Volume";
	public static final String PLAN_COMMISSION_DATE_RANGE= "Commission_Date_Range";
	public static final String PLAN_COMMISSION_LEVEL_SCALE__UNION_SCALE_STEP_1= "commission_Level_Scale__Union_Scale_Step_1";
	public static final String PLAN_COMMISSION_LEVEL_SCALE__UNION_SCALE_STEP_2= "commission_Level_Scale__Union_Scale_Step_2";
	public static final String PLAN_TOTAL_COLLECTIVE_BARGAINS= "plan_Total_Collective_Bargains";
	//public static final String PLAN_TOTAL_COLLECTIVE_BARGAINS= RuleRatingConstants.ADD_OPERATOR_KEY+PersonConstants.PEOPLE_COLLECTIVE_BARGAINED;
	public static final String PLAN_COMMISSION_LEVEL_SCALE_COMMISSIONS= "commission_Level_Scale_Commissions";
	public static final String PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED_STEP_2= "plan_Initial_Inforce_Renewal_Premium_NonAgeBanded_Step_2";
	public static final String PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED= "plan_Initial_Inforce_Renewal_Premium_NonAgeBanded";
	public static final String PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED_STEP_1= "plan_Initial_Manual_Premium_NonAgeBanded_Step_1";
	public static final String PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED_STEP_2= "plan_Initial_Manual_Premium_NonAgeBanded_Step_2";
	
	public static final String PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED= "plan_Initial_Manual_Premium_NonAgeBanded";
	
	public static final String PLAN_RENEWAL_RATE_ACTION_AGE_BANDED_OVERRIDDEN = "plan_Renewal_Rate_Action_Age_Banded_Overridden";
	public static final String PLAN_RENEWAL_RATE_ALL_AGE_BANDED_SINGLE_RATE = "plan_Renewal_All_Age_Banded_Single_Rate";
	public static final String PLAN_INFORCE_RATE_ALL_AGE_BANDED_SINGLE_RATE = "plan_Inforce_All_Age_Banded_Single_Rate";
	
	public static final String PLAN_RENEWAL_RATE_ACTION = "plan_Renewal_Rate_Action";
	public static final String PLAN_RENEWAL_RATE_ACTION_OVERRIDE = "plan_Renewal_Rate_Action_Override";
	public static final String PLAN_RATE_ACTION_OUT_STEP_1 = "plan_Rate_Action_Out_Step_1";
	public static final String PLAN_RATE_ACTION_OUT_STEP_2 = "plan_Rate_Action_Out_Step_2";

	public static final String PLAN_CERTIFICATE_TYPE_LOAD = "plan_Certificate_Type_Load";
	public static final String PLAN_SET_OTHER_PLAN_TYPE= "plan_Set_Other_Plan_Type";
	
	public static final String PLAN_RATE_METHOD= "plan_Rate_Method";
	
	public static final String PLAN_OVERRIDE_75000_POSTCALC_STEP_1= "plan_Override_75000_Postcalc_Step_1";
	public static final String PLAN_INITIAL_INFORCE_RATE_NONAGEBANDED_STEP_1= "plan_Initial_Inforce_Rate_NonAgeBanded_Step_1";
	public static final String PLAN_INITIAL_INFORCE_COMMISSION_PERCENTAGE_STEP_1= "plan_Initial_Inforce_Commission_Percentage_Step_1";
	public static final String PLAN_COUNT_PLAN= "plan_Count_Plan";
	public static final String PLAN_ADDITIONAL_ADMINISTRATION = "plan_Additional_Administration";
	public static final String PLAN_CONTRIBUTION_TO_SURPLUS = "plan_Contribution_To_Surplus";
	public static final String EXPERIENCE_ARRANGEMENT = "Experience_Arrangement";
	
	public static final String BL_AGE_BANDED = "plan_BL_Age_Banded";
	public static final String PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED = "plan_Renewal_Age_Banded_Overrides_Used";
	
	public static final String PLAN_CUSTOM_REDUCTION_AGE_1 = "plan_Custom_Reduction_Age_1";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_1 = "plan_Custom_Reduction_Type_1";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_1 = "plan_Custom_Reduction_Percent_1";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_1 = "plan_Custom_Reduction_Dollar_1";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_1 = "plan_Custom_Reduction_Minimum_1";
	
	public static final String PLAN_CUSTOM_REDUCTION_AGE_2 = "plan_Custom_Reduction_Age_2";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_2 = "plan_Custom_Reduction_Type_2";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_2 = "plan_Custom_Reduction_Percent_2";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_2 = "plan_Custom_Reduction_Dollar_2";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_2 = "plan_Custom_Reduction_Minimum_2";
	
	public static final String PLAN_CUSTOM_REDUCTION_AGE_3 = "plan_Custom_Reduction_Age_3";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_3 = "plan_Custom_Reduction_Type_3";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_3 = "plan_Custom_Reduction_Percent_3";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_3 = "plan_Custom_Reduction_Dollar_3";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_3 = "plan_Custom_Reduction_Minimum_3";
	
	public static final String PLAN_CUSTOM_REDUCTION_AGE_4 = "plan_Custom_Reduction_Age_4";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_4 = "plan_Custom_Reduction_Type_4";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_4 = "plan_Custom_Reduction_Percent_4";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_4 = "plan_Custom_Reduction_Dollar_4";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_4 = "plan_Custom_Reduction_Minimum_4";

	public static final String PLAN_CUSTOM_REDUCTION_AGE_5 = "plan_Custom_Reduction_Age_5";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_5 = "plan_Custom_Reduction_Type_5";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_5 = "plan_Custom_Reduction_Percent_5";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_5 = "plan_Custom_Reduction_Dollar_5";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_5 = "plan_Custom_Reduction_Minimum_5";

	public static final String PLAN_CUSTOM_REDUCTION_AGE_6 = "plan_Custom_Reduction_Age_6";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_6 = "plan_Custom_Reduction_Type_6";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_6 = "plan_Custom_Reduction_Percent_6";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_6 = "plan_Custom_Reduction_Dollar_6";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_6 = "plan_Custom_Reduction_Minimum_6";

	public static final String PLAN_CUSTOM_REDUCTION_AGE_7 = "plan_Custom_Reduction_Age_7";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_7 = "plan_Custom_Reduction_Type_7";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_7 = "plan_Custom_Reduction_Percent_7";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_7 = "plan_Custom_Reduction_Dollar_7";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_7 = "plan_Custom_Reduction_Minimum_7";

	public static final String PLAN_CUSTOM_REDUCTION_AGE_8 = "plan_Custom_Reduction_Age_8";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_8 = "plan_Custom_Reduction_Type_8";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_8 = "plan_Custom_Reduction_Percent_8";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_8 = "plan_Custom_Reduction_Dollar_8";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_8 = "plan_Custom_Reduction_Minimum_8";

	public static final String PLAN_CUSTOM_REDUCTION_AGE_9 = "plan_Custom_Reduction_Age_9";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_9 = "plan_Custom_Reduction_Type_9";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_9 = "plan_Custom_Reduction_Percent_9";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_9 = "plan_Custom_Reduction_Dollar_9";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_9 = "plan_Custom_Reduction_Minimum_9";

	public static final String PLAN_CUSTOM_REDUCTION_AGE_10 = "plan_Custom_Reduction_Age_10";
	public static final String PLAN_CUSTOM_REDUCTION_TYPE_10 = "plan_Custom_Reduction_Type_10";
	public static final String PLAN_CUSTOM_REDUCTION_PERCENT_10 = "plan_Custom_Reduction_Percent_10";
	public static final String PLAN_CUSTOM_REDUCTION_DOLLAR_10 = "plan_Custom_Reduction_Dollar_10";
	public static final String PLAN_CUSTOM_REDUCTION_MINIMUM_10 = "plan_Custom_Reduction_Minimum_10";
	
	public static final String PLAN_SET_ROUNDING_SELECTION_STEP1 = "plan_SetRoundingSelection__Step1";
	public static final String PLAN_ROUNDING_PREFERENCES = "plan_PlanRoundingPreferences";
	public static final String ROUNDING_SELECTION = "RoundingSelection";
	
	public static final String PLAN_UNDERWRITING_CHARGE = "plan_Underwriting_Charge";
	public static final String TRAVEL_ASSIST = "Travel_Assist";
	public static final String PLAN_TRAVEL_ASSIST_ADJUSTMENT = "plan_Travel_Assist_Adjustment";
	public static final String BENEFICIARY_SERVICES = "BeneficiaryServices";
	public static final String PLAN_BENEFICIARY_COUNSELING_SERVICE = "plan_Beneficiary_Counseling_Service";
	public static final String PLAN_BL_EXHIBIT__MONTHLY_RATE_ADVOCATE_ADJUSTMENT = "plan_BL_Exhibit__Monthly_Rate_Advocate_Adjustment";
	public static final String PLAN_BL_EXHIBIT__MONTHLY_RATE_RVP_ADJUSTMENT = "plan_BL_Exhibit__Monthly_Rate_RVP_Adjustment";
	
	
	public static final String PLAN_VERSION_28_UW_BOX_DATE_CHECK = "plan_Version_28_UW_Box_Date_Check";
	public static final String PLAN_INITIAL_INFORCE_RATE = "plan_Initial_Inforce_Rate";
	public static final String PLAN_COMPSYCH_RATE = "plan_Compsych_Rate";
	public static final String RATING_TYPE_PIA = "Rating_Type_PIA";
	public static final String RATING_TYPE = "Rating_Type";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_1 = "plan_BL_Exhibit_Monthly_Rates_Step_1";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_2 = "plan_BL_Exhibit_Monthly_Rates_Step_2";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_3 = "plan_BL_Exhibit_Monthly_Rates_Step_3";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_4 = "plan_BL_Exhibit_Monthly_Rates_Step_4";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5 = "plan_BL_Exhibit_Monthly_Rates_Step_5";
	public static final String PLAN_INITIAL_INFORCE_LIVES_NONAGEBANDED_STEP_1 = "plan_Initial_Inforce_Lives_NonAgeBanded_Step_1";
	public static final String PLAN_PLAN_TYPE = "plan_PlanType";
	public static final String PLAN_SET_FLAT_PLAN_TYPE = "plan_Set_Flat_Plan_Type";
	public static final String PLAN_SET_MULTIPLE_PLAN_TYPE = "plan_Set_Multiple_Plan_Type";
	public static final String PLAN_SETROUNDINGSELECTION_STEP1 = "plan_SetRoundingSelection__Step1";
	public static final String PLAN_PLANROUNDINGPREFERENCES = "plan_PlanRoundingPreferences";
	public static final String AGE_REDUCTION_MAX = "AGE_REDUCTION_MAX";
	public static final String AGE_REDUCTION_MIN = "AGE_REDUCTION_MIN";
	
	public static final String PLAN_FILING_RETENTION = "FilingRetention";
	public static final String PLAN_TOTAL_RETENTION = "plan_Total_Retention";
	public static final String PLAN_PREMIUM_TAX_FACTOR = "plan_Premium_Tax_Factor";
	public static final String PLAN_ASSESSMENT_FACTOR = "plan_Assessment_Factor";
	public static final String PLAN_COMMISSION_PERCENTAGE = "plan_Commission_Percentage";
	public static final String PLAN_RATE_FILING_PROFIT = "plan_Rate_Filing_Profit";
	public static final String PLAN_CLAIM_ADMINISTRATION = "plan_Claim_Administration";
	public static final String PLAN_REGULAR_ADMINISTRATION = "plan_Regular_Administration";
	public static final String PLAN_COMPWINDOW_DATE_CHECK = "CompWindow_Date_Check";
	public static final String PLAN_COMPETITIVE_WINDOW_REQUESTED = "plan_Competitive_Window_Requested";
	public static final String PLAN_COMPETITIVE_WINDOW_USER_OVERRIDE = "plan_Competitive_Window_User_Override";
	
	public static final String PLAN_TOTAL_LIVES_INVERSE = "plan_Total_Lives__Inverse";
	public static final String PLAN_TOTAL_COVERED_VOLUME_INVERSE = "plan_Total_Covered_Volume__Inverse";
	
	public static final String PLAN_AVERAGE_CERTIFICATE = "plan_Average_Certificate";
	public static final String PLAN_COMPETITIVE_WINDOW_CHECK_RANGES_STEP_1 = "plan_Competitive_Window__Check_Ranges_step_1";
	public static final String PLAN_COUNT_FLAT_AMOUNT_PLANS = "plan_Count_Flat_Amount_Plans";
	public static final String PLAN_COMPOSITE_COUNTER_STEP_1 = "plan_Composite_Counter_Step_1";
	public static final String PLAN_COMPETITIVE_WINDOW_ACTUAL = "plan_Competitive_Window_Actual";
	public static final String PLAN_SRB2_EFFECTIVE_DATE_CHECK = "plan_SBR2_Effective_Date_Check";
	
	public static final String PLAN_REGIONAL_VP_ADJUSTMENT_DESIRED_RATE = "plan_Regional_VP_Adjustment_Desired_Rate";
	public static final String PLAN_REGIONAL_VP_ADJUSTMENT_ORIGINAL_RATE = "plan_Regional_VP_Adjustment_Original_Rate";
	public static final String PLAN_REGIONAL_VP_ADJUSTMENT_RATIO = "plan_Regional_VP_Adjustment_Ratio";
	public static final String PLAN_REGIONAL_VP_ADJUSTMENT_FOR_COMPOSITE_PLANS = "plan_Regional_VP_Adjustment_For_Composite_Plans";
	public static final String PLAN_FINAL_UW_ADJUSTMENT_DESIRED_RATE = "plan_Final_UW_Adjustment_Desired_Rate";
	public static final String PLAN_FINAL_UW_ADJUSTMENT_ORIGNAL_RATE = "plan_Final_UW_Adjustment_Original_Rate";
	public static final String PLAN_FINAL_UW_ADJUSTMENT_RATIO = "plan_Final_UW_Adjustment_Ratio";
	public static final String PLAN_FINAL_UW_ADJUSTMENT_FOR_COMPOSITE_PLANS = "plan_Final_UW_Adjustment_For_Composite_Plans";
	public static final String PLAN_COMP_WINDOW_MAXIMUM_ALLOWED_DISCOUNT = "plan_Comp_Window_Maximum_Allowed_Discount";
	public static final String PLAN_FIELD_ADJUSTMENT_OVERRIDE = "plan_Field_Adjustment_Override";
	public static final String PLAN_COMPETITIVE_WINDOW_CHECK_RANGES = "plan_Competitive_Window__Check_Ranges";
	
	public static final String PLAN_RENEWAL_RATE_NONAGEBANDED_OUT_STEP_1 = "plan_Renewal_Rate_NonAgeBanded_Out_Step_1";
	public static final String MULTIPLE_EARNINGS = "MultipleEarnings";
	public static final String DISABILITY_SCHEDULE = "plan_DisabilitySchedule";
	public static final String DISABILITY_SCHEDULE_DURATION = "plan_DisabilitySchedule";
	public static final String GUARANTEE_ISSUE_DOLLAR_AMT = "plan_GuaranteeIssueDollarAmt";
	public static final String RATE_GUARANTEE_MONTH_NUM = "plan_RateGuaranteeMonthNum";
	
	public static final String PLAN_RENEWAL_MONTHLY_RATES_STEP_2 = "plan_Renewal_Monthly_Rates_Step_2";
	public static final String PLAN_RENEWAL_MONTHLY_RATES_STEP_3 = "plan_Renewal_Monthly_Rates_Step_3";
	public static final String PLAN_COMPOSITE_MINIMUM_RATE = "plan_Composite_Minimum_Rate";
	public static final String PLAN_PLAN_MINIMUM_RATE = "plan_Plan_Minimum_Rate";
	public static final String SUM_PEOPLE_LIFE_COUNT = RuleRatingConstants.ADD_OPERATOR_KEY + PersonConstants.PEOPLE_LIFE_COUNT;

	public static final String STATUS_POOLED_VOLUME_INVERSE = "status_Pooled_Volume__Inverse";
	public static final String STATUS_NON_POOLED_VOLUME_INVERSE = "status_Non_Pooled_Volume__Inverse";
	
	
	public static final String PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING = "plan_Coverage_Composite_Rate_Ignoring_Composite_Setting";
	public static final String PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM_STEP1 = "plan_BL_Exhibit_Total_Annual_Premium_Step1";
	
	public static final String ACTIVE_POOLED_VOLUME_INVERSE = "active_Pooled_Volume__Inverse";
	public static final String PLAN_INITIAL_INFORCE_VOLUME_NONAGEBANDED_STEP_1 = "plan_Initial_Inforce_Volume_NonAgeBanded_Step_1";
	public static final String PLAN_INITIAL_MANUAL_VOLUME_NONAGEBANDED = "plan_Initial_Manual_Volume_NonAgeBanded";
	public static final String PLAN_INITIAL_INFORCE_PREMIUM_NONAGEBANDED_STEP_1 = "plan_Initial_Inforce_Premium_NonAgeBanded_Step_1";
	public static final String PLAN_INITIAL_INFORCE_PREMIUM = "plan_Initial_Inforce_Premium";
	public static final String PLAN_INITIAL_MANUAL_RATE_NONAGEBANDED = "plan_Initial_Manual_Rate_NonAgeBanded";
	public static final String PLAN_BL_EXHIBIT_NON_MED_MAX = "plan_BL_Exhibit_Non_Med_Max";
	
	public static final String ACTIVE_NON_POOLED_VOLUME_INVERSE = "active_Non_Pooled_Volume__Inverse";
	public static final String RETIREE_POOLED_VOLUME_INVERSE = "retiree_Pooled_Volume__Inverse";
	public static final String RETIREE_NON_POOLED_VOLUME_INVERSE = "retiree_Non_Pooled_Volume__Inverse";
	public static final String PLAN_INITIAL_INFORCE_VOLUME_RENEWAL = "plan_Initial_Inforce_Volume_Renewal";
	public static final String PLAN_RENEWAL_PREMIUM_NONAGEBANDED_OUT = "plan_Renewal_Premium_NonAgeBanded_Out";
	public static final String PLAN_UW_ADJUSTMENT_BOX_2_RATIO = "plan_UW_Adjustment_Box_2_Ratio";
	public static final String PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_RATES = "plan_Renewal_UW_Adjusted_Monthly_Rates";
	public static final String PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_PREMIUM = "plan_Renewal_UW_Adjusted_Monthly_Premium";
	public static final String PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_1 = "plan_Renewal_Percent_Of_Manual_Step_1";
	public static final String PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2 = "plan_Renewal_Percent_Of_Manual_Step_2";
	public static final String PLAN_FIELD_ADJUSTMENT_RATIO = "plan_Field_Adjustment_Ratio";
	public static final String PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE = "plan_UW_Adjustment_Box_2_Original_Rate";
	public static final String PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE = "plan_UW_Adjustment_Box_2_Desired_Rate";
	public static final String PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1 = "plan_UW_Adjustment_Box_2_Calc_Discount_For_Pilot_Step_1";
	public static final String PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2 = "plan_UW_Adjustment_Box_2_Calc_Discount_For_Pilot_Step_2";
	public static final String PLAN_UW_ADJUSTMENT_BOX_2_RATIO_SUM = "plan_UW_Adjustment_Box_2_Ratio_Sum";
	public static final String PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE_OUTPUT = "plan_Renewal_UW_Rate_Change_Percentage_Output";
	public static final String PLAN_UW_OVERRIDE_ALL_AGE_BANDED_SINGLE_RATE = "plan_Renewal_UW_Rate_Change_Percentage";
	public static final String PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE = "plan_Renewal_UW_Rate_Change_Percentage";
	public static final String PLAN_AVERAGE_SALARY_FACTOR_STEP_3 = "plan_Average_Salary_Factor_Step_3";
	public static final String PLAN_RENEWAL_UW_ADJUSTED_PREMIUM_NONAGEBANDED_OUT = "plan_Renewal_UW_Adjusted_Premium_NonAgeBanded_Out";
	public static final String PLAN_RENEWAL_RATE_NONAGEBANDED = "plan_Renewal_Rate_NonAgeBanded";
	public static final String PLAN_PRODUCT_LIVES_SALES_OFFICE_DISCOUNT = "plan_Product_Lives_Sales_Office_Discount";
	public static final String PLAN_RATIO_RETIREE_TO_TOTAL_LIVES = "plan_Ratio_Retiree_to_Total_Lives";
	public static final String PLAN_RATIO_RETIREE_TO_TOTAL_VOLUME = "plan_Ratio_Retiree_to_Total_Volume";
	public static final String PLAN_NON_MEDICAL_MAX_STEP_2 = "plan_Non_Medical_Max__Step_2";
	public static final String PLAN_NON_MEDICAL_MAX_STEP_1 = "plan_Non_Medical_Max__Step_1";
	public static final String PLAN_APPEAL_ADJUSTMENT_BOX_RATIO = "plan_Appeal_Adjustment_Box_Ratio";
	public static final String PLAN_RENEWAL_APPEAL_MONTHLY_RATES = "plan_Renewal_Appeal_Monthly_Rates";
	public static final String PLAN_RENEWAL_APPEAL_RATE_CHANGE_PERCENTAGE = "plan_Renewal_Appeal_Rate_Change_Percentage";
	public static final String PLAN_NON_MEDICAL_MAX = "plan_Non_Medical_Max";
	public static final String PLAN_GUARANTEE_ISSUE_STEP_1 = "plan_Guarantee_Issue__Step_1";
	public static final String PLAN_GUARANTEE_ISSUE = "plan_Guarantee_Issue";
	public static final String PLAN_POOLED_CAB_STEP_1 = "plan_Pooled_CAB__Step_1";
	//public static final String PEOPLE_LOOP_1 = "People_Loop_1";
	public static final String PEOPLE_LOOP_1 = RuleRatingConstants.ADD_OPERATOR_KEY+PersonConstants.PEOPLE_COLLECTIVE_BARGAINED;
	public static final String STATE_ALLOCATION_FACTOR = "state_StateAllocationFactor";
	public static final String PLAN_RENEWAL_APPEAL_RATE_CHANGE_PERCENTAGE_OUTPUT = "plan_Renewal_Appeal_Rate_Change_Percentage_Output";
	public static final String PLAN_RENEWAL_APPEAL_PREMIUM_OUT = "plan_Renewal_Appeal_Premium_Out";
	public static final String PLAN_BL_EXHIBIT_ESTIMATED_LIVES = "plan_BL_Exhibit_Estimated_Lives";
	public static final String PLAN_INITIAL_INFORCE_LIVES = "plan_Initial_Inforce_Lives";
	public static final String PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY = "plan_Total_Lives_For_All_Plans__Composite_Only";
		 
	public static final String PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_3 = "plan_Renewal_Percent_of_Manual_Step_3";
	public static final String PLAN_UW_OVERRIDE_PREMIUM_ALL_AGEBANDED = "plan_UW_Override_Premium_All_AgeBanded";
	public static final String PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE = "plan_Appeal_Adjustment_Box_Original_Rate";
	public static final String PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE = "plan_Appeal_Adjustment_Box_Desired_Rate";
	public static final String PLAN_APPEAL_ADJUSTMENT_BOX_RATIO_SUM = "plan_Appeal_Adjustment_Box_Ratio_Sum";
	public static final String PLAN_PAYABLE_RATE_STEP_1 = "plan_Payable_Rate__Step_1";
	public static final String PLAN_PAYABLE_RATE_STEP_1_INVERSE = "plan_Payable_Rate__Step_1_Inverse";
	public static final String PLAN_PAYABLE_RATE_STEP_2 = "plan_Payable_Rate__Step_2";
	public static final String PLAN_MINIMUM_PREMIUM = "plan_Minimum_Premium";
	public static final String PLAN_BL_EXHIBIT_ESTIMATED_VOLUME = "plan_BL_Exhibit_Estimated_Volume";
	public static final String PLAN_BL_EXHIBIT_ESTIMATED_VOLUME_STEP_1 = "plan_BL_Exhibit_Estimated_Volume_Step_1";
	public static final String PLAN_INITIAL_INFORCE_VOLUME = "plan_Initial_Inforce_Volume";
	public static final String PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_4 = "plan_Renewal_Percent_of_Manual_Step_4";

	public static final String PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1  = "plan_Monthly_Premium_For_All_Plans__Composite_Only_Step_1";
	public static final String PLAN_COMPOSITE_RATE_STEP1  = "plan_Composite_Rate_Step1";
	public static final String PLAN_PAYABLE_RATE_STEP_5  = "plan_Payable_Rate_Step_5";
	public static final String PLAN_COMPOSITE_RATE_STEP2  = "plan_Composite_Rate_Step2";
	public static final String PLAN_COMPOSITE_RATE_ROUND_STEP1  = "plan_Composite_Rate_round_Step1";
	public static final String PLAN_COMPOSITE_RATE_ROUND_STEP2  = "plan_Composite_Rate_round_Step2";
	public static final String PLAN_COMPOSITE_RATE_ROUND_STEP3  = "plan_Composite_Rate_round_Step3";
	public static final String PLAN_COMPOSITE_MINIMUM_RATE_ROUND_1  = "plan_Composite_Minimum_Rate_Round_1";
	public static final String PLAN_COMPOSITE_MINIMUM_RATE_ROUND_2  = "plan_Composite_Minimum_Rate_Round_2";
	public static final String PLAN_COMPOSITE_MINIMUM_RATE_ROUND_3  = "plan_Composite_Minimum_Rate_Round_3";
	public static final String PLAN_PLAN_MINIMUM_RATE_ROUND_1  = "plan_Plan_Minimum_Rate_Round_1";
	public static final String PLAN_PLAN_MINIMUM_RATE_ROUND_2  = "plan_Plan_Minimum_Rate_Round_2";
	public static final String PLAN_PLAN_MINIMUM_RATE_ROUND_3  = "plan_Plan_Minimum_Rate_Round_3";
	public static final String PLAN_AVERAGE_AGE  = "plan_Average_Age";
	public static final String PLAN_PERCENTAGE_FEMALE__STEP_1  = "plan_Percentage_Female__Step_1";
	public static final String PLAN_PERCENTAGE_FEMALE   = "plan_Percentage_Female";
	public static final String PLAN_AGE_BANDED_COUNTER  = "plan_Age_Banded_Counter";

	public static final String PLAN_RENEWAL_PREMIUM_NON_AGE_BANDED = "plan_Renewal_Premium_NonAgeBanded";
	

	
	public static final String PLAN_COMPOSITE_RATE_STEP_2 = "plan_Composite_Rate_Step_2";
	
	public static final String PLAN_ESTIMATED_VOLUME = "plan_Estimated_Volume";
	public static final String PLAN_TOTAL_ESTIMATED_VOLUME__COMPOSITE_ONLY = "plan_Total_Estimated_Volume__Composite_Only";
	
	public static final String PLAN_TABLE_K_MONTHLY_PREMIUM = "plan_Table_K_Monthly_Premium";
    public static final String PLAN_TABLE_K_MONTHLY_PREMIUM_STEP_1 = "plan_Table_K_Monthly_Premium_Step_1";
    public static final String PLAN_TABLE_K_ANNUAL_PREMIUM_STEP_1 = "plan_Table_K_Annual_Premium_Step_1";
    public static final String PLAN_TABLE_K_ANNUAL_PREMIUM = "plan_Table_K_Annual_Premium";

	public static final String PLAN_RENEWAL_VOLUME_ALL_AGE_BANDED = "plan_Renewal_Volume_All_Age_Banded";
	public static final String PLAN_INITIAL_INFORCE_PREM_ALL_AGEBANDED = "plan_Initial_Inforce_Prem_All_AgeBanded";
	public static final String PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED = "plan_Renewal_Premium_All_AgeBanded";
	public static final String PLAN_APPEAL_PREMIUM_ALL_AGEBANDED = "plan_Appeal_Premium_All_AgeBanded";
	public static final String PLAN_UW_OVERRIDE_ALL_AGE_BANDED_SINGLERATE = "plan_UW_Override_All_Age_Banded_Single_Rate";
	public static final String PLAN_APPEAL_ALL_AGE_BANDED_SINGLE_RATE = "plan_Appeal_All_Age_Banded_Single_Rate";
	
	public static final String PLAN_BLENDED_CLAIM_RATE = "plan_Blended_Claim_Rate";
	public static final String PLAN_PAYABLE_RATE_STEP_3 = "plan_Payable_Rate__Step_3";
	public static final String PLAN_PAYABLE_RATE_STEP_4 = "plan_Payable_Rate__Step_4";
	public static final String PLAN_PAYABLE_RATE_ROUND_STEP_1 = "plan_Payable_Rate_round_Step1";
	public static final String PLAN_PAYABLE_RATE_ROUND_STEP_2 = "plan_Payable_Rate_round_Step2";
	public static final String PLAN_PAYABLE_RATE_ROUND_STEP_3 = "plan_Payable_Rate_round_Step3";
	public static final String MINIMUM_PREMIUM = "Minimum_Premium";
	public static final String PLAN_ANNUAL_PREMIUM_STEP_1 = "plan_Annual_Premium_Step_1";
	public static final String PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY_STEP_1 = "plan_Monthly_Premium_For_RFP_Display_Step_1";
	public static final String PLAN_COMPETITIVE_WINDOW_FOR_REPORTING_STEP_1 = "plan_Competitive_Window_for_Reporting__Step_1";
	public static final String PLAN_TOTAL_MANUAL_PREMIUM_FOR_POSTCALC_STEP_1 = "plan_Total_Manual_Premium_for_Postcalc_Step_1";
	public static final String BL_GRAND_FATHERED_POOLING_POINT = "BL_Grandfathered_Pooling_Point";
	public static final String PLAN_ANNUAL_PREMIUM = "plan_Annual_Premium";
	public static final String PLAN_COMPOSITE_RATE = "plan_Composite_Rate";
	public static final String PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY = "plan_Monthly_Premium_For_RFP_Display";
	public static final String PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY = "plan_Monthly_Premium_For_All_Plans__Composite_Only";
	public static final String  CONTRACT_STATE_LOOP_2A = "Contract_State_Loop_2A";
	public static final String  PLAN_AREA_FACTOR = "plan_Area_Factor";
	public static final String  PLAN_TOTAL_POOLED_VOLUME = "plan_Total_Pooled_Volume";
	public static final String  PLAN_TOTAL_NON_POOLED_VOLUME = "plan_Total_Non_Pooled_Volume";

	public static final String  AGEBRACKET_PRETABLEK_LOOP = "AgeBracket_PreTableK_Loop";


	public static final String  PLAN_FIELD_ADJUSTMENT_FACTOR = "plan_Field_Adjustment_Factor";
	public static final String  PLAN_FIELD_ADJUSTMENT_PREMIUM = "plan_Field_Adjustment_Premium";
	public static final String  PLAN_REGIONAL_VP_FACTOR = "plan_Regional_VP_Factor";
	public static final String  PLAN_REGIONAL_VP_ADJUSTMENT_PREMIUM = "plan_Regional_VP_Adjustment_Premium";
	public static final String PLAN_FINAL_RATE_ACTION_OUT_STEP_1  = "plan_Final_Rate_Action_Out_Step_1";
	public static final String PLAN_FINAL_RATE_ACTION_OUT_STEP_2  = "plan_Final_Rate_Action_Out_Step_2";
	public static final String PLAN_RATE_DISK_TOTAL_COVERED_VOLUME = "plan_Rate_Disk_Total_Covered_Volume";
	public static final String PLAN_RATE_DISK_TOTAL_LIVES = "plan_Rate_Disk_Total_Lives";
	public static final String PLAN_RATE_DISK_TOTAL_ANNUAL_PREM = "plan_Rate_Disk_Total_Annual_Prem";
	public static final String PLAN_TOTAL_COMP_WINDOW_DISCOUNT_APPLIED = "plan_Total_Comp_Window_Discount_Applied";
	public static final String PLAN_ADVOCATE_ADJUSTMENT_FACTOR = "plan_Advocate_Adjustment_Factor";
	public static final String PLAN_ADVOCATE_ADJUSTMENT_PREMIUM = "plan_Advocate_Adjustment_Premium";
	public static final String PLAN_FINAL_UW_ADJUSTMENT_FACTOR = "plan_Final_UW_Adjustment_Factor";
	public static final String PLAN_FINAL_UW_ADJUSTMENT_PREMIUM = "plan_Final_UW_Adjustment_Premium";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6 = "plan_BL_Exhibit_Monthly_Rates_Step_6";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_RATES = "plan_BL_Exhibit_Monthly_Rates";
	public static final String PLAN_RATE_DISK_TOTAL_MONTHLY_PREM = "plan_Rate_Disk_Total_Monthly_Prem";
	public static final String PLAN_FINALRATE_ACTION_OUT  = "plan_finalRate_Action_Out";
	public static final String PLAN_REGIONAL_VP_ADJUSTMENT_RATIO_AVERAGE  = "plan_Regional_VP_Adjustment_Ratio_Average";
	public static final String PLAN_UW_ADJUSTMENT_BOX_2_RATIO_AVERAGE  = "plan_UW_Adjustment_Box_2_Ratio_Average";
	public static final String PLAN_FINAL_UW_ADJUSTMENT_RATIO_AVERAGE  = "plan_Final_UW_Adjustment_Ratio_Average";
	public static final String PLAN_OVERRIDE_75000_PREMIUM_POSTCALC  = "plan_Override_75000_Premium_Postcalc";
	public static final String PLAN_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC  = "plan_Total_BL_Manual_Premium_for_Postcalc";
	public static final String PLAN_COMPETETIVE_WINDOW_FOR_POSTCALC  = "plan_Competetive_Window_for_Postcalc";
	public static final String PLAN_TOTAL_LIVES_FOR_ALL_PLANS  = "plan_Total_Lives_For_All_Plans";
	public static final String PLAN_MAXIMUM_EXHIBIT_VOLUME  = "plan_Maximum_Exhibit_Volume";
	public static final String PLAN_MAXIMUM_EXHIBIT_PREMIUM  = "plan_Maximum_Exhibit_Premium";
	public static final String PLAN_MAXIMUM_EXHIBIT_LIVES  = "plan_Maximum_Exhibit_Lives";
	public static final String PLAN_COMPETITIVE_WINDOW_FOR_REPORTING  = "plan_Competitive_Window_for_Reporting";
	public static final String PLAN_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING  = "plan_Total_Annual_Premium_for_Reporting";
	public static final String PLAN_CLAIMS_EXPERIENCE_FOR_REPORTING  = "plan_Claims_Experience_for_Reporting";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_PREMIUM_STEP_1 = "plan_BL_Exhibit_Monthly_Premium_Step_1";
	public static final String PLAN_RENEWAL_INFORCE_PREMIUM_COMPOSITE = "plan_Renewal_Inforce_Premium_Composite";
	public static final String PLAN_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE = "plan_Renewal_Inforce_Premium_Non_Composite";
	public static final String PLAN_BL_EXHIBIT_MONTHLY_PREMIUM = "plan_BL_Exhibit_Monthly_Premium";
	public static final String PLAN_RENEWAL_PRODUCTION_SUM_NON_AGE_BANDED  = "plan_Renewal_Production_Sum_Non_Age_Banded";
	public static final String PLAN_SBR2_CHECK_DATE_FOR_POSTCALC  = "plan_SBR2_Check_Date_For_PostCalc";
	public static final String PLAN_RENEWAL_PRODUCTION_SUM_AGE_BANDED_PREMIUM  = "plan_Renewal_Production_Sum_Age_Banded_Premium";
	public static final String PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_NON_AGE_BANDED  = "plan_Renewal_Production_Sum_Inforce_Non_Age_Banded";
	public static final String PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_AGE_BANDED  = "plan_Renewal_Production_Sum_Inforce_Age_Banded";
	public static final String PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM  = "plan_BL_Exhibit_Total_Annual_Premium";
	public static final String PLAN_BL_COMPOSITE_PREMIUM_FOR_REPORTING  = "plan_BL_Composite_Premium_for_Reporting";
	public static final String PLAN_BL_PREMIUM_FOR_REPORTING  = "plan_BL_Premium_for_Reporting";
	public static final String PLAN_RATE_ACTION_OUT = "plan_Rate_Action_Out";
	public static final String PLAN_RATE_CHANGE = "plan_Rate_Change";
	public static final String PLAN_MAXIMUM_EXHIBIT_PREMIUM_STEP_1 = "plan_Maximum_Exhibit_Premium_Step_1";
	public static final String PLAN_MAXIMUM_EXHIBIT_VOLUME_STEP_1 = "plan_Maximum_Exhibit_Volume_Step_1";
	public static final String PLAN_MAXIMUM_EXHIBIT_LIVES_STEP_1 = "plan_Maximum_Exhibit_Lives_Step_1";
	public static final String PLAN_TOTAL_REPORTING_VOLUME_NON_COMPOSITE_STEP_1 = "plan_Total_Reporting_Volume_Non_Composite_Step_1";
	public static final String PLAN_TOTAL_REPORTING_LIVES_NON_COMPOSITE_STEP_1 = "plan_Total_Reporting_Lives_Non_Composite_Step_1";

	public static final String PLAN_RENEWAL_PERCENT_OF_MANUAL_SUM_PREMIUMS_STEP_9  = "plan_Renewal_Percent_of_Manual_Sum_Premiums_Step_9";

	public static final String PLAN_TOTAL_BENEFIT_CHARGES = "plan_Total_Benefit_Charges";
	public static final String PLAN_BLENDED_AREA_FACTOR_STEP_1 = "plan_Blended_Area_Factor_Step_1";
	public static final String PLAN_FINAL_PREMIUM_OVERRIDE_STEP_2 = "plan_Final_Premium_Override_Step_2";
	public static final String PLAN_INFORCE_AGEBANDED_PREMIUM_STEP_A = "plan_Inforce_Agebanded_Premium_Step_A";
	public static final String PLAN_INFORCE_AGEBANDED_PREMIUM_STEP_B = "plan_Inforce_Agebanded_Premium_Step_B";
	public static final String PLAN_INITIAL_MANUAL_PREM_ALL_AGEBANDED = "PLAN_INITIAL_MANUAL_PREM_ALL_AGEBANDED";

	public static final String PLAN_RATE_METHOD_OUT_FOR_REPORTING  = "plan_Rate_Method_Out_for_Reporting";
	public static final String PLAN_RATE_ACTION_OUT_FOR_REPORTING  = "plan_Rate_Action_Out_for_Reporting";
	

	public static final String PLAN_BLENDED_RATE_GUARANTEE_FACTOR_STEP_1 = "plan_Blended_Rate_Guarantee_Factor_Step_1";
	public static final String PLAN_RENEWAL_UW_ADJUSTED_RATE_FOR_REPORTING  = "plan_Renewal_UW_Adjusted_Rate_for_Reporting";
	public static final String PLAN_RENEWAL_PERCENT_OF_MANUAL  = "plan_Renewal_Percent_of_Manual";
	public static final String PLAN_RENEWAL_RATE_FOR_REPORTING  = "plan_Renewal_Rate_for_Reporting";
	public static final String PLAN_RENEWAL_MANUAL_RATE  = "plan_Renewal_Manual_Rate";
	public static final String PLAN_RENEWAL_MANUAL_PREMIUM  = "plan_Renewal_Manual_Premium";
	public static final String PLAN_RATE_ACTION_RATIO   = "plan_Rate_Action_Ratio";
	public static final String PLAN_EST_ANN_INF_PREM  = "plan_Est_Ann_Inf_Prem";
	public static final String PLAN_RENEWAL_PRODUCTION  = "plan_Renewal_Production";
	public static final String PLAN_RENEWAL_PLAN_CHANGE  = "plan_Renewal_Plan_Change";
	public static final String PLAN_RENEWAL_INFORCE_RATE_FOR_REPORTING  = "plan_Renewal_Inforce_Rate_For_Reporting";
	public static final String PLAN_RENEWAL_APPEAL_RATE_FOR_REPORTING  = "plan_Renewal_Appeal_Rate_for_Reporting";
	public static final String PLAN_RENEWAL_APPEAL_ANNUAL_PREMIUM_FOR_REPORTING  = "plan_Renewal_Appeal_Annual_Premium_for_Reporting";
	public static final String PLAN_RENEWAL_REPORTING_STEP  = "plan_Renewal_Reporting_Step";
	public static final String PLAN_EXPECTED_ANNUAL_CLAIMS_EXPERIENCE  = "plan_Expected_Annual_Claims_Experience";
	public static final String EXPECTEDANNUALCLAIMSEXPERIENCE  = "ExpectedAnnualClaimsExperience";
	public static final String PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIMS  = "plan_Composite_Annual_Expected_Claims";
	public static final String PLAN_BLENDED_EXPECTED_CLAIMS_STEP_1  = "plan_Blended_Expected_Claims__Step_1";
	public static final String PLAN_BLENDED_EXPECTED_CLAIMS  = "plan_Blended_Expected_Claims";
	public static final String PLAN_TOTAL_BENEFIT_CHANGES_STEP_2  = "plan_Total_Benefit_Changes_Step_2";
	public static final String PLAN_BLENDED_CLAIM_RATE_STEP_1  = "plan_Blended_Claim_Rate_Step_1";
	public static final String PLAN_CLAIMS_TIMES_EXPERIENCE_FOR_REPORTING  = "plan_Claims_Times_Experience_for_Reporting";
	public static final String PLAN_RENEWAL_PLAN_CHANGE_STEP_1  = "plan_Renewal_Plan_Change_Step_1";
	public static final String PLAN_RENEWAL_CENSUS_AGE_ADJUSTMENT  = "plan_Renewal_Census_Age_Adjustment";
	public static final String PLAN_NON_POOLED_ANNUAL_EXPECTED_CLAIMS  = "plan_Non_Pooled_Annual_Expected_Claims";
	public static final String PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIM_RATE  = "plan_Composite_Annual_Expected_Claim_Rate";
	public static final String PLAN_ESTIMATEDVOLUME_COMPOSITE_YES = "plan_EstimatedVolume_Composite_Yes";
	public static final String PLAN_ANNUAL_PREMIUM_COMPOSITE_YES = "plan_Annual_Premium__Composite_Yes";
	public static final String PLAN_MONTHLY_PREMIUM_COMPOSITE_ONLY = "plan_Monthly_Premium__Composite_Only";
	
	public static final String  PLAN_RENEWAL_DATE_MINUS_CENSUS_CREATION_DATE = "plan_Renewal_Date_Minus_Census_Creation_Date";
	public static final Double  EXP_POWER = new Double(1.038);


	public static final String PLAN_HIGHEST_COVERAGE_AMOUNT = "plan_Highest_Coverage_Amount";
	public static final String PLAN_DISABILITY_PRODUCT_DISCOUNT = "plan_Disability_Product_Discount";
	public static final String PLAN_TOTAL_SALARY  = "plan_Total_Salary";
	public static final String PLAN_LOWEST_SALARY_OVER_50K  = "plan_Lowest_Salary_Over_50K";
	public static final String PLAN_AVERAGE_5_LOWEST_SALARY  = "plan_Average_5_Lowest_Salary";
	public static final String PLAN_HIGHEST_SALARY  = "plan_Highest_Salary";
	public static final String PLAN_TOTAL_LIVES__COMPOSITE_YES  = "plan_Total_Lives__Composite_Yes";
	public static final String PLAN_TOTAL_COVERED_VOLUME__COMPOSITE_YES  = "plan_Total_Covered_Volume__Composite_Yes";	
	public static final String PLAN_RATE_ACTION_TABLE_OUT = "plan_Rate_Action_Table_Out";
	public static final String PLAN_LEVEL_SCALE_COMMISSIONS  = "plan_Level_Scale_Commissions";

	public static final String PLAN_ADDITIONAL_SERVICE_COMMISSIONS  = "plan_Additional_Service_Commissions";
	public static final String PLAN_REQUESTED_COMMISSION  = "plan_Requested_Commission";
	public static final String PLAN_MAX_ALLOWABLE_COMMISSIONS  = "plan_Max_Allowable_Commissions";
	

	public static final String PLAN_BENEFIT_CHARGES_FOR_ALL_PLANS  = "plan_Benefit_Charges_For_All_Plans";
	public static final String PEOPLE_COUNT_FEMALE_LIVES = "people_Count_Female_Lives";

	public static final String PREMIUM_AXIS = "Premium_Axis";
	public static final String PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_1  = "plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_1";
	public static final String PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2 = "plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2";
	public static final String PLAN_OPTIONAL_LIFE_ADJUSTMENT = "plan_Optional_Life_Adjustment";
	public static final String PLAN_COVERAGE_COMPOSITE_RATE_STEP1_IGNORING_COMPOSITE_SETTING = "plan_Coverage_Composite_Rate_Step1_Ignoring_Composite_Setting";
	
	
 
	
	
	
	
}

	
	
	
	
	
	

	
	
	
	


