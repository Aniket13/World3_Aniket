package com.pru.sparc.drools.model;

public class CensusCompGrp {
	private String ageRange_0_19;
	private String ageRange_20_24;
	private String ageRange_25_29;
	private String ageRange_30_34;
	private String ageRange_35_39;
	private String ageRange_40_44;
	private String ageRange_45_49;
	private String ageRange_50_54;
	private String ageRange_55_59;
	private String ageRange_60_64;
	private String ageRange_65_69;
	private String ageRange_70_74;
	private String ageRange_75_79;
	private String ageRange_80_84;
	private String ageRange_85_100;
	
}
