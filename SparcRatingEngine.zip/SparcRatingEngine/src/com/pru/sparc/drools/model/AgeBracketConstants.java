package com.pru.sparc.drools.model;

import java.util.ArrayList;
import java.util.List;

import com.pru.sparc.drools.common.util.RuleRatingConstants;

@SuppressWarnings("serial")
public final class AgeBracketConstants {

	
	public static final List<String> AGE_BRACKET_LIST = new ArrayList<String>() {
    	{
    		add(RuleRatingConstants.AGE_BRACKET_0_19_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_20_24_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_25_29_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_30_34_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_35_39_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_40_44_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_45_49_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_50_54_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_55_59_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_60_64_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_65_69_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_70_74_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_75_79_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_80_84_KEY);
    		add(RuleRatingConstants.AGE_BRACKET_85_100_KEY);
    	}
    };
    
    public static final String AGEBRACKET_PRELIMINARY_RATE_ADJ = "agebracket_Preliminary_Rate_Adj";
    
    public static final String AGEBRACKET_PRELIMINARY_RATE_ADJ__TABLEI_FIFTEEN = "agebracket_Preliminary_Rate_Adj__TableI_Fifteen";
    public static final String AGEBRACKET_PRELIMINARY_RATE_ADJ__TABLEI_ZERO = "agebracket_Preliminary_Rate_Adj__TableI_Zero";
    public static final String AGEBRACKET_RENEWAL_APPEAL_FINAL_RATE = "agebracket_Renewal_Appeal_Final_Rate";
    public static final String AGEBRACKET_INITIAL_INFORCE_VOLUME_AGE_BANDED = "agebracket_Initial_Inforce_Volume_AgeBanded";
    public static final String AGEBRACKET_RENEWAL_PREMIUM_AGE_BANDED_OUT = "agebracket_Renewal_Premium_AgeBanded_Out";
    public static final String AGEBRACKET_FINAL_RATE_STEP_2 = "agebracket_Final_Rate_Step_2";
    public static final String AGEBRACKET_FINAL_RATE_STEP_3 = "agebracket_Final_Rate_Step_3";
    public static final String AGEBRACKET_FINAL_RATE = "agebracket_Final_Rate";
    public static final String AGEBRACKET_INITIAL_INFORCE_RATE_AGEBANDED = "agebracket_Initial_Inforce_Rate_AgeBanded";
    public static final String AGEBRACKET_TOTAL_COVERED_VOLUME = "agebracket_Total_Covered_Volume";
    public static final String AGEBRACKET_FINAL_PREMIUM_OVERRIDE_STEP_1 = "agebracket_Final_Premium_Override_Step_1";
    public static final String AGEBRACKET_RENEWAL_MANUAL_RATE = "agebracket_Renewal_Manual_Rate";
    public static final String AGEBRACKET_MAXIMUM_COMPOSITE_AGEBANDED_RATE_STEP_1 = "agebracket_Maximum_Composite_Agebanded_Rate_Step_1";
    public static final String AGEBRACKET_MAXIMUM_COMPOSITE_AGEBANDED_RATE = "agebracket_Maximum_Composite_Agebanded_Rate";
    public static final String AGEBRACKET_POSTCALC_COMPOSITE_AGEBANDED_RATE = "agebracket_Postcalc_Composite_Agebanded_Rate";
    public static final String AGEBRACKET_RENEWAL_RATE_AGEBANDED = "agebracket_Renewal_Rate_AgeBanded";
    public static final String AGEBRACKET_RENEWAL_PREMIUM_AGE_BANDED = "agebracket_Renewal_Premium_AgeBanded";
    public static final String AGEBRACKET_UW_OVERRIDE_RENEWAL_RATE_AGEBANDED = "agebracket_UW_Override_Renewal_Rate_AgeBanded";
    public static final String AGEBRACKET_RENEWAL_UW_OVERRIDE_SET_1 = "agebracket_Renewal_UW_Override_Set_1";
    public static final String AGEBRACKET_RENEWAL_UW_OVERRIDE_Rate = "agebracket_Renewal_UW_Override_Rate";
    public static final String AGEBRACKET_UW_OVERRIDE_PREMIUM_AGEBANDED = "agebracket_UW_Override_Premium_AgeBanded";

    
    public static final String AGEBRACKET_FINAL_RATE_CALC = "agebracket_Final_Rate_calc";
	public static final String AGEBRACKET_PRELIMINARY_RATE_ADJUSTED_FOR_TABLEI_CALC = "agebracket_Preliminary_Rate_Adjusted_for_TableI_calc";
	public static final String AGEBRACKET_TOTAL_LIVES = "agebracket_Total_Lives";
	public static final String AGEBRACKET_TOTAL_LIVES_CALC = "agebracket_Total_Lives_calc";
	
	public static final String AGEBRACKET_TOTAL_COVERED_VOLUME_CALC = "agebracket_Total_Covered_Volume_calc";
	public static final String AGEBRACKET_TABLEIRATE = "agebracket_TableIRate";
	public static final String AGEBRACKET_TABLEIRATE_CALC = "agebracket_TableIRate_calc";
	public static final String AGEBRACKET_CROSSTABLEI = "agebracket_CrossTableI";
	public static final String AGEBRACKET_CROSSTABLEI_CALC = "agebracket_CrossTableI_calc";
	public static final String AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED = "agebracket_Initial_Inforce_Premium_AgeBanded";
	
	
	public static final String AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED_STEP_1 = "agebracket_Initial_Manual_Premium_AgeBanded_step_1";
	public static final String AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED_STEP_2 = "agebracket_Initial_Manual_Premium_AgeBanded_step_2";
	public static final String AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED_STEP_2 = "agebracket_Initial_Inforce_Premium_AgeBanded_Step_2";
	public static final String AGEBRACKET_PRELIMINARY_RATE = "agebracket_Preliminary_Rate";
	public static final String AGEBRACKET_INITIAL_INFORCE_VOLUME_AGEBANDED_STEP_1 = "agebracket_Initial_Inforce_Volume_AgeBanded_Step_1";
	public static final String AGEBRACKET_INITIAL_INFORCE_RATE_AGEBANDED_STEP_1 = "agebracket_Initial_Inforce_Rate_AgeBanded_Step_1";
	
	public static final String AGEBRACKET_INITIAL_INFORCE_VOLUME_AGEBANDED = "agebracket_Initial_Inforce_Volume_AgeBanded";
	public static final String AGEBRACKET_INITIAL_MANUAL_RATE_AGEBANDED = "agebracket_Initial_Manual_Rate_AgeBanded";
	public static final String AGEBRACKET_FINAL_RATE_STEP_1 = "agebracket_Final_Rate_Step_1";
	public static final String AGEBRACKET_PRELIMINARY_RATE_CALC = "agebracket_Preliminary_Rate_calc";
	public static final String AGEBRACKET_PRELIMINARY_RATE_ADJUSTED_FOR_TABLE_I = "agebracket_Preliminary_Rate_Adjusted_for_Table_I";
	
	public static final String AGEBRACKET_FINAL_PREMIUM = "agebracket_Final_Premium";
	public static final String AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED = "agebracket_Initial_Manual_Premium_AgeBanded";
	public static final String AGEBRACKET_RENEWAL_INFORCE_PREMIUM_COMPOSITE = "agebracket_Renewal_Inforce_Premium_Composite";
	public static final String AGEBRACKET_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE = "agebracket_Renewal_Inforce_Premium_Non_Composite";
	
	public static final String AGEBRACKET_APPEAL_RENEWAL_RATE_AGEBANDED = "agebracket_Appeal_Renewal_Rate_AgeBanded";
    public static final String AGEBRACKET_CHECK_APPEAL_OVERRIDE_USED = "agebracket_Check_Appeal_Override_Used";
    public static final String AGEBRACKET_SET_TO_1 = "agebracket_Set_To_1";
    public static final String AGEBRACKET_APPEAL_PREMIUM_AGEBANDED = "agebracket_Appeal_Premium_AgeBanded";
    
    
    public static final String AGEBRACKET_NON_POOLED_VOL_BY_GENDER_STATUS_AGEBRACKET__INVERSE = "agebracket_Non_Pooled_Vol_by_Gender_Status_AgeBracket__Inverse";    
    public static final String AGEBRACKET_POOLED_VOL_BY_GENDER_STATUS_AGEBRACKET__INVERSE = "agebracket_Pooled_Vol_by_Gender_Status_AgeBracket__Inverse";
    public static final String AGEBRACKET_NON_POOLED_MANUAL_RATE = "agebracket_Non_Pooled_Manual_Rate";    
    public static final String AGEBRACKET_POOLED_MANUAL_RATE = "agebracket_Pooled_Manual_Rate";
    public static final String AGE_PRELIMINARY_RATE_STEP1_MALEONLY = "age_Preliminary_Rate_Step1_MaleOnly";

	public static final String AGEBRACKET_ADJUSTMENT_RATIO = "agebracket_Adjustment_Ratio";
	public static final String AGEBRACKET_PRELIMINARY_RATE_STEP2C = "agebracket_Preliminary_Rate_Step2c";
	public static final String AGEBRACKET_COMPOSITE_PRELIMINARY_RATE_STEP1 = "agebracket_Composite_Preliminary_Rate__Step1";
	public static final String AGEBRACKET_COMPOSITE_TABLEI_STEP1 = "agebracket_Composite_TableI__Step1";
	public static final String AGEBRACKET_PRELIMINARY_RATE_STEP2B = "agebracket_Preliminary_Rate_Step2b";
	public static final String AGEBRACKET_PRELIMINARY_RATE_STEP2A = "agebracket_Preliminary_Rate_Step2a";
	
	public static final String AGEBRACKET_TOTAL_LIVES_BY_GENDER_STATUS_AGEBRACKET = "agebracket_Total_Lives_by_Gender_Status_AgeBracket";
	public static final String AGEBRACKET_COVERED_VOLUME_BY_GENDER_STATUS_AGEBRACKET = "agebracket_Covered_Volume_by_Gender_Status_AgeBracket";
	public static final String AGEBRACKET_NON_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET = "agebracket_Non_Pooled_Volume_by_Gender_Status_AgeBracket";
	public static final String AGEBRACKET_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET = "agebracket_Pooled_Volume_by_Gender_Status_AgeBracket";
	
}
