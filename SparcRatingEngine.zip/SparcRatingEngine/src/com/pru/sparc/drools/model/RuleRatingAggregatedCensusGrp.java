package com.pru.sparc.drools.model;

public class RuleRatingAggregatedCensusGrp {
	
	private String ageBracket;
	private String gender;
	private String status;
	private double lives;
	private double coveredVolume;
	private double nonPooledVolume;
	private double pooledVolume;
	private double nonPooledManualRate;
	private double pooledManualRate;
	private String groupId;
	private int precision;
	
	
	public int getPrecision() {
		return precision;
	}
	public void setPrecision(int precision) {
		this.precision = precision;
	}
	public String getAgeBracket() {
		return ageBracket;
	}
	public void setAgeBracket(String ageBracket) {
		this.ageBracket = ageBracket;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getLives() {
		return lives;
	}
	public void setLives(double lives) {
		this.lives = lives;
	}
	public double getCoveredVolume() {
		return coveredVolume;
	}
	public void setCoveredVolume(double coveredVolume) {
		this.coveredVolume = coveredVolume;
	}
	public double getNonPooledVolume() {
		return nonPooledVolume;
	}
	public void setNonPooledVolume(double nonPooledVolume) {
		this.nonPooledVolume = nonPooledVolume;
	}
	public double getPooledVolume() {
		return pooledVolume;
	}
	public void setPooledVolume(double pooledVolume) {
		this.pooledVolume = pooledVolume;
	}
	public double getNonPooledManualRate() {
		return nonPooledManualRate;
	}
	public void setNonPooledManualRate(double nonPooledManualRate) {
		this.nonPooledManualRate = nonPooledManualRate;
	}
	public double getPooledManualRate() {
		return pooledManualRate;
	}
	public void setPooledManualRate(double pooledManualRate) {
		this.pooledManualRate = pooledManualRate;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
}
