package com.pru.sparc.drools.model;

public class AcknowledgeGrp {
	private double ackHighPrem;
	private double fieldAdjust;
	public double getAckHighPrem() {
		return ackHighPrem;
	}
	public void setAckHighPrem(double ackHighPrem) {
		this.ackHighPrem = ackHighPrem;
	}
	public double getFieldAdjust() {
		return fieldAdjust;
	}
	public void setFieldAdjust(double fieldAdjust) {
		this.fieldAdjust = fieldAdjust;
	}
	
}
