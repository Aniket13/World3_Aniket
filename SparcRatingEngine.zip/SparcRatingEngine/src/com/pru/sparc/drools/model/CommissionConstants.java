package com.pru.sparc.drools.model;

public class CommissionConstants {

	public static final String COMMISSION_LEVEL_SCALE__SCALE_B_STEP_1= "commission_Level_Scale__Scale_B_Step_1";
	public static final String COMMISSION_LEVEL_SCALE__SCALE_B_STEP_2= "commission_Level_Scale__Scale_B_Step_2";
	public static final String COMMISSION_LEVEL_SCALE__SCALE_B_CHECK= "commission_Level_Scale__Scale_B_Check";
	public static final String COMMISSION_LEVEL_SCALE__SCALE_C_STEP_1= "commission_Level_Scale__Scale_C_Step_1";
	public static final String COMMISSION_LEVEL_SCALE__SCALE_C_STEP_2= "commission_Level_Scale__Scale_C_Step_2";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__BENEFIT_ADMIN_SYSTEM_DESIGN= "commission_Addtl_Service_Comm__Benefit_Admin_System_Design";
	public static final String COMMISSION_COMMISSION_ADDTL_SERVICE_COMM__CLAIM_CONTROL_PROGRAM="commission_Addtl_Service_Comm__Claim_Control_Program";
	public static final String COMMISSION_ADDTL_SERVIE_COMM__CLAIM_EXPERIENCE_ANALYSIS="commission_Addtl_Servie_Comm__Claim_Experience_Analysis";
	public static final String COMMISSION_COMMISSION_ADDTL_SERVICE_COMM__COLLECTIVE_BARGAIN_CONSULT="commission_Addtl_Service_Comm__Collective_Bargain_Consult";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__CONTRACTUAL_PROVISION_REVIEW="commission_Addtl_Service_Comm__Contractual_Provision_Review";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__CUST_SATIS_MONITOR="commission_Addtl_Service_Comm__Cust_Satis_Monitor";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__ENROLL_ASSISTANCE="commission_Addtl_Service_Comm__Enroll_Assistance";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__MAINTAIN_RECORDS="commission_Addtl_Service_Comm__Maintain_Records";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__PLAN_DOC_ASSIST="commission_Addtl_Service_Comm__Plan_Doc_Assist";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__PLAN_CHANGE_CONSULT="commission_Addtl_Service_Comm__Plan_Change_Consult";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__SUPERVISING_GENERAL_AGENT="commission_Addtl_Service_Comm__Supervising_General_Agent";
	public static final String COMMISSION_ADMINSYSDESIGN="AdminSysDesign";
	public static final String COMMISSION_CLAIMANALYSIS="ClaimAnalysis";
	public static final String COMMISSION_CLAIMCONTROLPARTICIP="ClaimControlParticip";
	public static final String COMMISSION_BARGAINCONSULT="BargainConsult";
	public static final String COMMISSION_PROVISIONREVIEW="ProvisionReview";
	public static final String COMMISSION_CUSTSATISFMONITOR="CustSatisfMonitor";
	public static final String COMMISSION_ENROLLASSIST="EnrollAssist";
	public static final String COMMISSION_MAINTAINRECORDS="MaintainRecords";
	public static final String COMMISSION_PLANDOCASSIST="PlanDocAssist";
	public static final String COMMISSION_PLANCHANGECONSULT="PlanChangeConsult";
	public static final String COMMISSION_SUPERVISINGAGENT="SupervisingAgent";
	public static final String COMMISSION_LEVEL_SCALE_COMMISSIONS= "commission_Level_Scale_Commissions";
	public static final String COMMISSION_ADDTL_SERVICE_COMM__STEP_2= "commission_Addtl_Service_Comm__Step_2";
	public static final String COMMISSION_ADDITIONAL_SERVICE_COMMISSION= "commission_Additional_Service_Commission";
	public static final String COMMISSION_REQUESTED_COMMISSION__FLAT_PERCENT="commission_Requested_Commission__Flat_Percent";
	public static final String COMMISSION_REQUESTED_COMMISSION__FLAT_AMT="commission_Requested_Commission__Flat_Amt";
	public static final String COMMISSION_REQUESTED_COMMISSION__LEVEL="commission_Requested_Commission__Level";
	public static final String COMMISSIONFLATPCT="CommissionFlatPct";
	public static final String COMMISSIONFLATAMT="CommissionFlatAmt";
	public static final String COMMISSION_COMARRANGEMENT="ComArrangement";
	public static final String COMMISSION_REQUESTED_COMMISSION="commission_Requested_Commission";
	public static final String COMMISSION_SET_TO_INFORCE_VALUE="commission_Set_To_Inforce_Value";
	public static final String COMMISSION_MAX_ALLOWABLE_COMM__NY_YES_STEP_1="commission_Max_Allowable_Comm__NY_Yes_Step_1";
	public static final String COMMISSION_MAX_ALLOWABLE_COMM__NY_YES_STEP_2="commission_Max_Allowable_Comm__NY_Yes_Step_2";
	public static final String COMMISSION_MAX_ALLOWABLE_COMMISSIONS  = "commission_Max_Allowable_Commissions";
	public static final String COMMISSION_MAX_ALLOWABLE_COMM__NY_NO_STEP_1  = "commission_Max_Allowable_Comm__NY_No_Step_1";
	public static final String COMMISSION_MAX_ALLOWABLE_COMM__NY_NO_STEP_2  = "commission_Max_Allowable_Comm__NY_No_Step_2";
	public static final String COMMISSION_LEVEL_SCALE__UNION_SCALE_STEP_2 = "commission_Level_Scale__Union_Scale_Step_2";
	public static final String COMMISSION_LEVEL_SCALE__UNION_SCALE_STEP_1 = "commission_Level_Scale__Union_Scale_Step_1";
	public static final String COMMISSION_DATE_RANGE = "Commission_Date_Range";
	public static final String COMMISSION_COMMISSION_PERCENTAGE  = "commission_Commission_Percentage";
	
	
	
	
	
}
