package com.pru.sparc.drools.model;

import java.util.HashMap;

public class State {
	
	public HashMap<String, Object> stateMap = new HashMap<String, Object>();
	
	public HashMap<String, Object> getStateMap() {
		return stateMap;
	}

	public void setStateMap(HashMap<String, Object> stateMap) {
		this.stateMap = stateMap;
	}
	
	public Object get(Object key){		
		return this.getStateMap().get(key);
	}
	
	public void put(Object key, Object value){		
		this.getStateMap().put((String)key, value);
	}

}
