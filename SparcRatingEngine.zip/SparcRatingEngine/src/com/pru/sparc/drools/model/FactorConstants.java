package com.pru.sparc.drools.model;

public class FactorConstants {
	public static final String FACTOR_OUTPUT= "output1";
	public static final String FACTOR_DEFAULT_OUTPUT= "0";
	
}

