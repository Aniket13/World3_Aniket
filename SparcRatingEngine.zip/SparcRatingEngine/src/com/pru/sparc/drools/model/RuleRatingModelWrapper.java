package com.pru.sparc.drools.model;

import java.util.List;



public class RuleRatingModelWrapper {
	private List<RuleRatingModelOverrideGrp> ruleRatingModelOverrideGrp;
	private List<RuleRatingCensusCompGrp> ruleRatingCensusCompGrp;
	private List<RuleRatingModelRuleResultGrp> ruleRatingModelRuleResultGrp;
	public List<RuleRatingModelOverrideGrp> getRuleRatingModelOverrideGrp() {
		return ruleRatingModelOverrideGrp;
	}
	public void setRuleRatingModelOverrideGrp(
			List<RuleRatingModelOverrideGrp> ruleRatingModelOverrideGrp) {
		this.ruleRatingModelOverrideGrp = ruleRatingModelOverrideGrp;
	}
	public List<RuleRatingCensusCompGrp> getRuleRatingCensusCompGrp() {
		return ruleRatingCensusCompGrp;
	}
	public void setRuleRatingCensusCompGrp(
			List<RuleRatingCensusCompGrp> ruleRatingCensusCompGrp) {
		this.ruleRatingCensusCompGrp = ruleRatingCensusCompGrp;
	}
	public List<RuleRatingModelRuleResultGrp> getRuleRatingModelRuleResultGrp() {
		return ruleRatingModelRuleResultGrp;
	}
	public void setRuleRatingModelRuleResultGrp(
			List<RuleRatingModelRuleResultGrp> ruleRatingModelRuleResultGrp) {
		this.ruleRatingModelRuleResultGrp = ruleRatingModelRuleResultGrp;
	}
	
	
}
