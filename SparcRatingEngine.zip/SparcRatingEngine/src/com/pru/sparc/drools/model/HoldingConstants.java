	package com.pru.sparc.drools.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.pru.sparc.drools.common.util.RuleRatingConstants;

public  final  class HoldingConstants {

	public static final String ADDQUOTED = "ADDQuoted";
	public static final String LTDQUOTED = "LTDQuoted";
	public static final String STDQUOTED = "STDQuoted";
	public static final String COMP_PSYCH_FEE = "CompycheFee";
	public static final String SIC_CODE = "holding_SIC_code";
	public static final String HOLDING_CV_CASE_LIVES = "holding_cv_case_lives";
	public static final String RENEWAL = "holding_Renewal";
	public static final String RENEWAL_YES = "RenewalYes";
	
	public static final String RATING_TYPE = "holding_Rating_Type";
	public static final String HOLDING_COMMISSION_DATE = "holding_Commission_Date";
	public static final String HOLDING_TOTAL_BENEFIT_CHARGES = "holding_Total_Benefit_Charges";
	public static final String RENEWAL_LIVES = "holding_Renewal_Lives";
	public static final String HOLDING_NON_POOLED_MANUAL_RATE_STEP_3 = "holding_Non_Pooled_Manual_Rate_Step_3";
	public static final String HOLDING_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING = "holding_Coverage_Composite_Rate_Ignoring_Composite_Setting";
	public static final String HOLDING_TOTAL_FEMALE_LIVES = "holding_Total_Female_Lives_Ignoring_Composite_Setting";
	public static final String HOLDING_TOTAL_FEMALE_LIVES1 = "holding_Total_Female_Lives_Ignoring_Composite_Setting1";
	public static final String HOLDING_TOTAL_COMPSYCH_PREMIUM = "holding_Total_Compsych_Premium";
	public static final String HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS = "holding_Total_Lives_For_All_Plans";
	public static final String HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS = "holding_Total_Covered_Volume_For_All_Plans";
	public static final String HOLDING_AGE_BANDED_RATIO = "holding_Age_Banded_Ratio";
	public static final String HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY = "holding_Annual_Premium_For_All_Plans__Composite_Only";

	public static final String HOLDING_COMPOSITE_TABLEI = "holding_Composite_TableI";
	public static final String HOLDING_COMPOSITE_PRELIMINARY_RATE = "holding_Composite_Preliminary_Rate";

	public static final String ROSTER_BILL_METHOD = "Roster_Bill_Method";
	public static final String PROPOSALEFFECTIVEDATE = "proposalEffectiveDate";
	public static final String DV_BILLMETHOD = "holding_dv_BillMethod";

	public static final String HOLDING_RATE_ACTION_MAX = "holding_Rate_Action_Max";
	public static final String AGED_CENSUS = "holding_AgedCensus";
	public static final String HOLDING_PREMIUM_DIFF = "holding_Premium_Diff";
	public static final String RENEWAL_PREMIUM_PERCENTAGE = "Renewal_Premium_Percentage";
	public static final String HOLDING_RATE_ACTION_RAT = "holding_Rate_Action_RAT";

	public static final String CERTIFICATE_TYPE = "Cerificate_Type";
	public static final String HOLDING_TOTAL_CROSS_TABLEI = "holding_Total_Cross_TableI";

	public static final String HOLDING_TOTAL_LIVES_FOR_ALL_PLANS = "holding_Total_Lives_For_All_Plans";
	public static final String HOLDING_100_PILOT_CASE_INDICATOR = "holding_Under_100_Pilot_Case_Indicator";
	public static final String HOLDING_LIFE_100_PILOT = "holding_Life_100_Pilot";
	public static final String RATING_ENGINE_EFFECTIVE_DATE = "ratingEngineEffectiveDate";
	public static final String RATING_ENGINE_EFFECTIVE_DATETIME = "ratingEngineEffectiveDateTime";
	public static final String HOLDING_OLQUOTED = "OLQuoted";
	public static final String PLAN_LOOP_1 = "Plan_Loop_1";
	public static final String HOLDING_COMPOSITE_COUNTER_STEP_2 = "holding_Composite_Counter_Step_2";
	public static final String HOLDING_FLAT_PLANS_COUNT = "holding_Flat_Plans_Count";
	public static final String HOLDING_TOTAL_NUMBER_OF_BL_FLAT_AMT_PLANS = "holding_Total_Number_Of_BL_Flat_Amt_Plans";
	public static final String HOLDING_MULTIPLE_PLANS_COUNT = "holding_Multiple_Plans_Count";
	public static final String HOLDING_OTHER_PLANS_COUNT = "holding_Other_Plans_Count";
	public static final String HOLDING_SET_PLANS_TYPE = "holding_Set_Plans_Type";
	public static final String HOLDING_FLAT_PLANS_ONLY = "holding_Flat_Plans_Only";
	public static final String HOLDING_MULTIPLE_PLANS_ONLY = "holding_Multiple_Plans_Only";
	public static final String HOLDING_OTHER_PLANS = "holding_Other_Plans";
	public static final String DENTAL_QUOTED = "DentalQuoted";
	public static final String LDSM_PILOT_REP = "LDSM_Pilot_Rep";
	public static final String PRU_VALUE = "PruValue";
	public static final String RENEWAL_CRLP = "Renewal_CRLP";
	public static final String HOLDING_RENEWAL_MONTHLY_CRLP = "holding_Renewal_Monthly_CRLP";
	public static final String HOLDING_COMPSYCH_RATE = "holding_Compsych_Rate";
	public static final String HOLDING_RETIREE_COVERED_VOLUME = "holding_Retiree_Covered_Volume";
	public static final String HOLDING_RATIO_RETIREE_TO_TOTAL_VOLUME = "holding_Ratio_Retiree_to_Total_Volume";
	public static final String HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_INVERSE = "holding_Total_Covered_Volume_For_All_Plans__Inverse";
	public static final String HOLDING_COMPOSITE_FEMALE_PCT_IGNORING_COMPOSITE_SETTING = "holding_Composite_Female_Pct_Ignoring_Composite_Setting";
	public static final String HOLDING_COMPOSITE_MINIMUM_PREMIUM_STEP_1 = "holding_Composite_Minimum_Premium_Step_1";
	public static final String HOLDING_COMPOSITE_MINIMUM_PREMIUM = "holding_Composite_Minimum_Premium";
	public static final String HOLDING_AVERAGE_SALARY_FACTOR_STEP_2 = "holding_Average_Salary_Factor_Step_2";
	public static final String HOLDING_ADD_QUOTED = "holding_ADDQuoted";
	public static final String HOLDING_QL_QUOTED = "holding_QLQuoted";
	public static final String HOLDING_SALES_OFFICE = "holding_SalesOffice";
	
	public static final String HOLDING_RATIO_RETIREE_TO_TOTAL_LIVES = "holding_Ratio_Retiree_to_Total_Lives";
	public static final String HOLDING_CLIENT_POOLING_POINT_STEP_2 = "holding_Client_Pooling_Point__Step_2";
    public static final String HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING  = "holding_Total_Annual_Premium_for_Reporting";

    public static final String HOLDING_TOTAL_MONTHLY_PREMIUM = "holding_Total_Monthly_Premium";

	public static final String HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY = "holding_Total_Lives_For_All_Plans__Composite_Only";
	public static final String HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY = "holding_Total_Estimated_Volume_Composite_Only";
	public static final String HOLDING_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY = "holding_Monthly_Premium_For_All_Plans__Composite_Only";
	public static final String HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMP_ONLY__INVERSE = "holding_Total_Covered_Volume_For_All_Plans_Comp_Only__Inverse";

	public static final String HOLDING_COMPOSITE_MINIMUM_RATE_RATIO = "holding_Composite_Minimum_Rate_Ratio";

	public static final String HOLDING_SUM_RENEWAL_PREM_AGEBANDED_ALL_PLANS = "holding_Sum_Renewal_Prem_AgeBanded_All_Plans";
	public static final String HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS = "holding_Sum_Renewal_Prem_NonAgeBanded_All_Plans";
	public static final String HOLDING_INITIAL_INFORCE_PREMIUM = "holding_Initial_Inforce_Premium";
	public static final String HOLDING_COMPOSITE_MALE_PCT_IGNORING_COMPOSITE_SETTING = "holding_Composite_Male_Pct_Ignoring_Composite_Setting";
	public static final String HOLDING_TOTAL_NO_OF_PLANS = "holding_Total_Number_Of_Plans";
	public static final String HOLDING_RATE_ACTION_MAX_STEP_2 = "holding_Rate_Action_Max_Step_2";
	public static final String HOLDING_INITIAL_MANUAL_PREMIUM = "holding_Initial_Manual_Premium";
	public static final String HOLDING_INFORCE_TO_MANUAL_PREM_RATIO = "holding_Inforce_to_Manual_Prem_Ratio";
	public static final String HOLDING_SUM_MANUAL_PREM_AGEBANDED_ALL_PLANS = "holding_Sum_Manual_Prem_AgeBanded_All_Plans";
	public static final String HOLDING_SUM_MANUAL_PREM_NONAGEBANDED_ALL_PLANS = "holding_Sum_Manual_Prem_NonAgeBanded_All_Plans";
	public static final String HOLDING_SUM_INFORCE_PREM_AGEBANDED_ALL_PLANS = "holding_Sum_Inforce_Prem_AgeBanded_All_Plans";
	public static final String HOLDING_SUM_INFORCE_PREM_NONAGEBANDED_ALL_PLANS = "holding_Sum_Inforce_Prem_NonAgeBanded_All_Plans";
	public static final String HOLDING_AGE_BANDED_COUNTER_STEP_2  = "holding_Age_Banded_Counter_Step_2";
	public static final String SUM_AVG_PEOPLE_AVERAGE_SALARY_FACTOR_STEP_1 = RuleRatingConstants.ADD_OPERATOR_KEY + PlanConstants.AVG_PEOPLE_AVERAGE_SALARY_FACTOR_STEP_1;
	
	public static final String PRU_VALUE_YES = "PruValueYes";
	public static final String PRU_VALUE_NO = "PruValueNo";
	public static final String PROPOSALCREATIONDATE = "proposalCreationDate";
	public static final String PROPOSALCREATIONDATE_TIMESTAMP = "proposalCreationDate_Timestamp";
	
	public static final String STATUS_OTHER_POOLED_ADJUSTMENT = "status_Other_Pooled_Adjustment";
	public static final String STATUS_OTHER_NON_POOLED_ADJUSTMENT = "status_Other_Non_Pooled_Adjustment";

	public static final Date POOLED_ADJUSTMENT_EFFECTIVEDATE1_START_DATE;
	public static final Date POOLED_ADJUSTMENT_EFFECTIVEDATE1_END_DATE;
	public static final Date POOLED_ADJUSTMENT_EFFECTIVEDATE2_START_DATE;
	public static final Date NON_POOLED_ADJUSTMENT_EFFECTIVEDATE1_START_DATE;
	public static final Date NON_POOLED_ADJUSTMENT_EFFECTIVEDATE1_END_DATE;
	public static final Date NON_POOLED_ADJUSTMENT_EFFECTIVEDATE2_START_DATE;
	public static final Date NON_POOLED_ADJUSTMENT_EFFECTIVEDATE2_END_DATE;
	public static final Date NON_POOLED_ADJUSTMENT_EFFECTIVEDATE3_START_DATE;
	public static final String HOLDING_TOTAL_ANNUAL_PREM_ALL_PLANS = "holding_Total_Annual_Prem_All_Plans";
	public static final String HOLDING_TOTAL_MONTHLY_PREM_ALL_PLANS = "holding_Total_Monthly_Prem_All_Plans";

	public static final String HOLDING_OVERRIDE_75000_PREMIUM_POSTCALC = "holding_Override_75000_Premium_Postcalc";
	public static final String HOLDING_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC  = "holding_Total_BL_Manual_Premium_for_Postcalc";
	public static final String HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING  = "holding_Competitive_Window_for_Reporting";
	public static final String HOLDING_MAXIMUM_EXHIBIT_VOLUME  = "holding_Maximum_Exhibit_Volume";
	public static final String HOLDING_MAXIMUM_EXHIBIT_PREMIUM  = "holding_Maximum_Exhibit_Premium";
	public static final String HOLDING_MAXIMUM_EXHIBIT_LIVES  = "holding_Maximum_Exhibit_Lives";
	public static final String HOLDING_CLAIMS_EXPERIENCE_FOR_REPORTING  = "holding_Claims_Experience_for_Reporting";
	public static final String HOLDING_REGIONAL_VP_ADJUSTMENT_RATIO_AVERAGE  = "holding_Regional_VP_Adjustment_Ratio_Average";
	public static final String HOLDING_UW_ADJUSTMENT_BOX_2_RATIO_AVERAGE  = "holding_UW_Adjustment_Box_2_Ratio_Average";
	public static final String HOLDING_FINAL_UW_ADJUSTMENT_RATIO_AVERAGE  = "holding_Final_UW_Adjustment_Ratio_Average";
	public static final String HOLDING_RENEWAL_PREMIUM = "holding_Renewal_Premium";
	public static final String HOLDING_COMPOSITE_PRELIMINARY_RATE_STEP2 = "holding_Composite_Preliminary_Rate__Step2";
	public static final String HOLDING_COMPOSITE_TABLEI_STEP2 = "holding_Composite_TableI__Step2";
	public static final String HOLDING_TOTAL_CROSS_TABLE_STEP_1 = "holding_Total_Cross_TableI_Step_1";
	public static final String HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_5  = "holding_Renewal_UW_Override_Percent_of_Manual_Step_5";
	public static final String HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_6  = "holding_Renewal_UW_Override_Percent_of_Manual_Step_6";
	public static final String HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_7  = "holding_Renewal_UW_Override_Percent_of_Manual_Step_7";
	public static final String HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_8  = "holding_Renewal_UW_Override_Percent_of_Manual_Step_8";	
	public static final String PLAN_LOOP_7B_RENEWAL_OUT = "Plan_Loop_7b_Renewal_Out";
	public static final String HOLDING_FINAL_PREMIUM_OVERRIDE_STEP_3 = "holding_Final_Premium_Override_Step_3";
	public static final String HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_2 = "holding_Renewal_Inforce_Premium_Step_2";
	public static final String HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_3 = "holding_Renewal_Inforce_Premium_Step_3";
	public static final String HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_4 = "holding_Renewal_Inforce_Premium_Step_4";
	public static final String HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_5 = "holding_Renewal_Inforce_Premium_Step_5";
	public static final String HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_6 = "holding_Renewal_Inforce_Premium_Step_6";
	public static final String HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_7 = "holding_Renewal_Inforce_Premium_Step_7";
	public static final String HOLDING_RENEWAL_MANUAL_RATE_STEP_1 = "holding_Renewal_Manual_Rate_Step_1";

	public static final String HOLDING_TOTAL_ESTIMATED_VOLUME_FOR_REPORTING_1 = "holding_Total_Estimated_Volume_for_Reporting_1";
	public static final String HOLDING_TOTAL_ESTIMATED_VOLUME_FOR_REPORTING = "holding_Total_Estimated_Volume_for_Reporting";
	public static final String HOLDING_TOTAL_LIVES_FOR_REPORTING_NON_COMPOSITE = "holding_Total_Lives_For_Reporting_Non_Composite";
	public static final String HOLDING_TOTAL_VOLUME_FOR_REPORTING_NON_COMPOSITE = "holding_Total_Volume_For_Reporting_Non_Composite";

	
	public static final String HOLDING_RATE_ACTION_MAX_STEP_1 = "holding_Rate_Action_Max_Step_1";

	public static final String HOLDING_RENEWAL_MANUAL_RATE  = "holding_Renewal_Manual_Rate";
	public static final String HOLDING_RENEWAL_UW_ADJUSTED_AGE_BANDED_PREMIUM  = "holding_Renewal_UW_Adjusted_Age_Banded_Premium";
	public static final String HOLDING_TOTAL_ELIGIBLE_LIVES_FOR_REPORTING  = "holding_Total_Eligible_Lives_for_Reporting";
	public static final String HOLDING_EXPERIENCE_TIMES_CLAIMS_FOR_REPORTING  = "holding_Experience_Times_Claims_for_Reporting";
	public static final String HOLDING_RENEWAL_PRODUCTION_SUM_NON_AGE_BANDED  = "holding_Renewal_Production_Sum_Non_Age_Banded";
	public static final String HOLDING_RENEWAL_PRODUCTION_SUM_AGE_BANDED_PREMIUM  = "holding_Renewal_Production_Sum_Age_Banded_Premium";
	public static final String HOLDING_RENEWAL_PRODUCTION_SUM_INFORCE_NON_AGE_BANDED  = "holding_Renewal_Production_Sum_Inforce_Non_Age_Banded";
	public static final String HOLDING_RENEWAL_PRODUCTION_SUM_INFORCE_AGE_BANDED  = "holding_Renewal_Production_Sum_Inforce_Age_Banded";
	public static final String HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING_STEP_1  = "holding_Total_Annual_Premium_for_Reporting_Step_1";
	public static final String HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING_STEP_2  = "holding_Total_Annual_Premium_for_Reporting_Step_2";
	public static final String HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING_STEP_3  = "holding_Total_Annual_Premium_for_Reporting_Step_3";
	public static final String HOLDING_RENEWAL_PLAN_CHANGE_STEP_2  = "holding_Renewal_Plan_Change_Step_2";
	public static final String PLAN_LOOP_7 = "Plan_Loop_7";
	public static final String PLAN_LOOP_RATE_DISK_TOTAL = "plan_Rate_Disk_Total_Monthly_Prem";
	public static final String HOLDING_MONTHLY_PREMIUM = "holding_Monthly_Premium";
	public static final String HOLDING_NON_POOLED_MONTHLY_PREMIUM = "holding_Non_Pooled_Monthly_Premium";
	public static final String HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMPOSITE_ONLY = "holding_Total_Covered_Volume_For_All_Plans__Composite_Only";
	public static final String HOLDING_TOTAL_ANNUAL_PREMIUM = "holding_Total_Annual_Premium";
	public static final String GET_COVEREDVOLUMEFORALLCOMPONLYPLANS_ZERO = "getCoveredVolumeForAllCompOnlyPlans_Zero";
	public static final String GETONE_GETCOVEREDVOLUMEFORALLCOMPONLYPLANS_NONZERO="getOne_getCoveredVolumeForAllCompOnlyPlans_NonZero";
	public static final String GET_COVEREDVOLUMEFORALLCOMPONLYPLANS_NONZERO = "getCoveredVolumeForAllCompOnlyPlans_NonZero";
	public static final String HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS_COMPOSITE_ONLY_INVERSE = "holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse";
	public static final String HOLDING_BLENDED_AREA_FACTOR_STEP_3 = "holding_Blended_Area_Factor_Step_3";
	public static final String HOLDING_BLENDED_AREA_FACTOR_STEP_2 = "holding_Blended_Area_Factor_Step_2";
	public static final String HOLDING_BLENDED_RATE_GUARANTEE_FACTOR_STEP_2 = "holding_Blended_Rate_Guarantee_Factor_Step_2";
	public static final String HOLDING_BLENDED_RATE_GUARANTEE_FACTOR_STEP_3 = "holding_Blended_Rate_Guarantee_Factor_Step_3";
	public static final String CENSUS_MODIFICATION_DATE = "Census_Modification_Date";
	public static final String HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_INVERSE = "holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse";

	public static final String HOLDING_REGIONAL_VP_ADJUSTMENT_RATIO_SUM  = "holding_Regional_VP_Adjustment_Ratio_Sum";
	public static final String HOLDING_UW_ADJUSTMENT_BOX_2_RATIO_SUM  = "holding_UW_Adjustment_Box_2_Ratio_Sum";

	public static final String HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING__STEP_2  = "holding_Competitive_Window_for_Reporting__Step_2";

	public static final String HOLDING_RETIREE_LIVES = "holding_Retiree_Lives";
	public static final String HOLDING_FINAL_UW_ADJUSTMENT_RATIO_SUM  = "holding_Final_UW_Adjustment_Ratio_Sum";
	public static final String HOLDING_NON_POOLED_MANUAL_RATE_STEP_2 = "holding_Non_Pooled_Manual_Rate_Step_2";
	

	static {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		try {
			POOLED_ADJUSTMENT_EFFECTIVEDATE1_START_DATE = sdf
					.parse("01/01/1990");
			POOLED_ADJUSTMENT_EFFECTIVEDATE1_END_DATE = sdf.parse("09/24/2001");
			POOLED_ADJUSTMENT_EFFECTIVEDATE2_START_DATE = sdf
					.parse("09/24/2001");
			NON_POOLED_ADJUSTMENT_EFFECTIVEDATE1_START_DATE = sdf
					.parse("01/01/1990");
			NON_POOLED_ADJUSTMENT_EFFECTIVEDATE1_END_DATE = sdf
					.parse("09/24/2001");
			NON_POOLED_ADJUSTMENT_EFFECTIVEDATE2_START_DATE = sdf
					.parse("09/24/2001");
			NON_POOLED_ADJUSTMENT_EFFECTIVEDATE2_END_DATE = sdf
					.parse("01/01/2002");
			NON_POOLED_ADJUSTMENT_EFFECTIVEDATE3_START_DATE = sdf
					.parse("01/01/2002");
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}

}
