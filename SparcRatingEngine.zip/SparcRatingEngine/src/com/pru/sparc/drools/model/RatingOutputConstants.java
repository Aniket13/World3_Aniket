package com.pru.sparc.drools.model;

import java.util.LinkedHashMap;
import java.util.Map;

@SuppressWarnings("serial")
public final class RatingOutputConstants {
	
	public static final Map<String,String> OVERRIDEN_KEYS = new LinkedHashMap<String,String>() {
		{
			put("Acknowledgement of High Premium Discount Field",PlanConstants.PLAN_OVERRIDE_75000_POSTCALC_STEP_1);
			put("Field Adjustment",PlanConstants.PLAN_FIELD_ADJUSTMENT_OVERRIDE);
			put("Compsych Rate Override",PlanConstants.PLAN_COMPSYCH_RATE);
			put("Regional VP Adjustment Original Rate",	PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_ORIGINAL_RATE);
			put("Regional VP Adjustment Desired Rate",	PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_DESIRED_RATE);
			put("Advocate Adjustment Original Rate",	PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE);
			put("Advocate Adjustment Desired Rate",	PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_ORIGNAL_RATE);
			put("Final Underwriter Adjustment Original Rate", PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_ORIGNAL_RATE);
			put("Final Underwriter Adjustment Desired Rate", PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_DESIRED_RATE);
			put("Proposal Exhibit Lives",	HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS);
			put("Proposal Exhibit Volume",	HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS);
			put("Renewal Rate Action Override",	PlanConstants.PLAN_RENEWAL_RATE_ACTION);	
			put("Coverage Level Pooling Point", PlanConstants.PLAN_POOLING_POINT);
			put("Coverage Level Tabular Non-Medical Maximum", PlanConstants.PLAN_NON_MEDICAL_MAX);
			put("Industry Adjustment",	StatusConstants.STATUS_INDUSTRY_ADJUSTMENT);
			put("Dental Factor", StatusConstants.STATUS_DENTAL_DISCOUNT);
			put("Area Factor", 	StatusConstants.STATUS_AREA_FACTOR);
			put("Salary Adjustment Factor",	StatusConstants.STATUS_AVERAGE_SALARY_FACTOR);
			put("Waiver of premium SIC Adjustment",	StatusConstants.STATUS_WAIVER_OF_PREMIUM_ADJUSTMENT);
			put("PruValue Discount Factor/Non-PruValue Other Non-Pooled Adjustment",StatusConstants.STATUS_OTHER_NON_POOLED_ADJUSTMENT);
			put("PruValue Discount Factor/Non-PruValue Other Pooled Adjustment", StatusConstants.STATUS_OTHER_POOLED_ADJUSTMENT);
			put("Expected Annual Claim Experience",	PlanConstants.PLAN_EXPECTED_ANNUAL_CLAIMS_EXPERIENCE);
			put("Credibility",	PlanConstants.PLAN_CREDIBILITY);
			put("Margin", PlanConstants.PLAN_MARGIN);
			put("Rate Filing Profit",PlanConstants.PLAN_RATE_FILING_PROFIT);
			put("Maximum Allowable Commissions", PlanConstants.PLAN_MAX_ALLOWABLE_COMMISSIONS);
			put("Additional Administration Factor", PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION);
		}
	};
	
	
    public static final String BL_TABLE_COMPETITIVE_WINDOW_GROUP = "BLTableCompetitiveWindow";
	public static final Map<String,String> BL_TABLE_COMPETITIVE_WINDOW = new LinkedHashMap<String,String>() {
		{
			put("Acknowledgement of High Premium Discount Field",PlanConstants.PLAN_OVERRIDE_75000_POSTCALC_STEP_1);
			put("Field Adjustment",PlanConstants.PLAN_FIELD_ADJUSTMENT_OVERRIDE);
		}
	};
	
    public static final String BL_TABLE_UW_ADJUSTMENT_BOX_GROUP = "BLTableUWAdjustmentBox";
	public static final Map<String,String> BL_TABLE_UW_ADJUSTMENT_BOX = new LinkedHashMap<String,String>() {
		{
			put("Compsych Rate Override",PlanConstants.PLAN_COMPSYCH_RATE);
			put("Regional VP Adjustment Original Rate",PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_ORIGINAL_RATE);
			put("Regional VP Adjustment Desired Rate",PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_DESIRED_RATE);
			put("Advocate Adjustment Original Rate",PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE);
			put("Advocate Adjustment Desired Rate",PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_ORIGNAL_RATE);
			put("Final Underwriter Adjustment Original Rate",PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_ORIGNAL_RATE);
			put("Final Underwriter Adjustment Desired Rate",PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_DESIRED_RATE);
			put("Proposal Exhibit Lives",HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS);
			put("Proposal Exhibit Volume",HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS);
			put("Proposal Exhibit Rate",PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES);
			put("Proposal Exhibit Premium",PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM);
			put("Guarantee Issue Amount",PlanConstants.PLAN_BL_EXHIBIT_NON_MED_MAX);
			put("Estimated Lives for BL",HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS);
			put("Estimated Volume for BL",HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS);
			put("Monthly Rates for BL",PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES);
			put("Monthly Premium for BL",PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM);
			put("Commission Percentage",PlanConstants.PLAN_COMMISSION_PERCENTAGE);
			put("Total Annual Premium for BL",PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM);	
		}
	};
	
    public static final String BL_RENEWAL_TABLE_GROUP = "BL_Renewal_Table";
	public static final Map<String,String> BL_RENEWAL_TABLE = new LinkedHashMap<String,String>() {
		{
			put("Renewal Rate Action Override",PlanConstants.PLAN_RENEWAL_RATE_ACTION);
			put("Renewal Final Rate Action",PlanConstants.PLAN_FINALRATE_ACTION_OUT);
			put("Inforce Volume",HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS);
			put("Renewal Manual Rate",PlanConstants.PLAN_RENEWAL_MANUAL_RATE);
			put("Renewal RAT Table",PlanConstants.PLAN_RATE_ACTION_TABLE_OUT);
			put("Plan Payable Rate",PlanConstants.PLAN_PAYABLE_RATE);
			put("Plan Minimum Payable Rate",PlanConstants.PLAN_PAYABLE_RATE_STEP_3);
			put("Annual Plan Premium",PlanConstants.PLAN_ANNUAL_PREMIUM);
			put("Plan Total Lives",PlanConstants.SUM_PEOPLE_LIFE_COUNT);
			put("Average Age",PlanConstants.PLAN_AVERAGE_AGE);
			put("Average Annual Salary",PlanConstants.PLAN_AVERAGE_ANNUAL_SALARY);
			put("Maximum Coverage Amount",PlanConstants.PLAN_HIGHEST_COVERAGE_AMOUNT);
			put("Percentage Female",HoldingConstants.HOLDING_COMPOSITE_FEMALE_PCT_IGNORING_COMPOSITE_SETTING);
			put("Commission Percentage",PlanConstants.PLAN_COMMISSION_PERCENTAGE);
			
		}
	};
	
	public static final String BL_TABLE_L_GROUP = "BLTableL";
	//public static final String PROPOSAL_EXHIBIT_LIVES = PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES;
	public static final String PROPOSAL_EXHIBIT_LIVES = HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS;
	//public static final String PROPOSAL_EXHIBIT_VOLUME = PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME;
	public static final String PROPOSAL_EXHIBIT_VOLUME = HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS;
	public static final String PROPOSAL_EXHIBIT_RATE = PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES;
	public static final String PROPOSAL_EXHIBIT_PREMIUM = "plan_BL_Exhibit_Monthly_Premium";
	public static final String COMPOSITE_RATE = PlanConstants.PLAN_COMPOSITE_RATE;
	public static final String ESTIMATED_LIVES = PlanConstants.SUM_PEOPLE_LIFE_COUNT;
	public static final String ESTIMATED_LIVES_FOR_ALL_PLANS_COMPOSITE_ONLY = PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY;
	public static final String ESTIMATED_VOLUME = PlanConstants.PLAN_ESTIMATED_VOLUME;
	public static final String ESTIMATED_VOLUME_FOR_ALL_PLANS_COMPOSITE_ONLY = PlanConstants.PLAN_TOTAL_ESTIMATED_VOLUME__COMPOSITE_ONLY;
	public static final String MONHTLY_RATES = PlanConstants.PLAN_PAYABLE_RATE;
	public static final String MANUAL_RATE  = PlanConstants.PLAN_COMPOSITE_RATE;
	public static final String MONTHLY_PREMIUM = PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY;//"SUM_Monthly_Non_Pooled_Premium";//
	public static final String MONTHLY_PREMIUM_FOR_ALL_PLANS_COMPOSITE_ONLY = PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY;

	public static final String AGEBRACKET_FINAL_RATE_GROUP = "ageBracketFinalRateTableList";
	
	public static final String BL_TABLE_K_GROUP = "BLTableK";
	public static final String AGEBRACKET_TOTAL_LIVES = "SUM_people_life_count";//AgeBracketConstants.AGEBRACKET_TOTAL_LIVES;
	//public static final String AGEBRACKET_TOTAL_COVERED_VOLUME = AgeBracketConstants.AGEBRACKET_TOTAL_COVERED_VOLUME;//SUM_people_Covered_Volume
	public static final String AGEBRACKET_TOTAL_COVERED_VOLUME = "SUM_people_Covered_Volume";
	public static final String AGEBRACKET_PRELIMINARY_RATE = AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE;
	public static final String AGEBRACKET_TABLEIRATE = AgeBracketConstants.AGEBRACKET_TABLEIRATE;
	public static final String AGEBRACKET_CROSSTABLEI = AgeBracketConstants.AGEBRACKET_CROSSTABLEI;
	public static final String AGEBRACKET_PRELIMINARY_RATE_ADJUSTED_FOR_TABLEI_CALC = AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_ADJUSTED_FOR_TABLEI_CALC;
	public static final String AGEBRACKET_FINAL_RATE = AgeBracketConstants.AGEBRACKET_FINAL_RATE; 
	
	public static final String BL_TABLE_C_GROUP = "BLTableC";
	public static final Map<String,String> BL_TABLE_C = new LinkedHashMap<String,String>() {
		{	
			put("Plan Total Covered Volume","SUM_people_Covered_Volume");
			put("Coverage Level Pooling Point",PlanConstants.PLAN_POOLING_POINT);
			put("Plan Average Certificate",PlanConstants.PLAN_AVERAGE_CERTIFICATE);
			put("Coverage Level Client pooling Point", PlanConstants.PLAN_CLIENT_POOLING_POINT);
			put("Coverage Level Tabular Non-Medical Maximum",PlanConstants.PLAN_NON_MEDICAL_MAX);
			put("Plan Level Requested Guarantee Non-Medical Limit",PlanConstants.PLAN_GUARANTEE_ISSUE);
		}
	};
	
	public static final String BL_TABLE_F_GROUP = "BLTableF";
	public static final String AGEBRACKET_TOTAL_LIVES_BY_GENDER_STATUS_AGEBRACKET = AgeBracketConstants.AGEBRACKET_TOTAL_LIVES_BY_GENDER_STATUS_AGEBRACKET;
	public static final String AGEBRACKET_COVERED_VOLUME_BY_GENDER_STATUS_AGEBRACKET = AgeBracketConstants.AGEBRACKET_COVERED_VOLUME_BY_GENDER_STATUS_AGEBRACKET;
	public static final String AGEBRACKET_NON_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET = AgeBracketConstants.AGEBRACKET_NON_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET;
	public static final String AGEBRACKET_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET = AgeBracketConstants.AGEBRACKET_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET;
	public static final String AGEBRACKET_NON_POOLED_MANUAL_RATE = AgeBracketConstants.AGEBRACKET_NON_POOLED_MANUAL_RATE;
	public static final String AGEBRACKET_POOLED_MANUAL_RATE = AgeBracketConstants.AGEBRACKET_POOLED_MANUAL_RATE;
	
	
	public static final String BL_TABLE_G_GROUP = "BLTableG";
	public static final Map<String,String> BL_TABLE_G = new LinkedHashMap<String,String>() {
		{	
			put("Initial Base Claim Cost / Non-Pooled Annual Manual Premium", "SUM_Annual_Non_Pooled_Premium");
			put("Total Non-Pooled Volume", "SUM_people_Non_Pooled_Volume");
			put("Initial Base Claim Cost Rate / Non-Pooled Manual Rate Monthly", StatusConstants.STATUS_NON_POOLED_MANUAL_RATE);
			put("Initial Base Claim Cost High Cab / Pooled Annual Manual Premium", StatusConstants.STATUS_POOLED_ANNUAL_MANUAL_PREMIUM); 
			put("Total Pooled Volume", StatusConstants.STATUS_POOLED_VOLUME);
			put("Initial Base Claim Cost Rate High Cab / Pooled Manual Rate Monthly", StatusConstants.STATUS_POOLED_MANUAL_RATE);
			put("Effective Date Difference", StatusConstants.STATUS_EFFECTIVE_DATE_ADJUSTMENT_DIFFERENCE);
			put("Effective Date Adjustment", StatusConstants.STATUS_EFFECTIVE_DATE_ADJUSTMENT);
			put("Industry Adjustment", StatusConstants.STATUS_INDUSTRY_ADJUSTMENT);
			put("Dental Factor", StatusConstants.STATUS_DENTAL_DISCOUNT);
			put("Area Factor", StatusConstants.STATUS_AREA_FACTOR);
			put("Salary Adjustment Factor", StatusConstants.STATUS_AVERAGE_SALARY_FACTOR );
			put("Rate Guarantee Adjustment", StatusConstants.STATUS_RATE_GUARANTEE);
			put("Optional Life Adjustment", StatusConstants.STATUS_OPTIONAL_LIFE_ADJUSTMENT);
			put("AD_D Discount", StatusConstants.STATUS_ADD_DISCOUNT);
			put("Disability Product Discount", StatusConstants.STATUS_DISABILITY_PRODUCT_DISCOUNT);
			put("Life Plan Adjustment", StatusConstants.STATUS_LIFE_PLAN_ADJUSTMENT);
			put("Living Benefit Option Adjustment", StatusConstants.STATUS_LIVING_BENEFIT_OPTION_ADJUSTMENT);
			put("Waiver of Premium", StatusConstants.STATUS_WAIVER_OF_PREMIUM);
			put("Waiver of premium SIC Adjustment", StatusConstants.STATUS_WAIVER_OF_PREMIUM_ADJUSTMENT);
			put("Conversion Adjustment", StatusConstants.STATUS_CONVERSION_ADJUSTMENT);
			put("PruValue Discount Factor/Non-PruValue Other Non-Pooled Adjustment", StatusConstants.STATUS_OTHER_NON_POOLED_ADJUSTMENT);
			put("Non-Pooled Adjusted Annual Manual Premium", StatusConstants.STATUS_NON_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM);
			put("PruValue Discount Factor/Non-PruValue Other Pooled Adjustment", StatusConstants.STATUS_OTHER_POOLED_ADJUSTMENT);
			put("Pooled Adjusted Annual Manual Premium", StatusConstants.STATUS_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM);
			put("Non-Pooled CAB", StatusConstants.STATUS_NON_POOLED_CAB);
			put("Pooled CAB", StatusConstants.STATUS_POOLED_CAB);
			put("Non-Pooled Annual Expected Claims", StatusConstants.STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIMS);
			put("Non-Pooled Monthly Expected Claim Rate", StatusConstants.STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIM_RATE);
			put("Pooled Annual Expected Claims", StatusConstants.STATUS_POOLED_ANNUAL_EXPECTED_CLAIMS);
			put("Pooled Monthly Expected Claim Rate", StatusConstants.STATUS_POOLED_ANNUAL_EXPECTED_CLAIM_RATE);
		}
	};
	
	 
	public static final String BL_TABLE_H_GROUP = "BLTableH";
	public static final Map<String,String> BL_TABLE_H = new LinkedHashMap<String,String>() {
		{	
			put("Product Lives and Office Discount",PlanConstants.PLAN_PRODUCT_LIVES_SALES_OFFICE_DISCOUNT);
			put("Manual Claims Cost / Composite Annual Expected Claims",PlanConstants.PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIMS);
			put("Manual Claims Cost Rate / Composite Monthly Expected Claim RateMonthly Expected Claim Rate",PlanConstants.PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIM_RATE);
			put("Expected Annual Claim Experience",PlanConstants.PLAN_EXPECTED_ANNUAL_CLAIMS_EXPERIENCE);
			put("Credibility", PlanConstants.PLAN_CREDIBILITY);
			put("Blended Expected Claims", PlanConstants.PLAN_BLENDED_EXPECTED_CLAIMS);
			put("Margin", PlanConstants.PLAN_MARGIN);
			put("Adjusted Claim Cost / Plan Level Total Benefit Charges", PlanConstants.PLAN_TOTAL_BENEFIT_CHARGES);
			put("Adjusted Claim Cost Rate / Blended Plan Level Claim Rate" , PlanConstants.PLAN_BLENDED_CLAIM_RATE);
		}
	};
		
	public static final String BL_TABLE_I_GROUP = "BLTableI";	
	public static final Map<String,String> BL_TABLE_I = new LinkedHashMap<String,String>() {
		{
			put("PV Total Ben Charges All Life / NonPV Total Ben Charge Coverage", PlanConstants.PLAN_BENEFIT_CHARGES_FOR_ALL_PLANS);
			put("PV Total Est Ann Prem All Life / NonPV Est Ann Prem Coverage",PlanConstants.PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS);
			put("Premium Tax Factor", PlanConstants.PLAN_PREMIUM_TAX_FACTOR); 
			put("Rate Filing Expenses", PlanConstants.PLAN_RATE_FILING_EXPENSES);
			put("Rate Filing Profit", PlanConstants.PLAN_RATE_FILING_PROFIT);
			put("Level Scale Commissions", PlanConstants.PLAN_LEVEL_SCALE_COMMISSIONS);
			put("Additional Service Commissions", PlanConstants.PLAN_ADDITIONAL_SERVICE_COMMISSIONS);
			put("Requested Commission", PlanConstants.PLAN_REQUESTED_COMMISSION);
			put("Maximum Allowable Commissions", PlanConstants.PLAN_MAX_ALLOWABLE_COMMISSIONS);
			put("Commission Percentage", PlanConstants.PLAN_COMMISSION_PERCENTAGE);
			put("Additional Administration Factor", PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION);
			put("Travel Assistance Factor", PlanConstants.PLAN_TRAVEL_ASSIST_ADJUSTMENT);
			put("Manual Retention % / Adjusted Retention %",PlanConstants.PLAN_TOTAL_RETENTION);
		}
	};
	
	
	
	public static final String BL_REPORT_TABLE_GROUP = "BLReportTable";	
	public static final Map<String,String> BL_REPORT_TABLE = new LinkedHashMap<String,String>() {
		{
			put("Competative Window for Reporting",PlanConstants.PLAN_COMPETITIVE_WINDOW_FOR_REPORTING);
			put("Total Annual Premium for Reporting", PlanConstants.PLAN_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING);
		}
	};
}
