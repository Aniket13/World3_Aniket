package com.pru.sparc.drools.model;

public class RuleGrp {

}
