package com.pru.sparc.drools.model;

import java.util.List;

public class RatingBean {
		private List<AcknowledgeGrp> acknowledgeGrp;
		private List<PropExhibitGrp> propExhibitGrp;
		private List<RenewalGrp> renewalGrp;
		private List<CensusGrp> censusGrp;
		private List<CensusCompGrp> censusCompGrp;
		private List<CensusCompOverGrp> censusCompOverGrp;
		private List<CoverageGrp> coverageGrp;
		private List<CoverageCompGrp> coverageCompGrp;
		private List<StatusGrp> statusGrp;
		private List<ReportingGrp> reportingGrp;
		private List<RuleGrp> ruleGrp;
		
		
		public List<CensusCompOverGrp> getCensusCompOverGrp() {
			return censusCompOverGrp;
		}
		public void setCensusCompOverGrp(List<CensusCompOverGrp> censusCompOverGrp) {
			this.censusCompOverGrp = censusCompOverGrp;
		}
		public List<CoverageGrp> getCoverageGrp() {
			return coverageGrp;
		}
		public void setCoverageGrp(List<CoverageGrp> coverageGrp) {
			this.coverageGrp = coverageGrp;
		}
		public List<CoverageCompGrp> getCoverageCompGrp() {
			return coverageCompGrp;
		}
		public void setCoverageCompGrp(List<CoverageCompGrp> coverageCompGrp) {
			this.coverageCompGrp = coverageCompGrp;
		}
		public List<StatusGrp> getStatusGrp() {
			return statusGrp;
		}
		public void setStatusGrp(List<StatusGrp> statusGrp) {
			this.statusGrp = statusGrp;
		}
		public List<ReportingGrp> getReportingGrp() {
			return reportingGrp;
		}
		public void setReportingGrp(List<ReportingGrp> reportingGrp) {
			this.reportingGrp = reportingGrp;
		}
		public List<RuleGrp> getRuleGrp() {
			return ruleGrp;
		}
		public void setRuleGrp(List<RuleGrp> ruleGrp) {
			this.ruleGrp = ruleGrp;
		}
		public List<AcknowledgeGrp> getAcknowledgeGrp() {
			return acknowledgeGrp;
		}
		public void setAcknowledgeGrp(List<AcknowledgeGrp> acknowledgeGrp) {
			this.acknowledgeGrp = acknowledgeGrp;
		}
		public List<PropExhibitGrp> getPropExhibitGrp() {
			return propExhibitGrp;
		}
		public void setPropExhibitGrp(List<PropExhibitGrp> propExhibitGrp) {
			this.propExhibitGrp = propExhibitGrp;
		}
		public List<RenewalGrp> getRenewalGrp() {
			return renewalGrp;
		}
		public void setRenewalGrp(List<RenewalGrp> renewalGrp) {
			this.renewalGrp = renewalGrp;
		}
		public List<CensusGrp> getCensusGrp() {
			return censusGrp;
		}
		public void setCensusGrp(List<CensusGrp> censusGrp) {
			this.censusGrp = censusGrp;
		}
		public List<CensusCompGrp> getCensusCompGrp() {
			return censusCompGrp;
		}
		public void setCensusCompGrp(List<CensusCompGrp> censusCompGrp) {
			this.censusCompGrp = censusCompGrp;
		}
		
		
}
