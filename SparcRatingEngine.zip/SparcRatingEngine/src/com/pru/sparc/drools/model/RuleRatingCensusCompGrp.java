package com.pru.sparc.drools.model;

public class RuleRatingCensusCompGrp {
	private String ageBracket;
	private double totalLives;
	private double totalCoveredVolume;
	private double monthlyPayPremStepRate;
	private double tableIRate;
	private double crossTableRate;
	private double finalRate;
	private String groupId;
	private int precision;
	
	
	public int getPrecision() {
		return precision;
	}
	public void setPrecision(int precision) {
		this.precision = precision;
	}
	public String getAgeBracket() {
		return ageBracket;
	}
	public void setAgeBracket(String ageBracket) {
		this.ageBracket = ageBracket;
	}
	public double getTotalLives() {
		return totalLives;
	}
	public void setTotalLives(double d) {
		this.totalLives = d;
	}
	public double getTotalCoveredVolume() {
		return totalCoveredVolume;
	}
	public void setTotalCoveredVolume(double totalCoveredVolume) {
		this.totalCoveredVolume = totalCoveredVolume;
	}
	public double getMonthlyPayPremStepRate() {
		return monthlyPayPremStepRate;
	}
	public void setMonthlyPayPremStepRate(double monthlyPayPremStepRate) {
		this.monthlyPayPremStepRate = monthlyPayPremStepRate;
	}
	public double getTableIRate() {
		return tableIRate;
	}
	public void setTableIRate(double tableIRate) {
		this.tableIRate = tableIRate;
	}
	public double getCrossTableRate() {
		return crossTableRate;
	}
	public void setCrossTableRate(double crossTableRate) {
		this.crossTableRate = crossTableRate;
	}
	public double getFinalRate() {
		return finalRate;
	}
	public void setFinalRate(double finalRate) {
		this.finalRate = finalRate;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
}
