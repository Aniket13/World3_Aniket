package com.pru.sparc.drools.model;

public class PropExhibitGrp {
	private double compRateOver;
	private double regOrigRate;
	private double regDesRate;
	private double advOrigRate;
	private double advDesRate;
	private double finUndOrigRate;
	private double finUndDesRate;
	private double propExhLives;
	private double propExhVol;
	private double propExhRate;
	private double propExhPrem;
	private double guarIssueAmt;
	private double estLivesBl;
	private double estVolBl;
	private double monRateBl;
	private double monPremBl;
	private double comPerc;
	private double totAnnPremBl;
	public double getCompRateOver() {
		return compRateOver;
	}
	public void setCompRateOver(double compRateOver) {
		this.compRateOver = compRateOver;
	}
	public double getRegOrigRate() {
		return regOrigRate;
	}
	public void setRegOrigRate(double regOrigRate) {
		this.regOrigRate = regOrigRate;
	}
	public double getRegDesRate() {
		return regDesRate;
	}
	public void setRegDesRate(double regDesRate) {
		this.regDesRate = regDesRate;
	}
	public double getAdvOrigRate() {
		return advOrigRate;
	}
	public void setAdvOrigRate(double advOrigRate) {
		this.advOrigRate = advOrigRate;
	}
	public double getAdvDesRate() {
		return advDesRate;
	}
	public void setAdvDesRate(double advDesRate) {
		this.advDesRate = advDesRate;
	}
	public double getFinUndOrigRate() {
		return finUndOrigRate;
	}
	public void setFinUndOrigRate(double finUndOrigRate) {
		this.finUndOrigRate = finUndOrigRate;
	}
	public double getFinUndDesRate() {
		return finUndDesRate;
	}
	public void setFinUndDesRate(double finUndDesRate) {
		this.finUndDesRate = finUndDesRate;
	}
	public double getPropExhLives() {
		return propExhLives;
	}
	public void setPropExhLives(double propExhLives) {
		this.propExhLives = propExhLives;
	}
	public double getPropExhVol() {
		return propExhVol;
	}
	public void setPropExhVol(double propExhVol) {
		this.propExhVol = propExhVol;
	}
	public double getPropExhRate() {
		return propExhRate;
	}
	public void setPropExhRate(double propExhRate) {
		this.propExhRate = propExhRate;
	}
	public double getPropExhPrem() {
		return propExhPrem;
	}
	public void setPropExhPrem(double propExhPrem) {
		this.propExhPrem = propExhPrem;
	}
	public double getGuarIssueAmt() {
		return guarIssueAmt;
	}
	public void setGuarIssueAmt(double guarIssueAmt) {
		this.guarIssueAmt = guarIssueAmt;
	}
	public double getEstLivesBl() {
		return estLivesBl;
	}
	public void setEstLivesBl(double estLivesBl) {
		this.estLivesBl = estLivesBl;
	}
	public double getEstVolBl() {
		return estVolBl;
	}
	public void setEstVolBl(double estVolBl) {
		this.estVolBl = estVolBl;
	}
	public double getMonRateBl() {
		return monRateBl;
	}
	public void setMonRateBl(double monRateBl) {
		this.monRateBl = monRateBl;
	}
	public double getMonPremBl() {
		return monPremBl;
	}
	public void setMonPremBl(double monPremBl) {
		this.monPremBl = monPremBl;
	}
	public double getComPerc() {
		return comPerc;
	}
	public void setComPerc(double comPerc) {
		this.comPerc = comPerc;
	}
	public double getTotAnnPremBl() {
		return totAnnPremBl;
	}
	public void setTotAnnPremBl(double totAnnPremBl) {
		this.totAnnPremBl = totAnnPremBl;
	}
	
	
}
