package com.pru.sparc.drools.model;

import java.util.HashMap;

public class Comission {

	public HashMap<String, Object> commissionMap = new HashMap<String, Object>();

	public HashMap<String, Object> getCommissionMap() {
		return commissionMap;
	}

	public void setCommissionMap(HashMap<String, Object> commissionMap) {
		this.commissionMap = commissionMap;
	}
	
	public Object get(Object key){		
		return this.getCommissionMap().get(key);
	}
	
	public void put(Object key, Object value){		
		this.getCommissionMap().put((String)key, value);
	}
}
