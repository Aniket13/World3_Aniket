package com.pru.sparc.drools.model;

public class StateConstants {

	public static final String STATE = "state";
	public static final String STATE_ALLOCATION_FACTOR = "StateAllocationFactor";
	public static final String STATE_LIFE_AREA_FACTOR = "state_Life_Area_Factor";
	public static final String STATE_LIFE_AREA = "state_Life_Area";
	public static final String STATE_LIFE_TAX_FACTOR = "state_Life_Tax_Factor";
	public static final String STATE_PREMIUM_TAX = "state_Premium_Tax";
	public static final String  STATE_ASSESSMENT_FACTOR = "state_Assessment_Factor";
	public static final String  STATE_ASSESSMENT = "state_Assessment";
}
