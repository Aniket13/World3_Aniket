package com.pru.sparc.drools.model;

public class RenewalGrp {
	private double renRateOver;
	private double renFinRate;
	private double infVol;
	private double renManRate;
	private double renRatTbl;
	private double planPayRate;
	private double planMinPayRate;
	private double annPlanPrem;
	private double planTotLives;
	private double avgAge;
	private double avgAnnSal;
	private double maxCovAmt;
	private double perFem;
	private double comPercRen;
	public double getRenRateOver() {
		return renRateOver;
	}
	public void setRenRateOver(double renRateOver) {
		this.renRateOver = renRateOver;
	}
	public double getRenFinRate() {
		return renFinRate;
	}
	public void setRenFinRate(double renFinRate) {
		this.renFinRate = renFinRate;
	}
	public double getInfVol() {
		return infVol;
	}
	public void setInfVol(double infVol) {
		this.infVol = infVol;
	}
	public double getRenManRate() {
		return renManRate;
	}
	public void setRenManRate(double renManRate) {
		this.renManRate = renManRate;
	}
	public double getRenRatTbl() {
		return renRatTbl;
	}
	public void setRenRatTbl(double renRatTbl) {
		this.renRatTbl = renRatTbl;
	}
	public double getPlanPayRate() {
		return planPayRate;
	}
	public void setPlanPayRate(double planPayRate) {
		this.planPayRate = planPayRate;
	}
	public double getPlanMinPayRate() {
		return planMinPayRate;
	}
	public void setPlanMinPayRate(double planMinPayRate) {
		this.planMinPayRate = planMinPayRate;
	}
	public double getAnnPlanPrem() {
		return annPlanPrem;
	}
	public void setAnnPlanPrem(double annPlanPrem) {
		this.annPlanPrem = annPlanPrem;
	}
	public double getPlanTotLives() {
		return planTotLives;
	}
	public void setPlanTotLives(double planTotLives) {
		this.planTotLives = planTotLives;
	}
	public double getAvgAge() {
		return avgAge;
	}
	public void setAvgAge(double avgAge) {
		this.avgAge = avgAge;
	}
	public double getAvgAnnSal() {
		return avgAnnSal;
	}
	public void setAvgAnnSal(double avgAnnSal) {
		this.avgAnnSal = avgAnnSal;
	}
	public double getMaxCovAmt() {
		return maxCovAmt;
	}
	public void setMaxCovAmt(double maxCovAmt) {
		this.maxCovAmt = maxCovAmt;
	}
	public double getPerFem() {
		return perFem;
	}
	public void setPerFem(double perFem) {
		this.perFem = perFem;
	}
	public double getComPercRen() {
		return comPercRen;
	}
	public void setComPercRen(double comPercRen) {
		this.comPercRen = comPercRen;
	}

}
