package com.pru.sparc.drools.model;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

@SuppressWarnings("serial")
public class SparcBigDecimal extends BigDecimal {

	private final BigDecimal value;
	private static MathContext context = new MathContext(9, RoundingMode.HALF_UP);
	
	public SparcBigDecimal(Double val) {
		super(val,context);
		this.value = new BigDecimal(val);
	}

	public BigDecimal getValue() {
		return value;
	}
}
