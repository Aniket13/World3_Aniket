package com.pru.sparc.drools.model;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class Holding {
	
	List listOfPlans = new ArrayList<Plan>();
	
	@Deprecated
	Census census = new Census();
	
	int count;
	int peopleCount; //people count
	
	
	HashMap<String,Object> holdingMap = new HashMap<String,Object>();
	HashMap<String,Object> overRideMap = new HashMap<String,Object>();

	public HashMap<String, Object> holdingOutputMap = new HashMap<String, Object>();
	
	public HashMap<String, Object> getHoldingOutputMap() {
		return holdingOutputMap;
	}

	public void setHoldingOutputMap(HashMap<String, Object> holdingOutputMap) {
		this.holdingOutputMap = holdingOutputMap;
	}

	public HashMap<String, Object> getOverRideMap() {
		return overRideMap;
	}

	public void setOverRideMap(HashMap<String, Object> overRideMap) {
		this.overRideMap = overRideMap;
	}

	public HashMap<String, Object> getHoldingMap() {
		return holdingMap;
	}

	public void setHoldingMap(HashMap<String, Object> holdingMap) {
		this.holdingMap = holdingMap;
	}
	
	public int getPeopleCount() {
		return peopleCount;
	}
	public void setPeopleCount(int peopleCount) {
		this.peopleCount = peopleCount;
	}
	public List getListOfPlans() {
		return listOfPlans;
	}
	public void setListOfPlans(List listOfPlans) {
		this.listOfPlans = listOfPlans;
	}
	
	
	@Deprecated
	public Census getCensus() {
		return census;
	}
	
	@Deprecated
	public void setCensus(Census census) {
		this.census = census;
	}

	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	public Object get(Object key){		
		return this.getHoldingMap().get(key);
	}
	
	public void put(Object key, Object value){		
		this.getHoldingMap().put((String)key, value);
	}
}
