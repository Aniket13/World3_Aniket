package com.pru.sparc.drools.model;

public class RuleRatingProposalPlanDetails {
	
	private double proposalExhibitLives;
	private double proposalExhibitVolume;
	private double proposalExhibitRate;
	private double proposalExhibitPremium;
	private double compositeRate;
	private double estLivesForPlan;
	private double estLivesAllCompositePlan;
	private double estVolumeForPlan;
	private double estVolumeAllCompositePlan;
	private double monthlyRates;
	private double manualRate;
	private double monthlyPremiumForPlan;
	private double monthlyPremiumAllCompositePlan;
	private String groupId;
	
	public double getManualRate() {
		return manualRate;
	}
	public void setManualRate(double manualRate) {
		this.manualRate = manualRate;
	}
	public double getProposalExhibitLives() {
		return proposalExhibitLives;
	}
	public void setProposalExhibitLives(double proposalExhibitLives) {
		this.proposalExhibitLives = proposalExhibitLives;
	}
	public double getProposalExhibitVolume() {
		return proposalExhibitVolume;
	}
	public void setProposalExhibitVolume(double proposalExhibitVolume) {
		this.proposalExhibitVolume = proposalExhibitVolume;
	}
	public double getProposalExhibitRate() {
		return proposalExhibitRate;
	}
	public void setProposalExhibitRate(double proposalExhibitRate) {
		this.proposalExhibitRate = proposalExhibitRate;
	}
	public double getProposalExhibitPremium() {
		return proposalExhibitPremium;
	}
	public void setProposalExhibitPremium(double proposalExhibitPremium) {
		this.proposalExhibitPremium = proposalExhibitPremium;
	}
	public double getCompositeRate() {
		return compositeRate;
	}
	public void setCompositeRate(double compositeRate) {
		this.compositeRate = compositeRate;
	}
	public double getEstLivesForPlan() {
		return estLivesForPlan;
	}
	public void setEstLivesForPlan(double estLivesForPlan) {
		this.estLivesForPlan = estLivesForPlan;
	}
	public double getEstLivesAllCompositePlan() {
		return estLivesAllCompositePlan;
	}
	public void setEstLivesAllCompositePlan(double estLivesAllCompositePlan) {
		this.estLivesAllCompositePlan = estLivesAllCompositePlan;
	}
	public double getEstVolumeForPlan() {
		return estVolumeForPlan;
	}
	public void setEstVolumeForPlan(double estVolumeForPlan) {
		this.estVolumeForPlan = estVolumeForPlan;
	}
	public double getEstVolumeAllCompositePlan() {
		return estVolumeAllCompositePlan;
	}
	public void setEstVolumeAllCompositePlan(double estVolumeAllCompositePlan) {
		this.estVolumeAllCompositePlan = estVolumeAllCompositePlan;
	}
	public double getMonthlyRates() {
		return monthlyRates;
	}
	public void setMonthlyRates(double monthlyRates) {
		this.monthlyRates = monthlyRates;
	}
	public double getMonthlyPremiumForPlan() {
		return monthlyPremiumForPlan;
	}
	public void setMonthlyPremiumForPlan(double monthlyPremiumForPlan) {
		this.monthlyPremiumForPlan = monthlyPremiumForPlan;
	}
	public double getMonthlyPremiumAllCompositePlan() {
		return monthlyPremiumAllCompositePlan;
	}
	public void setMonthlyPremiumAllCompositePlan(
			double monthlyPremiumAllCompositePlan) {
		this.monthlyPremiumAllCompositePlan = monthlyPremiumAllCompositePlan;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

}
