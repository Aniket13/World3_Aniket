package com.pru.sparc.drools.model;

import java.util.ArrayList;
import java.util.List;

public class StatusConstants {
	public static final List<String> STATUS_LIST = new ArrayList<String>(){
		{
			add(ACTIVE);
			add(RETIREE);
		}
	};

	public static final String STATUS_POOLED_VOLUME_INVERSE = "status_Pooled_Volume__Inverse";
	public static final String STATUS_NON_POOLED_VOLUME_INVERSE = "status_Non_Pooled_Volume__Inverse";
	public static final String STATUS_NON_POOLED_MANUAL_RATE = "status_Non_Pooled_Manual_Rate" ;
	public static final String STATUS_POOLED_MANUAL_RATE = "status_Pooled_Manual_Rate" ;
	public static final String STATUS_WAIVER_OF_PREMIUM = "status_Waiver_of_Premium" ;
	public static final String STATUS_EFFECTIVE_DATE_ADJUSTMENT = "status_Effective_Date_Adjustment";
	public static final String STATUS_INDUSTRY_ADJUSTMENT = "status_Industry_Adjustment";
	public static final String STATUS_AREA_FACTOR = "status_Area_Factor";
	public static final String STATUS_AVERAGE_SALARY_FACTOR = "status_Average_Salary_Factor";
	public static final String STATUS_RATE_GUARANTEE = "status_Rate_Guarantee";
	public static final String STATUS_OPTIONAL_LIFE_ADJUSTMENT = "status_Optional_Life_Adjustment";
	public static final String STATUS_ADD_DISCOUNT = "status_ADD_Discount";
	public static final String STATUS_DISABILITY_PRODUCT_DISCOUNT = "status_Disability_Product_Discount";
	public static final String STATUS_LIFE_PLAN_ADJUSTMENT = "status_Life_Plan_Adjustment";
	public static final String STATUS_LIVING_BENEFIT_OPTION_ADJUSTMENT = "status_Living_Benefit_Option_Adjustment";
	public static final String STATUS_OTHER_NON_POOLED_ADJUSTMENT = "status_Other_Non_Pooled_Adjustment";
	public static final String STATUS_CONVERSION_ADJUSTMENT = "status_Conversion_Adjustment";
	public static final String STATUS_WAIVER_OF_PREMIUM_ADJUSTMENT = "status_Waiver_of_Premium_Adjustment";
	public static final String STATUS_NON_POOLED_ANNUAL_MANUAL_PREMIUM = "status_Non_Pooled_Annual_Manual_Premium";
	public static final String STATUS_DENTAL_DISCOUNT = "status_Dental_Discount";
	public static final String STATUS_POOLED_ANNUAL_MANUAL_PREMIUM = "status_Pooled_Annual_Manual_Premium";
	public static final String STATUS_OTHER_POOLED_ADJUSTMENT = "status_Other_Pooled_Adjustment";
	public static final String STATUS_NON_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM = "status_Non_Pooled_Adjusted_Annual_Manual_Premium";
	public static final String STATUS_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM = "status_Pooled_Adjusted_Annual_Manual_Premium";
	public static final String STATUS_POOLED_CAB = "status_Pooled_CAB";
	public static final String STATUS_POOLED_ANNUAL_EXPECTED_CLAIMS = "status_Pooled_Annual_Expected_Claims";
	public static final String STATUS_POOLED_ANNUAL_EXPECTED_CLAIM_RATE = "status_Pooled_Annual_Expected_Claim_Rate";
	public static final String STATUS_POOLED_MONTHLY_MANUAL_PREMIUM = "status_Pooled_Monthly_Manual_Premium";
	public static final String STATUS_NON_POOLED_MONTHLY_MANUAL_PREMIUM = "status_Non_Pooled_Monthly_Manual_Premium";
	
	public static final String STATUS_NON_POOLED_ADJUSTED_MONTHLY_MANUAL_PREMIUM = "status_Non_Pooled_Adjusted_Monthly_Manual_Premium";
	public static final String STATUS_POOLED_ADJUSTED_MONTHLY_MANUAL_PREMIUM = "status_Pooled_Adjusted_Monthly_Manual_Premium";
	public static final String STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIM_RATE = "status_Non_Pooled_Annual_Expected_Claim_Rate";

	public static final String STATUS_WAIVER_TO_AGE_65_ADJUSTMENT = "status_Waiver_To_Age_65_Adjustment";
	public static final String STATUS_FLAT_PLAN_ADJUSTMENT_STEP_1 = "status_Flat_Plan_Adjustment_step_1";
	public static final String STATUS_POOLED_VOLUME = "status_Pooled_Volume";
	public static final String STATUS_NON_POOLED_VOLUME = "status_Non_Pooled_Volume";
	public static final String ACTIVE = "Active";
	public static final String RETIREE = "Retiree";
	public static final String STATUS_NON_POOLED_MANUAL_RATE_STEP_1  = "status_Non_Pooled_Manual_Rate_Step_1";
	
	public static final String STATUS_ADD_DISCOUNT_ACTIVE_ONLY = "status_ADD_Discount__Active_Only";
	public static final String STATUS_DISABILITY_PRODUCT_DISCOUNT_ACTIVE_ONLY = "status_Disability_Product_Discount__Active_Only";
	public static final String STATUS_NON_POOLED_CAB = "status_Non_Pooled_CAB";
	public static final String STATUS_EFFECTIVE_DATE_ADJUSTMENT_DIFFERENCE = "status_Effective_Date_Adjustment_Difference";
	public static final String STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIMS = "status_Non_Pooled_Annual_Expected_Claims";
	public static final String STATUS_OPTIONAL_LIFE_ADJUSTMENT_STEP_1 = "status_Optional_Life_Adjustment_Step_1";
	public static final String STATUS_OPTIONAL_LIFE_ADJUSTMENT_STEP_2 = "status_Optional_Life_Adjustment_Step_2";
	public static final String STATUS_OPTIONAL_LIFE_ADJUSTMENT_STEP_3 = "status_Optional_Life_Adjustment_Step_3";
	
	public static final String STATUS_OPTIONAL_LIFE_ADJ_ACTIVE_ONLY = "status_Optional_Life_Adj__Active_Only";
	public static final String STATUS_FLAT_PLAN_ADJUSTMENT_STEP_2 = "status_Flat_Plan_Adjustment_Step_2";
	public static final String STATUS_FLAT_PLAN_ADJUSTMENT_STEP_3 = "status_Flat_Plan_Adjustment_Step_3";
	public static final String STATUS_FLAT_PLAN_ADJUSTMENT_STEP_3_TEMP = "status_Flat_Plan_Adjustment_Step_3_Temp";
	public static final String PEOPLE_CENSUS_SALARY  = "people_Census_Salary";
	public static final String STATUS_NON_POOLED_MONTHLY_PREMIUM = "status_Non_Pooled_Monthly_Premium";
	public static final String STATUS_POOLED_MONTHLY_PREMIUM = "status_Pooled_Monthly_Premium";
	public static final String STATUS_OPTIONAL_LIFE_ADJUSTMENT_STEP_4 = "status_Optional_Life_Adjustment_Step_4";
	
	
}
