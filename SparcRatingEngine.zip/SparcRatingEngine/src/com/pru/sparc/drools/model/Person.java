package com.pru.sparc.drools.model;
import java.util.HashMap;


public class Person {
	
	public HashMap<String, Object> peopleMap = new HashMap<String, Object>();

	public HashMap<String, Object> getPeopleMap() {
		return peopleMap;
	}

	public void setPeopleMap(HashMap<String, Object> peopleMap) {
		this.peopleMap = peopleMap;
	}

	public Object get(Object key){		
		return this.getPeopleMap().get(key);
	}
	
	public void put(Object key, Object value){		
		this.getPeopleMap().put((String)key, value);
	}
	

}
