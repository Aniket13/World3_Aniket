package com.pru.sparc.drools.model;

import java.util.Date;



public class MasterFactorBean {
	private String city;
	private String defaultState;
	private Date effectiveDate;
	private String productType;
	private String factorTable;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDefaultState() {
		return defaultState;
	}
	public void setDefaultState(String defaultState) {
		this.defaultState = defaultState;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getFactorTable() {
		return factorTable;
	}
	public void setFactorTable(String factorTable) {
		this.factorTable = factorTable;
	}
	
	
}
