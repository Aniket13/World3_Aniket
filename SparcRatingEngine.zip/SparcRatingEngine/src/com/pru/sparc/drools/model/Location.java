package com.pru.sparc.drools.model;


import org.drools.definition.type.Position;

public class Location {
	@Position(0)
	private String item;
	@Position(1)
	private String location;
	//declaring constructor
	public Location(String item,String location) {
		// TODO Auto-generated constructor stub
		this.item=item;
		this.location=location;
	}
	//overriding equals method
	@Override
	public boolean equals(Object obj) {
		
		if(this==obj){
			return true;
		}
		if(obj==null||getClass()!=obj.getClass()){
			return false;
		}
		Location location1=(Location)obj;
		
		if(item!=null?!item.equals(location1.item):location1.item!=null){
			return false;
		}
		
		if(location!=null?!location.equals(location1.location):location1.location!=null){
			return false;
		}
		return true;
	}
	//overriding hashcode
	public int hashCode() {
		int result=item!=null?item.hashCode():0;
		result=31*result+(location!=null?location.hashCode():0);
		return result;
	};
	
	
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
}

