package com.pru.sparc.drools.model;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

@SuppressWarnings("serial")
public class SBigDecimal extends BigDecimal {
	
	public static RoundingMode ROUND_NEAREST = RoundingMode.HALF_UP;

	private static MathContext context = new MathContext(18, RoundingMode.HALF_UP);
	
	public int compareTo(SBigDecimal arg0) {
		return super.compareTo(arg0);
	}

	public SBigDecimal multiply(SBigDecimal arg0) {

		return new SBigDecimal(super.multiply(arg0,context).toString());
	};

	public SBigDecimal add(SBigDecimal arg0) {

		return new SBigDecimal(super.add(arg0,context).toString());
	};
	
	public SBigDecimal subtract(SBigDecimal arg0) {

		return new SBigDecimal(super.subtract(arg0,context).toString());
	};
	
	public SBigDecimal divide(SBigDecimal arg0) {

		return new SBigDecimal(super.divide(arg0,context).toString());
	};
	
	public SBigDecimal min(SBigDecimal arg0) {
		return new SBigDecimal(super.min(arg0).toString());
	};

	public SBigDecimal max(SBigDecimal arg0) {
		return new SBigDecimal(super.max(arg0).toString());
	};
	
	public SBigDecimal remainder(SBigDecimal arg0) {
		return new SBigDecimal(super.remainder(arg0,context).toString());
	};
	
	
	public SBigDecimal(String string) {
		super(string);
		new BigDecimal(string,context);
	}

	public SBigDecimal(int string) {
		super(string);
		 new BigDecimal(string,context);
	}

	public SBigDecimal(Integer val) {
		super(val,context);
		new BigDecimal(val,context);
	}

	/*public SBigDecimal(Object string) {
		super((char[]) string);
		if (string.equals(null)) {
			string = "";
		}
		new BigDecimal((char[]) string,context);
	}
	*/
	public SBigDecimal(double val) {
		super(val,context);
		new BigDecimal(val,context);
	}

	public SBigDecimal(Double val) {
		super(val,context);
		new BigDecimal(val,context);
	}
	
	public Double getDouble(){
		return super.doubleValue();
	}
	
	public SBigDecimal setScale(int scale){
		return new SBigDecimal(super.setScale(scale).toString());
	}
	
	public SBigDecimal setScale(int scale, RoundingMode round){
		return new SBigDecimal(super.setScale(scale,round).toString());
	}
}
