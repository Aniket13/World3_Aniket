package com.pru.sparc.drools.model;

import java.util.Date;

public class RuleRatingModelOverrideGrp {
	private String fieldKey;
	private double fieldValue;
	private int fieldSeqNo;
	private boolean overrideAllowed;
	private boolean overrideIndicator;
	private double overrideValue;
	private boolean uwApproval;
	private String approvingUW;
	private Date approvalDate;
	private String uwEvaluation;
	private String ruleID;
	private String groupId;
	private int precision;
	
	public String getApprovingUW() {
		return approvingUW;
	}
	public void setApprovingUW(String approvingUW) {
		this.approvingUW = approvingUW;
	}
	public int getPrecision() {
		return precision;
	}
	public void setPrecision(int precision) {
		this.precision = precision;
	}
	public String getUwEvaluation() {
		return uwEvaluation;
	}
	public void setUwEvaluation(String uwEvaluation) {
		this.uwEvaluation = uwEvaluation;
	}
	public String getFieldKey() {
		return fieldKey;
	}
	public void setFieldKey(String fieldKey) {
		this.fieldKey = fieldKey;
	}
	public double getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(double fieldValue) {
		this.fieldValue = fieldValue;
	}
	public int getFieldSeqNo() {
		return fieldSeqNo;
	}
	public void setFieldSeqNo(int fieldSeqNo) {
		this.fieldSeqNo = fieldSeqNo;
	}
	public boolean isOverrideAllowed() {
		return overrideAllowed;
	}
	public void setOverrideAllowed(boolean overrideAllowed) {
		this.overrideAllowed = overrideAllowed;
	}
	public double getOverrideValue() {
		return overrideValue;
	}
	public void setOverrideValue(double overrideValue) {
		this.overrideValue = overrideValue;
	}
	public boolean isUwApproval() {
		return uwApproval;
	}
	public void setUwApproval(boolean uwApproval) {
		this.uwApproval = uwApproval;
	}
	public Date getApprovalDate() {
		return approvalDate;
	}
	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}
	public String getRuleID() {
		return ruleID;
	}
	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public boolean isOverrideIndicator() {
		return overrideIndicator;
	}
	public void setOverrideIndicator(boolean overrideIndicator) {
		this.overrideIndicator = overrideIndicator;
	}
}
