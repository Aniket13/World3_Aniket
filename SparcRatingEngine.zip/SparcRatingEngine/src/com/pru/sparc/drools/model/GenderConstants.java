package com.pru.sparc.drools.model;

import java.util.ArrayList;
import java.util.List;

public class GenderConstants {

	public static final String MALE = "Male";
	public static final String FEMALE = "Female";
	
	public static final List<String> GENDER_LIST = new ArrayList<String>() {
		{
    		add(MALE);
    		add(FEMALE);
		}
    	};


}
