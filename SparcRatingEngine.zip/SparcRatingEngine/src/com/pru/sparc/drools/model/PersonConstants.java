package com.pru.sparc.drools.model;

import com.pru.sparc.drools.common.util.RuleRatingConstants;


public  final class  PersonConstants {
	
	
	
	public static final String PEOPLE_SALARY = "people_Salary";
	public static final String PEOPLE_BASIC_AMT = "people_BasicAmt";
	public static final String PEOPLE_AGE = "Age";
	public static final String PEOPLE_GENDER = "gender";
	public static final String PEOPLE_STATUS = "status";
	public static final String AGEBRACKET_PRELIMINARY_RATE_STEP2B = "agebracket_Preliminary_Rate_Step2b";
	public static final String PEOPLE_NON_POOLED_VOLUME = "people_Non_Pooled_Volume";
	public static final String PEOPLE_POOLED_VOLUME = "people_Pooled_Volume";
	public static final String PEOPLE_POOLED_VOLUME_STEP_1 = "people_Pooled_Volume__Step_1";
	public static final String PEOPLE_ANNUAL_SALARY = "people_Annual_Salary";
	public static final String SUM_PEOPLE_ANNUAL_SALARY = RuleRatingConstants.ADD_OPERATOR_KEY + PEOPLE_ANNUAL_SALARY;

	public static final String PEOPLE_ACTIVE_STATUS = "Active";
	public static final String PEOPLE_RETIREE_STATUS = "Retiree";
	public static final String PEOPLE_GENDER_MALE = "male";
	public static final String PEOPLE_GENDER_FEMALE = "female";
	public static final String PEOPLE_TOTAL_COVERED_VOLUME = "total_covered_volume";
	public static final String PEOPLE_COLLECTIVE_BARGAINED = "people_CollectiveBargained";
	public static final String PEOPLE_COUNT_COLLECTIVE_BARGAIN = "people_Count_Collective_Bargain";



	public static final String PEOPLE_AGE_MANUAL_RATE = "age_Manual_Rate";
	public static final String MONTHLY_NON_POOLED_PREMIUM = "Monthly_Non_Pooled_Premium";
	public static final String ANNUAL_NON_POOLED_PREMIUM = "Annual_Non_Pooled_Premium";
	public static final String MONTHLY_POOLED_PREMIUM = "Monthly_Pooled_Premium";
	public static final String ANNUAL_POOLED_PREMIUM = "Annual_Pooled_Premium";
	public static final String PER_THOUSAND = "1000";
	public static final String MONTHS_IN_YEAR = "12";

	public static final String PEOPLE_STATE = "state";
	public static final String PEOPLE_LIFE_COUNT = "people_life_count";
	public static final String PEOPLE_RETRIEVE_AGE = "people_Retrieve_Age";
	
	public static final String PEOPLE_GROSS_VOLUME = "people_Gross_Volume";
	public static final String PEOPLE_GROSS_VOLUME_SYSTEM_CALCULATED = "people_Gross_Volume__System_Calculated";
	public static final String PEOPLE_CENSUS_SALARY_OVER_50K = "people_Census_Salary_Over_50K";
	public static final String PEOPLE_SET_ROUNDING_SELECTION_STEP2 = "people_SetRoundingSelection__Step2";
	public static final String PEOPLE_SET_ROUNDING_SELECTION_STEP3 = "people_SetRoundingSelection__Step3";
	public static final String PEOPLE_AVERAGE_SALARY_FACTOR_STEP_1 = "people_Average_Salary_Factor_Step_1";
	public static final String SUM_PEOPLE_AVERAGE_SALARY_FACTOR_STEP_1 = RuleRatingConstants.ADD_OPERATOR_KEY+PEOPLE_AVERAGE_SALARY_FACTOR_STEP_1;
	public static final String PRE_ROUNDED_VALUE = "PreRoundedValue";
	public static final String PEOPLE_ROUNDING_SALARY_TIMES_EARNINGS_FACTOR = "people_Rounding_Salary_times_Earnings_Factor";
	public static final String PEOPLE_GROSS_VOLUME_MULTIPLE_OF_EARNINGS_PLUS_FLAT_STEP_1 = "people_Gross_Volume__Multiple_Of_Earnings_Plus_Flat_Step_1";
	public static final String PEOPLE_GROSS_VOLUME_COMPARE_MIN_MAX = "people_Gross_Volume__Compare_Min_Max";
	public static final String PEOPLE_COVERED_VOLUME_AGE_REDUCTION_PCT_STEP_1 = "people_Covered_Volume__Age_Reduction_Pct_Step_1";
	public static final String PEOPLE_COVERED_VOLUME = "people_Covered_Volume";	
	public static final String PEOPLE_COUNT_FEMALE_LIVES = "people_Count_Female_Lives";

	public static final String SUM_PEOPLE_POOLED_VOLUME = RuleRatingConstants.ADD_OPERATOR_KEY + "people_Pooled_Volume";
	public static final String SUM_PEOPLE_NON_POOLED_VOLUME = RuleRatingConstants.ADD_OPERATOR_KEY + "people_Non_Pooled_Volume";
	public static final String SUM_MONTHLY_POOLED_PREMIUM = RuleRatingConstants.ADD_OPERATOR_KEY + MONTHLY_POOLED_PREMIUM;
	public static final String SUM_ANNUAL_POOLED_PREMIUM = RuleRatingConstants.ADD_OPERATOR_KEY + ANNUAL_POOLED_PREMIUM;
	public static final String SUM_MONTHLY_NON_POOLED_PREMIUM = RuleRatingConstants.ADD_OPERATOR_KEY + MONTHLY_NON_POOLED_PREMIUM;
	public static final String SUM_ANNUAL_NON_POOLED_PREMIUM = RuleRatingConstants.ADD_OPERATOR_KEY + ANNUAL_NON_POOLED_PREMIUM;
	

	public static final String AGE_PRELIMINARY_RATE_STEP1_MALEONLY = "age_Preliminary_Rate_Step1_MaleOnly";
	public static final String AGE_PRELIMINARY_RATE_STEP1_FEMALEONLY = "age_Preliminary_Rate_Step1_FemaleOnly";
	
	public static final String STATUS_NON_POOLED_MONTHLY_PREMIUM = "status_Non_Pooled_Monthly_Premium";
	public static final String STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIMS = "status_Non_Pooled_Annual_Expected_Claims";
	public static final String STATUS_POOLED_ANNUAL_EXPECTED_CLAIMS = "status_Pooled_Annual_Expected_Claims";
	
	public static final String AGE_PRELIMINARY_RATE_STEP1_FEMALE_ONLY = "age_Preliminary_Rate_Step1_FemaleOnly";
	public static final String AGE_PRELIMINARY_RATE_STEP1_MALE_ONLY = "age_Preliminary_Rate_Step1_MaleOnly";
	public static final String PEOPLE_CENSUS_SALARY = "people_Census_Salary";
	
}
