package com.pru.sparc.drools.service;

import java.util.List;

import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.RuleRatingOutputModelWrapper;

public interface RatingDroolsService {
	//Temporary commented for Demo
	//public List<RuleRatingOutputModelWrapper> invokeRatingEngine(Holding holding);
	//public List<RuleRatingOutputModelWrapper> invokeRatingEngine(Holding holding, int versionNumber);
	public List<RuleRatingOutputModelWrapper> invokeRatingEngine(Holding holding);
}
