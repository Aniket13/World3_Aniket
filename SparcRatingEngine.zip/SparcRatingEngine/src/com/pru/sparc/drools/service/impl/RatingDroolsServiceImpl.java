package com.pru.sparc.drools.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.pru.sparc.drools.common.util.HoldingResponseUtil;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.RuleRatingOutputModelWrapper;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.model.StatusConstants;
import com.pru.sparc.drools.service.RatingDroolsService;

@Service("ratingDroolsService")
public class RatingDroolsServiceImpl implements RatingDroolsService {

	@Override
	// public List<RuleRatingOutputModelWrapper> invokeRatingEngine(Holding
	// holding) {
	public List<RuleRatingOutputModelWrapper> invokeRatingEngine(Holding holding/*,
			int versionNumber*/) {

		// temporary code - mock data
		// TODO: to be removed once rating results are final
		// MockRatingEngineData objMockRatingEngineData = new
		// MockRatingEngineData();
		// holding = objMockRatingEngineData.createResult();

		// temporary code added for Demo - mocked input
	/*	Holding holding = null;
		if (versionNumber == 262) {
			TestIntegrationData objTest = new TestIntegrationData();
			holding = objTest.testDataforDemo(uiHolding);
		} else if (versionNumber == 283) {
			DemoIntegrationData objDemo = new DemoIntegrationData();
			holding = objDemo.testDataforDemo(uiHolding);
		} else if (versionNumber == 287) {
			MattDemoIntegrationData objDemo2 = new MattDemoIntegrationData();
			holding = objDemo2.testDataforDemo(uiHolding);
		}*/
		// temporary code added for Demo - mocked input

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop1\\BL_Plan_Loop1.drl", "plan-loop1",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop2\\BL_Plan_Loop2.drl", "plan-loop2",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop3\\BL_Plan_Loop3.drl", "plan-loop3",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop4\\BL_Plan_Loop4.drl", "plan-loop4",
				new Object[] { holding });
		// IntegrationTestLoop4 integrationTestForLoop4 = new
		// IntegrationTestLoop4();
		// integrationTestForLoop4.execute(holding);
		System.out.println("Loop4 End");

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop5\\BL_Plan_Loop5.drl", "plan-loop5",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop6\\BL_Plan_Loop6.drl", "plan-loop6",
				new Object[] { holding });
		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop7\\BL_Plan_Loop7.drl", "plan-loop7",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop7a\\BL_Plan_Loop7a.drl", "plan-loop7a",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop7b\\BL_Plan_Loop7b.drl", "plan-loop7b",
				new Object[] { holding });

		RuleUtility.getInitsData(RuleUtility.DRL,
				"basiclife\\loop8\\BL_Plan_Loop8.drl", "plan-loop8",
				new Object[] { holding });
		
		HoldingResponseUtil util = new HoldingResponseUtil();
		List<RuleRatingOutputModelWrapper> plansOutput = util
				.parseRatingExhibitOutput(holding);
		//setPrecision(holding);
		
		return plansOutput;
	}
	
	public void setPrecision(Holding holding){
		//List<Plan> planList = holding.getListOfPlans();
		
		System.out.println("Setting Precisions ");
		
		//for (Plan plan : planList) {
			
			List plans = (List) (holding.getListOfPlans());

			for (int i = 0; i < plans.size(); i++) {
				holding.setCount(i);
				Plan plan = (Plan) (holding.getListOfPlans()
						.get(holding.getCount()));
			System.out.println("Inside plans loop ");
				
			
			/*plan.getPlanMap().put(PlanConstants.PLAN_COMMISSION_PERCENTAGE,MinOfplanRequestedCommission.setScale(3, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_COMMISSION_PERCENTAGE :" + plan.getPlanMap().get(PlanConstants.PLAN_COMMISSION_PERCENTAGE));*/
			
			plan.getPlanMap().put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM)).setScale(3, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_BL_EXHIBIT_MONTHLY_PREMIUM :" + plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM));
			
			plan.getPlanMap().put(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM)).setScale(2, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM :" + plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM));
			
			plan.getPlanMap().put(PlanConstants.PLAN_ANNUAL_PREMIUM,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_ANNUAL_PREMIUM)).setScale(2, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_ANNUAL_PREMIUM :" + plan.getPlanMap().get(PlanConstants.PLAN_ANNUAL_PREMIUM));
			
			plan.getPlanMap().put(PlanConstants.PLAN_AVERAGE_ANNUAL_SALARY,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_AVERAGE_ANNUAL_SALARY)).setScale(0, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_AVERAGE_ANNUAL_SALARY :" + plan.getPlanMap().get(PlanConstants.PLAN_AVERAGE_ANNUAL_SALARY));
			
			plan.getPlanMap().put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY)).setScale(2, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY :" + plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY));
			
			plan.getPlanMap().put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY)).setScale(2, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY :" + plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY));
			
			plan.getPlanMap().put(PlanConstants.PLAN_LEVEL_SCALE_COMMISSIONS,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_LEVEL_SCALE_COMMISSIONS)).setScale(3, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_LEVEL_SCALE_COMMISSIONS :" + plan.getPlanMap().get(PlanConstants.PLAN_LEVEL_SCALE_COMMISSIONS));
			
			plan.getPlanMap().put(PlanConstants.PLAN_REQUESTED_COMMISSION,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_REQUESTED_COMMISSION)).setScale(3, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_REQUESTED_COMMISSION :" + plan.getPlanMap().get(PlanConstants.PLAN_REQUESTED_COMMISSION));
			
			plan.getPlanMap().put(PlanConstants.PLAN_TOTAL_RETENTION,((SBigDecimal) plan.getPlanMap().get(PlanConstants.PLAN_TOTAL_RETENTION)).setScale(4, SBigDecimal.ROUND_NEAREST));
			System.out.println("value of PLAN_TOTAL_RETENTION :" + plan.getPlanMap().get(PlanConstants.PLAN_TOTAL_RETENTION));

			
			for(String status : StatusConstants.STATUS_LIST){
				System.out.println("Inside StatusList");
					HashMap statusMap = (HashMap)(plan.getStatus_gender_ageB_age_AggregationMap().get(status));
				//HashMap statusMap = (HashMap)((HashMap)plan.getStatusAggregationMap()).get(status);
					if(statusMap != null){	
				System.out.println("Inside StatusMap");
				//status values
				statusMap.put(StatusConstants.STATUS_NON_POOLED_ANNUAL_MANUAL_PREMIUM,((SBigDecimal) statusMap.get(PersonConstants.SUM_ANNUAL_NON_POOLED_PREMIUM)).setScale(2, SBigDecimal.ROUND_NEAREST));
				System.out.println("value of STATUS_NON_POOLED_ANNUAL_MANUAL_PREMIUM :" + statusMap.get(StatusConstants.STATUS_NON_POOLED_ANNUAL_MANUAL_PREMIUM));
				
				statusMap.put(StatusConstants.STATUS_AREA_FACTOR,((SBigDecimal) statusMap.get(StatusConstants.STATUS_AREA_FACTOR)).setScale(4, SBigDecimal.ROUND_NEAREST));
				System.out.println("value of STATUS_AREA_FACTOR :" + statusMap.get(StatusConstants.STATUS_AREA_FACTOR));
				
				statusMap.put(StatusConstants.STATUS_AVERAGE_SALARY_FACTOR,((SBigDecimal) statusMap.get(StatusConstants.STATUS_AVERAGE_SALARY_FACTOR)).setScale(3, SBigDecimal.ROUND_NEAREST));
				System.out.println("value of STATUS_AVERAGE_SALARY_FACTOR :" + statusMap.get(StatusConstants.STATUS_AVERAGE_SALARY_FACTOR));
				
				statusMap.put(StatusConstants.STATUS_NON_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM,((SBigDecimal) statusMap.get(StatusConstants.STATUS_NON_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM)).setScale(2, SBigDecimal.ROUND_NEAREST));
				System.out.println("value of STATUS_NON_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM :" + statusMap.get(StatusConstants.STATUS_NON_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM));
				
				statusMap.put(StatusConstants.STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIMS,((SBigDecimal) statusMap.get(StatusConstants.STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIMS)).setScale(2, SBigDecimal.ROUND_NEAREST));	
				System.out.println("value of STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIMS :" + statusMap.get(StatusConstants.STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIMS));
				}
			}
		}
	}
}
