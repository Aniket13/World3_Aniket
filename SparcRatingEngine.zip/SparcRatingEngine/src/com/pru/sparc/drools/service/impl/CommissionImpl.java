package com.pru.sparc.drools.service.impl;

import com.pru.sparc.drools.service.ICommission;

public class CommissionImpl implements ICommission {

	@Override
	public String getCommission() {
		// TODO Auto-generated method stub
		System.out.println("in sparc rating");
		String asds="in sparc rating";
		return asds;
	}

}
