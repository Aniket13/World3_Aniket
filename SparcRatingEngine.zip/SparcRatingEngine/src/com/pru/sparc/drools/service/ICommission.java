package com.pru.sparc.drools.service;

public interface ICommission {
	public String getCommission();
}
