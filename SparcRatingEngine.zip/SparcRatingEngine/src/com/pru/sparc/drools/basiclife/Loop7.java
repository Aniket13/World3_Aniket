package com.pru.sparc.drools.basiclife;

import java.util.HashMap;

import org.apache.commons.lang.StringUtils;

import com.pru.sparc.drools.common.util.AggregationUtility;
import com.pru.sparc.drools.common.util.FactLookupUtility;
import com.pru.sparc.drools.common.util.MathUtility;
import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import java.math.RoundingMode;

public class Loop7 {

	public Plan excutePlan(Holding holding, Plan plan) {
		setPlan_BL_Exhibit_Estimated_Volume_Step_1(holding, plan);
		setPlan_BL_Exhibit_Monthly_Rates_Step_1(holding, plan);
		setPlan_BL_Exhibit_Monthly_Rates_Step_2(holding, plan);
		setPlan_BL_Exhibit_Monthly_Rates_Step_3(holding, plan);
		setPlan_BL_Exhibit__Monthly_Rate_RVP_Adjustment(holding, plan);
		setPlan_BL_Exhibit__Monthly_Rate_Advocate_Adjustment(holding, plan);
		setPlan_BL_Exhibit_Monthly_Rates_Step_4(holding, plan);
		setInitParam(holding, plan);
		setPlan_Initial_Inforce_Volume_Renewal(holding, plan);
		setPlan_Initial_Manual_Rate_NonAgeBanded(holding, plan);
		setPlan_Initial_Inforce_Renewal_Premium_NonAgeBanded_Step_2(holding,
				plan);
		setPlan_Initial_Inforce_Renewal_Premium_NonAgeBanded(holding, plan);
		setPlan_Initial_Manual_Premium_NonAgeBanded_Step_1(holding, plan);
		setPlan_Initial_Manual_Premium_NonAgeBanded_Step_2(holding, plan);
		setPlan_Initial_Manual_Premium_NonAgeBanded(holding, plan);
		setPlan_Initial_Inforce_Premium(holding, plan);
		setPlan_BL_Exhibit_Non_Med_Max(holding, plan);
		setPlan_BL_Exhibit_Total_Annual_Premium_Step1(holding, plan);
		setPlan_Payable_Rate(holding, plan);
		setPlan_Annual_Premium(holding, plan);
		setPlan_Composite_Rate(holding, plan);
		setPlan_Monthly_Premium_For_RFP_Display(holding, plan);
		setplan_Monthly_Premium_For_All_Plans_Composite_Only(holding, plan);
		setPlan_Loop_7(plan, holding);
		setHolding_Total_Annual_Prem_All_Plans(plan, holding);
		setHolding_Total_Monthly_Prem_All_Plans(plan, holding);
		return plan;
	}

	public Plan executePlan1(Holding holding, Plan plan) {
		setPlanLoopParams(holding, plan);
		setPlan_Loop_Rate_Disk_Total(plan, holding);
		setHolding_Sum_Inforce_Prem_NonAgeBanded_All_Plans(plan, holding);
		setHolding_Sum_Manual_Prem_NonAgeBanded_All_Plans(plan, holding);
		setHolding_Sum_Inforce_Prem_AgeBanded_All_Plans(plan, holding);
		setHolding_Sum_Manual_Prem_AgeBanded_All_Plans(plan, holding);
		setHolding_Initial_Inforce_Premium(holding, plan);
		setHolding_Initial_Manual_Premium(holding, plan);
		setHolding_Inforce_to_Manual_Prem_Ratio(holding, plan);
		setHolding_Rate_Action_RAT(holding, plan);
		setHolding_Rate_Action_Max_Step_1(holding, plan);
		setHolding_Rate_Action_Max_Step_2(holding, plan);
		setHolding_Rate_Action_Max(holding, plan);
		return plan;
	}

	public Plan executeAgeBracket(Holding holding, Plan plan,
			HashMap<Object, Object> currentMap) {

		// setAgeBracket_TableK_Loop(plan, currentMap);
		setPlan_Inforce_Agebanded_Premium_Step_A(plan, currentMap);
		setPlan_Inforce_Agebanded_Premium_Step_B(plan, currentMap);
		setPlan_Table_K_Monthly_Premium_Step_1(plan, currentMap);
		setPlan_Initial_Inforce_Prem_All_AgeBanded(plan, currentMap);
		setPlan_Initial_Manual_Prem_All_AgeBanded(plan, currentMap);
		return plan;
	}

	// agebracket_Preliminary_Rate_Adj Tested
	public Plan setAgebracket_Preliminary_Rate_Adj(Holding holding, Plan plan,
			HashMap<Object, Object> ageBracketMap) {

		SBigDecimal holding_Total_Cross_TableI = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_CROSS_TABLEI);

		SBigDecimal holding_Composite_TableI = (SBigDecimal) holding
				.getHoldingMap().get(HoldingConstants.HOLDING_COMPOSITE_TABLEI);

		if (holding_Total_Cross_TableI != null
				&& MathUtility.compareSBigDecimal(holding_Total_Cross_TableI,new SBigDecimal("0")) == 0) {
			SBigDecimal agebracket_Preliminary_Rate_calc = (SBigDecimal) ageBracketMap
					.get(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_CALC);
			ageBracketMap
					.put(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_ADJ__TABLEI_ZERO,
							agebracket_Preliminary_Rate_calc);
		} else if (holding_Total_Cross_TableI != null
				&& MathUtility.compareSBigDecimal(holding_Total_Cross_TableI,new SBigDecimal("15")) == 0) {
			SBigDecimal agebracket_Preliminary_Rate_calc = (SBigDecimal) ageBracketMap
					.get(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_CALC);
			ageBracketMap
					.put(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_ADJ__TABLEI_FIFTEEN,
							agebracket_Preliminary_Rate_calc);
		} else if (holding_Composite_TableI != null
				&& MathUtility.compareSBigDecimal(holding_Total_Cross_TableI,new SBigDecimal("0")) != 0) {
			SBigDecimal Value = ((SBigDecimal) ageBracketMap
					.get(AgeBracketConstants.AGEBRACKET_TABLEIRATE_CALC))
					.multiply(((SBigDecimal) (holding.getHoldingMap()
							.get(HoldingConstants.HOLDING_COMPOSITE_PRELIMINARY_RATE)))
							.divide((SBigDecimal) holding.getHoldingMap().get(
									HoldingConstants.HOLDING_COMPOSITE_TABLEI)));

			ageBracketMap.put(
					AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_ADJ, Value);
		} else if (holding_Composite_TableI != null
				&& MathUtility.compareSBigDecimal(holding_Total_Cross_TableI,new SBigDecimal("0")) == 0)

		{
			ageBracketMap.put(
					AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_ADJ,
					new SBigDecimal(0));
		} else {
			ageBracketMap.put(
					AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_ADJ,
					new SBigDecimal(-12345));
		}
		return plan;

	}

	// AgeBracket_TableK_Loop Tested Tested
	public void setAgeBracket_TableK_Loop(Plan plan,
			HashMap<Object, Object> currentMap) {
		// currentMap.put(AgeBracketConstants.AGEBRACKET_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE,
		// new SBigDecimal(10));
		AggregationUtility
				.sumAgeBracketUtil(
						plan,
						currentMap,
						AgeBracketConstants.AGEBRACKET_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE);

	}

	// plan_Inforce_Agebanded_Premium_Step_A
	public void setPlan_Inforce_Agebanded_Premium_Step_A(Plan plan,
			HashMap<Object, Object> currentMap) {

		AggregationUtility
				.sumAgeBracketUtil(
						plan,
						currentMap,
						AgeBracketConstants.AGEBRACKET_RENEWAL_INFORCE_PREMIUM_COMPOSITE);

	}

	// plan_Inforce_Agebanded_Premium_Step_B

	public void setPlan_Inforce_Agebanded_Premium_Step_B(Plan plan,
			HashMap<Object, Object> currentMap) {

		AggregationUtility
				.sumAgeBracketUtil(
						plan,
						currentMap,
						AgeBracketConstants.AGEBRACKET_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE);

	}

	// plan_Table_K_Monthly_Premium_Step_1
	public void setPlan_Table_K_Monthly_Premium_Step_1(Plan plan,
			HashMap<Object, Object> currentMap) {

		AggregationUtility.sumAgeBracketUtil(plan, currentMap,
				AgeBracketConstants.AGEBRACKET_FINAL_PREMIUM);

	}

	// plan_BL_Exhibit_Estimated_Volume_Step_1 Tested
	public Plan setPlan_BL_Exhibit_Estimated_Volume_Step_1(Holding holding,
			Plan plan) {

		String planCompositeValue = (String) plan.getPlanMap().get(
				PlanConstants.PLAN_COMPOSITE);

		if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(planCompositeValue), "CompositeY")) {

			SBigDecimal plan_Total_Estimated_Volume__Composite_Only = (SBigDecimal) plan
					.getPlanMap()
					.get(PlanConstants.PLAN_TOTAL_ESTIMATED_VOLUME__COMPOSITE_ONLY);
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME_STEP_1,
					plan_Total_Estimated_Volume__Composite_Only);
		} else if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(planCompositeValue), "CompositeN")) {
			SBigDecimal plan_Estimated_Volume = (SBigDecimal) plan.getPlanMap()
					.get(PlanConstants.PLAN_ESTIMATED_VOLUME);
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME_STEP_1,
					plan_Estimated_Volume);
		} else {
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME_STEP_1,
					new SBigDecimal(-12345));
		}

		return plan;

	}

	// plan_BL_Exhibit_Monthly_Rates_Step_1 Tested
	public Plan setPlan_BL_Exhibit_Monthly_Rates_Step_1(Holding holding,
			Plan plan) {

		String planCompositeValue = (String) plan.getPlanMap().get(
				PlanConstants.PLAN_COMPOSITE);

		if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(planCompositeValue), "CompositeY")) {

			SBigDecimal plan_Composite_Rate_Step_2 = (SBigDecimal) plan
					.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2);
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_1,
					plan_Composite_Rate_Step_2);
		} else if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(planCompositeValue), "CompositeN")) {
			SBigDecimal plan_Payable_Rate_Step_5 = (SBigDecimal) plan
					.getPlanMap().get(PlanConstants.PLAN_PAYABLE_RATE_STEP_5);
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_1,
					plan_Payable_Rate_Step_5);
		}

		return plan;

	}

	// plan_BL_Exhibit_Monthly_Rates_Step_2 Tested
	public Plan setPlan_BL_Exhibit_Monthly_Rates_Step_2(Holding holding,
			Plan plan) {

		SBigDecimal plan_Version_28_UW_Box_Date_Check = (SBigDecimal) plan
				.getPlanMap().get(
						PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK);

		String planCompositeValue = (String) plan.getPlanMap().get(
				PlanConstants.PLAN_COMPOSITE);

		if (plan_Version_28_UW_Box_Date_Check != null
				&& plan_Version_28_UW_Box_Date_Check.doubleValue() == 0) {

			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_2,
					new SBigDecimal(0));
		} else if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(planCompositeValue), "CompositeY")) {
			SBigDecimal plan_Composite_Minimum_Rate = (SBigDecimal) plan
					.getPlanMap()
					.get(PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE);
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_2,
					plan_Composite_Minimum_Rate);
		} else if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(planCompositeValue), "CompositeN")) {
			SBigDecimal plan_Plan_Minimum_Rate = (SBigDecimal) plan
					.getPlanMap().get(PlanConstants.PLAN_PLAN_MINIMUM_RATE);
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_2,
					plan_Plan_Minimum_Rate);
		}

		return plan;

	}

	// plan_BL_Exhibit_Monthly_Rates_Step_3 Tested
	public Plan setPlan_BL_Exhibit_Monthly_Rates_Step_3(Holding holding,
			Plan plan) {

		SBigDecimal holding_Total_Lives_For_All_Plans = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS);

		String Rating_Type = (String) holding.getHoldingMap().get(
				HoldingConstants.RATING_TYPE);

		SBigDecimal plan_Initial_Inforce_Rate = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_INFORCE_RATE);

		SBigDecimal plan_Compsych_Rate = (SBigDecimal) plan
				.get(PlanConstants.PLAN_COMPSYCH_RATE);

		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_1);

		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_2 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_2);
		SBigDecimal plan_Version_28_UW_Box_Date_Check = (SBigDecimal) plan
				.getPlanMap().get(
						PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK);

		if (holding_Total_Lives_For_All_Plans != null
				&& holding_Total_Lives_For_All_Plans.doubleValue() == 0
				&& StringUtils
						.equalsIgnoreCase(StringUtils.trimToEmpty(Rating_Type),
								"Rating_Type_PIA")) {
			SBigDecimal Value = plan_Initial_Inforce_Rate
					.add(plan_Compsych_Rate);
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_3, Value);
		}

		else if ((plan_BL_Exhibit_Monthly_Rates_Step_1 != null
				&& plan_BL_Exhibit_Monthly_Rates_Step_2 != null && plan_BL_Exhibit_Monthly_Rates_Step_1
				.doubleValue() >= plan_BL_Exhibit_Monthly_Rates_Step_2
				.doubleValue())
				|| (plan_Version_28_UW_Box_Date_Check != null && plan_Version_28_UW_Box_Date_Check
						.doubleValue() == 0)) {
			SBigDecimal Value = plan_BL_Exhibit_Monthly_Rates_Step_1
					.add(plan_Compsych_Rate);
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_3, Value);
		} else {
			SBigDecimal Value = plan_BL_Exhibit_Monthly_Rates_Step_2
					.add(plan_Compsych_Rate);
			plan.getPlanMap().put(
					PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_3, Value);
		}

		return plan;
	}

	public static Object lookup(String factorTable, Object input1) {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("input1", input1);
		FactLookupUtility.getFactorLookup(factorTable + ".xls", hm);
		System.out.println(hm);
		return hm.get("output1");

	}

	public static Object lookup2(String factorTable, Object input1,
			Object input2) {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("input1", input1);
		hm.put("input2", input2);
		FactLookupUtility.getFactorLookup(factorTable + ".xls", hm);
		System.out.println(hm);
		return hm.get("output1");

	}

	// plan_BL_Exhibit__Monthly_Rate_RVP_Adjustment Tested Factor
	public Plan setPlan_BL_Exhibit__Monthly_Rate_RVP_Adjustment(
			Holding holding, Plan plan) {
		String Renewal = (String) holding.getHoldingMap().get(
				HoldingConstants.RENEWAL);
		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_1);
		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_3 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_3);
		SBigDecimal plan_Regional_VP_Adjustment_Ratio = (SBigDecimal) plan
				.get(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_RATIO);

		SBigDecimal value = (SBigDecimal) lookup(
				"BL_Comp_Window_Date_Check",
				holding.getHoldingMap().get(
						HoldingConstants.RATING_ENGINE_EFFECTIVE_DATE));

		if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(Renewal),
				"RenewalYes")) {
			plan.put(
					PlanConstants.PLAN_BL_EXHIBIT__MONTHLY_RATE_RVP_ADJUSTMENT,
					plan_BL_Exhibit_Monthly_Rates_Step_1);
		} else if (value != null && value.doubleValue() == 0) {
			plan.put(
					PlanConstants.PLAN_BL_EXHIBIT__MONTHLY_RATE_RVP_ADJUSTMENT,
					plan_BL_Exhibit_Monthly_Rates_Step_3);
		} else {
			SBigDecimal valueStep3 = plan_BL_Exhibit_Monthly_Rates_Step_3
					.multiply(new SBigDecimal(1)
							.subtract(plan_Regional_VP_Adjustment_Ratio));
			plan.put(
					PlanConstants.PLAN_BL_EXHIBIT__MONTHLY_RATE_RVP_ADJUSTMENT,
					valueStep3);
		}

		return plan;

	}

	// plan_BL_Exhibit__Monthly_Rate_Advocate_Adjustment Tested
	public Plan setPlan_BL_Exhibit__Monthly_Rate_Advocate_Adjustment(
			Holding holding, Plan plan) {

		String Renewal = (String) holding.getHoldingMap().get(
				HoldingConstants.RENEWAL);

		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_1);

		SBigDecimal plan_BL_Exhibit__Monthly_Rate_RVP_Adjustment = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT__MONTHLY_RATE_RVP_ADJUSTMENT);

		SBigDecimal plan_UW_Adjustment_Box_2_Ratio = (SBigDecimal) plan
				.get(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO);

		if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(Renewal),
				"RenewalYes")) {
			plan.put(
					PlanConstants.PLAN_BL_EXHIBIT__MONTHLY_RATE_ADVOCATE_ADJUSTMENT,
					plan_BL_Exhibit_Monthly_Rates_Step_1);
		} else {
			SBigDecimal value = plan_BL_Exhibit__Monthly_Rate_RVP_Adjustment
					.multiply(new SBigDecimal(1)
							.subtract(plan_UW_Adjustment_Box_2_Ratio));
			plan.put(
					PlanConstants.PLAN_BL_EXHIBIT__MONTHLY_RATE_ADVOCATE_ADJUSTMENT,
					value);
		}

		return plan;

	}

	// plan_BL_Exhibit_Monthly_Rates_Step_4 Tested Factor
	public Plan setPlan_BL_Exhibit_Monthly_Rates_Step_4(Holding holding,
			Plan plan) {
		String Renewal = (String) holding.getHoldingMap().get(
				HoldingConstants.RENEWAL);
		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_1);
		SBigDecimal plan_BL_Exhibit__Monthly_Rate_Advocate_Adjustment = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT__MONTHLY_RATE_ADVOCATE_ADJUSTMENT);
		SBigDecimal plan_Final_UW_Adjustment_Ratio = (SBigDecimal) plan
				.get(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_RATIO);

		SBigDecimal Value = (SBigDecimal) lookup(
				"BL_Comp_Window_Date_Check",
				holding.getHoldingMap().get(
						HoldingConstants.RATING_ENGINE_EFFECTIVE_DATE));
		if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(Renewal),
				"RenewalYes")) {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_4,
					plan_BL_Exhibit_Monthly_Rates_Step_1);
		} else if (Value != null && Value.doubleValue() == 0) {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_4,
					plan_BL_Exhibit__Monthly_Rate_Advocate_Adjustment);
		} else {
			SBigDecimal value = plan_BL_Exhibit__Monthly_Rate_Advocate_Adjustment
					.multiply(new SBigDecimal(1)
							.subtract(plan_Final_UW_Adjustment_Ratio));
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_4, value);
		}

		return plan;

	}

	// InitParam Tested
	public Plan setInitParam(Holding holding, Plan plan) {

		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_4 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_4);

		SBigDecimal plan_BL_Exhibit_Estimated_Volume_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME_STEP_1);

		plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5,
				plan_BL_Exhibit_Monthly_Rates_Step_4);
		plan.put(PlanConstants.PLAN_INITIAL_INFORCE_LIVES_NONAGEBANDED_STEP_1,
				new SBigDecimal(0));
		plan.put(PlanConstants.PLAN_INITIAL_MANUAL_VOLUME_NONAGEBANDED,
				plan_BL_Exhibit_Estimated_Volume_Step_1);
		plan.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_NONAGEBANDED_STEP_1,
				new SBigDecimal(0));
		plan.put(
				PlanConstants.PLAN_INITIAL_INFORCE_PREMIUM_NONAGEBANDED_STEP_1,
				new SBigDecimal(0));
		return plan;

	}

	// plan_Initial_Inforce_Volume_Renewal Tested
	public Plan setPlan_Initial_Inforce_Volume_Renewal(Holding holding,
			Plan plan) {

		String Renewal = (String) holding.getHoldingMap().get(
				HoldingConstants.RENEWAL);

		SBigDecimal plan_Initial_Inforce_Volume_NonAgeBanded_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_NONAGEBANDED_STEP_1);

		SBigDecimal plan_Initial_Manual_Volume_NonAgeBanded = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_MANUAL_VOLUME_NONAGEBANDED);

		if (StringUtils.equalsIgnoreCase(StringUtils.trimToEmpty(Renewal),
				"RenewalYes")) {
			plan.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_RENEWAL,
					plan_Initial_Inforce_Volume_NonAgeBanded_Step_1);
		} else {

			plan.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_RENEWAL,
					plan_Initial_Manual_Volume_NonAgeBanded);
		}

		return plan;

	}

	// Plan_Initial_Manual_Rate_NonAgeBanded tested
	public Plan setPlan_Initial_Manual_Rate_NonAgeBanded(Holding holding,
			Plan plan) {
		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_5 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5);

		plan.put(PlanConstants.PLAN_INITIAL_MANUAL_RATE_NONAGEBANDED,
				plan_BL_Exhibit_Monthly_Rates_Step_5);
		return plan;
	}

	// plan_Initial_Inforce_Renewal_Premium_NonAgeBanded_Step_2 tested
	public Plan setPlan_Initial_Inforce_Renewal_Premium_NonAgeBanded_Step_2(
			Holding holding, Plan plan) {

		String BL_Age_Banded = (String) plan.get(PlanConstants.BL_AGE_BANDED);

		SBigDecimal plan_Initial_Inforce_Volume_Renewal = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_RENEWAL);

		SBigDecimal plan_Initial_Inforce_Rate = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_INFORCE_RATE);

		if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(BL_Age_Banded), "BL_Age_Banded_No")) {
			SBigDecimal value = plan_Initial_Inforce_Volume_Renewal
					.multiply(plan_Initial_Inforce_Rate.divide(new SBigDecimal(
							1000)));

			plan.put(
					PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED_STEP_2,
					value);
		} else {

			plan.put(
					PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED_STEP_2,
					new SBigDecimal(0));
		}

		return plan;

	}

	// Plan_Initial_Inforce_Renewal_Premium_NonAgeBanded Tested
	public Plan setPlan_Initial_Inforce_Renewal_Premium_NonAgeBanded(
			Holding holding, Plan plan) {
		SBigDecimal plan_Initial_Inforce_Renewal_Premium_NonAgeBanded_Step_2 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED_STEP_2);

		plan.put(
				PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED,
				plan_Initial_Inforce_Renewal_Premium_NonAgeBanded_Step_2);
		return plan;
	}

	// plan_Initial_Manual_Premium_NonAgeBanded_Step_1 Tested
	public Plan setPlan_Initial_Manual_Premium_NonAgeBanded_Step_1(
			Holding holding, Plan plan) {

		String BL_Age_Banded = (String) plan.get(PlanConstants.BL_AGE_BANDED);

		SBigDecimal plan_Initial_Manual_Volume_NonAgeBanded = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_MANUAL_VOLUME_NONAGEBANDED);

		SBigDecimal plan_Initial_Manual_Rate_NonAgeBanded = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_MANUAL_RATE_NONAGEBANDED);

		if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(BL_Age_Banded), "BL_Age_Banded_No")) {
			SBigDecimal value = plan_Initial_Manual_Volume_NonAgeBanded
					.multiply(plan_Initial_Manual_Rate_NonAgeBanded
							.divide(new SBigDecimal(1000)));

			plan.put(
					PlanConstants.PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED_STEP_1,
					value);
		} else {

			plan.put(
					PlanConstants.PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED_STEP_1,
					new SBigDecimal(0));
		}

		return plan;

	}

	// plan_Initial_Manual_Premium_NonAgeBanded_Step_2 Tested
	public Plan setPlan_Initial_Manual_Premium_NonAgeBanded_Step_2(
			Holding holding, Plan plan) {

		String BL_Age_Banded = (String) plan.get(PlanConstants.BL_AGE_BANDED);

		SBigDecimal plan_Initial_Inforce_Volume_Renewal = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_RENEWAL);

		SBigDecimal plan_Initial_Manual_Rate_NonAgeBanded = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_MANUAL_RATE_NONAGEBANDED);

		if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(BL_Age_Banded), "BL_Age_Banded_No")) {
			SBigDecimal value = plan_Initial_Inforce_Volume_Renewal
					.multiply(plan_Initial_Manual_Rate_NonAgeBanded
							.divide(new SBigDecimal(1000)));

			plan.put(
					PlanConstants.PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED_STEP_2,
					value);
		} else {

			plan.put(
					PlanConstants.PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED_STEP_2,
					new SBigDecimal(0));
		}

		return plan;

	}

	// plan_Initial_Manual_Premium_NonAgeBanded Tested
	public Plan setPlan_Initial_Manual_Premium_NonAgeBanded(Holding holding,
			Plan plan) {
		SBigDecimal plan_Initial_Manual_Premium_NonAgeBanded_Step_2 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED_STEP_2);

		plan.put(PlanConstants.PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED,
				plan_Initial_Manual_Premium_NonAgeBanded_Step_2);
		return plan;
	}

	// plan_Initial_Inforce_Prem_All_AgeBanded
	public void setPlan_Initial_Inforce_Prem_All_AgeBanded(Plan plan,
			HashMap<Object, Object> currentMap) {

		AggregationUtility
				.sumAgeBracketUtil(
						plan,
						currentMap,
						AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED);

	}

	// plan_Initial_Manual_Prem_All_AgeBanded
	public void setPlan_Initial_Manual_Prem_All_AgeBanded(Plan plan,
			HashMap<Object, Object> currentMap) {

		AggregationUtility
				.sumAgeBracketUtil(
						plan,
						currentMap,
						AgeBracketConstants.AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED);

	}

	// plan_Initial_Inforce_Premium Tested
	public Plan setPlan_Initial_Inforce_Premium(Holding holding, Plan plan) {

		SBigDecimal holding_Total_Lives_For_All_Plans = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS);

		String Rating_Type = (String) holding.getHoldingMap().get(
				HoldingConstants.RATING_TYPE);
		if ((plan
				.get(PlanConstants.PLAN_INITIAL_INFORCE_LIVES_NONAGEBANDED_STEP_1) != null)
				&& (plan.get(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_NONAGEBANDED_STEP_1) != null)
				&& (plan.get(PlanConstants.PLAN_INITIAL_INFORCE_PREMIUM_NONAGEBANDED_STEP_1) != null)) {

			SBigDecimal plan_Initial_Inforce_Lives_NonAgeBanded_Step_1 = (SBigDecimal) plan
					.get(PlanConstants.PLAN_INITIAL_INFORCE_LIVES_NONAGEBANDED_STEP_1);

			SBigDecimal plan_Initial_Inforce_Volume_NonAgeBanded_Step_1 = (SBigDecimal) plan
					.get(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_NONAGEBANDED_STEP_1);

			SBigDecimal plan_Initial_Inforce_Premium_NonAgeBanded_Step_1 = (SBigDecimal) plan
					.get(PlanConstants.PLAN_INITIAL_INFORCE_PREMIUM_NONAGEBANDED_STEP_1);
			String BL_Age_Banded = (String) plan
					.get(PlanConstants.BL_AGE_BANDED);

			if (holding_Total_Lives_For_All_Plans.doubleValue() == 0
					&& StringUtils.equalsIgnoreCase(
							StringUtils.trimToEmpty(Rating_Type),
							"Rating_Type_PIA")) {

				plan.put(PlanConstants.PLAN_INITIAL_INFORCE_LIVES,
						plan_Initial_Inforce_Lives_NonAgeBanded_Step_1);
				plan.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME,
						plan_Initial_Inforce_Volume_NonAgeBanded_Step_1);
				if (StringUtils.equalsIgnoreCase(
						StringUtils.trimToEmpty(BL_Age_Banded),
						"BL_Age_Banded_Yes")) {
					plan.put(PlanConstants.PLAN_INITIAL_INFORCE_PREMIUM,
							plan_Initial_Inforce_Premium_NonAgeBanded_Step_1);
				}
			}
		}
		return plan;
	}

	// plan_BL_Exhibit_Non_Med_Max tested
	public Plan setPlan_BL_Exhibit_Non_Med_Max(Holding holding, Plan plan) {

		SBigDecimal plan_Non_Medical_Max = (SBigDecimal) plan
				.get(PlanConstants.PLAN_NON_MEDICAL_MAX);

		SBigDecimal plan_Guarantee_Issue = (SBigDecimal) plan
				.get(PlanConstants.PLAN_GUARANTEE_ISSUE);

		if (plan_Non_Medical_Max != null
				&& plan_Guarantee_Issue != null
				&& plan_Non_Medical_Max.doubleValue() <= plan_Guarantee_Issue
						.doubleValue()) {

			plan.put(PlanConstants.PLAN_BL_EXHIBIT_NON_MED_MAX,
					plan_Non_Medical_Max);
		} else {

			plan.put(PlanConstants.PLAN_BL_EXHIBIT_NON_MED_MAX,
					plan_Guarantee_Issue);
		}

		return plan;

	}

	// plan_BL_Exhibit_Total_Annual_Premium_Step1 TEsted
	public Plan setPlan_BL_Exhibit_Total_Annual_Premium_Step1(Holding holding,
			Plan plan) {

		String Composite = (String) plan.get(PlanConstants.PLAN_COMPOSITE);

		SBigDecimal holding_Age_Banded_Ratio = (SBigDecimal) holding
				.getHoldingMap().get(HoldingConstants.HOLDING_AGE_BANDED_RATIO);

		SBigDecimal holding_Annual_Premium_For_All_Plans__Composite_Only = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY);

		SBigDecimal plan_Table_K_Annual_Premium_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_TABLE_K_ANNUAL_PREMIUM_STEP_1);

		SBigDecimal plan_Annual_Premium_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_ANNUAL_PREMIUM_STEP_1);

		if (holding_Age_Banded_Ratio.compareTo(new SBigDecimal(1)) == 0) {

			plan.put(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM_STEP1,
					plan_Table_K_Annual_Premium_Step_1);
		} else if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(Composite), "CompositeY")) {

			plan.put(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM_STEP1,
					holding_Annual_Premium_For_All_Plans__Composite_Only);
		} else {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM_STEP1,
					plan_Annual_Premium_Step_1);

		}

		return plan;

	}

	// plan_Payable_Rate Tested
	public Plan setPlan_Payable_Rate(Holding holding, Plan plan) {

		SBigDecimal holding_Age_Banded_Ratio = (SBigDecimal) holding
				.getHoldingMap().get(HoldingConstants.HOLDING_AGE_BANDED_RATIO);

		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_5 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5);

		if (holding_Age_Banded_Ratio.compareTo(new SBigDecimal(1)) == 0) {

			plan.put(PlanConstants.PLAN_PAYABLE_RATE, new SBigDecimal(0));
		} else {
			plan.put(PlanConstants.PLAN_PAYABLE_RATE,
					plan_BL_Exhibit_Monthly_Rates_Step_5);

		}

		return plan;

	}

	// plan_Annual_Premium Tested
	public Plan setPlan_Annual_Premium(Holding holding, Plan plan) {

		SBigDecimal holding_Age_Banded_Ratio = (SBigDecimal) holding
				.getHoldingMap().get(HoldingConstants.HOLDING_AGE_BANDED_RATIO);

		SBigDecimal plan_Annual_Premium_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_ANNUAL_PREMIUM_STEP_1);

		if (holding_Age_Banded_Ratio.compareTo(new SBigDecimal(1)) == 0) {

			plan.put(PlanConstants.PLAN_ANNUAL_PREMIUM, new SBigDecimal(0));
		} else {
			plan.put(PlanConstants.PLAN_ANNUAL_PREMIUM,
					plan_Annual_Premium_Step_1);

		}

		return plan;

	}

	// plan_Composite_Rate Tested
	public Plan setPlan_Composite_Rate(Holding holding, Plan plan) {

		SBigDecimal holding_Age_Banded_Ratio = (SBigDecimal) holding
				.getHoldingMap().get(HoldingConstants.HOLDING_AGE_BANDED_RATIO);

		SBigDecimal plan_BL_Exhibit_Monthly_Rates_Step_5 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5);

		String Composite = (String) plan.get(PlanConstants.PLAN_COMPOSITE);

		if (holding_Age_Banded_Ratio.compareTo(new SBigDecimal(1)) == 0) {

			plan.put(PlanConstants.PLAN_COMPOSITE_RATE, new SBigDecimal(0));
		} else if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(Composite), "CompositeN")) {
			plan.put(PlanConstants.PLAN_COMPOSITE_RATE, new SBigDecimal(0));
		} else {
			plan.put(PlanConstants.PLAN_COMPOSITE_RATE,
					plan_BL_Exhibit_Monthly_Rates_Step_5);

		}

		return plan;

	}

	// plan_Monthly_Premium_For_RFP_Display Tested
	public Plan setPlan_Monthly_Premium_For_RFP_Display(Holding holding,
			Plan plan) {

		SBigDecimal holding_Age_Banded_Ratio = (SBigDecimal) holding
				.getHoldingMap().get(HoldingConstants.HOLDING_AGE_BANDED_RATIO);

		SBigDecimal plan_Monthly_Premium_For_RFP_Display_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY_STEP_1);

		if (holding_Age_Banded_Ratio.compareTo(new SBigDecimal(1)) == 0) {

			plan.put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY,
					new SBigDecimal(0));
		} else {
			plan.put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY,
					plan_Monthly_Premium_For_RFP_Display_Step_1);

		}

		return plan;

	}

	// plan_Monthly_Premium_For_All_Plans__Composite_Only Tested
	public Plan setplan_Monthly_Premium_For_All_Plans_Composite_Only(
			Holding holding, Plan plan) {

		SBigDecimal holding_Age_Banded_Ratio = (SBigDecimal) holding
				.getHoldingMap().get(HoldingConstants.HOLDING_AGE_BANDED_RATIO);

		SBigDecimal plan_Table_K_Monthly_Premium = (SBigDecimal) plan
				.get(PlanConstants.PLAN_TABLE_K_MONTHLY_PREMIUM);
		String Composite = (String) plan.get(PlanConstants.PLAN_COMPOSITE);

		SBigDecimal plan_Monthly_Premium_For_All_Plans__Composite_Only_Step_1 = (SBigDecimal) plan
				.get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1);

		if (holding_Age_Banded_Ratio.compareTo(new SBigDecimal(1)) == 0) {

			plan.put(
					PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
					plan_Table_K_Monthly_Premium);
		} else if (Composite == "CompositeN") {
			plan.put(
					PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
					new SBigDecimal(0));
		} else {
			plan.put(
					PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
					plan_Monthly_Premium_For_All_Plans__Composite_Only_Step_1);

		}

		return plan;

	}

	// Plan_Loop_7 Tested
	public void setPlan_Loop_7(Plan plan, Holding holding) {

		AggregationUtility
				.getHoldingPlanAggregation(
						holding,
						HoldingConstants.PLAN_LOOP_7,
						plan,
						PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
						RuleRatingConstants.ADD_OPERATOR);

	}

	// holding_Total_Annual_Prem_All_Plans Tested
	public void setHolding_Total_Annual_Prem_All_Plans(Plan plan,
			Holding holding) {

		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_ANNUAL_PREM_ALL_PLANS, plan,
				PlanConstants.PLAN_ANNUAL_PREMIUM,
				RuleRatingConstants.ADD_OPERATOR);

	}

	// holding_Total_Monthly_Prem_All_Plans Tested
	public void setHolding_Total_Monthly_Prem_All_Plans(Plan plan,
			Holding holding) {

		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_MONTHLY_PREM_ALL_PLANS, plan,
				PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY,
				RuleRatingConstants.ADD_OPERATOR);

	}

	// Plan_Loop_Rate_Disk_Total starts here
	public static Plan setPlanLoopParams(Holding holding, Plan plan) {
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS);
		plan.put(PlanConstants.PLAN_RATE_DISK_TOTAL_COVERED_VOLUME,
				holding_Total_Covered_Volume_For_All_Plans);

		SBigDecimal holding_Total_Lives_For_All_Plans = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS);
		plan.put(PlanConstants.PLAN_RATE_DISK_TOTAL_LIVES,
				holding_Total_Lives_For_All_Plans);

		SBigDecimal holding_Total_Annual_Prem_All_Plans = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_ANNUAL_PREM_ALL_PLANS);
		plan.put(PlanConstants.PLAN_RATE_DISK_TOTAL_ANNUAL_PREM,
				holding_Total_Annual_Prem_All_Plans);

		SBigDecimal holding_Total_Monthly_Prem_All_Plans = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_MONTHLY_PREM_ALL_PLANS);
		plan.put(PlanConstants.PLAN_RATE_DISK_TOTAL_MONTHLY_PREM,
				holding_Total_Monthly_Prem_All_Plans);

		return plan;

	}

	// Plan_Loop_Rate_Disk_Total Tested
	public void setPlan_Loop_Rate_Disk_Total(Plan plan, Holding holding) {

		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.PLAN_LOOP_RATE_DISK_TOTAL, plan,
				PlanConstants.PLAN_RATE_DISK_TOTAL_MONTHLY_PREM,
				RuleRatingConstants.ADD_OPERATOR);

	}

	// holding_Sum_Inforce_Prem_NonAgeBanded_All_Plans Tested
	public void setHolding_Sum_Inforce_Prem_NonAgeBanded_All_Plans(Plan plan,
			Holding holding) {

		AggregationUtility
				.getHoldingPlanAggregation(
						holding,
						HoldingConstants.HOLDING_SUM_INFORCE_PREM_NONAGEBANDED_ALL_PLANS,
						plan,
						PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED,
						RuleRatingConstants.ADD_OPERATOR);

	}

	// holding_Sum_Manual_Prem_NonAgeBanded_All_Plans Tested
	public void setHolding_Sum_Manual_Prem_NonAgeBanded_All_Plans(Plan plan,
			Holding holding) {

		AggregationUtility
				.getHoldingPlanAggregation(
						holding,
						HoldingConstants.HOLDING_SUM_MANUAL_PREM_NONAGEBANDED_ALL_PLANS,
						plan,
						PlanConstants.PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED,
						RuleRatingConstants.ADD_OPERATOR);

	}

	// holding_Sum_Inforce_Prem_AgeBanded_All_Plans Tested
	public void setHolding_Sum_Inforce_Prem_AgeBanded_All_Plans(Plan plan,
			Holding holding) {

		AggregationUtility
				.getHoldingPlanAggregation(
						holding,
						HoldingConstants.HOLDING_SUM_INFORCE_PREM_AGEBANDED_ALL_PLANS,
						plan,
						RuleRatingConstants.ADD_OPERATOR_KEY
								+ AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED,
						RuleRatingConstants.ADD_OPERATOR);

	}

	// holding_Sum_Manual_Prem_AgeBanded_All_Plans Tested
	public void setHolding_Sum_Manual_Prem_AgeBanded_All_Plans(Plan plan,
			Holding holding) {

		AggregationUtility
				.getHoldingPlanAggregation(
						holding,
						HoldingConstants.HOLDING_SUM_MANUAL_PREM_AGEBANDED_ALL_PLANS,
						plan,
						RuleRatingConstants.ADD_OPERATOR_KEY
								+ AgeBracketConstants.AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED,
						RuleRatingConstants.ADD_OPERATOR);

	}

	// holding_Initial_Inforce_Premium Tested
	public Holding setHolding_Initial_Inforce_Premium(Holding holding, Plan plan) {

		SBigDecimal holding_Sum_Inforce_Prem_AgeBanded_All_Plans = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_SUM_INFORCE_PREM_AGEBANDED_ALL_PLANS);

		SBigDecimal holding_Sum_Inforce_Prem_NonAgeBanded_All_Plans = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_SUM_INFORCE_PREM_NONAGEBANDED_ALL_PLANS);

		SBigDecimal value = holding_Sum_Inforce_Prem_AgeBanded_All_Plans
				.add(holding_Sum_Inforce_Prem_NonAgeBanded_All_Plans);

		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_INITIAL_INFORCE_PREMIUM, value);
		return holding;
	}

	// holding_Initial_Manual_Premium Tested
	public Holding setHolding_Initial_Manual_Premium(Holding holding, Plan plan) {

		SBigDecimal holding_Sum_Manual_Prem_AgeBanded_All_Plans = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_SUM_MANUAL_PREM_AGEBANDED_ALL_PLANS);

		SBigDecimal holding_Sum_Manual_Prem_NonAgeBanded_All_Plans = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_SUM_MANUAL_PREM_NONAGEBANDED_ALL_PLANS);

		SBigDecimal value = holding_Sum_Manual_Prem_AgeBanded_All_Plans
				.add(holding_Sum_Manual_Prem_NonAgeBanded_All_Plans);

		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_INITIAL_MANUAL_PREMIUM, value);
		return holding;
	}

	// holding_Inforce_to_Manual_Prem_Ratio tested
	public Holding setHolding_Inforce_to_Manual_Prem_Ratio(Holding holding,
			Plan plan) {

		SBigDecimal holding_Initial_Inforce_Premium = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_INITIAL_INFORCE_PREMIUM);

		SBigDecimal holding_Initial_Manual_Premium = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_INITIAL_MANUAL_PREMIUM);

		SBigDecimal value = holding_Initial_Inforce_Premium
				.divide(holding_Initial_Manual_Premium);

		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_INFORCE_TO_MANUAL_PREM_RATIO, value);
		return holding;
	}

	// holding_Rate_Action_RAT Tested
	public Holding setHolding_Rate_Action_RAT(Holding holding, Plan plan) {

		SBigDecimal Value = (SBigDecimal) lookup2(
				"RenewalRateActionTable",
				plan.get(PlanConstants.PLAN_EFFECTIVEDATE),
				holding.getHoldingMap().get(
						HoldingConstants.HOLDING_INFORCE_TO_MANUAL_PREM_RATIO));
		holding.put(HoldingConstants.HOLDING_RATE_ACTION_RAT, Value);

		return holding;

	}

	// holding_Rate_Action_Max_Step_1 Tested
	public Holding setHolding_Rate_Action_Max_Step_1(Holding holding, Plan plan) {

		SBigDecimal Value = (SBigDecimal) lookup2("RenewalNoCensusLoad",
				holding.getHoldingMap().get(HoldingConstants.RENEWAL),
				plan.get(PlanConstants.PLAN_EFFECTIVEDATE));

		SBigDecimal holding_Rate_Action_RAT = (SBigDecimal) holding
				.getHoldingMap().get(HoldingConstants.HOLDING_RATE_ACTION_RAT);

		SBigDecimal Result = (SBigDecimal) MathUtility.max(Value,
				holding_Rate_Action_RAT);

		holding.put(HoldingConstants.HOLDING_RATE_ACTION_MAX_STEP_1, Result);

		return holding;
	}

	// holding_Rate_Action_Max_Step_2 Tested
	public Plan setHolding_Rate_Action_Max_Step_2(Holding holding, Plan plan) {

		SBigDecimal holding_Total_Lives_For_All_Plans = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS);
		SBigDecimal holding_Rate_Action_Max_Step_1 = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_RATE_ACTION_MAX_STEP_1);

		if (holding_Total_Lives_For_All_Plans.compareTo(new SBigDecimal(1)) == 1) {

			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_RATE_ACTION_MAX_STEP_2,
					new SBigDecimal(0));
		} else {

			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_RATE_ACTION_MAX_STEP_2,
					holding_Rate_Action_Max_Step_1);

		}

		return plan;

	}

	// holding_Rate_Action_Max Tested
	public Plan setHolding_Rate_Action_Max(Holding holding, Plan plan) {

		SBigDecimal holding_Rate_Action_Max_Step_2 = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_RATE_ACTION_MAX_STEP_2);
		holding.getHoldingMap().put(HoldingConstants.HOLDING_RATE_ACTION_MAX,
				holding_Rate_Action_Max_Step_2);
		return plan;
	}

}
