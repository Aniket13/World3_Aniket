package com.pru.sparc.drools.basiclife;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;

import com.pru.sparc.drools.common.util.AggregationUtility;
import com.pru.sparc.drools.common.util.MathUtility;
import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Loop5 {

	public void executePlan(Holding holding, Plan plan) {
		try {
			if (holding != null && plan != null) {
				// set value for
				// plan_Coverage_Composite_Rate_Ignoring_Composite_Setting in
				// loop 5 of basic life
				setPlanCoverageCompositeRateIgnoringCompositeSetting(holding,
						plan);
				// set value for plan_Total_Lives_For_All_Plans__Composite_Only
				// & plan_Total_Estimated_Volume__Composite_Only in loop 5 of
				// basic life
				setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnly(
						holding, plan);
				// set value for
				// plan_Monthly_Premium_For_All_Plans__Composite_Only_Step_1 &
				// plan_Composite_Rate_Step1 in loop 5 of basic life
				setplanCompositeRateStep1WithCompositeY(holding, plan);
				// set value for plan_Composite_Rate_Step2 in loop 5 of basic
				// life
				setPlanCompositeRateStep2(holding, plan);

				// set value for plan_Composite_Rate_round_Step1,
				// plan_Composite_Rate_round_Step2,
				// plan_Composite_Rate_round_Step3 in loop 5 of basic life
				setRoundNearestForPlanCompositeRateRoundStep(holding, plan);
				// set value for plan_Composite_Rate_Step_2 or
				// plan_Composite_Rate_Step2 in loop5 of basic life
				setPlanCompositeRateStep2BasedRoundNearest(holding, plan);
				// set value for
				// plan_Composite_Minimum_Rate_Round_1,plan_Composite_Minimum_Rate_Round_2,plan_Composite_Minimum_Rate_Round_3
				// in loop 5 of basic life
				setPlanCompositeMinimumRateRound(holding, plan);
				// set value for plan_Composite_Minimum_Rate in loop5 of basic
				// life
				setPlanCompositeMinimumRate(plan);
				// set value for plan_Plan_Minimum_Rate_Round_1,
				// plan_Plan_Minimum_Rate_Round_2 and
				// plan_Plan_Minimum_Rate_Round_3 in loop 5 of basic life
				setplanPlanMinimumRateRound(holding, plan);
				// set value for plan_Plan_Minimum_Rate in loop 5 of basic life
				setPlanPlanMinimumRate(plan);
				// set value for plan_Average_Age in loop 5 of basic life
				setPlanAverageAge(holding, plan);

				// set value for plan_Percentage_Female__Step_1 in loop 5
				setPlanPercentageFemaleStep1(holding, plan);
				// set value for plan_Percentage_Female in loop 5
				setPlanPercentageFemale(holding, plan);

				// set value for plan_Age_Banded_Counter in loop 5
				setPlanAgeBandedCounter(holding, plan);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void executeAggregationPlan(Holding holding) {
		try {
			if (holding != null) {
				// set value for
				// holding_Coverage_Composite_Rate_Ignoring_Composite_Setting
				setHoldingCoverageCompositeRateIgnoringCompositeSetting(holding);
				// set value for holding_Age_Banded_Counter_Step_2
				setHoldingAgeBandedCounterStep2(holding);
				// set value for holding_Age_Banded_Ratio
				setholdingAgeBandedRatio(holding);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setPlanCoverageCompositeRateIgnoringCompositeSetting(
			Holding holding, Plan plan) {

		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS) != null){
			
			SBigDecimal holdingTotalCoveredVolumeForAllPlans = ((SBigDecimal) holding
					.getHoldingMap()
					.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS));
			
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_STEP1_IGNORING_COMPOSITE_SETTING,
					(MathUtility.divide(holdingTotalCoveredVolumeForAllPlans, new SBigDecimal(1000))));
			
			if(holding.getHoldingMap().get(
					HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM) != null && holdingTotalCoveredVolumeForAllPlans.doubleValue()!=0){
				
				plan.getPlanMap()
				.put(PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING,
						(MathUtility.divide(holding.getHoldingMap().get(
								HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM), plan.getPlanMap()
								.get(PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_STEP1_IGNORING_COMPOSITE_SETTING))));
				
			}else if(holdingTotalCoveredVolumeForAllPlans.doubleValue()==0){
				
				plan.getPlanMap()
				.put(PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING,
						new SBigDecimal(0));
			}else{
				
				plan.getPlanMap()
				.put(PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING,
						new SBigDecimal(-12345));
			}
				
			
		}else{
			
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING,
					new SBigDecimal(-12345));
		}
			// aggregation for
			// PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING
			if (plan.getPlanMap()
					.get(PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING) != null) {
				AggregationUtility
						.getHoldingPlanAggregation(
								holding,
								plan,
								PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING,
								RuleRatingConstants.ADD_OPERATOR);
			}
}

	

	public void setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnly(

	Holding holding, Plan plan) {
		String planCompositeValue = (String) plan.getPlanMap().get(
				PlanConstants.PLAN_COMPOSITE);
		if (planCompositeValue != null || planCompositeValue != "") {
			// check plan composite value
			if (StringUtils.equalsIgnoreCase(
					StringUtils.trimToEmpty(planCompositeValue), "CompositeN")) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,
								new SBigDecimal(0));
				plan.getPlanMap()
						.put(PlanConstants.PLAN_TOTAL_ESTIMATED_VOLUME__COMPOSITE_ONLY,
								new SBigDecimal(0));
			} else {
				if (holding
						.getHoldingMap()
						.get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY) != null){
					plan.getPlanMap()
					.put(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
					
				}
				
				if( holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY) != null) {					

					plan.getPlanMap()
							.put(PlanConstants.PLAN_TOTAL_ESTIMATED_VOLUME__COMPOSITE_ONLY,
									((SBigDecimal) holding
											.getHoldingMap()
											.get(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY)));
					}
			}
		}

	}

	public void setplanCompositeRateStep1WithCompositeY(Holding holding,
			Plan plan) {
		if (plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE) != null) {
			String planCompositeValue = (String) plan.getPlanMap().get(
					PlanConstants.PLAN_COMPOSITE);
			if (StringUtils.equalsIgnoreCase(
					StringUtils.trimToEmpty(planCompositeValue), "CompositeY")) {
				
				if ((holding.getHoldingMap()
						.get(HoldingConstants.HOLDING_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY)) != null){
					plan.getPlanMap()
					.put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY));
					
				}											
						
				if((holding.getHoldingMap()
								.get(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY) != null)
						&& (holding
								.getHoldingMap()
								.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMP_ONLY__INVERSE) != null)){
					
				plan.getPlanMap()
						.put(PlanConstants.PLAN_COMPOSITE_RATE_STEP1,
								((SBigDecimal) holding
										.getHoldingMap()
										.get(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY))
										.multiply((((SBigDecimal) holding
												.getHoldingMap()
												.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMP_ONLY__INVERSE))
												.multiply((new SBigDecimal(1000))
														.divide(new SBigDecimal(
																12))))));
				}
			} else {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1,
								new SBigDecimal(0));
				
				setPlanCompositeRateStep1WithCompositeN(holding, plan);
			}
		}
	}

	public void setPlanCompositeRateStep1WithCompositeN(Holding holding,
			Plan plan) {
		String planCompositeValue = (String) plan.getPlanMap().get(
				PlanConstants.PLAN_COMPOSITE);
		if (StringUtils.equalsIgnoreCase(
				StringUtils.trimToEmpty(planCompositeValue), "CompositeN")) {
			if (plan.getPlanMap().get(PlanConstants.PLAN_PAYABLE_RATE_STEP_5) != null) {
				SBigDecimal planPayableRateStep5 = (SBigDecimal) plan
						.getPlanMap().get(
								PlanConstants.PLAN_PAYABLE_RATE_STEP_5);
				plan.getPlanMap().put(PlanConstants.PLAN_COMPOSITE_RATE_STEP1,
						planPayableRateStep5);
			}
		} else {
			plan.getPlanMap().put(PlanConstants.PLAN_COMPOSITE_RATE_STEP1,
					new SBigDecimal(-12345));
		}

	}

	public void setPlanCompositeRateStep2(Holding holding, Plan plan) {
		if ((holding.getHoldingMap().get(
				HoldingConstants.HOLDING_COMPOSITE_MINIMUM_PREMIUM) != null)
				&& (plan.getPlanMap().get(
						PlanConstants.PLAN_COMPOSITE_RATE_STEP1) != null)
				&& (plan.getPlanMap().get(
						PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK) != null)) {
			SBigDecimal holdingCompositeMinimumPremium = (SBigDecimal) holding
					.getHoldingMap().get(
							HoldingConstants.HOLDING_COMPOSITE_MINIMUM_PREMIUM);

			SBigDecimal planCompositeRateStep1 = (SBigDecimal) plan
					.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP1);
			SBigDecimal planVersion28UwBoxDateCheck = ((SBigDecimal) plan
					.getPlanMap().get(
							PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK));
			if (holdingCompositeMinimumPremium != null
					&& planCompositeRateStep1 != null
					&& planVersion28UwBoxDateCheck != null) {
				if (MathUtility.compareSBigDecimal(holdingCompositeMinimumPremium, planCompositeRateStep1) == 1
						&& MathUtility.compareSBigDecimal(planVersion28UwBoxDateCheck,new SBigDecimal(
								1)) == 0) {
					plan.getPlanMap().put(
							PlanConstants.PLAN_COMPOSITE_RATE_STEP2,
							holdingCompositeMinimumPremium);
				} else {
					if (plan.getPlanMap().get(
							PlanConstants.PLAN_COMPOSITE_RATE_STEP1) != null) {
						plan.getPlanMap()
								.put(PlanConstants.PLAN_COMPOSITE_RATE_STEP2,
										(SBigDecimal) plan
												.getPlanMap()
												.get(PlanConstants.PLAN_COMPOSITE_RATE_STEP1));
					}
				}

			}
		}
	}

	public void setRoundNearestForPlanCompositeRateRoundStep(Holding holding,
			Plan plan) throws ParseException {
		if (plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2) != null) {
			SBigDecimal planCompositeRateStep2 = (SBigDecimal) plan
					.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2);
			SBigDecimal roundNearestValueForplanCompositeRateStep2 = setRoundNearest(
					planCompositeRateStep2, 3);
			if (holding.getHoldingMap().get(
					HoldingConstants.PROPOSALCREATIONDATE) != null) {
				String proposalEffectiveDateString = (String) holding
						.getHoldingMap().get(
								HoldingConstants.PROPOSALCREATIONDATE);
				if (new SimpleDateFormat("MM/dd/yyyy")
						.parse(proposalEffectiveDateString)
						.before(new SimpleDateFormat("MM/dd/yyyy")
								.parse(Loop5Constants.PlanCompositeRateRoundStep1EndDate))) {
					plan.getPlanMap().put(
							PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP1,
							roundNearestValueForplanCompositeRateStep2);
				} else if (new SimpleDateFormat("MM/dd/yyyy")
						.parse(proposalEffectiveDateString)
						.after(new SimpleDateFormat("MM/dd/yyyy")
								.parse(Loop5Constants.PlanCompositeRateRoundStep2StartDate))
						&& new SimpleDateFormat("MM/dd/yyyy")
								.parse(proposalEffectiveDateString)
								.before(new SimpleDateFormat("MM/dd/yyyy")
										.parse(Loop5Constants.PlanCompositeRateRoundStep2EndDate))) {
					
					SBigDecimal roundNearestValueForplanCompositeRateStep2_2 = setRoundNearest(
							planCompositeRateStep2, 2);
					
					
					plan.getPlanMap().put(
							PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP2,
							roundNearestValueForplanCompositeRateStep2_2);

				} else if (new SimpleDateFormat("MM/dd/yyyy")
						.parse(proposalEffectiveDateString)
						.after(new SimpleDateFormat("MM/dd/yyyy")
								.parse(Loop5Constants.PlanCompositeRateRoundStep3StartDate))) {
					plan.getPlanMap().put(
							PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP3,
							roundNearestValueForplanCompositeRateStep2);
				}
			}

		}
	}

	public void setPlanCompositeRateStep2BasedRoundNearest(Holding holding,
			Plan plan) {

		if (plan.getPlanMap()
				.get(PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP1) != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_COMPOSITE_RATE_STEP2,
					(SBigDecimal) plan.getPlanMap().get(
							PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP1));
		} else if (plan.getPlanMap().get(
				PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP2) != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_COMPOSITE_RATE_STEP2,
					(SBigDecimal) plan.getPlanMap().get(
							PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP2));

		} else if (plan.getPlanMap().get(
				PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP3) != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_COMPOSITE_RATE_STEP2,
					(SBigDecimal) plan.getPlanMap().get(
							PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP3));

		}

	}

	public void setPlanCompositeMinimumRateRound(Holding holding, Plan plan)
			throws ParseException {
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_COMPOSITE_MINIMUM_RATE_RATIO) != null
				&& plan.getPlanMap().get(
						PlanConstants.PLAN_COMPOSITE_RATE_STEP2) != null
				&& holding.getHoldingMap().get(
						HoldingConstants.PROPOSALCREATIONDATE) != null) {
			SBigDecimal holdingCompositeMinimumRateRatio = (SBigDecimal) holding
					.getHoldingMap()
					.get(HoldingConstants.HOLDING_COMPOSITE_MINIMUM_RATE_RATIO);
			SBigDecimal planCompositeRateStep2 = (SBigDecimal) plan
					.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2);

			String proposalEffectiveDateString = (String) holding
					.getHoldingMap().get(HoldingConstants.PROPOSALCREATIONDATE);
			if (new SimpleDateFormat("MM/dd/yyyy")
					.parse(proposalEffectiveDateString)
					.before(new SimpleDateFormat("MM/dd/yyyy")
							.parse(Loop5Constants.PlanCompositeMinimumRateRound1EndDate))) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE_ROUND_1,
						setRoundNearest(holdingCompositeMinimumRateRatio
								.multiply(planCompositeRateStep2), 3));
			} else {
				if (new SimpleDateFormat("MM/dd/yyyy")
						.parse(proposalEffectiveDateString)
						.after(new SimpleDateFormat("MM/dd/yyyy")
								.parse(Loop5Constants.PlanCompositeMinimumRateRound2StartDate))
						&& new SimpleDateFormat("MM/dd/yyyy")
								.parse(proposalEffectiveDateString)
								.before(new SimpleDateFormat("MM/dd/yyyy")
										.parse(Loop5Constants.PlanCompositeMinimumRateRound2EndDate))) {
					plan.getPlanMap().put(
							PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE_ROUND_2,
							setRoundNearest(holdingCompositeMinimumRateRatio
									.multiply(planCompositeRateStep2), 2));
				} else {
					if (new SimpleDateFormat("MM/dd/yyyy")
							.parse(proposalEffectiveDateString)
							.after(new SimpleDateFormat("MM/dd/yyyy")
									.parse(Loop5Constants.PlanCompositeMinimumRateRound3StartDate))) {
						plan.getPlanMap()
								.put(PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE_ROUND_3,
										setRoundNearest(
												holdingCompositeMinimumRateRatio
														.multiply(planCompositeRateStep2),
												3));
					}
				}

			}
		}
	}

	public void setPlanCompositeMinimumRate(Plan plan) {
		if (plan.getPlanMap().get(
				PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE_ROUND_3) != null) {
			SBigDecimal planCompositeMinimumRateRound3 = (SBigDecimal) plan
					.getPlanMap().get(
							PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE_ROUND_3);
			plan.getPlanMap().put(PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE,
					planCompositeMinimumRateRound3.setScale(3,SBigDecimal.ROUND_NEAREST));
		}
	}

	public void setplanPlanMinimumRateRound(Holding holding, Plan plan)
			throws ParseException {
		SBigDecimal holdingCompositeMinimumRateRatio = (SBigDecimal) holding
				.getHoldingMap().get(
						HoldingConstants.HOLDING_COMPOSITE_MINIMUM_RATE_RATIO);
		SBigDecimal planCompositeRateStep2 = (SBigDecimal) plan.getPlanMap()
				.get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2);

		String proposalEffectiveDateString = (String) holding.getHoldingMap()
				.get(HoldingConstants.PROPOSALCREATIONDATE);
		if (holdingCompositeMinimumRateRatio != null
				&& planCompositeRateStep2 != null) {
			if (new SimpleDateFormat("MM/dd/yyyy")
					.parse(proposalEffectiveDateString)
					.before(new SimpleDateFormat("MM/dd/yyyy")
							.parse(Loop5Constants.PlanPlanMinimumRateRound1EndDate))) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_PLAN_MINIMUM_RATE_ROUND_1,
						setRoundNearest(holdingCompositeMinimumRateRatio
								.multiply(planCompositeRateStep2), 3));
			} else {
				if (new SimpleDateFormat("MM/dd/yyyy")
						.parse(proposalEffectiveDateString)
						.after(new SimpleDateFormat("MM/dd/yyyy")
								.parse(Loop5Constants.PlanPlanMinimumRateRound2StartDate))
						&& new SimpleDateFormat("MM/dd/yyyy")
								.parse(proposalEffectiveDateString)
								.before(new SimpleDateFormat("MM/dd/yyyy")
										.parse(Loop5Constants.PlanPlanMinimumRateRound2EndDate))) {
					plan.getPlanMap().put(
							PlanConstants.PLAN_PLAN_MINIMUM_RATE_ROUND_2,
							setRoundNearest(holdingCompositeMinimumRateRatio
									.multiply(planCompositeRateStep2), 2));
				} else {
					if (new SimpleDateFormat("MM/dd/yyyy")
							.parse(proposalEffectiveDateString)
							.after(new SimpleDateFormat("MM/dd/yyyy")
									.parse(Loop5Constants.PlanPlanMinimumRateRound3StartDate))) {
						plan.getPlanMap()
								.put(PlanConstants.PLAN_PLAN_MINIMUM_RATE_ROUND_3,
										setRoundNearest(
												holdingCompositeMinimumRateRatio
														.multiply(planCompositeRateStep2),
												3));
					}
				}

			}
		}
	}

	public void setPlanPlanMinimumRate(Plan plan) {
		SBigDecimal planPlanMinimumRateRound3 = (SBigDecimal) plan.getPlanMap()
				.get(PlanConstants.PLAN_PLAN_MINIMUM_RATE_ROUND_3);
		plan.getPlanMap().put(PlanConstants.PLAN_PLAN_MINIMUM_RATE,
				planPlanMinimumRateRound3.setScale(3,SBigDecimal.ROUND_NEAREST));
	}

	public void setPlanAverageAge(Holding holding, Plan plan) {

		// TODO: Remove below for loop. Aggregation values will be available
		// from loop 1
		/*
		 * List<Person> people = (plan.getCensus().getListOfPeople()); if
		 * (people != null && people.size() > 0) { // People loop starts for
		 * (int j = 0; j < people.size(); j++) { Person person = (Person)
		 * people.get(j); AggregationUtility.aggregationUtil(plan, person,
		 * PersonConstants.PEOPLE_RETRIEVE_AGE,
		 * RuleRatingConstants.ADD_OPERATOR);
		 * AggregationUtility.aggregationUtil(plan, person,
		 * PersonConstants.PEOPLE_LIFE_COUNT, RuleRatingConstants.ADD_OPERATOR);
		 * 
		 * 
		 * } }
		 */

		SBigDecimal sumOfpeopleAge = (SBigDecimal) plan
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PersonConstants.PEOPLE_RETRIEVE_AGE);

		SBigDecimal totalNoOfPeople = (SBigDecimal) plan
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PersonConstants.PEOPLE_LIFE_COUNT);

		plan.getPlanMap().put(PlanConstants.PLAN_AVERAGE_AGE,
				sumOfpeopleAge.divide(totalNoOfPeople).setScale(0, SBigDecimal.ROUND_NEAREST));

	}

	public void setPlanPercentageFemaleStep1(Holding holding, Plan plan) {

		if (plan.get(RuleRatingConstants.ADD_OPERATOR_KEY
				+ PersonConstants.PEOPLE_COUNT_FEMALE_LIVES) != null) {
			SBigDecimal sumOfFemales = (SBigDecimal) holding
					.get(HoldingConstants.HOLDING_TOTAL_FEMALE_LIVES);
			plan.getPlanMap().put(PlanConstants.PLAN_PERCENTAGE_FEMALE__STEP_1,
					sumOfFemales);
		}

	}

	public void setPlanPercentageFemale(Holding holding, Plan plan) {
		if (plan.getPlanMap().get(PlanConstants.PLAN_PERCENTAGE_FEMALE__STEP_1) != null
				&& plan.getPlanMap()
						.get(PlanConstants.PLAN_TOTAL_LIVES_INVERSE) != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_PERCENTAGE_FEMALE,
					((SBigDecimal) plan.getPlanMap().get(
							PlanConstants.PLAN_PERCENTAGE_FEMALE__STEP_1))
							.multiply(((SBigDecimal) plan.getPlanMap().get(
									PlanConstants.PLAN_TOTAL_LIVES_INVERSE))));
		}
	}

	public void setPlanAgeBandedCounter(Holding holding, Plan plan) {
		String planBlAgeBanded = (String) plan.getPlanMap().get(
				PlanConstants.BL_AGE_BANDED);
		if (planBlAgeBanded != null) {
			if (StringUtils.equalsIgnoreCase(
					StringUtils.trimToEmpty(planBlAgeBanded),
					"BL_Age_Banded_Yes")) {
				plan.getPlanMap().put(PlanConstants.PLAN_AGE_BANDED_COUNTER,
						new SBigDecimal(1));
			} else {
				plan.getPlanMap().put(PlanConstants.PLAN_AGE_BANDED_COUNTER,
						new SBigDecimal(0));
			}
		} else {
			plan.getPlanMap().put(PlanConstants.PLAN_AGE_BANDED_COUNTER,
					new SBigDecimal(0));
		}
		if (plan.getPlanMap().get(PlanConstants.PLAN_AGE_BANDED_COUNTER) != null) {
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_AGE_BANDED_COUNTER,
					RuleRatingConstants.ADD_OPERATOR);
		}
	}

	public void setHoldingCoverageCompositeRateIgnoringCompositeSetting(
			Holding holding) {

		if (holding
				.getHoldingMap()
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING) != null) {
			SBigDecimal holdingCoverageCompositeRateIgnoringCompositeSetting = (SBigDecimal) holding
					.getHoldingMap()
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PlanConstants.PLAN_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING);
			if (holdingCoverageCompositeRateIgnoringCompositeSetting != null) {
				holding.getHoldingMap()
						.put(HoldingConstants.HOLDING_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING,
								holdingCoverageCompositeRateIgnoringCompositeSetting);
			}
		}
	}

	public void setHoldingAgeBandedCounterStep2(Holding holding) {

		if (holding.getHoldingMap().get(
				RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_AGE_BANDED_COUNTER) != null) {
			SBigDecimal planAgeBandedCounter = (SBigDecimal) holding
					.getHoldingMap().get(
							RuleRatingConstants.ADD_OPERATOR_KEY
									+ PlanConstants.PLAN_AGE_BANDED_COUNTER);
			if (planAgeBandedCounter != null) {
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_AGE_BANDED_COUNTER_STEP_2,
						planAgeBandedCounter);
			}
		}
	}

	public void setholdingAgeBandedRatio(Holding holding) {
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_AGE_BANDED_COUNTER_STEP_2) != null) {
			SBigDecimal holdingAgeBandedCounterStep2 = (SBigDecimal) holding
					.getHoldingMap().get(
							HoldingConstants.HOLDING_AGE_BANDED_COUNTER_STEP_2);
			SBigDecimal holdingTotalNumberOfPlans = (SBigDecimal) holding
					.getHoldingMap().get(
							HoldingConstants.HOLDING_TOTAL_NO_OF_PLANS);
			if (holdingAgeBandedCounterStep2 != null
					&& holdingTotalNumberOfPlans != null
					&& holdingTotalNumberOfPlans.doubleValue() > 0) {
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_AGE_BANDED_RATIO,
						holdingAgeBandedCounterStep2
								.divide(holdingTotalNumberOfPlans));
			}

		}

	}

	private SBigDecimal setRoundNearest(SBigDecimal bigDecimal, int position) {
		if (bigDecimal == null) {
			return null;
		} else {
			return bigDecimal.setScale(position, SBigDecimal.ROUND_NEAREST);
		}
	}

}
