package com.pru.sparc.drools.basiclife;

public final class Loop5Constants {
	public static final String PlanCompositeRateRoundStep1StartDate = "";
	public static final String PlanCompositeRateRoundStep1EndDate = "06/29/2002";
	public static final String PlanCompositeRateRoundStep2StartDate = "06/29/2002";
	public static  final String PlanCompositeRateRoundStep2EndDate = "10/11/2002";
	public static final String PlanCompositeRateRoundStep3StartDate = "10/11/2002";
	public static final String PlanCompositeRateRoundStep3EndDate = "";

	public static final String PlanCompositeMinimumRateRound1StartDate = "";
	public static final String PlanCompositeMinimumRateRound1EndDate = "06/29/2002";
	public static final String PlanCompositeMinimumRateRound2StartDate = "06/29/2002";
	public static final String PlanCompositeMinimumRateRound2EndDate = "10/11/2002";
	public static final String PlanCompositeMinimumRateRound3StartDate = "10/11/2002";
	public static final String PlanCompositeMinimumRateRound3EndDate = "";

	public static final String PlanPlanMinimumRateRound1StartDate = "";
	public static final String PlanPlanMinimumRateRound1EndDate = "06/29/2002";
	public static final String PlanPlanMinimumRateRound2StartDate = "06/29/2002";
	public static final String PlanPlanMinimumRateRound2EndDate = "10/11/2002";
	public static final String PlanPlanMinimumRateRound3StartDate = "10/11/2002";
	public static final String PlanPlanMinimumRateRound3EndDate = "";

}
