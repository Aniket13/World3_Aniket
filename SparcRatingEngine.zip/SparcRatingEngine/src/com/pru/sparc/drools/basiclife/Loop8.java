package com.pru.sparc.drools.basiclife;

import com.pru.sparc.drools.common.util.MathUtility;
import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.model.*;
import java.math.RoundingMode;

public class Loop8 {
	public void executePlan(Holding holding, Plan plan) {
		try {
			if (holding != null && plan != null) {
				
				setPlanFinalRateActionOutStep1(holding, plan);
				// setplan_Final_Rate_Action_Out_Step_2
				setPlanFinalRateActionOutStep2(plan);
				// plan_finalRate_Action_Out
				setPlanfinalRateActionOut(holding, plan);
				// set PLAN_OVERRIDE_75000_PREMIUM_POSTCALC
				// set PLAN_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC
				// set PLAN_COMPETETIVE_WINDOW_FOR_POSTCALC
				// set PLAN_TOTAL_LIVES_FOR_ALL_PLANS
				// set PLAN_MAXIMUM_EXHIBIT_VOLUME
				// set PLAN_MAXIMUM_EXHIBIT_PREMIUM
				// set PLAN_MAXIMUM_EXHIBIT_LIVES
				// set PLAN_COMPETITIVE_WINDOW_FOR_REPORTING
				// set PLAN_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING
				// set PLAN_CLAIMS_EXPERIENCE_FOR_REPORTING
				assignmentHoldingToPlan(holding, plan);
				// plan_Renewal_Production_Sum_Non_Age_Banded
				setPlanRenewalProductionSumNonAgeBanded(holding, plan);
				// plan_Renewal_Production_Sum_Age_Banded_Premium
				setPlanRenewalProductionSumAgeBandedPremium(plan);
				// plan_Renewal_Production_Sum_Inforce_Non_Age_Banded
				setPlanRenewalProductionSumInforceNonAgeBanded(holding, plan);

				setPlanRenewalProductionSumInforceAgeBanded(plan);

				setPlanRenewalPercentofManualSumPremiumsStep9(holding, plan);
				// plan_Renewal_Reporting_Step
				setPlanRenewalReportingStep(holding, plan);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setPlanFinalRateActionOutStep1(Holding holding, Plan plan) {
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING) != null
				&& holding
						.getHoldingMap()
						.get(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_7) != null) {
			if (holding.getHoldingMap().get(HoldingConstants.RENEWAL) != null) {
				
				if (((String) holding.getHoldingMap().get(
						HoldingConstants.RENEWAL)).equalsIgnoreCase("RenewalYes")) {
					SBigDecimal holdingTotalAnnualPremiumforReporting = (SBigDecimal) holding
							.getHoldingMap()
							.get(HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING);
					SBigDecimal holdingRenewalInforcePremiumStep7 = (SBigDecimal) holding
							.getHoldingMap()
							.get(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_7);
					if (holdingTotalAnnualPremiumforReporting != null
							&& holdingRenewalInforcePremiumStep7 != null
							&& MathUtility.compareSBigDecimal(holdingRenewalInforcePremiumStep7,new SBigDecimal("0")) > 0) {
						plan.getPlanMap()
								.put(PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_1,
										holdingTotalAnnualPremiumforReporting
												.divide(holdingRenewalInforcePremiumStep7));
					}
				} else {
					plan.getPlanMap().put(
							PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_1,
							new SBigDecimal(0));
				}
			}

		}
	}

	public void setPlanFinalRateActionOutStep2(Plan plan) {
		// setplan_Final_Rate_Action_Out_Step_2
		if (plan.getPlanMap().get(
				PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_1) != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_2,
					((SBigDecimal) plan.getPlanMap().get(
							PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_1))
							.subtract(new SBigDecimal(1)).setScale(3, SBigDecimal.ROUND_NEAREST));
		}

	}

	public void setPlanfinalRateActionOut(Holding holding, Plan plan) {
		// plan_finalRate_Action_Out
		if (holding.getHoldingMap().get(HoldingConstants.RENEWAL) != null) {
			if (!((String) holding.getHoldingMap().get(HoldingConstants.RENEWAL)).equalsIgnoreCase("RenewalYes")) {
				plan.getPlanMap().put(PlanConstants.PLAN_FINALRATE_ACTION_OUT,
						new SBigDecimal(0));
			} else if (plan.getPlanMap().get(
					PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_2) != null
					&& ((SBigDecimal) plan.getPlanMap().get(
							PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_2))
							.equals(new SBigDecimal(0))) {
				plan.getPlanMap().put(PlanConstants.PLAN_FINALRATE_ACTION_OUT,
						new SBigDecimal(0));
			} else if (holding.getHoldingMap().get(
					HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_7) != null
					&& (MathUtility.compareSBigDecimal((SBigDecimal) holding
							.getHoldingMap()
							.get(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_7)
							, new SBigDecimal("0"))) >= 0) {
				// TODO: Remove .doubleValue with CompareTo. As of now
				// BigDecimal CompareTo does not have >= functionality.
				plan.getPlanMap()
						.put(PlanConstants.PLAN_FINALRATE_ACTION_OUT,
								(SBigDecimal) (plan.getPlanMap()
										.get(PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_2)));
			} else {
				plan.getPlanMap().put(PlanConstants.PLAN_FINALRATE_ACTION_OUT,
						new SBigDecimal(0));
			}
		}
	}

	public void assignmentHoldingToPlan(Holding holding, Plan plan) {
		// set PLAN_OVERRIDE_75000_PREMIUM_POSTCALC
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_OVERRIDE_75000_PREMIUM_POSTCALC) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_OVERRIDE_75000_PREMIUM_POSTCALC,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_OVERRIDE_75000_PREMIUM_POSTCALC));
		}
		// set PLAN_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC));
		}
		// set PLAN_COMPETETIVE_WINDOW_FOR_POSTCALC
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_COMPETETIVE_WINDOW_FOR_POSTCALC,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING));
		}
		// set PLAN_TOTAL_LIVES_FOR_ALL_PLANS
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS));
		}
		// set PLAN_MAXIMUM_EXHIBIT_VOLUME
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_VOLUME) != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_MAXIMUM_EXHIBIT_VOLUME,
					(SBigDecimal) holding.getHoldingMap().get(
							HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_VOLUME));
		}
		// set PLAN_MAXIMUM_EXHIBIT_PREMIUM
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_PREMIUM) != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_MAXIMUM_EXHIBIT_PREMIUM,
					(SBigDecimal) holding.getHoldingMap().get(
							HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_PREMIUM));
		}
		// set PLAN_MAXIMUM_EXHIBIT_LIVES
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_LIVES) != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_MAXIMUM_EXHIBIT_LIVES,
					(SBigDecimal) holding.getHoldingMap().get(
							HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_LIVES));
		}
		// set PLAN_COMPETITIVE_WINDOW_FOR_REPORTING
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_COMPETITIVE_WINDOW_FOR_REPORTING,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING));
		}
		// set PLAN_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING));
		}
		// set PLAN_CLAIMS_EXPERIENCE_FOR_REPORTING
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_CLAIMS_EXPERIENCE_FOR_REPORTING) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_CLAIMS_EXPERIENCE_FOR_REPORTING,
							(SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_CLAIMS_EXPERIENCE_FOR_REPORTING));
		}
	}

	public void setPlanRenewalProductionSumNonAgeBanded(Holding holding,
			Plan plan) {
		// plan_Renewal_Production_Sum_Non_Age_Banded
		// get value of HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS from
		// Loop 7a
		if (holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS) != null) {
			SBigDecimal planRenewalPremiumNonAgeBanded = (SBigDecimal) holding
					.getHoldingMap()
					.get(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS);
			if (planRenewalPremiumNonAgeBanded != null) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_NON_AGE_BANDED,
								planRenewalPremiumNonAgeBanded);
			}
		}
	}

	public void setPlanRenewalProductionSumAgeBandedPremium(Plan plan) {
		// plan_Renewal_Production_Sum_Age_Banded_Premium
		if (plan.getPlanMap().get(
				PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED) != null) {
			SBigDecimal planRenewalProductionSumAgeBandedPremium = (SBigDecimal) plan
					.getPlanMap().get(
							PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED);
			if (planRenewalProductionSumAgeBandedPremium != null) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_AGE_BANDED_PREMIUM,
								planRenewalProductionSumAgeBandedPremium);
			}
		}
	}

	public void setPlanRenewalProductionSumInforceNonAgeBanded(Holding holding,
			Plan plan) {
		// Get Sum of plan_Initial_Inforce_Renewal_Premium_NonAgeBanded from
		// Loop 7
		// plan_Renewal_Production_Sum_Inforce_Non_Age_Banded
		/*
		 * if (plan.get( RuleRatingConstants.ADD_OPERATOR_KEY +
		 * PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED) !=
		 * null) { SBigDecimal planRenewalProductionSumInforceNonAgeBanded =
		 * (SBigDecimal) plan
		 * 
		 * .get(RuleRatingConstants.ADD_OPERATOR_KEY +
		 * PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED); if
		 * (planRenewalProductionSumInforceNonAgeBanded != null) {
		 * plan.getPlanMap()
		 * .put(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_NON_AGE_BANDED
		 * , planRenewalProductionSumInforceNonAgeBanded); } }
		 */
		/*
		 * if (holding .getHoldingMap()
		 * .get(HoldingConstants.HOLDING_SUM_INFORCE_PREM_NONAGEBANDED_ALL_PLANS
		 * ) != null) { SBigDecimal planRenewalProductionSumInforceNonAgeBanded
		 * = (SBigDecimal) holding .getHoldingMap()
		 * .get(HoldingConstants.HOLDING_SUM_INFORCE_PREM_NONAGEBANDED_ALL_PLANS
		 * ); if (planRenewalProductionSumInforceNonAgeBanded != null) {
		 * plan.getPlanMap()
		 * .put(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_NON_AGE_BANDED
		 * , planRenewalProductionSumInforceNonAgeBanded); } }
		 */
		if (holding
				.get(HoldingConstants.HOLDING_SUM_INFORCE_PREM_NONAGEBANDED_ALL_PLANS) != null) {
			SBigDecimal planRenewalProductionSumInforceNonAgeBanded = (SBigDecimal) holding
					.get(HoldingConstants.HOLDING_SUM_INFORCE_PREM_NONAGEBANDED_ALL_PLANS);
			if (planRenewalProductionSumInforceNonAgeBanded != null) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_NON_AGE_BANDED,
								planRenewalProductionSumInforceNonAgeBanded);
			}
		}
	}

	public void setPlanRenewalProductionSumInforceAgeBanded(Plan plan) {
		// Get Sum of agebracket_Initial_Inforce_Premium_AgeBanded from Loop 7
		// plan_Renewal_Production_Sum_Inforce_Age_Banded
		/*
		 * if (plan.get( RuleRatingConstants.ADD_OPERATOR_KEY +
		 * AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED) !=
		 * null) { SBigDecimal planRenewalProductionSumInforceNonAgeBanded =
		 * (SBigDecimal) plan
		 * 
		 * .get(RuleRatingConstants.ADD_OPERATOR_KEY +
		 * AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED); if
		 * (planRenewalProductionSumInforceNonAgeBanded != null) {
		 * plan.getPlanMap()
		 * .put(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_AGE_BANDED,
		 * planRenewalProductionSumInforceNonAgeBanded); } }
		 */
		if (plan.get(RuleRatingConstants.ADD_OPERATOR_KEY
				+ PlanConstants.PLAN_INITIAL_INFORCE_PREM_ALL_AGEBANDED) != null) {
			SBigDecimal planRenewalProductionSumInforceNonAgeBanded = (SBigDecimal) plan
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PlanConstants.PLAN_INITIAL_INFORCE_PREM_ALL_AGEBANDED);
			if (planRenewalProductionSumInforceNonAgeBanded != null) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_AGE_BANDED,
								planRenewalProductionSumInforceNonAgeBanded);
			}
		}
	}

	public void setPlanRenewalPercentofManualSumPremiumsStep9(Holding holding,
			Plan plan) {
		// plan_Renewal_Percent_of_Manual_Sum_Premiums_Step_9
		if (plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED) != null) {
			if (((String) plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_Yes")) {
				SBigDecimal holdingRenewalUWOverridePercentofManualStep5 = (SBigDecimal) holding
						.getHoldingMap()
						.get(HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_5);
				SBigDecimal holdingRenewalUWOverridePercentofManualStep6 = (SBigDecimal) holding
						.getHoldingMap()
						.get(HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_6);
				if (holdingRenewalUWOverridePercentofManualStep5 != null
						&& holdingRenewalUWOverridePercentofManualStep6 != null) {
					plan.getPlanMap()
							.put(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_SUM_PREMIUMS_STEP_9,
									holdingRenewalUWOverridePercentofManualStep5
											.add(holdingRenewalUWOverridePercentofManualStep6));
				}

			} else {
				SBigDecimal holdingRenewalUWOverridePercentofManualStep7 = (SBigDecimal) holding
						.getHoldingMap()
						.get(HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_7);
				SBigDecimal holdingRenewalUWOverridePercentofManualStep8 = (SBigDecimal) holding
						.getHoldingMap()
						.get(HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_8);
				if (holdingRenewalUWOverridePercentofManualStep7 != null
						&& holdingRenewalUWOverridePercentofManualStep8 != null) {
					plan.getPlanMap()
							.put(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_SUM_PREMIUMS_STEP_9,
									holdingRenewalUWOverridePercentofManualStep7
											.add(holdingRenewalUWOverridePercentofManualStep8));
				}
			}
		}
	}

	// Not Test
	public void setPlanRenewalReportingStep(Holding holding, Plan plan) {
		// plan_Renewal_Reporting_Step
		if (holding.getHoldingMap().get(HoldingConstants.RENEWAL) != null) {
			if (((String) holding.getHoldingMap().get(HoldingConstants.RENEWAL)).equalsIgnoreCase("RenewalYes")) {
				// set plan_Rate_Method_Out_for_Reporting
				setPlanRateMethodOutforReporting(holding, plan);
				// set plan_Rate_Method_Out_for_Reporting
				setPlanRateActionOutforReporting(holding, plan);
				// plan_Renewal_UW_Adjusted_Rate_for_Reporting
				setPlanRenewalUWAdjustedRateforReporting(holding, plan);
				// plan_Renewal_Percent_of_Manual
				setPlanRenewalPercentofManual(holding, plan);
				// plan_Renewal_Rate_for_Reporting
				setPlanRenewalRateforReporting(holding, plan);
				// plan_Renewal_Manual_Rate
				setPlanRenewalManualRate(holding, plan);
				// plan_Renewal_Manual_Premium
				setPlanRenewalManualPremium(holding, plan);
				// plan_Rate_Action_Ratio
				setPlanRateActionRatio(holding, plan);
				// plan_Est_Ann_Inf_Prem
				setPlanEstAnnInfPrem(holding, plan);
				// plan_Renewal_Production
				setPlanRenewalProduction(holding, plan);

				setPlanRenewalPlanChange(holding, plan);
				// plan_Renewal_Inforce_Rate_For_Reporting
				setPlanRenewalInforceRateForReporting(plan);

				setPlanRenewalAppealRateforReporting(plan);
				// plan_Renewal_Appeal_Annual_Premium_for_Reporting
				setPlanRenewalAppealAnnualPremiumforReporting(plan);
			}
		}
	}

	private void setPlanRateMethodOutforReporting(Holding holding, Plan plan) {
		// set plan_Rate_Method_Out_for_Reporting
		if (plan.getPlanMap().get(PlanConstants.PLAN_RATE_METHOD) != null) {

			SBigDecimal planRateMethod = (SBigDecimal) plan
					.get(PlanConstants.PLAN_RATE_METHOD);
			if (planRateMethod != null) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_RATE_METHOD_OUT_FOR_REPORTING,
						planRateMethod);
			}
		}
	}

	private void setPlanRateActionOutforReporting(Holding holding, Plan plan) {
		// set plan_Rate_Action_Out_for_Reporting
		if (plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2) != null) {

			SBigDecimal planRateActionOutStep2 = (SBigDecimal) plan
					.get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2);
			if (planRateActionOutStep2 != null) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_RATE_ACTION_OUT_FOR_REPORTING,
						planRateActionOutStep2.setScale(3, SBigDecimal.ROUND_NEAREST));
			}
		}
	}

	private void setPlanRenewalUWAdjustedRateforReporting(Holding holding,
			Plan plan) {
		// plan_Renewal_UW_Adjusted_Rate_for_Reporting
		if (plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED) != null) {
			if (((String) plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_Yes")) {
				if (plan.getPlanMap()
						.get(PlanConstants.PLAN_UW_OVERRIDE_ALL_AGE_BANDED_SINGLE_RATE) != null) {
					plan.getPlanMap()
							.put(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_RATE_FOR_REPORTING,
									((SBigDecimal) plan
											.get(PlanConstants.PLAN_UW_OVERRIDE_ALL_AGE_BANDED_SINGLE_RATE)).setScale(3, SBigDecimal.ROUND_NEAREST));
				}
			} else {
				if (plan.getPlanMap().get(
						PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_RATES) != null) {
					plan.getPlanMap()
							.put(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_RATE_FOR_REPORTING,
									((SBigDecimal) plan
											.get(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_RATES)).setScale(3, SBigDecimal.ROUND_NEAREST));
				}
			}
		}
	}

	private void setPlanRenewalPercentofManual(Holding holding, Plan plan) {
		// plan_Renewal_Percent_of_Manual
		if (holding.getHoldingMap().get(HoldingConstants.RENEWAL) != null) {
			if (((String) holding.getHoldingMap().get(HoldingConstants.RENEWAL)).equalsIgnoreCase("RenewalNo")) {

				plan.getPlanMap().put(
						PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL,
						new SBigDecimal(0));

			} else {
				if (plan.getPlanMap().get(
						PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES) != null
						&& holding.getHoldingMap().get(
								HoldingConstants.HOLDING_RENEWAL_MANUAL_RATE) != null
						&& (MathUtility.compareSBigDecimal((SBigDecimal) holding.getHoldingMap().get(
								HoldingConstants.HOLDING_RENEWAL_MANUAL_RATE)
								,new SBigDecimal("0"))) > 0) {
					plan.getPlanMap()
							.put(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL,
									((SBigDecimal) plan
											.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES))
											.divide(((SBigDecimal) holding
													.getHoldingMap()
													.get(HoldingConstants.HOLDING_RENEWAL_MANUAL_RATE))).setScale(3, SBigDecimal.ROUND_NEAREST));
				}
			}
		}
	}

	private void setPlanRenewalRateforReporting(Holding holding, Plan plan) {
		// plan_Renewal_Rate_for_Reporting
		if (plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED) != null) {
			if (((String) plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_No")) {
				if (plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_RATE_NONAGEBANDED) != null) {
					plan.getPlanMap()
							.put(PlanConstants.PLAN_RENEWAL_RATE_FOR_REPORTING,
									((SBigDecimal) plan
											.get(PlanConstants.PLAN_RENEWAL_RATE_NONAGEBANDED)).setScale(3, SBigDecimal.ROUND_NEAREST));
				}
			} else if (((String) plan.getPlanMap().get(
					PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_Yes")) {
				if (plan.getPlanMap()
						.get(PlanConstants.PLAN_RENEWAL_RATE_ALL_AGE_BANDED_SINGLE_RATE) != null) {
					plan.getPlanMap()
							.put(PlanConstants.PLAN_RENEWAL_RATE_FOR_REPORTING,
										((SBigDecimal) plan
												.get(PlanConstants.PLAN_RENEWAL_RATE_ALL_AGE_BANDED_SINGLE_RATE)).setScale(3, SBigDecimal.ROUND_NEAREST));
				}
			}
		}
	}

	private void setPlanRenewalManualRate(Holding holding, Plan plan) {
		// plan_Renewal_Manual_Rate
		if (holding.getHoldingMap().get(HoldingConstants.RENEWAL) != null) {
			if (((String) holding.getHoldingMap().get(HoldingConstants.RENEWAL)).equalsIgnoreCase("RenewalYes")) {
				if (plan.getPlanMap().get(
						PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_3) != null) {
					plan.getPlanMap()
							.put(PlanConstants.PLAN_RENEWAL_MANUAL_RATE,
									((SBigDecimal) plan
											.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_3)).setScale(3, SBigDecimal.ROUND_NEAREST));
				}

			} else {
				plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_MANUAL_RATE,
						new SBigDecimal(0));
			}
		}
	}

	private void setPlanRenewalManualPremium(Holding holding, Plan plan) {
		// plan_Renewal_Manual_Premium
		if (holding.getHoldingMap().get(HoldingConstants.RENEWAL) != null) {
			if (((String) holding.getHoldingMap().get(HoldingConstants.RENEWAL)).equalsIgnoreCase("RenewalYes")) {
				if (plan.getPlanMap().get(
						PlanConstants.PLAN_RENEWAL_MANUAL_RATE) != null
						&& plan.getPlanMap().get(
								PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME) != null) {
					SBigDecimal manualRate = (SBigDecimal) plan.getPlanMap()
							.get(PlanConstants.PLAN_RENEWAL_MANUAL_RATE);

					SBigDecimal estimatedVolume = (SBigDecimal) plan
							.getPlanMap()
							.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME);

					SBigDecimal value = (SBigDecimal) (new SBigDecimal(12)
							.multiply(manualRate)).multiply(estimatedVolume
							.divide(new SBigDecimal(1000)));
					
					plan.getPlanMap().put(
							PlanConstants.PLAN_RENEWAL_MANUAL_PREMIUM, value);

				}

			} else {
				plan.getPlanMap().put(
						PlanConstants.PLAN_RENEWAL_MANUAL_PREMIUM,
						new SBigDecimal(0));
			}
		}
	}

	private void setPlanRateActionRatio(Holding holding, Plan plan) {
		// plan_Rate_Action_Ratio
		if (plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2) != null
				&& (MathUtility.compareSBigDecimal((SBigDecimal) plan.getPlanMap().get(
						PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2)
						,new SBigDecimal("0"))) > 0) {
			if (plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT) != null) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RATE_ACTION_RATIO,
								((SBigDecimal) plan.getPlanMap().get(
										PlanConstants.PLAN_RATE_ACTION_OUT))
										.divide((SBigDecimal) plan
												.getPlanMap()
												.get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2)));
			}
		} else {
			plan.getPlanMap().put(PlanConstants.PLAN_RATE_ACTION_RATIO,
					new SBigDecimal(1));
		}
	}

	private void setPlanEstAnnInfPrem(Holding holding, Plan plan) {
		// plan_Est_Ann_Inf_Prem
		if (plan.getPlanMap().get(
				PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM) != null
				&& plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_EST_ANN_INF_PREM,
							((SBigDecimal) plan
									.getPlanMap()
									.get(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM)).divide(new SBigDecimal(
									1).add((SBigDecimal) plan.getPlanMap().get(
									PlanConstants.PLAN_RATE_ACTION_OUT))));
		}
	}

	private void setPlanRenewalProduction(Holding holding, Plan plan) {
		// plan_Renewal_Production
		if (holding.getHoldingMap().get(HoldingConstants.RENEWAL) != null) {
			if (((String) holding.getHoldingMap().get(HoldingConstants.RENEWAL)).equalsIgnoreCase("RenewalNo")) {

				plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_PRODUCTION,
						new SBigDecimal(0));

			} else if ((((SBigDecimal) plan.getPlanMap().get(
					PlanConstants.PLAN_RATE_ACTION_OUT))
					.compareTo(new SBigDecimal(-1)) != -1)) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_PRODUCTION,
								((SBigDecimal) plan
										.getPlanMap()
										.get(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM))
										.subtract((SBigDecimal) plan
												.getPlanMap()
												.get(PlanConstants.PLAN_RATE_ACTION_OUT)).setScale(2, SBigDecimal.ROUND_NEAREST));
			} else {
				plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_PRODUCTION,
						new SBigDecimal(0));
			}

		}
	}

	private void setPlanRenewalPlanChange(Holding holding, Plan plan) {
		// plan_Renewal_Plan_Change
		if (holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS) != null
				&& ((SBigDecimal) holding
						.getHoldingMap()
						.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS))
						.compareTo(new SBigDecimal(0)) > 0) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_RENEWAL_PLAN_CHANGE,
							((SBigDecimal) holding
									.getHoldingMap()
									.get(HoldingConstants.HOLDING_RENEWAL_PLAN_CHANGE_STEP_2))
									.divide(((SBigDecimal) holding
											.getHoldingMap()
											.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS))).setScale(3, SBigDecimal.ROUND_NEAREST));
		} else {
			plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_PLAN_CHANGE,
					new SBigDecimal(0));
		}
	}

	private void setPlanRenewalInforceRateForReporting(Plan plan) {
		// plan_Renewal_Inforce_Rate_For_Reporting
		if (plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED) != null) {
			if (((String) plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_No")) {

				plan.getPlanMap().put(
						PlanConstants.PLAN_RENEWAL_INFORCE_RATE_FOR_REPORTING,
						((SBigDecimal) plan.getPlanMap().get(
								PlanConstants.PLAN_INITIAL_INFORCE_RATE)).setScale(3, SBigDecimal.ROUND_NEAREST));

			} else if (((String) plan.getPlanMap().get(
					PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_Yes")) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_INFORCE_RATE_FOR_REPORTING,
								((SBigDecimal) plan
										.getPlanMap()
										.get(PlanConstants.PLAN_INFORCE_RATE_ALL_AGE_BANDED_SINGLE_RATE)).setScale(3, SBigDecimal.ROUND_NEAREST));
			}

		}
	}

	private void setPlanRenewalAppealRateforReporting(Plan plan) {
		// plan_Renewal_Appeal_Rate_for_Reporting
		if (plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED) != null) {
			if (((String) plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_Yes")) {

				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_APPEAL_RATE_FOR_REPORTING,
								((SBigDecimal) plan
										.getPlanMap()
										.get(PlanConstants.PLAN_APPEAL_ALL_AGE_BANDED_SINGLE_RATE)).setScale(3, SBigDecimal.ROUND_NEAREST));

			} else if (((String) plan.getPlanMap().get(
					PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_No")) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_APPEAL_RATE_FOR_REPORTING,
								((SBigDecimal) plan
										.getPlanMap()
										.get(PlanConstants.PLAN_RENEWAL_APPEAL_MONTHLY_RATES)).setScale(3, SBigDecimal.ROUND_NEAREST));
			}

		}
	}

	private void setPlanRenewalAppealAnnualPremiumforReporting(Plan plan) {
		// plan_Renewal_Appeal_Annual_Premium_for_Reporting
		if (plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED) != null) {
			if (((String) plan.getPlanMap().get(PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_Yes")) {

				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_APPEAL_ANNUAL_PREMIUM_FOR_REPORTING,
								new SBigDecimal(12)
										.multiply((SBigDecimal) plan
												.getPlanMap()
												.get(PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED)).setScale(2, SBigDecimal.ROUND_NEAREST));

			} else if (((String) plan.getPlanMap().get(
					PlanConstants.BL_AGE_BANDED)).equalsIgnoreCase("BL_Age_Banded_No")) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_RENEWAL_APPEAL_ANNUAL_PREMIUM_FOR_REPORTING,
								new SBigDecimal(12)
										.multiply((SBigDecimal) plan
												.getPlanMap()
												.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM)).setScale(2, SBigDecimal.ROUND_NEAREST));
			}

		}
		if (plan.getPlanMap().get(
				PlanConstants.PLAN_RENEWAL_APPEAL_ANNUAL_PREMIUM_FOR_REPORTING) != null) {
			plan.getPlanMap()
					.put(PlanConstants.PLAN_RENEWAL_REPORTING_STEP,
							(SBigDecimal) plan
									.getPlanMap()
									.get(PlanConstants.PLAN_RENEWAL_APPEAL_ANNUAL_PREMIUM_FOR_REPORTING));
		}
	}
}
