package com.pru.sparc.drools.basiclife;

import java.util.HashMap;

import com.pru.sparc.drools.common.util.AggregationUtility;
import com.pru.sparc.drools.common.util.FactLookupUtility;
import com.pru.sparc.drools.common.util.MathUtility;
import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.GenderConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import java.math.RoundingMode;

public class Loop6 {

	public void executeAgeBracket(Holding holding, Plan plan,
			HashMap ageBracketMap) {

		if (holding != null && plan != null && ageBracketMap != null) {
			//("BEGIN : setAgebracket_Preliminary_Rate_Step2a");
			setAgebracket_Preliminary_Rate_Step2a(ageBracketMap);
			//("END : setAgebracket_Preliminary_Rate_Step2a");
			//("BEGIN : setAgebracket_Preliminary_Rate_Step2b");
			setAgebracket_Preliminary_Rate_Step2b(ageBracketMap);
			//("END : setAgebracket_Preliminary_Rate_Step2b");
			//("BEGIN :setAgebracket_Preliminary_Rate_Step2c ");
			setAgebracket_Preliminary_Rate_Step2c(ageBracketMap);
			//("END : setAgebracket_Preliminary_Rate_Step2c");
			//("BEGIN : setAgebracket_Total_Lives_calc");
			setAgebracket_Total_Lives_calc(ageBracketMap);
			//("END : setAgebracket_Total_Lives_calc");
			//("BEGIN :setAgebracket_Total_Covered_Volume_calc ");
			setAgebracket_Total_Covered_Volume_calc(ageBracketMap);
			//("END : setAgebracket_Total_Covered_Volume_calc");
			//("BEGIN : setAgebracket_Adjustment_Ratio");
			setAgebracket_Adjustment_Ratio(holding, ageBracketMap);
			//("END : setAgebracket_Adjustment_Ratio");
			//("BEGIN : setAgebracket_Preliminary_Rate_calc");
			setAgebracket_Preliminary_Rate_calc(ageBracketMap);
			//("END : setAgebracket_Preliminary_Rate_calc");
			//("BEGIN : setAgebracket_Composite_Preliminary_Rate__Step1");
			setAgebracket_Composite_Preliminary_Rate__Step1(plan, ageBracketMap);
			//("END : setAgebracket_Composite_Preliminary_Rate__Step1");
			//("BEGIN : setAgebracket_TableIRate_calc");
			setAgebracket_TableIRate_calc(plan, ageBracketMap);
			//("END : setAgebracket_TableIRate_calc");
			//("BEGIN : setAgebracket_CrossTableI_calc");
			setAgebracket_CrossTableI_calc(plan, ageBracketMap);
			//("END : setAgebracket_CrossTableI_calc");
			//("BEGIN : setAgebracket_Composite_TableI__Step1");
			setAgebracket_Composite_TableI__Step1(plan, ageBracketMap);
			//("END :setAgebracket_Composite_TableI__Step1 ");
		}

	}

	public void executePlan(Holding holding, Plan plan) {
		if (holding != null && plan != null) {
			//("BEGIN : setAgeBracket_PreTableK_Loop");
			setAgeBracket_PreTableK_Loop(holding, plan);
			//("END : setAgeBracket_PreTableK_Loop");
			//("BEGIN :setPlan_Regional_VP_Adjustment_Ratio_Average ");
			setPlan_Regional_VP_Adjustment_Ratio_Average(holding, plan);
			//("END : setPlan_Regional_VP_Adjustment_Ratio_Average");
			//("BEGIN : setplan_UW_Adjustment_Box_2_Ratio_Average");
			
			setplan_UW_Adjustment_Box_2_Ratio_Average(holding, plan);
			//("END : setplan_UW_Adjustment_Box_2_Ratio_Average");
			//("BEGIN : setplan_Final_UW_Adjustment_Ratio_Average");
			setplan_Final_UW_Adjustment_Ratio_Average(holding, plan);
			//("END : setplan_Final_UW_Adjustment_Ratio_Average");
			//("BEGIN : setPlan_SBR2_Check_Date_For_PostCalc");
			setPlan_SBR2_Check_Date_For_PostCalc(holding, plan);
			//("END :setPlan_SBR2_Check_Date_For_PostCalc ");
			//("BEGIN : setAgebracket_Composite_Preliminary_Rate__Step1Aggregate");
			setAgebracket_Composite_Preliminary_Rate__Step1Aggregate(holding,
					plan);
			//("END : setAgebracket_Composite_Preliminary_Rate__Step1Aggregate");
			//("BEGIN : setAgebracket_CrossTableI_calc_Aggregat");
			setAgebracket_CrossTableI_calc_Aggregat(holding, plan);
			//("END : setAgebracket_CrossTableI_calc_Aggregat");
		}

	}

	public void executeHolding(Holding holding) {

		if (holding != null) {
			//("BEGIN :setHolding_Composite_Preliminary_Rate__Step2 ");
			
			setHolding_Composite_Preliminary_Rate__Step2(holding);
			//("END : setHolding_Composite_Preliminary_Rate__Step2");
			//("BEGIN : setHolding_Composite_Preliminary_Rate");
			
			setHolding_Composite_Preliminary_Rate(holding);
			//("END : setHolding_Composite_Preliminary_Rate");
			//("BEGIN : setHolding_Composite_TableI__Step2");
			setHolding_Composite_TableI__Step2(holding);
			//("END : setHolding_Composite_TableI__Step2");
			//("BEGIN : setHolding_Composite_TableI");
			
			setHolding_Composite_TableI(holding);
			//("END : setHolding_Composite_TableI");
			//("BEGIN : setHolding_Total_Cross_TableI_Step_1");
			
			setHolding_Total_Cross_TableI_Step_1(holding);
			//("END :setHolding_Total_Cross_TableI_Step_1 ");
			//("BEGIN :setHolding_Total_Cross_TableI ");
			
			setHolding_Total_Cross_TableI(holding);
			//("END : setHolding_Total_Cross_TableI");
			//("BEGIN : setHolding_Monthly_Premium");
			
			setHolding_Monthly_Premium(holding);
			//("END : setHolding_Monthly_Premium");
			
		}

	}

	public void setAgebracket_Preliminary_Rate_Step2a(HashMap ageBracketMap) {
		SBigDecimal agebracket_Preliminary_Rate_Step2a = null;
		HashMap<Object, Object> maleMap = (HashMap<Object, Object>) ageBracketMap
				.get(GenderConstants.MALE);
		if (maleMap == null) {
			agebracket_Preliminary_Rate_Step2a = new SBigDecimal(0);
		} else {
			SBigDecimal sumAge_Preliminary_Rate_Step1_MaleOnly = (SBigDecimal) ageBracketMap
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PersonConstants.AGE_PRELIMINARY_RATE_STEP1_MALEONLY);
			SBigDecimal totalMaleCount = (SBigDecimal) maleMap
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PersonConstants.PEOPLE_LIFE_COUNT);
			agebracket_Preliminary_Rate_Step2a = MathUtility.divide(
					sumAge_Preliminary_Rate_Step1_MaleOnly, totalMaleCount);
		}
		ageBracketMap.put(
				AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_STEP2A,
				agebracket_Preliminary_Rate_Step2a);
	}

	public void setAgebracket_Preliminary_Rate_Step2b(HashMap ageBracketMap) {
		SBigDecimal avgAge_Preliminary_Rate_Step1_FemaleOnly = null;
		SBigDecimal agebracket_Preliminary_Rate_Step2b = null;
		HashMap<Object, Object> femaleMap = (HashMap<Object, Object>) ageBracketMap
				.get(GenderConstants.FEMALE);
		if (femaleMap == null) {
			avgAge_Preliminary_Rate_Step1_FemaleOnly = new SBigDecimal(0);
		} else {
			SBigDecimal sumAge_Preliminary_Rate_Step1_FemaleOnly = (SBigDecimal) ageBracketMap
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PersonConstants.AGE_PRELIMINARY_RATE_STEP1_FEMALEONLY);
			SBigDecimal totalFemaleCount = (SBigDecimal) femaleMap
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PersonConstants.PEOPLE_LIFE_COUNT);
			avgAge_Preliminary_Rate_Step1_FemaleOnly = MathUtility.divide(
					sumAge_Preliminary_Rate_Step1_FemaleOnly, totalFemaleCount);
		}
		agebracket_Preliminary_Rate_Step2b = MathUtility
				.add((SBigDecimal) ageBracketMap
						.get(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_STEP2A),
						avgAge_Preliminary_Rate_Step1_FemaleOnly);
		ageBracketMap.put(
				AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_STEP2B,
				agebracket_Preliminary_Rate_Step2b);
	}

	public void setAgebracket_Preliminary_Rate_Step2c(HashMap ageBracketMap) {
		SBigDecimal agebracket_Preliminary_Rate_Step2c = MathUtility
				.multiply(
						(SBigDecimal) ageBracketMap
								.get(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_STEP2B),
						new SBigDecimal(2));
		ageBracketMap.put(
				AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_STEP2C,
				agebracket_Preliminary_Rate_Step2c);
	}

	public void setAgebracket_Total_Lives_calc(HashMap ageBracketMap) {
		SBigDecimal agebracket_Total_Lives_calc = (SBigDecimal) ageBracketMap
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PersonConstants.PEOPLE_LIFE_COUNT);
		ageBracketMap.put(AgeBracketConstants.AGEBRACKET_TOTAL_LIVES_CALC,
				agebracket_Total_Lives_calc);
	}

	public void setAgebracket_Total_Covered_Volume_calc(HashMap ageBracketMap) {
		SBigDecimal agebracket_Total_Covered_Volume_calc = (SBigDecimal) ageBracketMap
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PersonConstants.PEOPLE_COVERED_VOLUME);
		ageBracketMap.put(
				AgeBracketConstants.AGEBRACKET_TOTAL_COVERED_VOLUME_CALC,
				agebracket_Total_Covered_Volume_calc);
	}

	public void setAgebracket_Adjustment_Ratio(Holding holding,
			HashMap ageBracketMap) {

		SBigDecimal agebracket_Adjustment_Ratio = MathUtility
				.divide(holding
						.getHoldingMap()
						.get(HoldingConstants.HOLDING_COVERAGE_COMPOSITE_RATE_IGNORING_COMPOSITE_SETTING),
						holding.getHoldingMap()
								.get(HoldingConstants.HOLDING_NON_POOLED_MANUAL_RATE_STEP_3));

		ageBracketMap.put(AgeBracketConstants.AGEBRACKET_ADJUSTMENT_RATIO,
				agebracket_Adjustment_Ratio);
	}

	public void setAgebracket_Preliminary_Rate_calc(HashMap ageBracketMap) {

		SBigDecimal agebracket_Preliminary_Rate_calc = MathUtility
				.multiply(
						ageBracketMap
								.get(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_STEP2C),
						ageBracketMap
								.get(AgeBracketConstants.AGEBRACKET_ADJUSTMENT_RATIO));
		ageBracketMap.put(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_CALC,
				agebracket_Preliminary_Rate_calc.setScale(3, SBigDecimal.ROUND_NEAREST));
	}

	public void setAgebracket_Composite_Preliminary_Rate__Step1(Plan plan,
			HashMap ageBracketMap) {
		SBigDecimal agebracket_Composite_Preliminary_Rate__Step1 = MathUtility
				.multiply(
						ageBracketMap
								.get(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_CALC),
						ageBracketMap
								.get(AgeBracketConstants.AGEBRACKET_TOTAL_COVERED_VOLUME_CALC));
		ageBracketMap
				.put(AgeBracketConstants.AGEBRACKET_COMPOSITE_PRELIMINARY_RATE_STEP1,
						agebracket_Composite_Preliminary_Rate__Step1);

		AggregationUtility
				.sumAgeBracketUtil(
						plan,
						ageBracketMap,
						AgeBracketConstants.AGEBRACKET_COMPOSITE_PRELIMINARY_RATE_STEP1);
	}

	// FACTOR TABLE CALL
	public void setAgebracket_TableIRate_calc( Plan plan,
			HashMap ageBracketMap) {

		Holding holding=new Holding();
		// get factor table value
		String ageBracket = plan.getAgeBracket();
		SBigDecimal lowVal = SparcRatingUtil.getLowAgeVal(ageBracket);
		
		SBigDecimal value = (SBigDecimal) lookup1("tblIRate", lowVal);

		ageBracketMap
				.put(AgeBracketConstants.AGEBRACKET_TABLEIRATE_CALC, value.setScale(2,SBigDecimal.ROUND_NEAREST));
	}

	public void setAgebracket_CrossTableI_calc(Plan plan, HashMap ageBracketMap) {

		SBigDecimal agebracket_Preliminary_Rate_calc = (SBigDecimal) ageBracketMap
				.get(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE_CALC);
		SBigDecimal agebracket_TableIRate_calc = (SBigDecimal) ageBracketMap
				.get(AgeBracketConstants.AGEBRACKET_TABLEIRATE_CALC);

		if (agebracket_Preliminary_Rate_calc
				.compareTo(agebracket_TableIRate_calc) == 1) {
			ageBracketMap.put(AgeBracketConstants.AGEBRACKET_CROSSTABLEI_CALC,
					new SBigDecimal(1));
		} else {
			ageBracketMap.put(AgeBracketConstants.AGEBRACKET_CROSSTABLEI_CALC,
					new SBigDecimal(0));
		}

		AggregationUtility.sumAgeBracketUtil(plan, ageBracketMap,
				AgeBracketConstants.AGEBRACKET_CROSSTABLEI_CALC);

	}

	public void setAgebracket_Composite_TableI__Step1(Plan plan,
			HashMap ageBracketMap) {
		SBigDecimal agebracket_Composite_TableI__Step1 = MathUtility
				.multiply(
						ageBracketMap
								.get(AgeBracketConstants.AGEBRACKET_TABLEIRATE_CALC),
						ageBracketMap
								.get(AgeBracketConstants.AGEBRACKET_TOTAL_COVERED_VOLUME_CALC));
		ageBracketMap.put(
				AgeBracketConstants.AGEBRACKET_COMPOSITE_TABLEI_STEP1,
				agebracket_Composite_TableI__Step1);

		AggregationUtility.sumAgeBracketUtil(plan, ageBracketMap,
				AgeBracketConstants.AGEBRACKET_COMPOSITE_TABLEI_STEP1);
	}

	public void setAgeBracket_PreTableK_Loop(Holding holding, Plan plan) {

		SBigDecimal sumAgebracket_Composite_TableI__Step1 = (SBigDecimal) plan
				.getPlanMap()
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ AgeBracketConstants.AGEBRACKET_COMPOSITE_TABLEI_STEP1);

		plan.getPlanMap().put(PlanConstants.AGEBRACKET_PRETABLEK_LOOP,
				sumAgebracket_Composite_TableI__Step1);

		AggregationUtility.getHoldingPlanAggregation(holding, plan,
				RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.AGEBRACKET_PRETABLEK_LOOP,
				RuleRatingConstants.ADD_OPERATOR);
	}

	public void setPlan_Regional_VP_Adjustment_Ratio_Average(Holding holding,
			Plan plan) {

		SBigDecimal holding_Regional_VP_Adjustment_Ratio_Average = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_REGIONAL_VP_ADJUSTMENT_RATIO_AVERAGE);

		if (holding_Regional_VP_Adjustment_Ratio_Average != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_RATIO_AVERAGE,
					holding_Regional_VP_Adjustment_Ratio_Average.setScale(10,SBigDecimal.ROUND_NEAREST));
		}

	}

	public void setplan_UW_Adjustment_Box_2_Ratio_Average(Holding holding,
			Plan plan) {

		SBigDecimal holding_UW_Adjustment_Box_2_Ratio_Average = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_UW_ADJUSTMENT_BOX_2_RATIO_AVERAGE);

		if (holding_UW_Adjustment_Box_2_Ratio_Average != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO_AVERAGE,
					holding_UW_Adjustment_Box_2_Ratio_Average.setScale(10,SBigDecimal.ROUND_NEAREST));
		}

	}

	public void setplan_Final_UW_Adjustment_Ratio_Average(Holding holding,
			Plan plan) {

		SBigDecimal holding_Final_UW_Adjustment_Ratio_Average = (SBigDecimal) holding
				.getHoldingMap()
				.get(HoldingConstants.HOLDING_FINAL_UW_ADJUSTMENT_RATIO_AVERAGE);

		if (holding_Final_UW_Adjustment_Ratio_Average != null) {
			plan.getPlanMap().put(
					PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_RATIO_AVERAGE,
					holding_Final_UW_Adjustment_Ratio_Average.setScale(10,SBigDecimal.ROUND_NEAREST));
		}

	}

	public void setPlan_SBR2_Check_Date_For_PostCalc(Holding holding, Plan plan) {
		// get factor table value
		/*SBigDecimal compWindowDateCheckValue = (SBigDecimal) lookup(
				"BL_Comp_Window_Date_Check",
				holding.getHoldingMap().get(
						HoldingConstants.RATING_ENGINE_EFFECTIVE_DATE));*/
		SBigDecimal compWindowDateCheckValue = (SBigDecimal) lookup(
				"BL_Comp_Window_Date_Check",
				holding.getHoldingMap().get(
						HoldingConstants.RATING_ENGINE_EFFECTIVE_DATE));

		plan.getPlanMap().put(PlanConstants.PLAN_SBR2_CHECK_DATE_FOR_POSTCALC,
				compWindowDateCheckValue);
	}

	public void setAgebracket_Composite_Preliminary_Rate__Step1Aggregate(
			Holding holding, Plan plan) {

		AggregationUtility
				.getHoldingPlanAggregation(
						holding,
						plan,
						RuleRatingConstants.ADD_OPERATOR_KEY
								+ AgeBracketConstants.AGEBRACKET_COMPOSITE_PRELIMINARY_RATE_STEP1,
						RuleRatingConstants.ADD_OPERATOR);

	}

	public void setAgebracket_CrossTableI_calc_Aggregat(Holding holding,
			Plan plan) {
		AggregationUtility.getHoldingPlanAggregation(holding, plan,
				RuleRatingConstants.ADD_OPERATOR_KEY
						+ AgeBracketConstants.AGEBRACKET_CROSSTABLEI_CALC,
				RuleRatingConstants.ADD_OPERATOR);

	}
	
	// aggregation holding_Composite_Preliminary_Rate__Step2
	public void setHolding_Composite_Preliminary_Rate__Step2(Holding holding) {

		SBigDecimal SUM_agebracket_Composite_Preliminary_Rate__Step1 = (SBigDecimal) holding
				.getHoldingMap()
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ AgeBracketConstants.AGEBRACKET_COMPOSITE_PRELIMINARY_RATE_STEP1);

		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_COMPOSITE_PRELIMINARY_RATE_STEP2,
				SUM_agebracket_Composite_Preliminary_Rate__Step1);
	}

	// holding_Composite_Preliminary_Rate
	public void setHolding_Composite_Preliminary_Rate(Holding holding) {
		SBigDecimal holding_Composite_Preliminary_Rate = MathUtility
				.multiply(
						holding.getHoldingMap()
								.get(HoldingConstants.HOLDING_COMPOSITE_PRELIMINARY_RATE_STEP2),
						holding.getHoldingMap()
								.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_INVERSE));
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_COMPOSITE_PRELIMINARY_RATE,
				holding_Composite_Preliminary_Rate);
	}

	// aggregation step holding_Composite_TableI__Step2
	public void setHolding_Composite_TableI__Step2(Holding holding) {

		SBigDecimal SUM_agebracket_Composite_TableI__Step1 = (SBigDecimal) holding
				.getHoldingMap()
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ AgeBracketConstants.AGEBRACKET_COMPOSITE_TABLEI_STEP1);

		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_COMPOSITE_TABLEI_STEP2,
				SUM_agebracket_Composite_TableI__Step1);
	}

	// holding_Composite_TableI
	public void setHolding_Composite_TableI(Holding holding) {
		SBigDecimal holding_Composite_TableI = MathUtility
				.multiply(
						holding.getHoldingMap()
								.get(HoldingConstants.HOLDING_COMPOSITE_TABLEI_STEP2),
						holding.getHoldingMap()
								.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_INVERSE));
		holding.getHoldingMap().put(HoldingConstants.HOLDING_COMPOSITE_TABLEI,
				holding_Composite_TableI);
	}

	// aggregation step holding_Total_Cross_TableI_Step_1
	public void setHolding_Total_Cross_TableI_Step_1(Holding holding) {

		SBigDecimal SUM_agebracket_CrossTableI_calc = (SBigDecimal) holding
				.getHoldingMap()
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ AgeBracketConstants.AGEBRACKET_CROSSTABLEI_CALC);

		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_TOTAL_CROSS_TABLE_STEP_1,
				SUM_agebracket_CrossTableI_calc);
	}

	// holding_Total_Cross_TableI
	public void setHolding_Total_Cross_TableI(Holding holding) {
		SBigDecimal holding_Total_Cross_TableI = MathUtility.divide(
				holding.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_CROSS_TABLE_STEP_1),
				holding.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_NO_OF_PLANS));
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_TOTAL_CROSS_TABLEI,
				holding_Total_Cross_TableI);
	}

	// aggregation step holding_Monthly_Premium
	public void setHolding_Monthly_Premium(Holding holding) {

		SBigDecimal SUM_plan_Monthly_Premium_For_RFP_Display_Step_1 = (SBigDecimal) holding
				.getHoldingMap()
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY_STEP_1);

		holding.getHoldingMap().put(HoldingConstants.HOLDING_MONTHLY_PREMIUM,
				SUM_plan_Monthly_Premium_For_RFP_Display_Step_1);
	}

	public static Object lookup1(String factorTable, Object input1) {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("input1", input1);
		FactLookupUtility.getFactorLookup(factorTable + ".xls", hm);
		////(hm);
		return hm.get("output1");

	}
	public static Object lookup(String factorTable, Object input1) {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("input1", input1);
		FactLookupUtility.getFactorLookup(factorTable + ".xls", hm);
		////(hm);
		return hm.get("output1");

	}
}
