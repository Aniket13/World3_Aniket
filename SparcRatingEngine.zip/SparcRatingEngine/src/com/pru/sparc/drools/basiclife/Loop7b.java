package com.pru.sparc.drools.basiclife;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.AggregationUtility;
import com.pru.sparc.drools.common.util.MathUtility;
import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import java.math.RoundingMode;

public class Loop7b {
	
	final static Logger logger = LoggerFactory.getLogger(Loop7b.class);
	
	public void execute(final Holding holding){
		List plans= (List)(holding.getListOfPlans());
    	
    	//plan loop starts
    	for(int i = 0; i < plans.size(); i++){
    		
    		holding.setCount(i);
			Plan plan =(Plan)(holding.getListOfPlans().get(holding.getCount()));
			if(holding.getHoldingMap().get(HoldingConstants.HOLDING_RATE_ACTION_RAT)!=null){
				
				plan.getPlanMap().put(PlanConstants.PLAN_RATE_ACTION_TABLE_OUT, holding.getHoldingMap().get(HoldingConstants.HOLDING_RATE_ACTION_RAT));
			}			
			
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Rate_Action_Age_Banded_Overridden.xls",
    									"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_1.xls",
										"",new Object[]{holding});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_2.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Method.xls",
										"",new Object[]{holding});
			
			for (int j = 0; j< AgeBracketConstants.AGE_BRACKET_LIST.size();j++) {
				plan.setAgeBracket(AgeBracketConstants.AGE_BRACKET_LIST.get(j));
				String ageBracket = AgeBracketConstants.AGE_BRACKET_LIST.get(j);
				HashMap<Object,Object> currentMap = (HashMap)plan.getAgeBracketAggregationMap().get(ageBracket);
				logger.debug("AgeBracket map {}",currentMap);
				RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Agebracket_Renewal_Premium_AgeBanded_Out.xls",
											"",new Object[]{currentMap});
				RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Agebracket_Final_Rate_Step_3.xls",
											"",new Object[]{currentMap,plan});
				RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Agebracket_Final_Rate.xls",
											"",new Object[]{holding,plan,currentMap});
				RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Agebracket_Final_Premium_Override_Step_1.xls",
											"",new Object[]{holding,plan,currentMap});
				RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Agebracket_Renewal_Manual_Rate.xls",
											"",new Object[]{holding,plan,currentMap});
				RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Agebracket_Maximum_Composite_Agebanded_Rate_Step_1.xls",
											"",new Object[]{holding,plan,currentMap});
				
				//aggregated value of agebracket_Final_Premium_Override_Step_1
				AggregationUtility.sumAgeBracketUtil(plan,plan.getAgeBracketAggregationMap(),AgeBracketConstants.AGEBRACKET_FINAL_PREMIUM_OVERRIDE_STEP_1);
				//aggregated value of agebracket_Renewal_Premium_AgeBanded_Out
				AggregationUtility.sumAgeBracketUtil(plan,plan.getAgeBracketAggregationMap(),AgeBracketConstants.AGEBRACKET_RENEWAL_PREMIUM_AGE_BANDED_OUT);
			}
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Rate_NonAgeBanded_Out_Step_1.xls",
											"",new Object[]{holding,plan});
			
			for (int k = 0; k< AgeBracketConstants.AGE_BRACKET_LIST.size();k++) {
				plan.setAgeBracket(AgeBracketConstants.AGE_BRACKET_LIST.get(k));
				//HashMap<Object, Object> currentMap = plan.getAgeBracketAggregationMap().get(plan.getAgeBracket());
				
				//aggregated Max value of agebracket_Maximum_Composite_Agebanded_Rate_Step_1
				AggregationUtility.maxAgeBracketUtil(plan,plan.getAgeBracketAggregationMap(),AgeBracketConstants.AGEBRACKET_MAXIMUM_COMPOSITE_AGEBANDED_RATE_STEP_1);
				HashMap ageBracketMap = (HashMap)plan.getAgeBracketAggregationMap().get(AgeBracketConstants.AGE_BRACKET_LIST.get(k));
				RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Agebracket_Postcalc_Composite_Agebanded_Rate.xls",
											"",new Object[]{holding,plan,ageBracketMap});
				//aggregated value of agebracket_Postcalc_Composite_Agebanded_Rate
				AggregationUtility.sumAgeBracketUtil(plan,plan.getAgeBracketAggregationMap(),AgeBracketConstants.AGEBRACKET_POSTCALC_COMPOSITE_AGEBANDED_RATE);
			}
			
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Monthly_Rates_Step_2.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Monthly_Rates_Step_3.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Premium_NonAgeBanded_Out.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_UW_Adjusted_Monthly_Rates.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_UW_Adjusted_Monthly_Premium.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Percent_Of_Manual_Step_1_2.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_UW_Rate_Change_Percentage.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_UW_Rate_Change_Percentage_Output.xls",
										"",new Object[]{holding,plan});
			//plan_Renewal_Rate_NonAgeBanded_Out = plan_Renewal_Rate_NonAgeBanded is skipped. plan_Renewal_Rate_NonAgeBanded will be used instead of plan_Renewal_Rate_NonAgeBanded_Out
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_UW_Adjusted_Premium_NonAgeBanded_Out.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Appeal_Monthly_Rates.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Appeal_Rate_Change_Percentage.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Appeal_Rate_Change_Percentage_Output.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Appeal_Premium_Out.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Lives.xls",
										"",new Object[]{holding,plan});
			RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Volume.xls",
										"",new Object[]{holding,plan});
			
			//Loop7b objLoop7b = new Loop7b();
			//objLoop7b.executePlan(holding,plan);
			
			executePlan(holding,plan);
		}
    	
    	for(int l = 0; l  < plans.size(); l ++){
    		holding.setCount(l );
			Plan plan =(Plan)(holding.getListOfPlans().get(holding.getCount()));
			Loop7b objLoop7b = new Loop7b();
			objLoop7b.executePlanStep2(holding,plan);
    	}
	}
	
	public void executePlan(final Holding holding, final Plan plan) {
		setPlan_Field_Adjustment_Factor(holding,plan);
		setPlan_Field_Adjustment_Premium(holding,plan);
		setPlan_Regional_VP_Factor(holding,plan);
		setPlan_Regional_VP_Adjustment_Premium(holding,plan);
		setPlan_Total_Comp_Window_Discount_Applied(holding,plan);
		setPlan_Advocate_Adjustment_Factor(holding,plan);
		setPlan_Advocate_Adjustment_Premium(holding,plan);
		setPlan_Final_UW_Adjustment_Factor(holding,plan);
		setPlan_Final_UW_Adjustment_Premium(holding,plan);
		setPlan_BL_Exhibit_Monthly_Rates_Step_6(holding,plan);
		setPlan_BL_Exhibit_Monthly_Rates(holding,plan);
		setPlan_BL_Exhibit_Monthly_Premium_Step_1(holding,plan);
		setPlan_Renewal_Inforce_Premium_Composite(holding,plan);
		setPlan_Renewal_Inforce_Premium_Non_Composite(holding,plan);
		setPlan_BL_Exhibit_Monthly_Premium(holding,plan);
		setPlan_BL_Exhibit_Total_Annual_Premium(holding,plan);
		setPlan_BL_Composite_Premium_for_Reporting(holding,plan);
		setPlan_BL_Premium_for_Reporting(holding,plan);
		setPlan_Rate_Action_Out(holding,plan);
		setPlan_Rate_Change(holding, plan);
		setPlan_Maximum_Exhibit_Premium_Step_1(holding,plan);
		setPlan_Maximum_Exhibit_Volume_Step_1(holding,plan);
		setPlan_Maximum_Exhibit_Lives_Step_1(holding,plan);
		setPlan_Total_Reporting_Volume_Non_Composite_Step_1(holding,plan);
		setPlan_Total_Reporting_Lives_Non_Composite_Step_1(holding,plan);
		aggregateHoldingPlan(holding,plan);
	}
	
	public void executePlanStep2(final Holding holding, final Plan plan) {
		setHolding_Renewal_Manual_Rate(holding,plan);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_UW_ADJUSTED_AGE_BANDED_PREMIUM, plan, 
				RuleRatingConstants.ADD_OPERATOR_KEY + 
				AgeBracketConstants.AGEBRACKET_UW_OVERRIDE_PREMIUM_AGEBANDED,RuleRatingConstants.ADD_OPERATOR);
		
		setHolding_Total_Eligible_Lives_for_Reporting(holding,plan);
		setHolding_Claims_Experience_for_Reporting(holding,plan);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_PRODUCTION_SUM_NON_AGE_BANDED, plan, 
				PlanConstants.PLAN_RENEWAL_PREMIUM_NON_AGE_BANDED,RuleRatingConstants.ADD_OPERATOR);
		
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_PRODUCTION_SUM_AGE_BANDED_PREMIUM, plan, 
				RuleRatingConstants.ADD_OPERATOR_KEY + 
				AgeBracketConstants.AGEBRACKET_RENEWAL_PREMIUM_AGE_BANDED,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_PRODUCTION_SUM_INFORCE_NON_AGE_BANDED, plan, 
				PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_PRODUCTION_SUM_INFORCE_AGE_BANDED, plan, 
				RuleRatingConstants.ADD_OPERATOR_KEY + 
				AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING_STEP_1, plan, 
				PlanConstants.PLAN_BL_COMPOSITE_PREMIUM_FOR_REPORTING,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING_STEP_2, plan, 
				PlanConstants.PLAN_BL_PREMIUM_FOR_REPORTING,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING_STEP_3, plan, 
				PlanConstants.PLAN_TABLE_K_ANNUAL_PREMIUM,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC, plan, 
				PlanConstants.PLAN_TOTAL_MANUAL_PREMIUM_FOR_POSTCALC_STEP_1,RuleRatingConstants.ADD_OPERATOR);
		
		setHolding_Total_Estimated_Volume_for_Reporting(holding,plan);
		setHolding_Total_Annual_Premium_for_Reporting(holding,plan);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_OVERRIDE_75000_PREMIUM_POSTCALC, plan, 
				PlanConstants.PLAN_OVERRIDE_75000_POSTCALC_STEP_1,RuleRatingConstants.MAX_OPERATOR);
	}
	
	
	private void setHolding_Total_Estimated_Volume_for_Reporting(final Holding holding, final Plan plan) {
		holding.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_FOR_REPORTING,
				MathUtility.add((SBigDecimal)holding.get(HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_VOLUME), 
					(SBigDecimal)holding.get(HoldingConstants.HOLDING_TOTAL_VOLUME_FOR_REPORTING_NON_COMPOSITE)));
	}


	private void setHolding_Claims_Experience_for_Reporting(final Holding holding, final Plan plan) {
		holding.put(HoldingConstants.HOLDING_CLAIMS_EXPERIENCE_FOR_REPORTING,
				holding.get(HoldingConstants.HOLDING_EXPERIENCE_TIMES_CLAIMS_FOR_REPORTING));
	}

	private void setHolding_Renewal_Manual_Rate(final Holding holding, final Plan plan) {
		if (MathUtility.compareSBigDecimal((SBigDecimal)holding.get(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_FOR_REPORTING_1),new SBigDecimal("0")) > 0) {
			holding.put(HoldingConstants.HOLDING_RENEWAL_MANUAL_RATE, 
						MathUtility.divide(((SBigDecimal)holding.get(HoldingConstants.HOLDING_RENEWAL_MANUAL_RATE_STEP_1)), 
								MathUtility.divide(((SBigDecimal)holding.get(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_FOR_REPORTING_1)),
										new SBigDecimal("1000"))));
		} else {
			holding.put(HoldingConstants.HOLDING_RENEWAL_MANUAL_RATE,new SBigDecimal("0"));
		}
	}

	private void setHolding_Total_Eligible_Lives_for_Reporting(final Holding holding, final Plan plan) {
		holding.put(HoldingConstants.HOLDING_TOTAL_ELIGIBLE_LIVES_FOR_REPORTING,
					MathUtility.add((SBigDecimal)holding.get(HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_LIVES), 
						(SBigDecimal)holding.get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_REPORTING_NON_COMPOSITE)));	
	}
	
	
	private void setHolding_Total_Annual_Premium_for_Reporting(final Holding holding, final Plan plan) {
		if (MathUtility.compareSBigDecimal((SBigDecimal)holding.get(HoldingConstants.HOLDING_AGE_BANDED_RATIO),new SBigDecimal("1")) == 0) {
			holding.put(HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING, 
						MathUtility.multiply((SBigDecimal)holding.get(HoldingConstants.HOLDING_FINAL_PREMIUM_OVERRIDE_STEP_3), 
								 new SBigDecimal("12")));
		} else {
			holding.put(HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING, 
					MathUtility.add((SBigDecimal)holding.get(HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING_STEP_1), 
							(SBigDecimal)holding.get(HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING_STEP_2)));
		}		
	}
	
	public void aggregateHoldingPlan(final Holding holding, final Plan plan) {
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.PLAN_LOOP_7B_RENEWAL_OUT, plan, 
				PlanConstants.PLAN_TOTAL_REPORTING_LIVES_NON_COMPOSITE_STEP_1,RuleRatingConstants.ADD_OPERATOR);
		
		plan.put(PlanConstants.PLAN_FINAL_PREMIUM_OVERRIDE_STEP_2, 
					plan.get(RuleRatingConstants.ADD_OPERATOR_KEY + 
							AgeBracketConstants.AGEBRACKET_FINAL_PREMIUM_OVERRIDE_STEP_1));
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_FINAL_PREMIUM_OVERRIDE_STEP_3, plan, 
				PlanConstants.PLAN_FINAL_PREMIUM_OVERRIDE_STEP_2,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_2, plan, 
				PlanConstants.PLAN_RENEWAL_INFORCE_PREMIUM_COMPOSITE,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_3, plan, 
				PlanConstants.PLAN_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE,RuleRatingConstants.ADD_OPERATOR);
		
		
		plan.put(PlanConstants.PLAN_INFORCE_AGEBANDED_PREMIUM_STEP_A, 
				plan.get(RuleRatingConstants.ADD_OPERATOR_KEY + 
						AgeBracketConstants.AGEBRACKET_RENEWAL_INFORCE_PREMIUM_COMPOSITE));
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_4, plan, 
				PlanConstants.PLAN_INFORCE_AGEBANDED_PREMIUM_STEP_A,RuleRatingConstants.ADD_OPERATOR);
		
		
		plan.put(PlanConstants.PLAN_INFORCE_AGEBANDED_PREMIUM_STEP_B, 
				plan.get(RuleRatingConstants.ADD_OPERATOR_KEY + 
						AgeBracketConstants.AGEBRACKET_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE));
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_5, plan, 
				PlanConstants.PLAN_INFORCE_AGEBANDED_PREMIUM_STEP_B,RuleRatingConstants.ADD_OPERATOR);
		
		holding.put(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_6, new SBigDecimal("12"));
		
		setHolding_Renewal_Inforce_Premium_Step_7(holding,plan);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_PREMIUM, plan, 
				PlanConstants.PLAN_MAXIMUM_EXHIBIT_PREMIUM_STEP_1,RuleRatingConstants.MAX_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_LIVES, plan, 
				PlanConstants.PLAN_MAXIMUM_EXHIBIT_LIVES_STEP_1,RuleRatingConstants.MAX_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_VOLUME, plan, 
				PlanConstants.PLAN_MAXIMUM_EXHIBIT_VOLUME_STEP_1,RuleRatingConstants.MAX_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_MANUAL_RATE_STEP_1, plan, 
				PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY_STEP_1,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_5, plan, 
				PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_3,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_6, plan, 
				PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_4,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_7, plan, 
				PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_1,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_8, plan, 
				PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_FOR_REPORTING_1, plan, 
				PlanConstants.PLAN_ESTIMATED_VOLUME,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_LIVES_FOR_REPORTING_NON_COMPOSITE, plan, 
				PlanConstants.PLAN_TOTAL_REPORTING_LIVES_NON_COMPOSITE_STEP_1,RuleRatingConstants.ADD_OPERATOR);
		
		AggregationUtility.getHoldingPlanAggregation(holding,
				HoldingConstants.HOLDING_TOTAL_VOLUME_FOR_REPORTING_NON_COMPOSITE, plan, 
				PlanConstants.PLAN_TOTAL_REPORTING_VOLUME_NON_COMPOSITE_STEP_1,RuleRatingConstants.ADD_OPERATOR);
	}
	
	private void setHolding_Renewal_Inforce_Premium_Step_7(final Holding holding, final Plan plan) {
		SBigDecimal add1 = MathUtility.add(holding.get(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_2), 
				holding.get(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_3));
		SBigDecimal add2 = MathUtility.add(holding.get(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_4), 
			holding.get(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_5));
		SBigDecimal add3 = add1.add(add2);
		holding.put(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_7, 
			 MathUtility.multiply(holding.get(HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_6),add3));
	}


	private void setPlan_Field_Adjustment_Factor(final Holding holding, final Plan plan) {
		if(MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_FIELD_ADJUSTMENT_RATIO), new SBigDecimal("0")) != 0) {
			plan.put(PlanConstants.PLAN_FIELD_ADJUSTMENT_FACTOR,MathUtility.Subtract(new SBigDecimal("1"), 
							(SBigDecimal)plan.get(PlanConstants.PLAN_FIELD_ADJUSTMENT_RATIO)));
		} else {
			plan.put(PlanConstants.PLAN_FIELD_ADJUSTMENT_FACTOR, new SBigDecimal("1"));
		}	
	}
	
	private void setPlan_Field_Adjustment_Premium(final Holding holding, final Plan plan) {
		plan.put(PlanConstants.PLAN_FIELD_ADJUSTMENT_PREMIUM, 
				((SBigDecimal)MathUtility.multiply(plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME), 
				plan.get(PlanConstants.PLAN_FIELD_ADJUSTMENT_FACTOR))).setScale(3, SBigDecimal.ROUND_NEAREST));
	
	}
	
	private void setPlan_Regional_VP_Factor(final Holding holding, final Plan plan) {
		if(MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_COMPWINDOW_DATE_CHECK), new SBigDecimal("0")) == 0) {
			plan.put(PlanConstants.PLAN_REGIONAL_VP_FACTOR, new SBigDecimal("1"));
		} else if (((SBigDecimal)plan.get(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_RATIO)).doubleValue() != 0) {
			plan.put(PlanConstants.PLAN_REGIONAL_VP_FACTOR,MathUtility.Subtract(new SBigDecimal("1"), 
					(SBigDecimal)plan.get(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_RATIO)));
		} else {
			plan.put(PlanConstants.PLAN_REGIONAL_VP_FACTOR, new SBigDecimal("1"));
		}
	}
	
	private void setPlan_Regional_VP_Adjustment_Premium(final Holding holding, final Plan plan) {
		plan.put(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_PREMIUM, 
				((SBigDecimal)MathUtility.multiply(plan.get(PlanConstants.PLAN_REGIONAL_VP_FACTOR), 
				plan.get(PlanConstants.PLAN_FIELD_ADJUSTMENT_PREMIUM))).setScale(3, SBigDecimal.ROUND_NEAREST));
	}
	
	private void setPlan_Total_Comp_Window_Discount_Applied(final Holding holding, final Plan plan) {
		plan.put(
				PlanConstants.PLAN_TOTAL_COMP_WINDOW_DISCOUNT_APPLIED, 
				(new SBigDecimal(1).subtract(
						((SBigDecimal)plan.get(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_PREMIUM)).
						divide((SBigDecimal)plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME))
						)).setScale(3, SBigDecimal.ROUND_NEAREST)
				);
	}
	
	private void setPlan_Advocate_Adjustment_Factor(final Holding holding, final Plan plan) {
		if(MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO), new SBigDecimal("0")) != 0) {
			plan.put(PlanConstants.PLAN_ADVOCATE_ADJUSTMENT_FACTOR,MathUtility.Subtract(new SBigDecimal("1"), 
				(SBigDecimal)plan.get(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO)));
		} else {
			plan.put(PlanConstants.PLAN_ADVOCATE_ADJUSTMENT_FACTOR, new SBigDecimal("1"));
		}	
	}
	
	private void setPlan_Advocate_Adjustment_Premium(final Holding holding, final Plan plan) {
		plan.put(PlanConstants.PLAN_ADVOCATE_ADJUSTMENT_PREMIUM, 
				((SBigDecimal)MathUtility.multiply(plan.get(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_PREMIUM), 
				plan.get(PlanConstants.PLAN_ADVOCATE_ADJUSTMENT_FACTOR))).setScale(3, SBigDecimal.ROUND_NEAREST));
	}
	
	private void setPlan_Final_UW_Adjustment_Factor(final Holding holding, final Plan plan) {
		if(holding.get(HoldingConstants.RATING_ENGINE_EFFECTIVE_DATE) != null) {
			plan.put(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_FACTOR, new SBigDecimal(1));
		} else if (MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_RATIO),new SBigDecimal("0")) != 0) {
			plan.put(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_FACTOR,MathUtility.Subtract(new SBigDecimal("1"), 
					(SBigDecimal)plan.get(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_RATIO)));
		} else {
			plan.put(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_FACTOR, new SBigDecimal("1"));
		}
	}
	
	private void setPlan_Final_UW_Adjustment_Premium(final Holding holding, final Plan plan) {
		plan.put(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_PREMIUM, 
				((SBigDecimal)MathUtility.multiply(plan.get(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_FACTOR), 
				plan.get(PlanConstants.PLAN_ADVOCATE_ADJUSTMENT_PREMIUM))).setScale(3, SBigDecimal.ROUND_NEAREST));
	}
	
	private void setPlan_BL_Exhibit_Monthly_Rates_Step_6(final Holding holding, final Plan plan) {
		logger.debug("-> setPlan_BL_Exhibit_Monthly_Rates_Step_6");
		logger.debug("holding.get(HoldingConstants.RENEWAL): {}",holding.get(HoldingConstants.RENEWAL));
		logger.debug("plan.get(PlanConstants.PLAN_RENEWAL_APPEAL_MONTHLY_RATES): {}",plan.get(PlanConstants.PLAN_RENEWAL_APPEAL_MONTHLY_RATES));
		logger.debug("plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5): {}",plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5));
		if (StringUtils.equalsIgnoreCase((String) holding.get(HoldingConstants.RENEWAL), "RenewalYes")) {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6, 
							((SBigDecimal) plan.get(PlanConstants.PLAN_RENEWAL_APPEAL_MONTHLY_RATES)).setScale(3, SBigDecimal.ROUND_NEAREST));
		} else {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6, 
					((SBigDecimal) plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5)).setScale(3, SBigDecimal.ROUND_NEAREST));
		}
		logger.debug("plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6): {}",plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6));
		logger.debug("<- setPlan_BL_Exhibit_Monthly_Rates_Step_6");
	}
	
	private void setPlan_BL_Exhibit_Monthly_Rates(final Holding holding, final Plan plan) {
		logger.debug("-> setPlan_BL_Exhibit_Monthly_Rates");
		logger.debug("plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6): {}",plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6));
		if (MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6),new SBigDecimal("0")) < 0) {
			
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES, new SBigDecimal("0"));
		} else {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES, 
					((SBigDecimal) plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_6)).setScale(3, SBigDecimal.ROUND_NEAREST));
		}
		logger.debug("plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES): {}",plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES));
		logger.debug("<- setPlan_BL_Exhibit_Monthly_Rates");
	}
	
	
	private void setPlan_BL_Exhibit_Monthly_Premium_Step_1(final Holding holding, final Plan plan) {
		if (MathUtility.compareSBigDecimal((SBigDecimal)holding.get(HoldingConstants.HOLDING_AGE_BANDED_RATIO),new SBigDecimal("1")) == 0) {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM_STEP_1, 
				plan.get(PlanConstants.PLAN_TABLE_K_MONTHLY_PREMIUM_STEP_1));
		} else {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM_STEP_1,
				MathUtility.multiply((SBigDecimal)plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES), 
				MathUtility.divide((SBigDecimal)plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME), new SBigDecimal("1000"))));
		}
	}
	
	private void setPlan_Renewal_Inforce_Premium_Composite(final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeY") &&
				StringUtils.equalsIgnoreCase((String) holding.get(HoldingConstants.RENEWAL), "RenewalYes") &&
				StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.BL_AGE_BANDED), "BL_Age_Banded_No")) {
			plan.put(PlanConstants.PLAN_RENEWAL_INFORCE_PREMIUM_COMPOSITE,  
				MathUtility.multiply(plan.get(PlanConstants.PLAN_INITIAL_INFORCE_RATE), 
				MathUtility.divide(plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME), new SBigDecimal("1000")))); 
		} else {
			plan.put(PlanConstants.PLAN_RENEWAL_INFORCE_PREMIUM_COMPOSITE, new SBigDecimal("0"));
		}
	}
	
	private void setPlan_Renewal_Inforce_Premium_Non_Composite(final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeN") &&
				StringUtils.equalsIgnoreCase((String) holding.get(HoldingConstants.RENEWAL), "RenewalYes") &&
				StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.BL_AGE_BANDED), "BL_Age_Banded_No")) {
			plan.put(PlanConstants.PLAN_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE,  
					MathUtility.multiply(plan.get(PlanConstants.PLAN_INITIAL_INFORCE_RATE), 
					MathUtility.divide(plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME), new SBigDecimal("1000")))); 
		} else {
			plan.put(PlanConstants.PLAN_RENEWAL_INFORCE_PREMIUM_NON_COMPOSITE, new SBigDecimal("0"));
		}
	}
	
	private void setPlan_BL_Exhibit_Monthly_Premium(final Holding holding, final Plan plan) {
		
		if (StringUtils.equalsIgnoreCase((String) holding.get(HoldingConstants.RENEWAL), "RenewalYes") &&
			(MathUtility.compareSBigDecimal((SBigDecimal)holding.get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS),new SBigDecimal("0"))) == 0 &&
			StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.BL_AGE_BANDED), "BL_Age_Banded_Yes")) {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM,
					MathUtility.multiply(holding.get(HoldingConstants.HOLDING_RENEWAL_MONTHLY_CRLP), 
					MathUtility.add(plan.get(PlanConstants.PLAN_RENEWAL_RATE_ACTION), new SBigDecimal("1"))));
			
		} else if (StringUtils.equalsIgnoreCase((String) holding.get(HoldingConstants.RENEWAL), "RenewalYes") &&
				StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.BL_AGE_BANDED), "BL_Age_Banded_Yes")) {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM,plan.get(PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED));
			
		} else if (StringUtils.equalsIgnoreCase((String) holding.get(HoldingConstants.RATING_TYPE), "Rating_Type_PIA") &&
				(MathUtility.compareSBigDecimal((SBigDecimal)holding.get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS),new SBigDecimal("0"))) == 0 &&
				StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.BL_AGE_BANDED), "BL_Age_Banded_Yes")) {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM, plan.get(PlanConstants.PLAN_INITIAL_INFORCE_PREMIUM));
			
		} else if (StringUtils.equalsIgnoreCase((String) holding.get(HoldingConstants.RENEWAL), "RenewalYes") &&
				StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.BL_AGE_BANDED), "BL_Age_Banded_No")) {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM, plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM_STEP_1));
			
		} else {
			plan.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM, plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM_STEP_1));
		}
	}
	
	private void setPlan_BL_Exhibit_Total_Annual_Premium (final Holding holding, final Plan plan) {
		plan.put(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM, 
				MathUtility.multiply(plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM), new SBigDecimal("12")));
	}
	
	private void setPlan_BL_Composite_Premium_for_Reporting (final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeY")) {
			plan.put(PlanConstants.PLAN_BL_COMPOSITE_PREMIUM_FOR_REPORTING, 
					MathUtility.multiply(plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM), new SBigDecimal("12")));
		} else {
			plan.put(PlanConstants.PLAN_BL_COMPOSITE_PREMIUM_FOR_REPORTING, new SBigDecimal("0"));
		}
	}
	
	private void setPlan_BL_Premium_for_Reporting (final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeN")) {
			plan.put(PlanConstants.PLAN_BL_PREMIUM_FOR_REPORTING, 
					MathUtility.multiply(plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM), new SBigDecimal("12")));
		} else {
			plan.put(PlanConstants.PLAN_BL_PREMIUM_FOR_REPORTING, new SBigDecimal("0"));
		}
	}
	
	private void setPlan_Rate_Action_Out (final Holding holding, final Plan plan) {
		if (!StringUtils.equalsIgnoreCase((String) holding.get(HoldingConstants.RENEWAL), "RenewalYes")) {
			plan.put(PlanConstants.PLAN_RATE_ACTION_OUT, new SBigDecimal("0"));
		} else if ((MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_RATIO),new SBigDecimal("0"))) == 0 &&
				(MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO),new SBigDecimal("0"))) == 0) {
			plan.put(PlanConstants.PLAN_RATE_ACTION_OUT, plan.get(PlanConstants.PLAN_RENEWAL_RATE_ACTION));
		} else {
			plan.put(PlanConstants.PLAN_RATE_ACTION_OUT, plan.get(PlanConstants.PLAN_RENEWAL_RATE_ACTION));
		}
	}
	
	private void setPlan_Rate_Change (final Holding holding, final Plan plan) {
		if ((MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_RATE_ACTION_OUT), new SBigDecimal("0"))) == 0) {
			plan.put(PlanConstants.PLAN_RATE_CHANGE, new SBigDecimal("2"));
		} else if ((MathUtility.compareSBigDecimal((SBigDecimal)plan.get(PlanConstants.PLAN_RATE_ACTION_OUT), new SBigDecimal("0"))) > 0) {
			plan.put(PlanConstants.PLAN_RATE_CHANGE, new SBigDecimal("0"));
		} else {
			plan.put(PlanConstants.PLAN_RATE_CHANGE, new SBigDecimal("1"));
		}
	} 

	private void setPlan_Maximum_Exhibit_Premium_Step_1 (final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeY")) {
			plan.put(PlanConstants.PLAN_MAXIMUM_EXHIBIT_PREMIUM_STEP_1, plan.get(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM));
		} else {
			plan.put(PlanConstants.PLAN_MAXIMUM_EXHIBIT_PREMIUM_STEP_1, new SBigDecimal("0"));
		}
	}
	
	private void setPlan_Maximum_Exhibit_Volume_Step_1 (final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeY")) {
			plan.put(PlanConstants.PLAN_MAXIMUM_EXHIBIT_VOLUME_STEP_1, plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME));
		} else {
			plan.put(PlanConstants.PLAN_MAXIMUM_EXHIBIT_VOLUME_STEP_1, new SBigDecimal("0"));
		}
	}
	
	private void setPlan_Maximum_Exhibit_Lives_Step_1 (final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeY")) {
			plan.put(PlanConstants.PLAN_MAXIMUM_EXHIBIT_LIVES_STEP_1, plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
		} else {
			plan.put(PlanConstants.PLAN_MAXIMUM_EXHIBIT_LIVES_STEP_1, new SBigDecimal("0"));
		}
	}
	
	private void setPlan_Total_Reporting_Volume_Non_Composite_Step_1 (final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeN")) {
			plan.put(PlanConstants.PLAN_TOTAL_REPORTING_VOLUME_NON_COMPOSITE_STEP_1, plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME));
		} else {
			plan.put(PlanConstants.PLAN_TOTAL_REPORTING_VOLUME_NON_COMPOSITE_STEP_1, new SBigDecimal("0"));
		}
	}
	
	private void setPlan_Total_Reporting_Lives_Non_Composite_Step_1 (final Holding holding, final Plan plan) {
		if (StringUtils.equalsIgnoreCase((String) plan.get(PlanConstants.PLAN_COMPOSITE), "CompositeN")) {
			plan.put(PlanConstants.PLAN_TOTAL_REPORTING_LIVES_NON_COMPOSITE_STEP_1, plan.get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
		} else {
			plan.put(PlanConstants.PLAN_TOTAL_REPORTING_LIVES_NON_COMPOSITE_STEP_1, new SBigDecimal("0"));
		}
	}	
}
