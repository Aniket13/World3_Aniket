package com.pru.sparc.drools.basiclife;

import java.util.HashMap;

import com.pru.sparc.drools.common.util.DateUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.common.util.FactLookupUtility;

public class Loop3 {

	public void executeStatus(Holding holding, HashMap statusMap, Plan plan,
			String status) {
		setBL_Plan_Other_Non_Pooled_Adjustment(holding, statusMap, plan, status);
		setBL_Plan_Other_Pooled_Adjustment(holding, statusMap, plan, status);

	}

	public void setBL_Plan_Other_Non_Pooled_Adjustment(Holding holding,
			HashMap statusMap, Plan plan, String status) {
		if (DateUtil.isBetween(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("01/01/1990"), DateUtil
				.getDateMMddyyy("09/24/2001"))
				&& ((String) holding.get(HoldingConstants.PRU_VALUE))
						.equalsIgnoreCase(HoldingConstants.PRU_VALUE_YES)) {
			statusMap.put(HoldingConstants.STATUS_OTHER_NON_POOLED_ADJUSTMENT,
					new SBigDecimal("0.9"));

		} else if (DateUtil.isBetween(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("01/01/1990"), DateUtil
				.getDateMMddyyy("09/24/2001"))
				&& !((String) holding.get(HoldingConstants.PRU_VALUE))
						.equalsIgnoreCase(HoldingConstants.PRU_VALUE_YES)) {
			statusMap.put(HoldingConstants.STATUS_OTHER_NON_POOLED_ADJUSTMENT,
					new SBigDecimal("1.00"));

		} else if (DateUtil.isBetween(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("09/24/2001"), DateUtil
				.getDateMMddyyy("01/01/2002"))
				&& ((String) holding.get(HoldingConstants.PRU_VALUE))
						.equalsIgnoreCase(HoldingConstants.PRU_VALUE_YES)) {
			statusMap.put(HoldingConstants.STATUS_OTHER_NON_POOLED_ADJUSTMENT,
					new SBigDecimal("1.00"));

		} else if (DateUtil.isBetween(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("09/24/2001"), DateUtil
				.getDateMMddyyy("01/01/2002"))
				&& !((String) holding.get(HoldingConstants.PRU_VALUE))
						.equalsIgnoreCase(HoldingConstants.PRU_VALUE_YES)) {
			statusMap.put(HoldingConstants.STATUS_OTHER_NON_POOLED_ADJUSTMENT,
					new SBigDecimal("1.00"));

		} else if (DateUtil.isAfter(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("09/24/2002"))) {
			HashMap<String, Object> hm = new HashMap<String, Object>();
			hm.put("input1", status);
			hm.put("input2",
					plan.get(PlanConstants.PLAN_EFFECTIVEDATE_TIMESTAMP));
			hm.put("input3",
					holding.get(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS));
			hm.put("input4",
					holding.get(HoldingConstants.PROPOSALCREATIONDATE));
			FactLookupUtility.getFactorLookup("OtherNPAAdjustment.xls", hm);
			statusMap.put(HoldingConstants.STATUS_OTHER_NON_POOLED_ADJUSTMENT,
					hm.get("output1"));
		}
	}

	public void setBL_Plan_Other_Pooled_Adjustment(Holding holding,
			HashMap statusMap, Plan plan, String status) {
		if (DateUtil.isBetween(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("01/01/1990"), DateUtil
				.getDateMMddyyy("09/24/2001"))
				&& ((String) holding.get(HoldingConstants.PRU_VALUE))
						.equalsIgnoreCase(HoldingConstants.PRU_VALUE_YES)) {
			statusMap.put(HoldingConstants.STATUS_OTHER_POOLED_ADJUSTMENT,
					new SBigDecimal("0.9"));

		} else if (DateUtil.isBetween(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("01/01/1990"), DateUtil
				.getDateMMddyyy("09/24/2001"))
				&& !((String) holding.get(HoldingConstants.PRU_VALUE))
						.equalsIgnoreCase(HoldingConstants.PRU_VALUE_YES)) {
			statusMap.put(HoldingConstants.STATUS_OTHER_POOLED_ADJUSTMENT,
					new SBigDecimal("1.00"));
		} else if (DateUtil.isAfter(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("09/24/2001"))
				&& ((String) holding.get(HoldingConstants.PRU_VALUE))
						.equalsIgnoreCase(HoldingConstants.PRU_VALUE_YES)) {
			statusMap.put(HoldingConstants.STATUS_OTHER_POOLED_ADJUSTMENT,
					new SBigDecimal("1.00"));
		} else if (DateUtil.isAfter(DateUtil.getDateMMddyyy((String) holding
				.get(HoldingConstants.PROPOSALCREATIONDATE)), DateUtil
				.getDateMMddyyy("09/24/2001"))
				&& !((String) holding.get(HoldingConstants.PRU_VALUE))
						.equalsIgnoreCase(HoldingConstants.PRU_VALUE_YES)) {
			statusMap.put(HoldingConstants.STATUS_OTHER_POOLED_ADJUSTMENT,
					new SBigDecimal("1.00"));
		}
	}
}
