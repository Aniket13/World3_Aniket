package com.pru.sparc.drools.common.util;

public final class RuleRatingConstants {
	public static final int maxCommonRatingRuleCount = 25;
	public static final int maxCommonCensusAgeRange = 12;
	public static final int maxCommonRuleCount = 25;
	
	public static final String AGE_BRACKET_0_19_KEY = "0_19";
	public static final String AGE_BRACKET_20_24_KEY = "20_24";
	public static final String AGE_BRACKET_25_29_KEY = "25_29";
	public static final String AGE_BRACKET_30_34_KEY = "30_34";
	public static final String AGE_BRACKET_35_39_KEY = "35_39";
	public static final String AGE_BRACKET_40_44_KEY = "40_44";
	public static final String AGE_BRACKET_45_49_KEY = "45_49";
	public static final String AGE_BRACKET_50_54_KEY = "50_54";
	public static final String AGE_BRACKET_55_59_KEY = "55_59";
	public static final String AGE_BRACKET_60_64_KEY = "60_64";
	public static final String AGE_BRACKET_65_69_KEY = "65_69";
	public static final String AGE_BRACKET_70_74_KEY = "70_74";
	public static final String AGE_BRACKET_75_79_KEY = "75_79";
	public static final String AGE_BRACKET_80_84_KEY = "80_84";
	public static final String AGE_BRACKET_85_100_KEY = "85_100";
	
	public static final String ADD_OPERATOR = "SUM";
	public static final String MIN_OPERATOR = "MIN";
	public static final String MAX_OPERATOR = "MAX";
	
	public static final String ADD_OPERATOR_KEY = "SUM_";
	public static final String MIN_OPERATOR_KEY = "MIN_";
	public static final String MAX_OPERATOR_KEY = "MAX_";
	public static final String AVG_OPERATOR_KEY = "AVG_";
	
	public static final String GENDER_MALE_KEY = "male";
	public static final String GENDER_FEMALE_KEY = "female";
}
