package com.pru.sparc.drools.common.util;

import java.math.MathContext;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.model.SBigDecimal;

public final class SparcRatingUtil {

	final static Logger logger = LoggerFactory.getLogger(SparcRatingUtil.class);
	private SparcRatingUtil() {

	}

	public static SBigDecimal roundUp(SBigDecimal value) {
		value = new SBigDecimal(value.setScale(0, RoundingMode.UP).doubleValue());
		return value;
	}

	public static SBigDecimal roundDown(SBigDecimal value) {
		value = new SBigDecimal(value.setScale(0, RoundingMode.DOWN).doubleValue());
		return value;
	}

	public static SBigDecimal roundNearest(final SBigDecimal input){
		return new SBigDecimal(input.round(
				new MathContext(
						input.toBigInteger().toString().length(),
						RoundingMode.HALF_UP
						)
				).doubleValue());
	}

	/*public static SBigDecimal getRemainder(final SBigDecimal input, final SBigDecimal divisor){
	    return new SBigDecimal(input.remainder(divisor).doubleValue());
	}*/

	public static SBigDecimal divideByRoundDown(final SBigDecimal input, final SBigDecimal divisor){
		return new SBigDecimal(input.divide(divisor,RoundingMode.DOWN).doubleValue());
	}

	/*public static SBigDecimal divideBy(final SBigDecimal input, final SBigDecimal divisor){
		return new SBigDecimal(input.divide(divisor).doubleValue());
	}*/

	public static SBigDecimal divideByRoundUp(final SBigDecimal input, final SBigDecimal divisor){
		return new SBigDecimal(input.divide(divisor,RoundingMode.UP).doubleValue());
	}

	public static void showMap(Map lookup) {
		logger.debug("->Start printing lookup");
		if (lookup != null) {
			Iterator it = lookup.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				logger.debug("Key : {}| Value: {}", key, lookup.get(key));
			}
			logger.debug("<-End printing lookup");

		} else {
			logger.debug("<-Cannot print as map is null");
		}
	}

	/*public static SBigDecimal multiply(final SBigDecimal input, final SBigDecimal divisor){
	    return new SBigDecimal(input.multiply(divisor).doubleValue());
	}*/

	public static SBigDecimal getLowAgeVal(String ageBracket)
	{
		HashMap<Object,SBigDecimal> lowAge = new HashMap<Object,SBigDecimal>();
		lowAge.put(RuleRatingConstants.AGE_BRACKET_0_19_KEY  , new SBigDecimal(0));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_20_24_KEY , new SBigDecimal(20));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_25_29_KEY , new SBigDecimal(25));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_30_34_KEY , new SBigDecimal(30));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_35_39_KEY , new SBigDecimal(35));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_40_44_KEY , new SBigDecimal(40));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_45_49_KEY , new SBigDecimal(45));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_50_54_KEY , new SBigDecimal(50));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_55_59_KEY , new SBigDecimal(55));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_60_64_KEY , new SBigDecimal(60));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_65_69_KEY , new SBigDecimal(65));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_70_74_KEY , new SBigDecimal(70));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_75_79_KEY , new SBigDecimal(75));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_80_84_KEY , new SBigDecimal(80));
		lowAge.put(RuleRatingConstants.AGE_BRACKET_85_100_KEY, new SBigDecimal(85));

		SBigDecimal lowVal = (SBigDecimal) lowAge.get(ageBracket);
		return lowVal;
	}

	public static SBigDecimal getHighAgeVal(String ageBracket)
	{
		HashMap<Object,SBigDecimal> highAge = new HashMap<Object,SBigDecimal>();
		highAge.put(RuleRatingConstants.AGE_BRACKET_0_19_KEY  , new SBigDecimal(19));
		highAge.put(RuleRatingConstants.AGE_BRACKET_20_24_KEY , new SBigDecimal(24));
		highAge.put(RuleRatingConstants.AGE_BRACKET_25_29_KEY , new SBigDecimal(29));
		highAge.put(RuleRatingConstants.AGE_BRACKET_30_34_KEY , new SBigDecimal(34));
		highAge.put(RuleRatingConstants.AGE_BRACKET_35_39_KEY , new SBigDecimal(39));
		highAge.put(RuleRatingConstants.AGE_BRACKET_40_44_KEY , new SBigDecimal(44));
		highAge.put(RuleRatingConstants.AGE_BRACKET_45_49_KEY , new SBigDecimal(49));
		highAge.put(RuleRatingConstants.AGE_BRACKET_50_54_KEY , new SBigDecimal(54));
		highAge.put(RuleRatingConstants.AGE_BRACKET_55_59_KEY , new SBigDecimal(59));
		highAge.put(RuleRatingConstants.AGE_BRACKET_60_64_KEY , new SBigDecimal(64));
		highAge.put(RuleRatingConstants.AGE_BRACKET_65_69_KEY , new SBigDecimal(69));
		highAge.put(RuleRatingConstants.AGE_BRACKET_70_74_KEY , new SBigDecimal(74));
		highAge.put(RuleRatingConstants.AGE_BRACKET_75_79_KEY , new SBigDecimal(79));
		highAge.put(RuleRatingConstants.AGE_BRACKET_80_84_KEY , new SBigDecimal(84));
		highAge.put(RuleRatingConstants.AGE_BRACKET_85_100_KEY, new SBigDecimal(100));

		SBigDecimal highVal = (SBigDecimal) highAge.get(ageBracket);
		return highVal;
	}

	public static SBigDecimal calculateDifferenceInDaysMMddYYYY(String date1, String date2) throws ParseException{
		return new SBigDecimal(TimeUnit.DAYS.convert(
				new SimpleDateFormat("MM/dd/yyyy").parse(
						date1).getTime()
						- new SimpleDateFormat("MM/dd/yyyy").parse(
								date2)
								.getTime(), TimeUnit.MILLISECONDS));
	}

	//dates are expected to be in "EEE MMM dd hh:mm:ss z yyyy" format
	public static SBigDecimal calculateDifferenceInMonthsTimeStamp(Date date2, Date date1) throws ParseException{
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date1);
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date2);
		int yearDiff = cal1.get(Calendar.YEAR)-cal2.get(Calendar.YEAR);
		int monthDiff = (cal1.get(Calendar.MONTH)-cal2.get(Calendar.MONTH)+12*yearDiff)-1;
		monthDiff = Math.abs(monthDiff);
		return new SBigDecimal(String.valueOf(monthDiff));
	}
}
