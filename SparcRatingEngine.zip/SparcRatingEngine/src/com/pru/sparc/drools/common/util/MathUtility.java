package com.pru.sparc.drools.common.util;

import com.pru.sparc.drools.model.SBigDecimal;

public class MathUtility {

	public static int compareSBigDecimal(SBigDecimal bd1, SBigDecimal bd2) {

		return bd1.compareTo(bd2);

	}
	
	
	/** Compare the values and returns boolean function 
	 * @param obj1
	 * @param obj2
	 * @return
	 */
	public static boolean isEqualSBigDecimal(Object obj1, Object obj2) {
		
		SBigDecimal bd1 = (SBigDecimal) obj1;
		SBigDecimal bd2 = (SBigDecimal) obj2;

		if (bd1 == null && bd2 == null) {
			return true;
		} else if (bd1 == null || bd2 == null) {
			return false;
		} else {
			return compareSBigDecimal((SBigDecimal) bd1, (SBigDecimal) bd2) == 0;
		}
	}

	/**
	 * This method adds 2 BigDecimal objects. The input parameters are passed as
	 * Objects instead of BigDecimal for cleaner implementation in the decision
	 * tables. The objects will be first casted to BigDecimal before adding.
	 * This method will also handle the null condition for either of the inputs
	 * passed
	 * 
	 * @param obj1
	 *            - BigDecimal object1 to be added
	 * @param obj2
	 *            - BigDecimal object2 to be added
	 * @return - Addition of obj1 and obj2 if either of them is not null.
	 *         Returns ZERO if both objects are null
	 */
	public static SBigDecimal add(Object obj1, Object obj2) {
		SBigDecimal bd1 = (SBigDecimal) obj1;
		SBigDecimal bd2 = (SBigDecimal) obj2;

		if (bd1 == null & bd2 != null) {
			return bd2;
		} else if (bd1 != null & bd2 == null) {
			return bd1;
		} else if (bd1 != null & bd2 != null) {
			return bd1.add(bd2);
		} else {
			return new SBigDecimal(0);
		}

	}

	public static SBigDecimal divide(Object obj1, Object obj2) {
		SBigDecimal bd1 = (SBigDecimal) obj1;
		SBigDecimal bd2 = (SBigDecimal) obj2;

		if (bd1 == null || bd2 == null) {
			return new SBigDecimal(0);
		} else if ((bd1.compareTo(SBigDecimal.ZERO) == 0)
				|| (bd2.compareTo(SBigDecimal.ZERO) == 0)) {
			return new SBigDecimal(0);
		} else {
			return bd1.divide(bd2);

		}

	}

	public static SBigDecimal Subtract(Object obj1, Object obj2) {
		SBigDecimal bd1 = (SBigDecimal) obj1;
		SBigDecimal bd2 = (SBigDecimal) obj2;

		if (bd1 == null && bd2 == null) {
			return new SBigDecimal(0);
		} else if (bd1 != null & bd2 == null) {
			return bd1;

		} else if (bd1 == null & bd2 != null) {
			return bd2;

		} else {
			return bd1.subtract(bd2);
		}

	}

	public static SBigDecimal multiply(Object obj1, Object obj2) {
		SBigDecimal bd1 = (SBigDecimal) obj1;
		SBigDecimal bd2 = (SBigDecimal) obj2;

		if (bd1 == null || bd2 == null) {
			return new SBigDecimal(0);
		} else if ((bd1.compareTo(SBigDecimal.ZERO) == 0)
				|| (bd2.compareTo(SBigDecimal.ZERO) == 0)) {
			return new SBigDecimal(0);
		} else {
			return bd1.multiply(bd2);

		}

	}

	public static SBigDecimal min(Object obj1, Object obj2) {
		SBigDecimal bd1 = (SBigDecimal) obj1;
		SBigDecimal bd2 = (SBigDecimal) obj2;

		if (bd1 == null && bd2 != null) {
			return bd2;
		} else if (bd1 != null && bd2 == null) {
			return bd1;
		} else {
			return bd1.min(bd2);
		}
	}
	
	
	public static SBigDecimal max(Object obj1, Object obj2) {
		SBigDecimal bd1 = (SBigDecimal) obj1;
		SBigDecimal bd2 = (SBigDecimal) obj2;
		if (bd1 == null && bd2 != null) {
			return bd2;
		} else if (bd1 != null && bd2 == null) {
			return bd1;
		}
		else {
			return bd1.max(bd2);
		}
	}
	

	public static SBigDecimal add(final SBigDecimal val1, final SBigDecimal val2) {
		SBigDecimal result = new SBigDecimal("0");
		if (val1 != null && val2 != null) {
			result = val1.add(val2);
		} else if (val1 == null && val2 != null) {
			result = val2;
		} else if (val1 != null && val2 == null) {
			result = val1;
		}
		return result;
	}

	public static SBigDecimal min(final SBigDecimal val1, final SBigDecimal val2) {
		SBigDecimal result = new SBigDecimal("0");
		if (val1 != null && val2 != null) {
			result = val1.min(val2);
		} else if (val1 == null && val2 != null) {
			result = val2;
		} else if (val1 != null && val2 == null) {
			result = val1;
		}
		return result;
	}

	public static SBigDecimal max(final SBigDecimal val1, final SBigDecimal val2) {
		SBigDecimal result = new SBigDecimal("0");
		if (val1 != null && val2 != null) {
			result = val1.max(val2);
		} else if (val1 == null && val2 != null) {
			result = val2;
		} else if (val1 != null && val2 == null) {
			result = val1;
		}
		return result;
	}

}
