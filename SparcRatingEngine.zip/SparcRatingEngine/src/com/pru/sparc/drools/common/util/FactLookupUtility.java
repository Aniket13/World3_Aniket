package com.pru.sparc.drools.common.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.model.FactorConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class FactLookupUtility {

	//public static String EXECUTION_MODE = "web";
	private static HashMap cache;

	static {
		cache = new HashMap();
	}
	
	final static Logger logger = LoggerFactory.getLogger(FactLookupUtility.class);

	public static Object getFactorLookup(String factorTable, Map lookupparams) {

		logger.debug("factorTable: {}", factorTable);
		logger.debug("lookupparams: {}", lookupparams);
		String[] loadFile = { factorTable };
		String executionMode= System.getProperty("EXECUTIONMODE");
		try {
			long start = System.nanoTime();
			PeopleCoveredVolumeMain pcvm = new PeopleCoveredVolumeMain();
			// String executionMode = pcvm.getExecutionMode();
			//String executionMode = "standalone";
			StatefulKnowledgeSession kSession;

			KnowledgeBase kbase;

			String key = factorTable;
			if (executionMode.equalsIgnoreCase("web")) {
			//if (!EXECUTION_MODE.equalsIgnoreCase("Standalone")) {
				DynaCacheUtil dynaCacheUtil = new DynaCacheUtil();

				if (dynaCacheUtil.getValue(key) == null) {
					//logger.debug("Did not find the file {} in cache,hence putting in cache", key);
					kbase = readKnowledgeBase(loadFile);
					kbase.newStatefulKnowledgeSession();
					dynaCacheUtil.putValue(key, kbase);
				} else {
					//logger.debug("Found the file {} in cache", key);
					kbase = (KnowledgeBase) dynaCacheUtil.getValue(key);
				}
			} else {
				if (cache.get(key) == null) {
					//logger.debug("Did not find the file {} in cache,hence putting in cache", key);
					kbase = readKnowledgeBase(loadFile);
					kbase.newStatefulKnowledgeSession();
					cache.put(key, kbase);
				} else {
					//logger.debug("Found the file {key} in cache", key);
					kbase = (KnowledgeBase) cache.get(key);
				}

			}

			kSession = kbase.newStatefulKnowledgeSession();

			long endTime = System.nanoTime();
			
			logger.debug("Time taken for {} I/O & compile(ms): {}",factorTable,(endTime - start)/1000000);
			kSession.insert(lookupparams);
			kSession.fireAllRules();
			kSession.dispose();
			logger.debug("Output from Factor table lookup: {}",lookupparams.get("output1"));
		} catch (Exception e) {
			//logger.error("Exception: ", e);
			e.printStackTrace();
		}
		return lookupparams;
	}

	public static Object getFactorLookup(String factorTable, Map input,
			Map output) {
		String[] loadFile = { factorTable };
		try {
			KnowledgeBase kbase;
			kbase = readKnowledgeBase(loadFile);
			StatefulKnowledgeSession kSession = kbase
					.newStatefulKnowledgeSession();
			kSession.insert(input);
			kSession.fireAllRules();
			// kSession.execute(input);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	public static Object getFactorLookupDefaultVal (String factorTable, Map lookupparams) {
		Map outParams = (Map)getFactorLookup(factorTable, lookupparams);
		SBigDecimal out =(SBigDecimal)outParams.get(FactorConstants.FACTOR_OUTPUT);
		if(out == null){
			outParams.put(FactorConstants.FACTOR_OUTPUT, new SBigDecimal(FactorConstants.FACTOR_DEFAULT_OUTPUT));
			return outParams;
		}else{
			return outParams;
		}
	}
	
	public static void showMap(Map lookup) {
		//logger.debug("-> Start printing lookup");
		if (lookup != null) {
			Iterator it = lookup.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				//logger.debug("Key: {}| Value: {}", key, lookup.get(key));
			}
			//logger.debug("<-End printing lookup");

		} else {
			//logger.debug("<-Cannot print as map is null");
		}
	}

	private static KnowledgeBase readKnowledgeBase(String[] loadFile)
			throws Exception {

		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		String drlinput= System.getProperty("DRLRATINGINPUT");
		for (int fileCount = 0; fileCount < loadFile.length; fileCount++) {

			DecisionTableConfiguration config = KnowledgeBuilderFactory
					.newDecisionTableConfiguration();
			config.setInputType(DecisionTableInputType.XLS);

			//Remove below comment for stand alone
			/*kbuilder.add(
					ResourceFactory
							.newClassPathResource(BasicLifeConstant.BL_FACTOR_TABLE_LOCATION
									+ loadFile[fileCount]),
					ResourceType.DTABLE, config);*/
			
			//below is for Web 
			kbuilder.add(
					ResourceFactory
							.newFileResource(drlinput+BasicLifeConstant.BL_FACTOR_TABLE_LOCATION
									+ loadFile[fileCount]),
					ResourceType.DTABLE, config);
			//below is for Web (Cloud )
			/*kbuilder.add(
					ResourceFactory
					.newFileResource("F:\\SPARC\\External_Resources\\RatingEngine\\"+BasicLifeConstant.BL_FACTOR_TABLE_LOCATION
									+ loadFile[fileCount]),
					ResourceType.DTABLE, config);*/

		}
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());

		return kbase;
	}
	
	/**
	 * @param factorTable - Name of the factor table to be looked up
	 * @param input1 - Input 1 for the factor table
	 * @param input2 - Input 2 for the factor table
	 * @return Output as per the factor table
	 */
	public static Object getFactorLookup(String factorTable, Object input1, Object input2) {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("input1", input1);
		hm.put("input2",input2);
		FactLookupUtility.getFactorLookup(factorTable + ".xls", hm);
		return hm.get("output1");
	}
	
	/**
	 * @param factorTable - Name of the factor table to be looked up
	 * @param input1 - Input 1 for the factor table
	 * @return Output as per the factor table
	 */
	public static Object getFactorLookup(String factorTable, Object input1) {
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("input1", input1);
		FactLookupUtility.getFactorLookup(factorTable + ".xls", hm);
		return hm.get("output1");
	}

}
