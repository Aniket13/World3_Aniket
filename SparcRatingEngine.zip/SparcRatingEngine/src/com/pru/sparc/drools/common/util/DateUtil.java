package com.pru.sparc.drools.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.pru.sparc.drools.model.SBigDecimal;

public class DateUtil {

	public static final String VIEW_DATE_FORMAT = "MM/dd/yyyy";
	public static boolean isBetween(Date date, Date startDate, Date endDate) {
		if (date != null && startDate != null && endDate != null) {
			if (date.after(startDate) && date.before(endDate)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	public static boolean isBetweenInclStartDate(Date date, Date startDate, Date endDate) {
		if (date != null && startDate != null && endDate != null) {
			if ((isSameDate(date,startDate) || date.after(startDate)) && date.before(endDate)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	public static boolean isBetweenInclStartDate(String date1, String startDate1, String endDate1) {
		Date date = getDateMMddyyy(date1);
		Date startDate = getDateMMddyyy(startDate1);
		Date endDate = getDateMMddyyy(endDate1);
		if (date != null && startDate != null && endDate != null) {
			if ((isSameDate(date,startDate) || date.after(startDate)) && date.before(endDate)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	public static boolean isSameDate(Date date1, Date date2){
		SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
		return fmt.format(date1).equals(fmt.format(date2));
	}

	public static Date format(Object str) {
		try {
			return new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy")
					.parse((String) str);
		} catch (Exception e) {
			return null;
		}

	}

	/**
	 * @param date1 - String object for date in MM/dd/yyyy format
	 * @param date2 - String object for date in MM/dd/yyyy format
	 * @return SBigDecimal - Difference in days between date1 & date2 
	 */
	public static SBigDecimal differenceInDays(Object date1, Object date2) {
		String str1 = (String) date1;
		String str2 = (String) date2;
		try {
			return new SBigDecimal(TimeUnit.DAYS.convert(
					new SimpleDateFormat("MM/dd/yyyy").parse(str1).getTime()
							- new SimpleDateFormat("MM/dd/yyyy").parse(str2)
									.getTime(), TimeUnit.MILLISECONDS));
		} catch (Exception e) {
			e.printStackTrace();
			return new SBigDecimal(0);

		}

	}
	

	/**
	 * 
	 * @param inDate inDate
	 * @return Date
	 */
	public static Date convertStrToDate(final String inDate) {
		if (inDate == null) {
			return null;
		}
		Date result = null;
	    SimpleDateFormat dateFormat = new SimpleDateFormat(VIEW_DATE_FORMAT);		    		
	    //dateFormat.setLenient(false);	    
		try {
			result = dateFormat.parse(inDate.trim());
		} catch (ParseException pe) {
			return null;
		}
		return result;
	}
	
	
	/**
	 * @param date1
	 * @param date2
	 * @return - true if date1 is before date2, false otherwise
	 */
	public static boolean isBefore(Date date1, Date date2){
		if (date1 != null && date2 != null ) {
			if (date1.before(date2)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	/**
	 * @param date1
	 * @param date2
	 * @return - true if date1 is after date2, false otherwise
	 */
	public static boolean isAfter(Date date1, Date date2){
		if (date1 != null && date2 != null ) {
			if (date1.after(date2)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	/**
	 * @param str - date in string MM/dd/yyyy format
	 * @return - date object from string
	 */
	public static Date getDateMMddyyy(String str) {
		try {
			if (str != null) {
				return new SimpleDateFormat("MM/dd/yyyy").parse(str);
			} else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * @param date1
	 * @param date2
	 * @return - Difference between date1 and date2 in months
	 */
	public static final int getMonthsDifference(Date date1, Date date2) {
	    int m1 = date1.getYear() * 12 + date1.getMonth();
	    int m2 = date2.getYear() * 12 + date2.getMonth();
	    return m2 - m1;
	}
	
	/**
	 * @param date - Date object
	 * @return - Returns date as string in EEE MMM dd hh:mm:ss z yyyy format
	 */
	public static String format(Date date) {
		try {
			return new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy")
					.format(date);
		} catch (Exception e) {
			return null;
		}

	}
	
	public static String formatDate(Date date) {
		try {
			return new SimpleDateFormat("MM/dd/yyyy")
					.format(date);
		} catch (Exception e) {
			return null;
		}

	}
	
	/**
	 * @param date - String date in MM/dd/yyyy format
	 * @return - Returns input date in MMddyyyy as string in EEE MMM dd hh:mm:ss z yyyy format
	 */
	public static String formatMMddyyyyToEEEMMMddhhmmsszyyyy(String date) {
		try {
			
			return new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy").format(new SimpleDateFormat("MM/dd/yyyy").parse(date));
		} catch (Exception e) {
			return null;
		}

	}
	
	public static String formatMMddyyyyToEEEMMMddhhmmsszyyyyDiffFormat(String date) {
		try {
			
			return new SimpleDateFormat("EEE MMM dd hh:mm:ss z yyyy").format(new SimpleDateFormat("MM-dd-yyyy").parse(date));
		} catch (Exception e) {
			return null;
		}

	}
	
}
