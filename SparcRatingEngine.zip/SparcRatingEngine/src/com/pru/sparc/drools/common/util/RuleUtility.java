package com.pru.sparc.drools.common.util;

import java.io.File;
import java.util.HashMap;
import java.util.Properties;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderConfiguration;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.builder.conf.DumpDirOption;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RuleUtility {

	public static String DRL = "DRL";
	public static String DT = "DT";
	//public static String EXECUTION_MODE = "web";
	private static HashMap cache;
	
	static{
		cache = new HashMap();
	}
	
	final static Logger logger = LoggerFactory.getLogger(RuleUtility.class);

	public static Object getInitData(String fileType, String fileName,
			String agendaGp, Object obj) {
		String executionMode= System.getProperty("EXECUTIONMODE");
		String[] loadFile = { fileName };
		try {
			long start = System.nanoTime();
			StatefulKnowledgeSession kSession;
			PeopleCoveredVolumeMain pcvm = new PeopleCoveredVolumeMain();
			//String executionMode = pcvm.getExecutionMode();
			KnowledgeBase kbase;
			String key = fileType + fileName;
			if (executionMode.equalsIgnoreCase("web")) {
			//if (!EXECUTION_MODE.equalsIgnoreCase("abc")) {
				DynaCacheUtil dynaCacheUtil = new DynaCacheUtil();
				if (dynaCacheUtil.getValue(key) == null) {
					logger.debug("Did not find the file {} in cache,hence putting in cache", key);
					kbase = readKnowledgeBase(loadFile, fileType);
					kbase.newStatefulKnowledgeSession();
					dynaCacheUtil.putValue(key, kbase);
				} else {
					logger.debug("Found the file {} in cache", key);
					kbase = (KnowledgeBase) dynaCacheUtil.getValue(key);
				}
			} else {
				if (cache.get(key) == null) {
					logger.debug("Did not find the file {} in cache,hence putting in cache", key);
					kbase = readKnowledgeBase(loadFile, fileType); // kSession =
					kbase.newStatefulKnowledgeSession();
					cache.put(key, kbase);
				} else {
					logger.debug("Found the file {} in cache", key);
					kbase = (KnowledgeBase) cache.get(key);
				}
				
			}
			long endTime = System.nanoTime();
			logger.debug("Time taken for {} I/O & compile(ms):", fileName,
					(endTime - start) / 1000000);
			kSession = kbase.newStatefulKnowledgeSession();
			// kSession.getFactHandle(obj);
			kSession.getAgenda().getAgendaGroup(agendaGp).setFocus();
			kSession.insert(obj);
			kSession.fireAllRules();

			// kSession.execute(obj);

			kSession.dispose();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return obj;
	}

	private static KnowledgeBase readKnowledgeBase(String[] loadFile,
			String ruleType) throws Exception {
		Properties props = new Properties();
		/*System.setProperty("drools.dialect.mvel.strict", "false");
		System.setProperty("drools.dialect.java.compiler", "JANINO");*/
		//props.setProperty("drools.dialect.default", "Java");
		//props.setProperty("drools.dialect.java.compiler", "JANINO");
		KnowledgeBuilderConfiguration cfg = KnowledgeBuilderFactory.newKnowledgeBuilderConfiguration();
		cfg.setProperty("drools.dialect.default", "java");
		cfg.setProperty("drools.dialect.mvel.strict", "false");
		//cfg.setOption(DumpDirOption.get(new File("D:/Drools/target/dumpDir"))); 
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder( cfg );
	    String drlinput= System.getProperty("DRLRATINGINPUT");
		for (int fileCount = 0; fileCount < loadFile.length; fileCount++) {
			if (ruleType.equalsIgnoreCase("dt")) {
				DecisionTableConfiguration config = KnowledgeBuilderFactory
						.newDecisionTableConfiguration();
				config.setInputType(DecisionTableInputType.XLS);

			/*	kbuilder.add(ResourceFactory
						.newClassPathResource(loadFile[fileCount],RuleUtility.class.getClassLoader()),
						ResourceType.DTABLE, config);*/
				
				kbuilder.add(ResourceFactory
						.newFileResource(drlinput+loadFile[fileCount]),
						ResourceType.DTABLE, config);
				
				/*kbuilder.add(ResourceFactory
						.newFileResource("F:\\SPARC\\External_Resources\\RatingEngine\\"+loadFile[fileCount]),
						ResourceType.DTABLE, config);*/
			}
			if (ruleType.equalsIgnoreCase("drl")) {

			/*	//Remove below comment for stand alone
				kbuilder.add(ResourceFactory
						.newClassPathResource(loadFile[fileCount],RuleUtility.class.getClassLoader()),
						ResourceType.DRL);*/
				
				//below is for web 
				kbuilder.add(ResourceFactory
						.newFileResource(drlinput+loadFile[fileCount]),
						ResourceType.DRL);
				
				//below is for web (Cloud )
				/*kbuilder.add(ResourceFactory
						.newFileResource("F:\\SPARC\\External_Resources\\RatingEngine\\"+loadFile[fileCount]),
						ResourceType.DRL);*/
			}
		}
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

	public static StatefulKnowledgeSession readKnowledgeBaseWithCaching(
			String[] loadFile, String ruleType) throws Exception {

		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		DynaCacheUtil dynaCacheUtil = new DynaCacheUtil();

		for (int fileCount = 0; fileCount < loadFile.length; fileCount++) {/*
																			 * 
																			 * if
																			 * (
																			 * ruleType
																			 * .
																			 * equalsIgnoreCase
																			 * (
																			 * "dt"
																			 * )
																			 * )
																			 * {
																			 * DecisionTableConfiguration
																			 * config
																			 * =
																			 * KnowledgeBuilderFactory
																			 * .
																			 * newDecisionTableConfiguration
																			 * (
																			 * )
																			 * ;
																			 * config
																			 * .
																			 * setInputType
																			 * (
																			 * DecisionTableInputType
																			 * .
																			 * XLS
																			 * )
																			 * ;
																			 * String
																			 * filename
																			 * =
																			 * loadFile
																			 * [
																			 * fileCount
																			 * ]
																			 * +
																			 * ".xls"
																			 * ;
																			 * System
																			 * .
																			 * out
																			 * .
																			 * println
																			 * (
																			 * "looking for file :"
																			 * +
																			 * filename
																			 * )
																			 * ;
																			 * if
																			 * (
																			 * dynaCacheUtil
																			 * .
																			 * getValue
																			 * (
																			 * filename
																			 * )
																			 * ==
																			 * null
																			 * )
																			 * {
																			 * System
																			 * .
																			 * out
																			 * .
																			 * println
																			 * (
																			 * "Did not find the file in cache,hence putting in cache "
																			 * )
																			 * ;
																			 * 
																			 * Resource
																			 * dtFile
																			 * =
																			 * (
																			 * Resource
																			 * )
																			 * (
																			 * dynaCacheUtil
																			 * .
																			 * getValue
																			 * (
																			 * filename
																			 * )
																			 * )
																			 * ;
																			 * 
																			 * kbuilder
																			 * .
																			 * add
																			 * (
																			 * ResourceFactory
																			 * .
																			 * newClassPathResource
																			 * (
																			 * loadFile
																			 * [
																			 * fileCount
																			 * ]
																			 * )
																			 * ,
																			 * ResourceType
																			 * .
																			 * DTABLE
																			 * ,
																			 * config
																			 * )
																			 * ;
																			 * dynaCacheUtil
																			 * .
																			 * putValue
																			 * (
																			 * filename
																			 * ,
																			 * ResourceFactory
																			 * .
																			 * newClassPathResource
																			 * (
																			 * loadFile
																			 * [
																			 * fileCount
																			 * ]
																			 * )
																			 * )
																			 * ;
																			 * }
																			 * else
																			 * {
																			 * System
																			 * .
																			 * out
																			 * .
																			 * println
																			 * (
																			 * "Found the file in cache"
																			 * )
																			 * ;
																			 * Resource
																			 * dtFile
																			 * =
																			 * (
																			 * Resource
																			 * )
																			 * (
																			 * dynaCacheUtil
																			 * .
																			 * getValue
																			 * (
																			 * filename
																			 * )
																			 * )
																			 * ;
																			 * kbuilder
																			 * .
																			 * add
																			 * (
																			 * dtFile
																			 * ,
																			 * ResourceType
																			 * .
																			 * DTABLE
																			 * ,
																			 * config
																			 * )
																			 * ;
																			 * }
																			 * 
																			 * }
																			 * if
																			 * (
																			 * ruleType
																			 * .
																			 * equalsIgnoreCase
																			 * (
																			 * "drl"
																			 * )
																			 * )
																			 * {
																			 * String
																			 * filename
																			 * =
																			 * loadFile
																			 * [
																			 * fileCount
																			 * ]
																			 * +
																			 * ".drl"
																			 * ;
																			 * System
																			 * .
																			 * out
																			 * .
																			 * println
																			 * (
																			 * "looking for file :"
																			 * +
																			 * filename
																			 * )
																			 * ;
																			 * if
																			 * (
																			 * dynaCacheUtil
																			 * .
																			 * getValue
																			 * (
																			 * filename
																			 * )
																			 * ==
																			 * null
																			 * )
																			 * {
																			 * System
																			 * .
																			 * out
																			 * .
																			 * println
																			 * (
																			 * "Did not find the file in cache,hence putting in cache "
																			 * )
																			 * ;
																			 * Resource
																			 * dtFile
																			 * =
																			 * (
																			 * Resource
																			 * )
																			 * (
																			 * dynaCacheUtil
																			 * .
																			 * getValue
																			 * (
																			 * filename
																			 * )
																			 * )
																			 * ;
																			 * kbuilder
																			 * .
																			 * add
																			 * (
																			 * dtFile
																			 * ,
																			 * ResourceType
																			 * .
																			 * DRL
																			 * )
																			 * ;
																			 * dynaCacheUtil
																			 * .
																			 * putValue
																			 * (
																			 * filename
																			 * ,
																			 * dtFile
																			 * )
																			 * ;
																			 * }
																			 * else
																			 * {
																			 * System
																			 * .
																			 * out
																			 * .
																			 * println
																			 * (
																			 * "Found the file in cache"
																			 * )
																			 * ;
																			 * Resource
																			 * dtFile
																			 * =
																			 * (
																			 * Resource
																			 * )
																			 * (
																			 * dynaCacheUtil
																			 * .
																			 * getValue
																			 * (
																			 * filename
																			 * )
																			 * )
																			 * ;
																			 * kbuilder
																			 * .
																			 * add
																			 * (
																			 * dtFile
																			 * ,
																			 * ResourceType
																			 * .
																			 * DRL
																			 * )
																			 * ;
																			 * }
																			 * 
																			 * }
																			 */
		}
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
		return ksession;
	}

	public static Object getInitsData(String fileType, String fileName,
			String agendaGp, Object[] obj) {
		String[] loadFile = { fileName };
		String executionMode= System.getProperty("EXECUTIONMODE");
		try {
			long start = System.nanoTime();
			StatefulKnowledgeSession kSession;
			PeopleCoveredVolumeMain pcvm = new PeopleCoveredVolumeMain();
			// String executionMode = pcvm.getExecutionMode();
			//String executionMode = "standalone";
			KnowledgeBase kbase;
			String key = fileType + fileName;
			if (executionMode.equalsIgnoreCase("web")) {
			//if (!EXECUTION_MODE.equalsIgnoreCase("Standalone")) {
				DynaCacheUtil dynaCacheUtil = new DynaCacheUtil();
				if (dynaCacheUtil.getValue(key) == null) {
					//logger.debug("Did not find the file {} in cache,hence putting in cache", key);
					kbase = readKnowledgeBase(loadFile, fileType);
					kbase.newStatefulKnowledgeSession();
					dynaCacheUtil.putValue(key, kbase);
				} else {
					//logger.debug("Found the file {} in cache", key);
					kbase = (KnowledgeBase) dynaCacheUtil.getValue(key);

				}
			} else {
				if (cache.get(key) == null) {
					//logger.debug("Did not find the file {} in cache,hence putting in cache", key);
					kbase = readKnowledgeBase(loadFile, fileType); // kSession =
					kbase.newStatefulKnowledgeSession();
					cache.put(key, kbase);
				} else {
					//logger.debug("Found the file {} in cache", key);
					kbase = (KnowledgeBase) cache.get(key);
				}
			}
			long endTime = System.nanoTime();
			logger.debug("Time taken for {} I/O & compile(ms): {}",fileName, (endTime - start) / 1000000);
			kSession = kbase.newStatefulKnowledgeSession();
			// kSession.getFactHandle(obj);
			kSession.getAgenda().getAgendaGroup(agendaGp).setFocus();
			for (int i = 0; i < obj.length; i++) {
				Object fact = obj[i];
				kSession.insert(fact);
			}
			kSession.fireAllRules();

			// kSession.execute(obj);

			kSession.dispose();

		} catch (Exception e) {
			logger.error("Error executing the rule: ",e);
			e.printStackTrace();
		} catch (Throwable th){
			logger.error("Error executing the rule: ",th);
			th.printStackTrace();
		}

		return obj;
	}
}
