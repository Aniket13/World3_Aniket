package com.pru.sparc.drools.common.util;

import com.pru.sparc.drools.model.Commission;
import com.pru.sparc.drools.model.SBigDecimal;

public class CommonUtils {
	/*@author: utkakuma
	 * This method calculate and update the calculated commisson to object
	 * */
	public static Commission calculateCommission(Commission m,int param){
		
		if(m.getCurrentCommission()==0.0){
			m.setCurrentCommission((m.premiumYearlyAmount*param)/100);
			if(m.getPremiumYear()==0){
				 m.setTotalCommission(m.getTotalCommission()+(m.premiumYearlyAmount*param)/100);
			}
		}
		
		if(m.getPremiumYear()>=1){
			 m.setTotalCommission(m.getTotalCommission()+(m.premiumYearlyAmount*param)/100);
			 m.setPremiumYear(m.getPremiumYear()-1);
		}else{
			m.setExitStatus(true);
		}
		return m;
	}
	/*@author: utkakuma
	 * This method calculate and update the calculated commisson to object
	 * (overridden method to handle double)
	 * */
	public static Commission calculateCommission(Commission m,double param){
		
		if(m.getCurrentCommission()==0.0){
			m.setCurrentCommission((m.premiumYearlyAmount*param)/100);
			if(m.getPremiumYear()==0){
				 m.setTotalCommission(m.getTotalCommission()+(m.premiumYearlyAmount*param)/100);
			}
		}
		
		if(m.getPremiumYear()>=1){
			 m.setTotalCommission(m.getTotalCommission()+(m.premiumYearlyAmount*param)/100);
			 m.setPremiumYear(m.getPremiumYear()-1);
		}else{
			m.setExitStatus(true);
		}
		return m;
	}
	
	public static boolean isNotNull(SBigDecimal val) {
		boolean isNotNull = false;
		if (val != null) {
			isNotNull = true;
		}
		return isNotNull;
	}
	public static int compareValues(SBigDecimal val1,SBigDecimal val2) {
		int val = 0;
		if (val1 != null && val2 != null) {
			val1.compareTo(val2);
		} 
		return val;
	}
}
