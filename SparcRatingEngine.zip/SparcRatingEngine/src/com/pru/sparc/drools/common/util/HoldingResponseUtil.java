package com.pru.sparc.drools.common.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.GenderConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.RatingOutputConstants;
import com.pru.sparc.drools.model.RuleRatingAggregatedCensusGrp;
import com.pru.sparc.drools.model.RuleRatingCensusCompGrp;
import com.pru.sparc.drools.model.RuleRatingModelOverrideGrp;
import com.pru.sparc.drools.model.RuleRatingOutputModelWrapper;
import com.pru.sparc.drools.model.RuleRatingProposalPlanDetails;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.model.StatusConstants;

public class HoldingResponseUtil {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<RuleRatingOutputModelWrapper> parseRatingExhibitOutput(Holding holding) {
		
		List<Plan> planList = holding.getListOfPlans();
		List<RuleRatingOutputModelWrapper> plansOutput = new ArrayList<RuleRatingOutputModelWrapper>();
		
		if (CollectionUtils.isNotEmpty(planList)) {
			for (Plan plan : planList) {
				
				RuleRatingOutputModelWrapper wrapper = new RuleRatingOutputModelWrapper();
				if (plan.getPlanMap().containsKey(PlanConstants.PLAN_ID)) {
					if (plan.get(PlanConstants.PLAN_ID) instanceof Integer) {
						wrapper.setPlanId((Integer)plan.get(PlanConstants.PLAN_ID));
					}
				}
				//added logic to handle the overrides in the rating engine
				if (plan.getOverRideMap() != null && plan.getOverRideMap().size() > 0) {
					wrapper.setOverriddenPlanRating(true);
				}
				
				List<ArrayList<RuleRatingModelOverrideGrp>> ratingModelOverideGrpList = new ArrayList<ArrayList<RuleRatingModelOverrideGrp>>();
				
				//Table 1
				ArrayList<RuleRatingModelOverrideGrp> competitiveWindowList = new ArrayList<RuleRatingModelOverrideGrp>();
				int index = 0;
				for (Map.Entry<String, String> entry : RatingOutputConstants.BL_TABLE_COMPETITIVE_WINDOW.entrySet()) {
					RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
					objOverride.setFieldKey(entry.getKey());
					if (((SBigDecimal)plan.get(entry.getValue()) != null)) {
						objOverride.setFieldValue(((SBigDecimal)plan.get(entry.getValue())).doubleValue());
					} else {
						objOverride.setFieldValue(0);
					}
					objOverride.setOverrideAllowed(true);
					objOverride.setGroupId(RatingOutputConstants.BL_TABLE_COMPETITIVE_WINDOW_GROUP);
					objOverride.setFieldSeqNo(++index);
					
					if(StringUtils.equalsIgnoreCase(entry.getKey(), "Acknowledgement of High Premium Discount Field")) {
						objOverride.setPrecision(1);
					}else if(StringUtils.equalsIgnoreCase(entry.getKey(), "Field Adjustment")) {
						objOverride.setPrecision(3);
					}
					
					competitiveWindowList.add(objOverride);
				}
				ratingModelOverideGrpList.add(competitiveWindowList);
				
				
				//Table 2
				ArrayList<RuleRatingModelOverrideGrp> uwAdjustmentBoxList = new ArrayList<RuleRatingModelOverrideGrp>();
				index = 0;
				for (Map.Entry<String, String> entry : RatingOutputConstants.BL_TABLE_UW_ADJUSTMENT_BOX.entrySet()) {
					RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
					objOverride.setFieldKey(entry.getKey());
					if (((SBigDecimal)plan.get(entry.getValue()) != null) 
							|| ((SBigDecimal)holding.get(entry.getValue()) != null)) {
						if (StringUtils.equalsIgnoreCase(entry.getKey(), "Proposal Exhibit Lives") ||
								StringUtils.equalsIgnoreCase(entry.getKey(), "Proposal Exhibit Volume") ||
								StringUtils.equalsIgnoreCase(entry.getKey(), "Estimated Lives for BL") ||
								StringUtils.equalsIgnoreCase(entry.getKey(), "Estimated Volume for BL"))  {
							objOverride.setFieldValue(((SBigDecimal)holding.get(entry.getValue())).doubleValue());
							
						} else {
							objOverride.setFieldValue(((SBigDecimal)plan.get(entry.getValue())).doubleValue());
						}
					} else {
						objOverride.setFieldValue(0);
					}
					objOverride.setGroupId(RatingOutputConstants.BL_TABLE_UW_ADJUSTMENT_BOX_GROUP);

					if(StringUtils.equalsIgnoreCase(entry.getKey(), "Compsych Rate Override") || 
						StringUtils.equalsIgnoreCase(entry.getKey(), "Regional VP Adjustment Original Rate") ||
						StringUtils.equalsIgnoreCase(entry.getKey(), "Regional VP Adjustment Desired Rate") ||
						StringUtils.equalsIgnoreCase(entry.getKey(), "Advocate Adjustment Original Rate") ||
						StringUtils.equalsIgnoreCase(entry.getKey(), "Advocate Adjustment Desired Rate") ||
						StringUtils.equalsIgnoreCase(entry.getKey(), "Final Underwriter Adjustment Original Rate") ||
						StringUtils.equalsIgnoreCase(entry.getKey(), "Final Underwriter Adjustment Desired Rate") ||
						StringUtils.equalsIgnoreCase(entry.getKey(), "Proposal Exhibit Lives") ||
						StringUtils.equalsIgnoreCase(entry.getKey(), "Proposal Exhibit Volume")) {
						objOverride.setOverrideAllowed(true);
					}
					objOverride.setFieldSeqNo(++index);
					if (StringUtils.equalsIgnoreCase(entry.getKey(),
							"Proposal Exhibit Lives")
							|| StringUtils.equalsIgnoreCase(entry.getKey(),
									"Estimated Lives for BL")
							|| StringUtils.equalsIgnoreCase(entry.getKey(),
									"Estimated Volume for BL")) {
						objOverride.setPrecision(0);

					} else if (StringUtils.equalsIgnoreCase(entry.getKey(),
							"Guarantee Issue Amount")||StringUtils.equalsIgnoreCase(entry.getKey(),
									"Monthly Premium for BL") ||StringUtils.equalsIgnoreCase(entry.getKey(),
											"Total Annual Premium for BL")) {						
						objOverride.setPrecision(2);

					} else {
						objOverride.setPrecision(3);

					}
					uwAdjustmentBoxList.add(objOverride);
				}
				ratingModelOverideGrpList.add(uwAdjustmentBoxList);

				
				//Table 3
				ArrayList<RuleRatingModelOverrideGrp>  renewalTableList = new ArrayList<RuleRatingModelOverrideGrp>();
				index = 0;
				for (Map.Entry<String, String> entry : RatingOutputConstants.BL_RENEWAL_TABLE.entrySet()) {
					RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
					objOverride.setFieldKey(entry.getKey());
					if (((SBigDecimal)plan.get(entry.getValue()) != null) || 
							((SBigDecimal)holding.get(entry.getValue()) != null)) {
						
						if (StringUtils.equalsIgnoreCase(entry.getKey(), "Inforce Volume") ||
								StringUtils.equalsIgnoreCase(entry.getKey(), "Percentage Female"))  {
							objOverride.setFieldValue(((SBigDecimal)holding.get(entry.getValue())).doubleValue());
						} else {
							objOverride.setFieldValue(((SBigDecimal)plan.get(entry.getValue())).doubleValue());
						}
					} else {
						objOverride.setFieldValue(0);
					}
					if(StringUtils.equalsIgnoreCase(entry.getKey(), "Renewal Rate Action Override")) {
						objOverride.setOverrideAllowed(true);
					}
					objOverride.setGroupId(RatingOutputConstants.BL_RENEWAL_TABLE_GROUP);
					objOverride.setFieldSeqNo(++index);
					if (StringUtils.equalsIgnoreCase(entry.getKey(),
							"Inforce Volume")
							|| StringUtils.equalsIgnoreCase(entry.getKey(),
									"Plan Total Lives")
							|| StringUtils.equalsIgnoreCase(entry.getKey(),
									"Average Age")
							|| StringUtils.equalsIgnoreCase(entry.getKey(),
									"Average Annual Salary")
							|| StringUtils.equalsIgnoreCase(entry.getKey(),
									"Maximum Coverage Amount")) {
						objOverride.setPrecision(0);

					} else if (StringUtils.equalsIgnoreCase(entry.getKey(),
							"Annual Plan Premium")) {
						objOverride.setPrecision(2);

					} else if (StringUtils.equalsIgnoreCase(entry.getKey(),
							"Percentage Female")) {
						objOverride.setPrecision(4);

					} else {
						objOverride.setPrecision(3);
					}
					renewalTableList.add(objOverride);
				}
				ratingModelOverideGrpList.add(renewalTableList);

				
				//Table 4
				RuleRatingProposalPlanDetails objProposalDetails = new RuleRatingProposalPlanDetails();
				if ((SBigDecimal)holding.get(RatingOutputConstants.PROPOSAL_EXHIBIT_LIVES) != null) {
					objProposalDetails.setProposalExhibitLives(((SBigDecimal)holding.get(RatingOutputConstants.PROPOSAL_EXHIBIT_LIVES)).doubleValue());
				}
				
				if ((SBigDecimal)holding.get(RatingOutputConstants.PROPOSAL_EXHIBIT_VOLUME) != null) {
					objProposalDetails.setProposalExhibitVolume(((SBigDecimal)holding.get(RatingOutputConstants.PROPOSAL_EXHIBIT_VOLUME)).doubleValue());
				}
				
				if ((SBigDecimal)plan.get(RatingOutputConstants.PROPOSAL_EXHIBIT_RATE) != null) {
					objProposalDetails.setProposalExhibitRate(((SBigDecimal)plan.get(RatingOutputConstants.PROPOSAL_EXHIBIT_RATE)).doubleValue());
				}
				
				if ((SBigDecimal)plan.get(RatingOutputConstants.PROPOSAL_EXHIBIT_PREMIUM) != null) {
					objProposalDetails.setProposalExhibitPremium(((SBigDecimal)plan.get(RatingOutputConstants.PROPOSAL_EXHIBIT_PREMIUM)).doubleValue());
				}
				
				if ((SBigDecimal)plan.get(RatingOutputConstants.COMPOSITE_RATE) != null) {
					objProposalDetails.setCompositeRate(((SBigDecimal)plan.get(RatingOutputConstants.COMPOSITE_RATE)).doubleValue());
				}

				if ((SBigDecimal)plan.get(RatingOutputConstants.ESTIMATED_LIVES) != null) {
					objProposalDetails.setEstLivesForPlan(((SBigDecimal)plan.get(RatingOutputConstants.ESTIMATED_LIVES)).doubleValue());
				}
				
				if ((SBigDecimal)plan.get(RatingOutputConstants.ESTIMATED_LIVES_FOR_ALL_PLANS_COMPOSITE_ONLY) != null) {
					objProposalDetails.setEstLivesAllCompositePlan(((SBigDecimal)plan.get(RatingOutputConstants.ESTIMATED_LIVES_FOR_ALL_PLANS_COMPOSITE_ONLY)).doubleValue());
				}

				if ((SBigDecimal)plan.get(RatingOutputConstants.ESTIMATED_VOLUME) != null) {
					objProposalDetails.setEstVolumeForPlan(((SBigDecimal)plan.get(RatingOutputConstants.ESTIMATED_VOLUME)).doubleValue());
				}
				
				if ((SBigDecimal)plan.get(RatingOutputConstants.ESTIMATED_VOLUME_FOR_ALL_PLANS_COMPOSITE_ONLY) != null) {
					objProposalDetails.setEstVolumeAllCompositePlan(((SBigDecimal)plan.get(RatingOutputConstants.ESTIMATED_VOLUME_FOR_ALL_PLANS_COMPOSITE_ONLY)).doubleValue());
				}
				
				if ((SBigDecimal)plan.get(RatingOutputConstants.MONHTLY_RATES) != null) {
					objProposalDetails.setMonthlyRates(((SBigDecimal)plan.get(RatingOutputConstants.MONHTLY_RATES)).doubleValue());
				}

				if ((SBigDecimal)plan.get(RatingOutputConstants.MANUAL_RATE) != null) {
					objProposalDetails.setManualRate(((SBigDecimal)plan.get(RatingOutputConstants.MANUAL_RATE)).doubleValue());
				}
				
				if ((SBigDecimal)plan.get(RatingOutputConstants.MONTHLY_PREMIUM) != null) {
					objProposalDetails.setMonthlyPremiumForPlan(((SBigDecimal)plan.get(RatingOutputConstants.MONTHLY_PREMIUM)).doubleValue());
				}
				
				if ((SBigDecimal)plan.get(RatingOutputConstants.MONTHLY_PREMIUM_FOR_ALL_PLANS_COMPOSITE_ONLY) != null) {
					objProposalDetails.setMonthlyPremiumAllCompositePlan(((SBigDecimal)plan.get(RatingOutputConstants.MONTHLY_PREMIUM_FOR_ALL_PLANS_COMPOSITE_ONLY)).doubleValue());
				}
				objProposalDetails.setGroupId(RatingOutputConstants.BL_TABLE_L_GROUP);
					
				//Table 5
				List<RuleRatingCensusCompGrp> table_K_List = new ArrayList<RuleRatingCensusCompGrp>();
				for (String ageBracket : AgeBracketConstants.AGE_BRACKET_LIST) {
					RuleRatingCensusCompGrp objCensusGrp = new RuleRatingCensusCompGrp();
					objCensusGrp.setAgeBracket(ageBracket);
					
					if (plan.getAgeBracketAggregationMap() != null) {
						if ((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket) != null) {
							
							if (((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
									get(RatingOutputConstants.AGEBRACKET_TOTAL_LIVES)) != null) {
								objCensusGrp.setTotalLives(((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
										get(RatingOutputConstants.AGEBRACKET_TOTAL_LIVES)).doubleValue());
							}
							
							if (((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
									get(RatingOutputConstants.AGEBRACKET_TOTAL_COVERED_VOLUME)) != null) {
								objCensusGrp.setTotalCoveredVolume(((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
										get(RatingOutputConstants.AGEBRACKET_TOTAL_COVERED_VOLUME)).doubleValue());
							}
							
							if (((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
									get(RatingOutputConstants.AGEBRACKET_PRELIMINARY_RATE)) != null) {
								objCensusGrp.setMonthlyPayPremStepRate(((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
										get(RatingOutputConstants.AGEBRACKET_PRELIMINARY_RATE)).doubleValue());
							}
							
							if (((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
									get(RatingOutputConstants.AGEBRACKET_TABLEIRATE)) != null) {
								objCensusGrp.setTableIRate(((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
										get(RatingOutputConstants.AGEBRACKET_TABLEIRATE)).doubleValue());
							}
							
							if (((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
									get(RatingOutputConstants.AGEBRACKET_CROSSTABLEI)) != null) {
								objCensusGrp.setTableIRate(((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
										get(RatingOutputConstants.AGEBRACKET_CROSSTABLEI)).doubleValue());
							}
							
							if (((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
									get(RatingOutputConstants.AGEBRACKET_FINAL_RATE)) != null) {
								objCensusGrp.setTableIRate(((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
										get(RatingOutputConstants.AGEBRACKET_FINAL_RATE)).doubleValue());
							}
							objCensusGrp.setGroupId(RatingOutputConstants.BL_TABLE_K_GROUP);
						}
					}
					table_K_List.add(objCensusGrp);
				}
				
				//Table 6
				ArrayList<RuleRatingModelOverrideGrp>  ageBracketFinalRateTableList = new ArrayList<RuleRatingModelOverrideGrp>();
				index = 0;
				for (String ageBracket : AgeBracketConstants.AGE_BRACKET_LIST) {
					RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
					
					if (plan.getAgeBracketAggregationMap() != null) {
						if ((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket) != null) {
							if (((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
									get(RatingOutputConstants.AGEBRACKET_FINAL_RATE)) != null) {
								objOverride.setFieldValue(((SBigDecimal)((HashMap)plan.getAgeBracketAggregationMap().get(ageBracket)).
										get(RatingOutputConstants.AGEBRACKET_FINAL_RATE)).doubleValue());
							} else {
								objOverride.setFieldValue(0.0);
							}
						}
					}
					objOverride.setFieldKey(ageBracket);
					objOverride.setGroupId(RatingOutputConstants.AGEBRACKET_FINAL_RATE_GROUP);
					objOverride.setFieldSeqNo(++index);
					objOverride.setOverrideAllowed(true);
					ageBracketFinalRateTableList.add(objOverride);
				}
				ratingModelOverideGrpList.add(ageBracketFinalRateTableList);
				
				//Table 7
				ArrayList<RuleRatingModelOverrideGrp>  tableC_List = new ArrayList<RuleRatingModelOverrideGrp>();
				index = 0;
				for (Map.Entry<String, String> entry : RatingOutputConstants.BL_TABLE_C.entrySet()) {
					RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
					objOverride.setFieldKey(entry.getKey());
					if (((SBigDecimal)plan.get(entry.getValue()) != null)) {
						objOverride.setFieldValue(((SBigDecimal)plan.get(entry.getValue())).doubleValue());
					} else {
						objOverride.setFieldValue(0);
					}
					if(StringUtils.equalsIgnoreCase(entry.getKey(), "Coverage Level Pooling Point") ||
							StringUtils.equalsIgnoreCase(entry.getKey(), "Coverage Level Tabular Non-Medical Maximum")) {
						objOverride.setOverrideAllowed(true);
					} else {
						objOverride.setOverrideAllowed(false);
					}
					objOverride.setGroupId(RatingOutputConstants.BL_TABLE_C_GROUP);
					objOverride.setFieldSeqNo(++index);
					if (StringUtils.equalsIgnoreCase(entry.getKey(),
							"Plan Level Requested Guarantee Non-Medical Limit")
							|| StringUtils
									.equalsIgnoreCase(entry.getKey(),
											"Coverage Level Tabular Non-Medical Maximum")) {
						objOverride.setPrecision(2);
					} else {
						objOverride.setPrecision(0);
					}
					tableC_List.add(objOverride);
				}
				ratingModelOverideGrpList.add(tableC_List);

				
				//Table 8
				List<RuleRatingAggregatedCensusGrp>  tableF_List = new ArrayList<RuleRatingAggregatedCensusGrp>();
				for(String status : StatusConstants.STATUS_LIST) {
					for(String gender : GenderConstants.GENDER_LIST) {
						for (String ageBracket : AgeBracketConstants.AGE_BRACKET_LIST) {
							HashMap statusMap = (HashMap) plan.getStatus_gender_ageB_age_AggregationMap().get(status);
							if (statusMap != null) {
								HashMap genderMap = (HashMap) statusMap.get(gender);
								if (genderMap != null) {
									HashMap ageBracketMap = (HashMap) genderMap.get(ageBracket);
									if (ageBracketMap != null) {
										RuleRatingAggregatedCensusGrp objAggregatedGrp = new RuleRatingAggregatedCensusGrp();
										objAggregatedGrp.setAgeBracket(ageBracket);
										objAggregatedGrp.setStatus(status);
										objAggregatedGrp.setGender(gender);
										
										if (ageBracketMap.get(RatingOutputConstants.AGEBRACKET_TOTAL_LIVES_BY_GENDER_STATUS_AGEBRACKET) != null) {
											objAggregatedGrp.setLives(((SBigDecimal)ageBracketMap.
														get(RatingOutputConstants.AGEBRACKET_TOTAL_LIVES_BY_GENDER_STATUS_AGEBRACKET)).doubleValue());
										}
										
										if (ageBracketMap.get(RatingOutputConstants.AGEBRACKET_COVERED_VOLUME_BY_GENDER_STATUS_AGEBRACKET) != null) {
											objAggregatedGrp.setCoveredVolume(((SBigDecimal)ageBracketMap.
														get(RatingOutputConstants.AGEBRACKET_COVERED_VOLUME_BY_GENDER_STATUS_AGEBRACKET)).doubleValue());
										}
										
										if (ageBracketMap.get(RatingOutputConstants.AGEBRACKET_NON_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET) != null) {
											objAggregatedGrp.setNonPooledVolume(((SBigDecimal)ageBracketMap.
														get(RatingOutputConstants.AGEBRACKET_NON_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET)).doubleValue());
										}
										
										
										if (ageBracketMap.get(RatingOutputConstants.AGEBRACKET_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET) != null) {
											objAggregatedGrp.setPooledVolume(((SBigDecimal)ageBracketMap.
														get(RatingOutputConstants.AGEBRACKET_POOLED_VOLUME_BY_GENDER_STATUS_AGEBRACKET)).doubleValue());
										}
										
										if (ageBracketMap.get(RatingOutputConstants.AGEBRACKET_NON_POOLED_MANUAL_RATE) != null) {
											objAggregatedGrp.setNonPooledManualRate(((SBigDecimal)ageBracketMap.
														get(RatingOutputConstants.AGEBRACKET_NON_POOLED_MANUAL_RATE)).doubleValue());
										}
										
										if (ageBracketMap.get(RatingOutputConstants.AGEBRACKET_POOLED_MANUAL_RATE) != null) {
											objAggregatedGrp.setPooledManualRate(((SBigDecimal)ageBracketMap.
														get(RatingOutputConstants.AGEBRACKET_POOLED_MANUAL_RATE)).doubleValue());
										}
										
										objAggregatedGrp.setGroupId(RatingOutputConstants.BL_TABLE_F_GROUP);
										tableF_List.add(objAggregatedGrp);
									}
								}
							}
						} // end AGE_BRACKET_LIST
					} // end GENDER_LIST
				} // end STATUS_LIST
				
				
				//logic to display active/retiree status
				boolean isActive = false;
				boolean isRetiree = false;
				/*for(String status : StatusConstants.STATUS_LIST) {
					if (plan.getStatusAggregationMap() != null && ((HashMap)plan.getStatusAggregationMap().get(status)) != null) {
						if (StringUtils.equalsIgnoreCase(status, StatusConstants.ACTIVE)) {
							isActive = true;
						} else if(StringUtils.equalsIgnoreCase(status, StatusConstants.RETIREE)) {
							isRetiree = true;
						}
					}
				}*/
				
				if (plan.getStatusAggregationMap() != null) {
					if (((HashMap)plan.getStatusAggregationMap()).containsKey(StatusConstants.ACTIVE)) {
						isActive = true;
					}
					if (((HashMap)plan.getStatusAggregationMap()).containsKey(StatusConstants.RETIREE)) {
						isRetiree = true;
					}
				}
				
				String displayStatus = StatusConstants.ACTIVE;
				if (isActive && isRetiree) {
					displayStatus = StatusConstants.ACTIVE;
				} else if(!isActive && isRetiree) {
					displayStatus = StatusConstants.RETIREE;
				} else if(isActive && !isRetiree) {
					displayStatus = StatusConstants.ACTIVE;
				}
				
				//Table 9
				ArrayList<RuleRatingModelOverrideGrp>  tableG_List = new ArrayList<RuleRatingModelOverrideGrp>();
				index = 0;
				for(String status : StatusConstants.STATUS_LIST) {
					if(StringUtils.equalsIgnoreCase(status,displayStatus)) {
						for (Map.Entry<String, String> entry : RatingOutputConstants.BL_TABLE_G.entrySet()) {
							if (plan.getStatusAggregationMap() != null && ((HashMap)plan.getStatusAggregationMap().get(status)) != null) {
								RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
								objOverride.setFieldKey(entry.getKey());
								SBigDecimal value = (SBigDecimal) ((HashMap)plan.getStatusAggregationMap().get(status)).
										get(entry.getValue());
								if (value != null) {
									objOverride.setFieldValue(value.doubleValue());
								} else {
									objOverride.setFieldValue(0);
								}
								//check this while commiting the file
								if(StringUtils.equalsIgnoreCase(entry.getKey(), "Industry Adjustment") ||
										StringUtils.equalsIgnoreCase(entry.getKey(), "Dental Factor") ||
										StringUtils.equalsIgnoreCase(entry.getKey(), "Area Factor") ||
										StringUtils.equalsIgnoreCase(entry.getKey(), "Salary Adjustment Factor") ||
										StringUtils.equalsIgnoreCase(entry.getKey(), "Waiver of premium SIC Adjustment") ||
										StringUtils.equalsIgnoreCase(entry.getKey(), "PruValue Discount Factor/Non-PruValue Other Non-Pooled Adjustment") ||
										StringUtils.equalsIgnoreCase(entry.getKey(), "PruValue Discount Factor/Non-PruValue Other Pooled Adjustment")) {
									objOverride.setOverrideAllowed(true);
								} else {
									objOverride.setOverrideAllowed(false);
								}
								objOverride.setGroupId(RatingOutputConstants.BL_TABLE_G_GROUP);
								objOverride.setFieldSeqNo(++index);
								
								
								
								
								if (StringUtils
										.equalsIgnoreCase(entry.getKey(),
												"Initial Base Claim Cost / Non-Pooled Annual Manual Premium")
										|| StringUtils
												.equalsIgnoreCase(
														entry.getKey(),
														"Initial Base Claim Cost High Cab / Pooled Annual Manual Premium")
										|| StringUtils
												.equalsIgnoreCase(
														entry.getKey(),
														"Non-Pooled Adjusted Annual Manual Premium")
										|| StringUtils
												.equalsIgnoreCase(
														entry.getKey(),
														"Pooled Adjusted Annual Manual Premium")
										|| StringUtils
												.equalsIgnoreCase(
														entry.getKey(),
														"Non-Pooled Adjusted Annual Manual Premium")
										|| StringUtils
												.equalsIgnoreCase(
														entry.getKey(),
														"Pooled Adjusted Annual Manual Premium")
										|| StringUtils
												.equalsIgnoreCase(
														entry.getKey(),
														"Non-Pooled Annual Expected Claims")|| StringUtils
														.equalsIgnoreCase(
																entry.getKey(),
																"Pooled Annual Expected Claims")) {
									objOverride.setPrecision(2);
								} else if (StringUtils.equalsIgnoreCase(
										entry.getKey(),
										"Total Non-Pooled Volume")
										|| StringUtils.equalsIgnoreCase(
												entry.getKey(),
												"Total Pooled Volume")
										|| StringUtils.equalsIgnoreCase(
												entry.getKey(),
												"Effective Date Difference")
										|| StringUtils.equalsIgnoreCase(
												entry.getKey(),
												"Pooled Monthly Expected Claim Rate")) {
									objOverride.setPrecision(0);
								} else if (StringUtils.equalsIgnoreCase(
										entry.getKey(),
										"Salary Adjustment Factor")
										|| StringUtils
												.equalsIgnoreCase(
														entry.getKey(),
														"Non-Pooled Monthly Expected Claim Rate")) {
									objOverride.setPrecision(3);
								} else {
									objOverride.setPrecision(4);
								}

								tableG_List.add(objOverride);
								
							}
						}
				     }
				}
				ratingModelOverideGrpList.add(tableG_List);

				//Table 10
				ArrayList<RuleRatingModelOverrideGrp>  tableH_List = new ArrayList<RuleRatingModelOverrideGrp>();
				index = 0;
				for (Map.Entry<String, String> entry : RatingOutputConstants.BL_TABLE_H.entrySet()) {
					RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
					objOverride.setFieldKey(entry.getKey());
					if (((SBigDecimal)plan.get(entry.getValue()) != null)) {
						objOverride.setFieldValue(((SBigDecimal)plan.get(entry.getValue())).doubleValue());
					} else {
						objOverride.setFieldValue(0);
					}
					if(StringUtils.equalsIgnoreCase(entry.getKey(), "Expected Annual Claim Experience") ||
							StringUtils.equalsIgnoreCase(entry.getKey(), "Credibility") ||
							StringUtils.equalsIgnoreCase(entry.getKey(), "Margin")) {
						objOverride.setOverrideAllowed(true);
					} else {
						objOverride.setOverrideAllowed(false);
					}
					objOverride.setGroupId(RatingOutputConstants.BL_TABLE_H_GROUP);
					objOverride.setFieldSeqNo(++index);
					if (StringUtils.equalsIgnoreCase(entry.getKey(),
							"Manual Claims Cost Rate / Composite Monthly Expected Claim RateMonthly Expected Claim Rate")
							|| StringUtils.equalsIgnoreCase(entry.getKey(),
									"Adjusted Claim Cost Rate / Blended Plan Level Claim Rate")) {
						objOverride.setPrecision(3);
					} else {
						objOverride.setPrecision(2);
					}
					tableH_List.add(objOverride);
				}
				ratingModelOverideGrpList.add(tableH_List);
				
				//Table 11
				ArrayList<RuleRatingModelOverrideGrp>  tableI_List = new ArrayList<RuleRatingModelOverrideGrp>();
				index = 0;
				for (Map.Entry<String, String> entry : RatingOutputConstants.BL_TABLE_I.entrySet()) {
					RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
					objOverride.setFieldKey(entry.getKey());
					if (((SBigDecimal)plan.get(entry.getValue()) != null)) {
						objOverride.setFieldValue(((SBigDecimal)plan.get(entry.getValue())).doubleValue());
					} else {
						objOverride.setFieldValue(0);
					}
					if(StringUtils.equalsIgnoreCase(entry.getKey(), "Rate Filing Profit") ||
							StringUtils.equalsIgnoreCase(entry.getKey(), "Maximum Allowable Commissions") ||
							StringUtils.equalsIgnoreCase(entry.getKey(), "Additional Administration Factor")) {
						objOverride.setOverrideAllowed(true);
					} else {
						objOverride.setOverrideAllowed(false);
					}
					objOverride.setGroupId(RatingOutputConstants.BL_TABLE_I_GROUP);
					objOverride.setFieldSeqNo(++index);
					
					
					if (StringUtils
							.equalsIgnoreCase(
									entry.getKey(),
									"PV Total Ben Charges All Life / NonPV Total Ben Charge Coverage")
							|| StringUtils
									.equalsIgnoreCase(entry.getKey(),
											"PV Total Est Ann Prem All Life / NonPV Est Ann Prem Coverage")) {
						objOverride.setPrecision(2);
					}else if (StringUtils
							.equalsIgnoreCase(
									entry.getKey(),
									"Premium Tax Factor")
							|| StringUtils
									.equalsIgnoreCase(entry.getKey(),
											"PV Total Est Ann Prem All Life / NonPV Est Ann Prem Coverage")) {
						objOverride.setPrecision(5);
					}else if (StringUtils
							.equalsIgnoreCase(
									entry.getKey(),
									"Rate Filing Expenses")
							|| StringUtils
									.equalsIgnoreCase(entry.getKey(),
											"Rate Filing Profit")|| StringUtils
											.equalsIgnoreCase(entry.getKey(),
													"Additional Administration Factor")|| StringUtils
													.equalsIgnoreCase(entry.getKey(),
															"Travel Assistance Factor")|| StringUtils
															.equalsIgnoreCase(entry.getKey(),
																	"Manual Retention % / Adjusted Retention %")) {
						objOverride.setPrecision(4);
					}else {
						objOverride.setPrecision(3);
					}
					
					
					tableI_List.add(objOverride);
				}
				ratingModelOverideGrpList.add(tableI_List);

				//Table 12
				ArrayList<RuleRatingModelOverrideGrp>  reportTable_List = new ArrayList<RuleRatingModelOverrideGrp>();
				index = 0;
				for (Map.Entry<String, String> entry : RatingOutputConstants.BL_REPORT_TABLE.entrySet()) {
					RuleRatingModelOverrideGrp objOverride = new RuleRatingModelOverrideGrp();
					objOverride.setFieldKey(entry.getKey());
					if (((SBigDecimal)plan.get(entry.getValue()) != null)) {
						objOverride.setFieldValue(((SBigDecimal)plan.get(entry.getValue())).doubleValue());
					} else {
						objOverride.setFieldValue(0);
					}
					objOverride.setOverrideAllowed(false);
					objOverride.setGroupId(RatingOutputConstants.BL_REPORT_TABLE_GROUP);
					objOverride.setFieldSeqNo(++index);
					reportTable_List.add(objOverride);
				}
				ratingModelOverideGrpList.add(reportTable_List);

				
				wrapper.setRatingModelOverideGrp(ratingModelOverideGrpList);
				wrapper.setRatingCensusCompGrp(table_K_List);
				//wrapper.setRatingRuleResultGrp(ratingRuleResultGrp);
				wrapper.setRatingAggregatedCensusGrp(tableF_List);
				wrapper.setProposalPlanDetails(objProposalDetails);  
				plansOutput.add(wrapper);
			} //end PlanList
		}
		
		return plansOutput;
	}
}
