package com.pru.sparc.drools.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.model.SBigDecimal;



public final class SparcRoundingMethodology {
	private static final Double FACTOR_1 = new Double(1);
	private static final Double FACTOR_10 = new Double(10);
	private static final Double FACTOR_100 = new Double(100);
	private static final Double FACTOR_500 = new Double(500);
	private static final Double FACTOR_1000 = new Double(1000);
	final static Logger logger = LoggerFactory.getLogger(SparcRoundingMethodology.class);
	
	private SparcRoundingMethodology() {
		
	}
	
	public static void main(String[] args) {
		SBigDecimal val = new SBigDecimal(new Double(30187));
		SBigDecimal roundingSelection = new SBigDecimal(11);
		logger.debug("Rounding selection: {}", roundingSubMethodology(roundingSelection,val).doubleValue());
		
		SBigDecimal val1 = new SBigDecimal(new Double("30187.51"));
		SBigDecimal val2 = new SBigDecimal(new Double("-30187.65"));

		logger.debug("Value 1: {}", val1);
		logger.debug("Value 2: {}", val2);

	}
	
	public static SBigDecimal roundingSubMethodology(SBigDecimal rSelection, SBigDecimal preRoundedVal) {
		int roundingSelection = rSelection.intValue();
       
		//SBigDecimal checkDivisibleby500 = SparcRatingUtil.getRemainder(preRoundedVal, new SBigDecimal(FACTOR_500));
		SBigDecimal checkDivisibleby500 = preRoundedVal.remainder(new SBigDecimal(FACTOR_500));

		
		SBigDecimal divideby1000_RoundDown = SparcRatingUtil.divideByRoundDown(preRoundedVal, new SBigDecimal(FACTOR_1000));
		SBigDecimal divideby1000_RoundUp = SparcRatingUtil.divideByRoundUp(preRoundedVal, new SBigDecimal(FACTOR_1000));
		SBigDecimal valueToRound = preRoundedVal;
		
		SBigDecimal scale_To_Rounding_Magnitude = null;
		if (roundingSelection == 2 
				|| roundingSelection == 6 
				|| roundingSelection == 8 
				|| roundingSelection == 12) {
			//scale_To_Rounding_Magnitude = SparcRatingUtil.divideBy(valueToRound, new SBigDecimal(FACTOR_1));
			scale_To_Rounding_Magnitude = valueToRound.divide(new SBigDecimal(FACTOR_1));

			
		} else if (roundingSelection == 3 || roundingSelection == 9)  {
			//scale_To_Rounding_Magnitude = SparcRatingUtil.divideBy(valueToRound, new SBigDecimal(FACTOR_10));
			scale_To_Rounding_Magnitude = valueToRound.divide(new SBigDecimal(FACTOR_10));
		} else if (roundingSelection == 4 || roundingSelection == 10)  {
			//scale_To_Rounding_Magnitude = SparcRatingUtil.divideBy(valueToRound, new SBigDecimal(FACTOR_100));
			scale_To_Rounding_Magnitude = valueToRound.divide(new SBigDecimal(FACTOR_100));

		}  else if (roundingSelection == 5 || roundingSelection == 11)  {
			//scale_To_Rounding_Magnitude = SparcRatingUtil.divideBy(valueToRound, new SBigDecimal(FACTOR_1000));
			scale_To_Rounding_Magnitude = valueToRound.divide(new SBigDecimal(FACTOR_1000));

		} else if (roundingSelection == 1 || roundingSelection == 7 
				|| checkDivisibleby500.doubleValue() == 0)  {
			//scale_To_Rounding_Magnitude = SparcRatingUtil.divideBy(valueToRound, new SBigDecimal(FACTOR_1));
			scale_To_Rounding_Magnitude = valueToRound.divide(new SBigDecimal(FACTOR_1));

		} else if (roundingSelection == 1 || roundingSelection == 7 
				|| checkDivisibleby500.doubleValue() != 0)  {
			//scale_To_Rounding_Magnitude = SparcRatingUtil.divideBy(valueToRound, new SBigDecimal(FACTOR_1000));
			scale_To_Rounding_Magnitude = valueToRound.divide(new SBigDecimal(FACTOR_1000));

		}
		
		SBigDecimal doRounding = null;
		SBigDecimal round500_No = null;
		if(roundingSelection >= 2 && roundingSelection <= 5) {
			doRounding = SparcRatingUtil.roundDown(scale_To_Rounding_Magnitude);
		} else if(roundingSelection >= 8 && roundingSelection <= 11) {
			doRounding = SparcRatingUtil.roundUp(scale_To_Rounding_Magnitude);
		} else if (roundingSelection == 1 || roundingSelection == 7 
					|| checkDivisibleby500.doubleValue() != 0)  {
			doRounding = SparcRatingUtil.roundNearest(scale_To_Rounding_Magnitude);
		} else if (roundingSelection == 1 || roundingSelection == 7 
				|| checkDivisibleby500.doubleValue() == 0)  {
			if (roundingSelection == 1) {
				round500_No = divideby1000_RoundDown;
			} else if (roundingSelection == 7) {
				round500_No = divideby1000_RoundUp;
			}
		} else {
			//Do not round. No operations in this else
		}
		SBigDecimal output = null;
		if (doRounding != null) {
			output = doRounding;
		} else if (round500_No != null) {
			output = round500_No;
		} else {
			output = scale_To_Rounding_Magnitude;
		}
		SBigDecimal scale_To_Original_Magnitude = null;
		if (roundingSelection == 2 
				|| roundingSelection == 6 
				|| roundingSelection == 8 
				|| roundingSelection == 12)  {
			//scale_To_Original_Magnitude =  SparcRatingUtil.multiply(output, new SBigDecimal(FACTOR_1));
			scale_To_Original_Magnitude =  output.multiply(new SBigDecimal(FACTOR_1));

		} else if (roundingSelection == 3 || roundingSelection == 9)  {
			//scale_To_Original_Magnitude =  SparcRatingUtil.multiply(output, new SBigDecimal(FACTOR_10));
			scale_To_Original_Magnitude =  output.multiply(new SBigDecimal(FACTOR_10));
		} else if (roundingSelection == 4 || roundingSelection == 10)  {
			//scale_To_Original_Magnitude =  SparcRatingUtil.multiply(output, new SBigDecimal(FACTOR_100));
			scale_To_Original_Magnitude =  output.multiply(new SBigDecimal(FACTOR_100));

		}  else if (roundingSelection == 1 || roundingSelection == 5
					|| roundingSelection == 7 || roundingSelection == 11)  {
			//scale_To_Original_Magnitude =  SparcRatingUtil.multiply(output, new SBigDecimal(FACTOR_1000));
			scale_To_Original_Magnitude =  output.multiply(new SBigDecimal(FACTOR_1000));

		}
		return scale_To_Original_Magnitude;
	}
}
