package com.pru.sparc.drools.common.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ibm.websphere.cache.DistributedMap;

public class DynaCacheUtil {
	private static DistributedMap cache;

	static {

		InitialContext ic;
		try {
			ic = new InitialContext();
			cache = (DistributedMap) ic.lookup("jndi/dynacache");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Object getValue(Object key) {

		return (cache.get(key));

	}

	public void putValue(Object key, Object value) {

		cache.put(key, value);

	}

}
