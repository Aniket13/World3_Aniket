package com.pru.sparc.drools.common.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import org.drools.RuleBase;
import org.drools.RuleBaseFactory;
import org.drools.compiler.PackageBuilder;
import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;



public class BusinessRulesHelper {
	public BusinessRulesHelper()
    {
    }

    public static List readDecisionTable(String ruleSheetFilePath)
        throws Exception
    {
    	System.out.println("reading");
        RuleBase ruleBase = null;
        List returnList = new ArrayList();
        String extension = "";
        try
        {
        	int i = ruleSheetFilePath.lastIndexOf('.');
        	if (i >= 0) {
        	    extension = ruleSheetFilePath.substring(i+1);
        	}	
        	System.out.println("ext-"+extension);
            String drl = constructDrl(ruleSheetFilePath,extension);
            ruleBase = createRuleBaseFrmDrl(drl);
        }
        catch(Exception e)
        {
            throw e;
        }
        returnList.add(ruleBase);
        
        return returnList;
    }

    public static Boolean checkIfFileModified(Long fileLastModifiedTimeStamp, ArrayList ruleBaseLst)
        throws Exception
    {
        try
        {
            if(!((Long)ruleBaseLst.get(0)).equals(fileLastModifiedTimeStamp))
                return Boolean.valueOf(true);
        }
        catch(Exception e)
        {
            throw e;
        }
        return Boolean.valueOf(false);
    }

    public static String constructDrl(String absoluteRulePath,String fileType)
        throws Exception
    {
        InputStream ruleSourceStream;
        String drl;
        if(absoluteRulePath == null || absoluteRulePath.trim().length() == 0)
            throw new Exception("RuleFileName is required");
        ruleSourceStream = null;
        drl = "";
        try
        {
            File file = new File(absoluteRulePath);
            ruleSourceStream = new FileInputStream(file);
            
            if(fileType.equalsIgnoreCase("drl"))
            {
            	
            	drl = getStringFromInputStream(ruleSourceStream);
            	
            }
            
            else if(fileType.equalsIgnoreCase("xls"))
        
            {
            	 SpreadsheetCompiler converter = new SpreadsheetCompiler();
                drl = converter.compile(ruleSourceStream, InputType.XLS);
            	
            }
        
           
        }
        catch(NullPointerException npe)
        {
            throw npe;
        }
        catch(FileNotFoundException fe)
        {
            throw fe;
        }
        catch(Exception e)
        {
            throw e;
        }
       
        if(ruleSourceStream != null)
            ruleSourceStream.close();
            
        return drl;
    }

    private static String getStringFromInputStream(InputStream is) {

		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line+"\n");
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();

	}
    public static RuleBase createRuleBaseFrmDrl(String drl)
        throws Exception
    {
        StringReader reader;
        RuleBase ruleBase;
      
        reader = null;
        ruleBase = null;
        //builder = null;
        if(drl == null || drl.trim().length() == 0)
            throw new Exception("Drool String is required");
        try
        {
        	PackageBuilder builder = new PackageBuilder();
            reader = new StringReader(drl);
            builder.addPackageFromDrl(reader);
            org.drools.rule.Package pkg = null;
            if(!builder.hasErrors())
                pkg = builder.getPackage();
            else
                throw new Exception(builder.getErrors().toString());
            if(pkg != null)
            {
                ruleBase = RuleBaseFactory.newRuleBase();
                ruleBase.addPackage(pkg);
            }
        }
        catch(Exception e)
        {
            throw e;
        }
     
        if(reader != null)
            reader.close();
       /* if(builder != null)
            builder = null;*/
        return ruleBase;
    }

}
