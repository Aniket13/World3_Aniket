package com.pru.sparc.drools.common.util;

import java.util.Collection;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.definition.KnowledgePackage;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

public class RuleRunner {
	
	public RuleRunner() {
		// TODO Auto-generated constructor stub
	}
	public void runRules(String[] rules,Object[] facts,String ruleFocus){
	//create knowledge base	
		KnowledgeBase kbase=KnowledgeBaseFactory.newKnowledgeBase();
		//create knowledge builder
		KnowledgeBuilder kbuilder=KnowledgeBuilderFactory.newKnowledgeBuilder();
		//insert rules into knowledge builder
		for(int i=0;i<rules.length;i++){
			String ruleFile=rules[i];
			System.out.println("Loading files:"+ruleFile);
			kbuilder.add(ResourceFactory.newClassPathResource(ruleFile, RuleRunner.class), ResourceType.DRL);
		}
		//Add knowledge data to knowledge base
		Collection<KnowledgePackage> pkgs=kbuilder.getKnowledgePackages();
		kbase.addKnowledgePackages(pkgs);
		//create knowledge session
		StatefulKnowledgeSession ksession=kbase.newStatefulKnowledgeSession();
		//insert facts into session
		for(int i=0;i<facts.length;i++){
			Object fact= facts[i];
			System.out.println("Inserting fact:"+fact);
			ksession.insert(fact);
		}
		if(ruleFocus!=null){
			ksession.getAgenda().getAgendaGroup(ruleFocus).setFocus();
		}
		
		//fire all rules against all facts
		ksession.fireAllRules();
	}
}
