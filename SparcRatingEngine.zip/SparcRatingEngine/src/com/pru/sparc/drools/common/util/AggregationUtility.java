package com.pru.sparc.drools.common.util;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Comission;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.model.State;

public class AggregationUtility {
	final static Logger logger = LoggerFactory
			.getLogger(AggregationUtility.class);

	public static void main(String[] args) {

		HashMap<String, Object> planMap = new HashMap<String, Object>();
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		census.setCensusMap(censusMap);
		int peopleCount = 10;
		census.setListOfPeople(getCensusWithEmployees(peopleCount));
		plan.setCensus(census);

		String key = PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME;
		for (int i = 0; i < plan.getCensus().getListOfPeople().size(); i++) {
			Person person = plan.getCensus().getListOfPeople().get(i);
			aggregationUtil(plan, person, key, RuleRatingConstants.ADD_OPERATOR);
			logger.debug("**************Iteration:+ ({}+1) + **************", i);
			//logger.debug("Status Map: {}", plan.getStatusAggregationMap());
			logger.debug("Gender Map: {}", plan.getGenderAggregationMap());
			logger.debug("Age Bracket Map: {}",
					plan.getAgeBracketAggregationMap());
			logger.debug("Age Map: {}", plan.getAgeAggregationMap());
			logger.debug("Combination Map: {}",
					plan.getStatus_gender_ageB_age_AggregationMap());
		}

		// avgAgeBracketGenderUtil(plan.getAgeBracketAggregationMap(),RuleRatingConstants.AGE_BRACKET_20_24_KEY,key);
		// logger.debug("Age Bracket Map with avg: " +
		// plan.getAgeBracketAggregationMap());
		// logger.debug(((HashMap)(plan.getAgeBracketAggregationMap().get(RuleRatingConstants.AGE_BRACKET_20_24_KEY))).get(RuleRatingConstants.AVG_OPERATOR_KEY+key));
	}

	/**
	 * To calculate the min/max/add of agebracket output variables and store the aggregated value in plan 
	 * @param plan
	 * @param agebracketKey
	 * @param operator
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void aggregationUtilAgeBracket(final Plan plan,final String outputKey,final String agebracketKey,final String operator) {
		
		HashMap agebracketMap = (HashMap) plan.getAgeBracketAggregationMap().get(plan.getAgeBracket());
		SBigDecimal ageBracketVal = (SBigDecimal) agebracketMap.get(agebracketKey);
		
		String key = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR, operator)) {
			key = RuleRatingConstants.ADD_OPERATOR_KEY + agebracketKey;
			plan.getPlanMap().put(outputKey, MathUtility.add((SBigDecimal)plan.getPlanMap().get(outputKey),ageBracketVal));
		} else if (StringUtils.equalsIgnoreCase(RuleRatingConstants.MIN_OPERATOR, operator)) {
			key = RuleRatingConstants.MIN_OPERATOR_KEY + agebracketKey;
			plan.getPlanMap().put(outputKey, MathUtility.min((SBigDecimal)plan.getPlanMap().get(outputKey),ageBracketVal));
		} else if (StringUtils.equalsIgnoreCase(RuleRatingConstants.MAX_OPERATOR, operator)) {
			key = RuleRatingConstants.MAX_OPERATOR_KEY + agebracketKey;
			plan.getPlanMap().put(outputKey, MathUtility.max((SBigDecimal)plan.getPlanMap().get(outputKey),ageBracketVal));
		}
		
	}
	
	
	/**
	 * To calculate the min/max/add of each plan variables and store value in holding
	 * @param holding 
	 * @param plan
	 * @param outputKey
	 * @param planKey
	 * @param operator
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void aggregationUtilPlanLevel(final Holding holding,final Plan plan,final String outputKey,final String planKey,final String operator) {
		
		SBigDecimal planVal =  (SBigDecimal) plan.getPlanMap().get(planKey);
		
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR, operator)) {
			holding.getHoldingMap().put(outputKey, MathUtility.add((SBigDecimal)holding.getHoldingMap().get(outputKey),planVal));
		} else if (StringUtils.equalsIgnoreCase(RuleRatingConstants.MIN_OPERATOR, operator)) {
			holding.getHoldingMap().put(outputKey, MathUtility.add((SBigDecimal)holding.getHoldingMap().get(outputKey),planVal));
		} else if (StringUtils.equalsIgnoreCase(RuleRatingConstants.MAX_OPERATOR, operator)) {
			holding.getHoldingMap().put(outputKey, MathUtility.add((SBigDecimal)holding.getHoldingMap().get(outputKey),planVal));
		}
		
	}
	
	
	/**
	 * To calculate the min/max/add of people output variables and the store the
	 * aggregated value in plan
	 * 
	 * @param plan
	 * @param person
	 * @param peopleKey
	 * @param operator
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Plan aggregationUtil(final Plan plan, final Person person,
			final String peopleKey, final String operator) {
		SBigDecimal personVal = (SBigDecimal) person.getPeopleMap().get(
				peopleKey);
		String key = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			key = RuleRatingConstants.ADD_OPERATOR_KEY + peopleKey;
			plan.getPlanMap().put(key,
					MathUtility.add((SBigDecimal) plan.getPlanMap().get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			key = RuleRatingConstants.MIN_OPERATOR_KEY + peopleKey;
			plan.getPlanMap().put(key,
					MathUtility.min((SBigDecimal) plan.getPlanMap().get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			key = RuleRatingConstants.MAX_OPERATOR_KEY + peopleKey;
			plan.getPlanMap().put(key,
					MathUtility.max((SBigDecimal) plan.getPlanMap().get(key), personVal));
		}

		/*
		 * //Aggregation at plan level plan.getPlanMap().put(key,
		 * add((SBigDecimal)plan.getPlanMap().get(key),personVal));
		 */

		// logic for status aggregation
		String status = (String) person.getPeopleMap().get(
				PersonConstants.PEOPLE_STATUS);
		
		// logic for gender aggregation
		String gender = (String) person.getPeopleMap().get(
				PersonConstants.PEOPLE_GENDER);
		HashMap genderIndMap = (HashMap) plan.getGenderAggregationMap().get(
				gender);
		if (genderIndMap == null) {
			genderIndMap = new HashMap();
			plan.getGenderAggregationMap().put(gender, genderIndMap);
		}
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			genderIndMap.put(key,
					MathUtility.add((SBigDecimal) genderIndMap.get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			genderIndMap.put(key,
					MathUtility.min((SBigDecimal) genderIndMap.get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			genderIndMap.put(key,
					MathUtility.max((SBigDecimal) genderIndMap.get(key), personVal));
		}

		// logic for age-bracket aggregation and gender aggregation
		String ageBracket = getAgeBracketKey(((SBigDecimal) person
				.getPeopleMap().get(PersonConstants.PEOPLE_AGE)).intValue());
		HashMap ageBracketIndMap = (HashMap) plan.getAgeBracketAggregationMap()
				.get(ageBracket);
		if (ageBracketIndMap == null) {
			ageBracketIndMap = new HashMap();
			plan.getAgeBracketAggregationMap()
					.put(ageBracket, ageBracketIndMap);
		}
		HashMap genderInnerMap = (HashMap) ageBracketIndMap.get(gender);
		if (genderInnerMap == null) {
			genderInnerMap = new HashMap();
			ageBracketIndMap.put(gender, genderInnerMap);
		}
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			ageBracketIndMap.put(key,
					MathUtility.add((SBigDecimal) ageBracketIndMap.get(key), personVal));
			genderInnerMap.put(key,
					MathUtility.add((SBigDecimal) genderInnerMap.get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			ageBracketIndMap.put(key,
					MathUtility.min((SBigDecimal) ageBracketIndMap.get(key), personVal));
			genderInnerMap.put(key,
					MathUtility.min((SBigDecimal) genderInnerMap.get(key), personVal));

		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			ageBracketIndMap.put(key,
					MathUtility.max((SBigDecimal) ageBracketIndMap.get(key), personVal));
			genderInnerMap.put(key,
					MathUtility.min((SBigDecimal) genderInnerMap.get(key), personVal));
		}

		// logic for age aggregation
		String age = ((SBigDecimal) person.getPeopleMap().get(
				PersonConstants.PEOPLE_AGE)).toString();
		HashMap ageIndMap = (HashMap) plan.getAgeAggregationMap().get(age);
		if (ageIndMap == null) {
			ageIndMap = new HashMap();
			plan.getAgeAggregationMap().put(age, ageIndMap);
		}
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			ageIndMap
					.put(key, MathUtility.add((SBigDecimal) ageIndMap.get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			ageIndMap
					.put(key, MathUtility.min((SBigDecimal) ageIndMap.get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			ageIndMap
					.put(key, MathUtility.max((SBigDecimal) ageIndMap.get(key), personVal));
		}

		// logic for combined aggregation
		HashMap statusMap = (HashMap) plan
				.getStatus_gender_ageB_age_AggregationMap().get(status);
		if (statusMap == null) {
			statusMap = new HashMap();
			plan.getStatus_gender_ageB_age_AggregationMap().put(status,
					statusMap);
		}
		HashMap genderMap = (HashMap) statusMap.get(gender);
		if (genderMap == null) {
			genderMap = new HashMap();
			statusMap.put(gender, genderMap);
		}
		HashMap ageBracketMap = (HashMap) genderMap.get(ageBracket);
		if (ageBracketMap == null) {
			ageBracketMap = new HashMap();
			genderMap.put(ageBracket, ageBracketMap);
		}
		HashMap ageMap = (HashMap) ageBracketMap.get(age);
		if (ageMap == null) {
			ageMap = new HashMap();
			ageBracketMap.put(age, ageMap);
		}
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			ageMap.put(key, MathUtility.add((SBigDecimal) ageMap.get(key), personVal));
			ageBracketMap.put(key,
					MathUtility.add((SBigDecimal) ageBracketMap.get(key), personVal));
			genderMap
					.put(key, MathUtility.add((SBigDecimal) genderMap.get(key), personVal));
			statusMap
					.put(key, MathUtility.add((SBigDecimal) statusMap.get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			ageMap.put(key, MathUtility.min((SBigDecimal) ageMap.get(key), personVal));
			ageBracketMap.put(key,
					MathUtility.min((SBigDecimal) ageBracketMap.get(key), personVal));
			genderMap
					.put(key, MathUtility.min((SBigDecimal) genderMap.get(key), personVal));
			statusMap
					.put(key, MathUtility.min((SBigDecimal) statusMap.get(key), personVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			ageMap.put(key, MathUtility.max((SBigDecimal) ageMap.get(key), personVal));
			ageBracketMap.put(key,
					MathUtility.max((SBigDecimal) ageBracketMap.get(key), personVal));
			genderMap
					.put(key, MathUtility.max((SBigDecimal) genderMap.get(key), personVal));
			statusMap
					.put(key, MathUtility.max((SBigDecimal) statusMap.get(key), personVal));
		}
		return plan;
	}
	
	
	
	public static void aggregationStateUtil(final Plan plan, final State state,
			final String stateKey, final String operator) {
		SBigDecimal stateVal = (SBigDecimal) state.getStateMap().get(
				stateKey);
		String key = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			key = RuleRatingConstants.ADD_OPERATOR_KEY + stateKey;
			plan.getPlanMap().put(key,
					MathUtility.add((SBigDecimal) plan.getPlanMap().get(key), stateVal));
		} 
	}
	
	

	/**
	 * To calculate the average of people output variables based on status
	 * (Active/Retiree) and at plan level
	 * 
	 * @param plan
	 * @param peopleKey
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void averageUtil(final Plan plan, final String peopleKey) {

		String avgKey = RuleRatingConstants.AVG_OPERATOR_KEY + peopleKey;
		String sumKey = RuleRatingConstants.ADD_OPERATOR_KEY + peopleKey;
		String sumCountKey = RuleRatingConstants.ADD_OPERATOR_KEY
				+ PersonConstants.PEOPLE_LIFE_COUNT;
		HashMap activeStatusMap = (HashMap) plan.getStatus_gender_ageB_age_AggregationMap().get(
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		if (activeStatusMap != null) {
			SBigDecimal sumValue = (SBigDecimal) activeStatusMap.get(sumKey);
			SBigDecimal countValue = (SBigDecimal) activeStatusMap
					.get(sumCountKey);
			activeStatusMap.put(avgKey, sumValue.divide(countValue));
		}

		HashMap retireeStatusMap = (HashMap) plan.getStatus_gender_ageB_age_AggregationMap()
				.get(PersonConstants.PEOPLE_RETIREE_STATUS);
		if (retireeStatusMap != null) {
			SBigDecimal sumValue = (SBigDecimal) retireeStatusMap.get(sumKey);
			SBigDecimal countValue = (SBigDecimal) retireeStatusMap
					.get(sumCountKey);
			retireeStatusMap.put(avgKey, sumValue.divide(countValue));
		}
		SBigDecimal sumValue = (SBigDecimal) plan.get(sumKey);
		SBigDecimal countValue = (SBigDecimal) plan
				.get(sumCountKey);
		plan.put(avgKey, sumValue.divide(countValue));
		
	}

	
	/**
	 * To calculate the average of people output variables based on plan
	 * Use planKey to put the average value in plan instead of AVG_peopleKey.
	 * Need to invoke method to calculate SUM_peopleKey before invoking the average
	 * @param plan
	 * @param planKey
	 * @param peopleKey
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void averagePlanUtil(final Plan plan, final String planKey,  final String peopleKey) {

		//String sumKey = RuleRatingConstants.ADD_OPERATOR_KEY + peopleKey;
		String sumCountKey = RuleRatingConstants.ADD_OPERATOR_KEY
				+ PersonConstants.PEOPLE_LIFE_COUNT;
		SBigDecimal sumValue = (SBigDecimal) plan.get(peopleKey);
		SBigDecimal countValue = (SBigDecimal) plan
				.get(sumCountKey);
		plan.put(planKey, MathUtility.divide(sumValue, countValue));
		
	}
	
	
	/**
	 * To calculate the average of plan output variables based on holding
	 * Use holdingKey to put the average value in holding instead of AVG_planKey.
	 * Need to invoke method to calculate SUM_planKey before invoking the average
	 * @param plan
	 * @param planKey
	 * @param peopleKey
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void averageHoldingUtil(final Holding holding, final String holdingKey,final String holdingSumKey) {
		SBigDecimal sumValue = (SBigDecimal) holding.get(holdingSumKey);
		SBigDecimal countValue = (SBigDecimal) holding
				.get(HoldingConstants.HOLDING_TOTAL_NO_OF_PLANS);
		holding.put(holdingKey, MathUtility.divide(sumValue, countValue));
		
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void averageHoldingPeopleUtil(final Holding holding,final Plan plan, final String peopleKey) {

		//String HOLDING_AVERAGE_SALARY_FACTOR_STEP_2 = RuleRatingConstants.AVG_OPERATOR_KEY + peopleKey;
		String avgKey = RuleRatingConstants.AVG_OPERATOR_KEY + peopleKey;
		String sumKey = RuleRatingConstants.ADD_OPERATOR_KEY + peopleKey;
		String sumCountKey = RuleRatingConstants.ADD_OPERATOR_KEY
				+ PersonConstants.PEOPLE_LIFE_COUNT;
		
		SBigDecimal sumValue = (SBigDecimal) plan.get(sumKey);
		SBigDecimal countValue = (SBigDecimal) plan.get(sumCountKey);
		
		holding.put(avgKey,sumValue.divide(countValue));
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
    public static void avgSalaryUtil(final Person person, final String key) {
           
           String avgKey = RuleRatingConstants.AVG_OPERATOR_KEY + key;
           String sumKey = RuleRatingConstants.ADD_OPERATOR_KEY + key;
           String sumCountKey = RuleRatingConstants.ADD_OPERATOR_KEY + PersonConstants.PEOPLE_LIFE_COUNT;
           HashMap map = (HashMap)person.get(key);
           if (map != null){
                  SBigDecimal sumValue = (SBigDecimal)map.get(sumKey);
                  SBigDecimal countValue = (SBigDecimal)map.get(sumCountKey);                
                  map.put(avgKey, sumValue.divide(countValue));
           }
           
           
    }
	

	/**
	 * To calculate the average of age bracket output variables based on Gender
	 * (Male/Female)
	 * 
	 * @param ageBracketAggregationMap
	 * @param ageBracketKey
	 * @param peopleKey
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void avgAgeBracketGenderUtil(
			final HashMap<Object, Object> ageBracketAggregationMap,
			final String ageBracketKey, final String peopleKey) {
		String avgKey = RuleRatingConstants.AVG_OPERATOR_KEY + peopleKey;
		String sumKey = RuleRatingConstants.ADD_OPERATOR_KEY + peopleKey;
		String sumCountKey = RuleRatingConstants.ADD_OPERATOR_KEY
				+ PersonConstants.PEOPLE_LIFE_COUNT;

		HashMap currentMap = (HashMap) ageBracketAggregationMap
				.get(ageBracketKey);
		if (currentMap != null) {
			SBigDecimal sumValue = (SBigDecimal) currentMap.get(sumKey);
			SBigDecimal countValue = (SBigDecimal) currentMap.get(sumCountKey);
			// SBigDecimal countValue = new SBigDecimal(5);
			currentMap.put(avgKey, sumValue.divide(countValue));
		}
		HashMap maleGenderMap = (HashMap) ((HashMap) ageBracketAggregationMap
				.get(ageBracketKey)).get(PersonConstants.PEOPLE_GENDER_MALE);
		if (maleGenderMap != null) {
			SBigDecimal sumValue = (SBigDecimal) maleGenderMap.get(sumKey);
			SBigDecimal countValue = (SBigDecimal) currentMap.get(sumCountKey);
			// SBigDecimal countValue = new SBigDecimal(5);
			maleGenderMap.put(avgKey, sumValue.divide(countValue));
		}
		HashMap femaleGenderMap = (HashMap) ((HashMap) ageBracketAggregationMap
				.get(ageBracketKey)).get(PersonConstants.PEOPLE_GENDER_FEMALE);
		if (femaleGenderMap != null) {
			SBigDecimal sumValue = (SBigDecimal) femaleGenderMap.get(sumKey);
			SBigDecimal countValue = (SBigDecimal) currentMap.get(sumCountKey);
			// SBigDecimal countValue = new SBigDecimal(5);
			femaleGenderMap.put(avgKey, sumValue.divide(countValue));
		}
	}

	public static void sumAgeBracketUtil(final Plan plan,
			final HashMap<Object, Object> currentMap,
			final String ageBracketKey) {
		if (plan.getAgeBracketAggregationMap()!= null) {
			String sumKey = RuleRatingConstants.ADD_OPERATOR_KEY + ageBracketKey;
			if (currentMap != null) {
				plan.put(sumKey,
						MathUtility.add((SBigDecimal) currentMap.get(
						ageBracketKey), (SBigDecimal) plan.get(sumKey)));
			}
		}
		
	}

	
	public static void maxAgeBracketUtil(final Plan plan,
			final HashMap<Object, Object> currentMap,
			final String ageBracketKey) {
		if (plan.getAgeBracketAggregationMap()!= null) {
			String sumKey = RuleRatingConstants.MAX_OPERATOR_KEY + ageBracketKey;
			if (currentMap != null) {
				plan.put(sumKey,
						MathUtility.max((SBigDecimal) currentMap.get(
						ageBracketKey), (SBigDecimal) plan.get(sumKey)));
			}
		}	
	}
	/**
	 * To calculate the min/max/add of plan output variables and store the aggregation value in Plan
	 * @param plan
	 * @param commission
	 * @param keyName
	 * @param operator
	 */
	public static void aggregationUtil(final Plan plan, final Comission commission,
			final String keyName, final String operator) {
		SBigDecimal commissionValue = (SBigDecimal) commission.getCommissionMap().get(
				keyName);
		String key = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			key = RuleRatingConstants.ADD_OPERATOR_KEY + keyName;
			plan.getPlanMap().put(key,
					MathUtility.add((SBigDecimal) plan.getPlanMap().get(key), commissionValue));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			key = RuleRatingConstants.MIN_OPERATOR_KEY + keyName;
			plan.getPlanMap().put(key,
					MathUtility.min((SBigDecimal) plan.getPlanMap().get(key), commissionValue));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			key = RuleRatingConstants.MAX_OPERATOR_KEY + keyName;
			plan.getPlanMap().put(key,
					MathUtility.max((SBigDecimal) plan.getPlanMap().get(key), commissionValue));
		}
	}
	
	/**
	 * To calculate the min/max/add of plan output variables and the store the
	 * aggregated value in Holding
	 * 
	 * @param holding
	 * @param plan
	 * @param holdingKey
	 * @param planKey
	 * @param operator
	 * @return
	 */
	public static Holding getHoldingPlanAggregation(final Holding holding,
			final Plan plan, final String planKey, final String operator) {
		String aggregationKey = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			aggregationKey = RuleRatingConstants.ADD_OPERATOR_KEY + planKey;
			holding.getHoldingMap().put(
					aggregationKey,
					MathUtility.add((SBigDecimal) holding.getHoldingMap().get(
							aggregationKey), (SBigDecimal) plan.getPlanMap()
							.get(planKey)));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			aggregationKey = RuleRatingConstants.MIN_OPERATOR_KEY + planKey;
			holding.getHoldingMap().put(
					aggregationKey,
					MathUtility.min((SBigDecimal) holding.getHoldingMap().get(
							aggregationKey), (SBigDecimal) plan.getPlanMap()
							.get(planKey)));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			aggregationKey = RuleRatingConstants.MAX_OPERATOR_KEY + planKey;
			holding.getHoldingMap().put(
					aggregationKey,
					MathUtility.max((SBigDecimal) holding.getHoldingMap().get(
							aggregationKey), (SBigDecimal) plan.getPlanMap()
							.get(planKey)));
		}
		return holding;
	}

	/**
	 * To calculate the min/max/add of plan output variables and the store the
	 * aggregated value in Holding
	 * 
	 * @param holding
	 * @param plan
	 * @param holdingKey
	 * @param planKey
	 * @param operator
	 * @return
	 */
	public static Holding getHoldingPlanAggregation(final Holding holding,
			final String holdingKey, final Plan plan, final String planKey,
			final String operator) {

		
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {

			holding.getHoldingMap().put(
					holdingKey,
					MathUtility.add((SBigDecimal) holding.getHoldingMap().get(holdingKey),
							(SBigDecimal) plan.getPlanMap().get(planKey)));
			//System.out.println(holdingKey+""+holding.getHoldingMap().get(holdingKey));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {

			holding.getHoldingMap().put(
					holdingKey,
					MathUtility.min((SBigDecimal) holding.getHoldingMap().get(holdingKey),
							(SBigDecimal) plan.getPlanMap().get(planKey)));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {

			holding.getHoldingMap().put(
					holdingKey,
					MathUtility.max((SBigDecimal) holding.getHoldingMap().get(holdingKey),
							(SBigDecimal) plan.getPlanMap().get(planKey)));
		}
		return holding;
	}
	
	
	public static Holding aggregationHoldUtil(final Holding holding,final Plan plan, 
			final String planKey, final String operator) {
		SBigDecimal planVal = (SBigDecimal) plan.getPlanMap().get(
				planKey);
		String key = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			key = RuleRatingConstants.ADD_OPERATOR_KEY + planKey;
			holding.getHoldingMap().put(key,
					MathUtility.add((SBigDecimal) holding.getHoldingMap().get(key), planVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			key = RuleRatingConstants.MIN_OPERATOR_KEY + planKey;
			holding.getHoldingMap().put(key,
					MathUtility.min((SBigDecimal) holding.getHoldingMap().get(key), planVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			key = RuleRatingConstants.MAX_OPERATOR_KEY + planKey;
			holding.getHoldingMap().put(key,
					MathUtility.max((SBigDecimal) holding.getHoldingMap().get(key), planVal));
		}
		return holding;
	}
	
	
	/**
	 * To calculate the min/max/add of status output variables and the store the
	 * aggregated value in Holding
	 * 
	 * @param holding
	 * @param plan
	 * @param holdingKey
	 * @param planKey
	 * @param operator
	 * @return
	 */
	public static Holding getHoldingStatusAggregation(final Holding holding,
			final String holdingKey, final HashMap statusMap, final String statusKey,
			final String operator) {

		
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {

			holding.getHoldingMap().put(
					holdingKey,
					MathUtility.add((SBigDecimal) holding.getHoldingMap().get(holdingKey),
							(SBigDecimal) statusMap.get(statusKey)));
			//System.out.println(holdingKey+""+holding.getHoldingMap().get(holdingKey));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {

			holding.getHoldingMap().put(
					holdingKey,
					MathUtility.min((SBigDecimal) holding.getHoldingMap().get(holdingKey),
							(SBigDecimal) statusMap.get(statusKey)));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {

			holding.getHoldingMap().put(
					holdingKey,
					MathUtility.max((SBigDecimal) holding.getHoldingMap().get(holdingKey),
							(SBigDecimal) statusMap.get(statusKey)));
		}
		return holding;
	}
	
	
	
	
	/**
	 * To calculate the min/max/add of plan output variables and the store the
	 * aggregated value in Holding
	 * 
	 * @param holding
	 * @param plan
	 * @param holdingKey
	 * @param planKey
	 * @param operator
	 * @return
	 */
	public static void getPlanStatusAggregation(final Plan plan,
			final String planKey, final HashMap statusMap,
			final String statusKey, final String operator) {

		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			plan.getPlanMap().put(
					planKey,
					MathUtility.add((SBigDecimal) plan.getPlanMap()
							.get(planKey), (SBigDecimal) statusMap
							.get(statusKey)));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {

			plan.getPlanMap().put(
					planKey,
					MathUtility.min((SBigDecimal) plan.getPlanMap()
							.get(planKey), (SBigDecimal) statusMap
							.get(statusKey)));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {

			plan.getPlanMap().put(
					planKey,
					MathUtility.max((SBigDecimal) plan.getPlanMap()
							.get(planKey), (SBigDecimal) statusMap
							.get(statusKey)));
		}
	}

	/**
	 * To calculate the min/max/add of plan output variables and the store the
	 * aggregated value in Holding
	 * 
	 * @param holding
	 * @param genderAggregationMap
	 * @param holdingKey
	 * @param planKey
	 * @param operator
	 * @return
	 */
	public static Holding getHoldingGenderAggregation(final Holding holding, final String holdingkey,
			final String gender, final HashMap genderAggregationMap, final String key,
			final String operator) {
		String aggregationKey = "";
		HashMap genderMap = (HashMap) genderAggregationMap
				.get(gender);
		if(genderMap!=null){
		
			if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
					operator)) {
				aggregationKey = RuleRatingConstants.ADD_OPERATOR_KEY + key;
				holding.put(
						holdingkey,
						MathUtility.add(holding.get(holdingkey),
								genderMap.get(aggregationKey)));
			}
			if (StringUtils.equalsIgnoreCase(RuleRatingConstants.MIN_OPERATOR,
					operator)) {
				aggregationKey = RuleRatingConstants.MIN_OPERATOR_KEY + key;
				
				holding.put(
						holdingkey,
						MathUtility.min((SBigDecimal) holding.get(holdingkey),
								(SBigDecimal) genderMap.get(aggregationKey)));
			}
			if (StringUtils.equalsIgnoreCase(RuleRatingConstants.MAX_OPERATOR,
					operator)) {
				aggregationKey = RuleRatingConstants.MAX_OPERATOR_KEY + key;
				
				holding.put(
						holdingkey,
						MathUtility.max((SBigDecimal) holding.get(holdingkey),
								(SBigDecimal) genderMap.get(aggregationKey)));
			}
		}
		return holding;
	}
	
	public static void getPlanGenderAggregation(final Plan plan,
			final String plankey, final String gender,
			final HashMap genderAggregationMap, final String key) {
		HashMap genderMap = (HashMap) genderAggregationMap.get(gender);
		if (genderMap != null) {
			plan.put(plankey, genderMap.get(key));
		}
	}
	
	
	
	
	//Dummy
	
	/**
	 * To calculate the min/max/add of people output variables and the store the
	 * aggregated value in plan
	 * 
	 * @param plan
	 * @param person
	 * @param peopleKey
	 * @param operator
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Plan aggregationUtilAgeAggregate(final Plan plan,
			final String agebracketKey, final String operator) {
		
		HashMap agebracketMap = (HashMap) plan.getAgeBracketAggregationMap().get(plan.getAgeBracket());
		SBigDecimal ageBracketVal = (SBigDecimal) agebracketMap.get(agebracketKey);

		String key = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			key = RuleRatingConstants.ADD_OPERATOR_KEY + agebracketKey;
			plan.getPlanMap().put(key,
					MathUtility.add((SBigDecimal) plan.getPlanMap().get(key), ageBracketVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			key = RuleRatingConstants.MIN_OPERATOR_KEY + agebracketKey;
			plan.getPlanMap().put(key,
					MathUtility.min((SBigDecimal) plan.getPlanMap().get(key), ageBracketVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			key = RuleRatingConstants.MAX_OPERATOR_KEY + agebracketKey;
			plan.getPlanMap().put(key,
					MathUtility.max((SBigDecimal) plan.getPlanMap().get(key), ageBracketVal));
		}
		return plan;
	}
	
	public static String getAgeBracketKey(final int age) {
		String ageBracket = "";
		if (age >= 0 && age <= 19) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_0_19_KEY;
		} else if (age >= 20 && age <= 24) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_20_24_KEY;
		} else if (age >= 25 && age <= 29) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_25_29_KEY;
		} else if (age >= 30 && age <= 34) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_30_34_KEY;
		} else if (age >= 35 && age <= 39) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_35_39_KEY;
		} else if (age >= 40 && age <= 44) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_40_44_KEY;
		} else if (age >= 45 && age <= 49) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_45_49_KEY;
		} else if (age >= 50 && age <= 54) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_50_54_KEY;
		} else if (age >= 55 && age <= 59) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_55_59_KEY;
		} else if (age >= 60 && age <= 64) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_60_64_KEY;
		} else if (age >= 65 && age <= 69) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_65_69_KEY;
		} else if (age >= 70 && age <= 74) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_70_74_KEY;
		} else if (age >= 75 && age <= 79) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_75_79_KEY;
		} else if (age >= 80 && age <= 84) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_80_84_KEY;
		} else if (age > 84) {
			ageBracket = RuleRatingConstants.AGE_BRACKET_85_100_KEY;
		}
		return ageBracket;
	}

	// test data
	private static ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
		}

		return peopleList;
	}
	
	

	private static Person getPersonObject(int position) {
		List<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(22));
		peopleMap1.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap1.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap1.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(1200));
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(24));
		peopleMap2.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap2.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap2.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(2000));
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(26));
		peopleMap3.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap3.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap3.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(2200));
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(28));
		peopleMap4.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap4.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap4.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(4200));
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(30));
		peopleMap5.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap5.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap5.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(200));
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(32));
		peopleMap6.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap6.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap6.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(400));
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(34.0));
		peopleMap7.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap7.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap7.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(300));
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(36));
		peopleMap8.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap8.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap8.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(400));
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(38));
		peopleMap9.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap9.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap9.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(400));
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(40));
		peopleMap10.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap10.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap10.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(400));
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);
	}
	
	//Adding Rounding function
	
	/**
	 * To calculate the min/max/add of people output variables and the store the
	 * aggregated value in plan
	 * 
	 * @param plan
	 * @param person
	 * @param peopleKey
	 * @param operator
	 * @param setScale
	 * @param Round_Nearest
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Plan aggregationUtil(final Plan plan, final Person person,
			final String peopleKey, final String operator,final int scale, final RoundingMode roundingMode) {
		SBigDecimal personVal = (SBigDecimal) person.getPeopleMap().get(
				peopleKey);
		String key = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			key = RuleRatingConstants.ADD_OPERATOR_KEY + peopleKey;
			plan.getPlanMap().put(key,
					MathUtility.add((SBigDecimal) plan.getPlanMap().get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			key = RuleRatingConstants.MIN_OPERATOR_KEY + peopleKey;
			plan.getPlanMap().put(key,
					MathUtility.min((SBigDecimal) plan.getPlanMap().get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			key = RuleRatingConstants.MAX_OPERATOR_KEY + peopleKey;
			plan.getPlanMap().put(key,
					MathUtility.max((SBigDecimal) plan.getPlanMap().get(key), personVal).setScale(scale, roundingMode));
		}

		/*
		 * //Aggregation at plan level plan.getPlanMap().put(key,
		 * add((SBigDecimal)plan.getPlanMap().get(key),personVal));
		 */

		// logic for status aggregation
		String status = (String) person.getPeopleMap().get(
				PersonConstants.PEOPLE_STATUS);
		
		// logic for gender aggregation
		String gender = (String) person.getPeopleMap().get(
				PersonConstants.PEOPLE_GENDER);
		HashMap genderIndMap = (HashMap) plan.getGenderAggregationMap().get(
				gender);
		if (genderIndMap == null) {
			genderIndMap = new HashMap();
			plan.getGenderAggregationMap().put(gender, genderIndMap);
		}
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			genderIndMap.put(key,
					MathUtility.add((SBigDecimal) genderIndMap.get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			genderIndMap.put(key,
					MathUtility.min((SBigDecimal) genderIndMap.get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			genderIndMap.put(key,
					MathUtility.max((SBigDecimal) genderIndMap.get(key), personVal).setScale(scale, roundingMode));
		}

		// logic for age-bracket aggregation and gender aggregation
		String ageBracket = getAgeBracketKey(((SBigDecimal) person
				.getPeopleMap().get(PersonConstants.PEOPLE_AGE)).intValue());
		HashMap ageBracketIndMap = (HashMap) plan.getAgeBracketAggregationMap()
				.get(ageBracket);
		if (ageBracketIndMap == null) {
			ageBracketIndMap = new HashMap();
			plan.getAgeBracketAggregationMap()
					.put(ageBracket, ageBracketIndMap);
		}
		HashMap genderInnerMap = (HashMap) ageBracketIndMap.get(gender);
		if (genderInnerMap == null) {
			genderInnerMap = new HashMap();
			ageBracketIndMap.put(gender, genderInnerMap);
		}
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			ageBracketIndMap.put(key,
					MathUtility.add((SBigDecimal) ageBracketIndMap.get(key), personVal).setScale(scale, roundingMode));
			genderInnerMap.put(key,
					MathUtility.add((SBigDecimal) genderInnerMap.get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			ageBracketIndMap.put(key,
					MathUtility.min((SBigDecimal) ageBracketIndMap.get(key), personVal).setScale(scale, roundingMode));
			genderInnerMap.put(key,
					MathUtility.min((SBigDecimal) genderInnerMap.get(key), personVal).setScale(scale, roundingMode));

		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			ageBracketIndMap.put(key,
					MathUtility.max((SBigDecimal) ageBracketIndMap.get(key), personVal).setScale(scale, roundingMode));
			genderInnerMap.put(key,
					MathUtility.min((SBigDecimal) genderInnerMap.get(key), personVal).setScale(scale, roundingMode));
		}

		// logic for age aggregation
		String age = ((SBigDecimal) person.getPeopleMap().get(
				PersonConstants.PEOPLE_AGE)).toString();
		HashMap ageIndMap = (HashMap) plan.getAgeAggregationMap().get(age);
		if (ageIndMap == null) {
			ageIndMap = new HashMap();
			plan.getAgeAggregationMap().put(age, ageIndMap);
		}
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			ageIndMap
					.put(key, MathUtility.add((SBigDecimal) ageIndMap.get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			ageIndMap
					.put(key, MathUtility.min((SBigDecimal) ageIndMap.get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			ageIndMap
					.put(key, MathUtility.max((SBigDecimal) ageIndMap.get(key), personVal).setScale(scale, roundingMode));
		}

		// logic for combined aggregation
		HashMap statusMap = (HashMap) plan
				.getStatus_gender_ageB_age_AggregationMap().get(status);
		if (statusMap == null) {
			statusMap = new HashMap();
			plan.getStatus_gender_ageB_age_AggregationMap().put(status,
					statusMap);
		}
		HashMap genderMap = (HashMap) statusMap.get(gender);
		if (genderMap == null) {
			genderMap = new HashMap();
			statusMap.put(gender, genderMap);
		}
		HashMap ageBracketMap = (HashMap) genderMap.get(ageBracket);
		if (ageBracketMap == null) {
			ageBracketMap = new HashMap();
			genderMap.put(ageBracket, ageBracketMap);
		}
		HashMap ageMap = (HashMap) ageBracketMap.get(age);
		if (ageMap == null) {
			ageMap = new HashMap();
			ageBracketMap.put(age, ageMap);
		}
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			ageMap.put(key, MathUtility.add((SBigDecimal) ageMap.get(key), personVal).setScale(scale, roundingMode));
			ageBracketMap.put(key,
					MathUtility.add((SBigDecimal) ageBracketMap.get(key), personVal).setScale(scale, roundingMode));
			genderMap
					.put(key, MathUtility.add((SBigDecimal) genderMap.get(key), personVal).setScale(scale, roundingMode));
			statusMap
					.put(key, MathUtility.add((SBigDecimal) statusMap.get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			ageMap.put(key, MathUtility.min((SBigDecimal) ageMap.get(key), personVal).setScale(scale, roundingMode));
			ageBracketMap.put(key,
					MathUtility.min((SBigDecimal) ageBracketMap.get(key), personVal).setScale(scale, roundingMode));
			genderMap
					.put(key, MathUtility.min((SBigDecimal) genderMap.get(key), personVal).setScale(scale, roundingMode));
			statusMap
					.put(key, MathUtility.min((SBigDecimal) statusMap.get(key), personVal).setScale(scale, roundingMode));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			ageMap.put(key, MathUtility.max((SBigDecimal) ageMap.get(key), personVal).setScale(scale, roundingMode));
			ageBracketMap.put(key,
					MathUtility.max((SBigDecimal) ageBracketMap.get(key), personVal).setScale(scale, roundingMode));
			genderMap
					.put(key, MathUtility.max((SBigDecimal) genderMap.get(key), personVal).setScale(scale, roundingMode));
			statusMap
					.put(key, MathUtility.max((SBigDecimal) statusMap.get(key), personVal).setScale(scale, roundingMode));
		}
		return plan;
	}
	
	
	/**
	 * @param plan
	 * @param statusMap
	 * @param genderMap
	 * @param ageBracketMap
	 * @param ageMap
	 * @param agekey
	 * @param operator
	 * @return - This method updates the value from the ageMap to the respective status, gender and ageBracket maps. This needs to be called in the age loop which is called in the hierarchy
	 * of status -> gender -> age bracket. This will effectively give the aggregation at each of the levels in the loop.
	 */
	public static Plan ageAggregationUtil(final Plan plan, final HashMap statusMap, final HashMap genderMap, final HashMap ageBracketMap, final HashMap ageMap,
			final String agekey, final String operator) {
		SBigDecimal ageVal = (SBigDecimal) ageMap.get(agekey);
		String key = "";
		if (StringUtils.equalsIgnoreCase(RuleRatingConstants.ADD_OPERATOR,
				operator)) {
			key = RuleRatingConstants.ADD_OPERATOR_KEY + agekey;
			plan.put(key,
					MathUtility.add((SBigDecimal) plan.getPlanMap().get(key), ageVal));
			statusMap.put(key,
					MathUtility.add((SBigDecimal) statusMap.get(key), ageVal));
			genderMap.put(key,
					MathUtility.add((SBigDecimal) genderMap.get(key), ageVal));
			ageBracketMap.put(key,
					MathUtility.add((SBigDecimal) ageBracketMap.get(key), ageVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MIN_OPERATOR, operator)) {
			key = RuleRatingConstants.MIN_OPERATOR_KEY + agekey;
			plan.put(key,
					MathUtility.min((SBigDecimal) plan.getPlanMap().get(key), ageVal));
			statusMap.put(key,
					MathUtility.add((SBigDecimal) statusMap.get(key), ageVal));
			genderMap.put(key,
					MathUtility.add((SBigDecimal) genderMap.get(key), ageVal));
			ageBracketMap.put(key,
					MathUtility.add((SBigDecimal) ageBracketMap.get(key), ageVal));
		} else if (StringUtils.equalsIgnoreCase(
				RuleRatingConstants.MAX_OPERATOR, operator)) {
			key = RuleRatingConstants.MAX_OPERATOR_KEY + agekey;
			plan.put(key,
					MathUtility.max((SBigDecimal) plan.getPlanMap().get(key), ageVal));
			statusMap.put(key,
					MathUtility.add((SBigDecimal) statusMap.get(key), ageVal));
			genderMap.put(key,
					MathUtility.add((SBigDecimal) genderMap.get(key), ageVal));
			ageBracketMap.put(key,
					MathUtility.add((SBigDecimal) ageBracketMap.get(key), ageVal));
		}
		return plan;
	}
	
	
	
	
}
