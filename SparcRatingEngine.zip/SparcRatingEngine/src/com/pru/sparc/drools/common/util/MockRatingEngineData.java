package com.pru.sparc.drools.common.util;

import java.util.HashMap;
import java.util.List;

import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.model.StatusConstants;

public class MockRatingEngineData {

	@SuppressWarnings("unchecked")
	public Holding createResult() {
		
		Holding holding = new Holding();
		List<Plan> planList = holding.getListOfPlans();
		
		Plan plan = new Plan();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_ID, new Integer(1));
		planMap.put(PlanConstants.PLAN_OVERRIDE_75000_POSTCALC_STEP_1, new SBigDecimal(0.0));
		planMap.put(PlanConstants.PLAN_FIELD_ADJUSTMENT_OVERRIDE, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_COMPSYCH_RATE, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_ORIGINAL_RATE, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_DESIRED_RATE, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_ORIGNAL_RATE, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_DESIRED_RATE, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES, new SBigDecimal(10));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME, new SBigDecimal(6000.000));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES, new SBigDecimal(1.667));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM, new SBigDecimal(100.020));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_NON_MED_MAX, new SBigDecimal(6000.00));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME, new SBigDecimal(10));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM, new SBigDecimal(6000));
		planMap.put(PlanConstants.PLAN_COMMISSION_PERCENTAGE, new SBigDecimal(0.150));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM, new SBigDecimal(1200.24));
		
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_FINALRATE_ACTION_OUT, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME, new SBigDecimal(60000.00));
		planMap.put(PlanConstants.PLAN_RENEWAL_MANUAL_RATE, new SBigDecimal(1.667));
		planMap.put(PlanConstants.PLAN_RATE_ACTION_TABLE_OUT, new SBigDecimal(0.250));
		planMap.put(PlanConstants.PLAN_PAYABLE_RATE, new SBigDecimal(1.667));
		planMap.put(PlanConstants.PLAN_PAYABLE_RATE_STEP_3, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_ANNUAL_PREMIUM, new SBigDecimal(51.12));
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal(10));
		planMap.put(PlanConstants.PLAN_AVERAGE_AGE, new SBigDecimal(22));
		planMap.put(PlanConstants.PLAN_AVERAGE_ANNUAL_SALARY, new SBigDecimal(24000));
		planMap.put(PlanConstants.PLAN_HIGHEST_COVERAGE_AMOUNT, new SBigDecimal(6000));
		planMap.put(PlanConstants.PLAN_PERCENTAGE_FEMALE, new SBigDecimal(0.5000));
		planMap.put(PlanConstants.PLAN_COMMISSION_PERCENTAGE, new SBigDecimal(0.150));
		
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES, new SBigDecimal(10));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME, new SBigDecimal(60000.000));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES, new SBigDecimal(1.667));
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM, new SBigDecimal(100.020));
		planMap.put(PlanConstants.PLAN_COMPOSITE_RATE, new SBigDecimal(1.667));
		planMap.put(PlanConstants.PLAN_PAYABLE_RATE_STEP_3, new SBigDecimal(10.00));
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY, new SBigDecimal(10));
		planMap.put(PlanConstants.PLAN_ESTIMATED_VOLUME, new SBigDecimal(6000.00));
		planMap.put(PlanConstants.PLAN_TOTAL_ESTIMATED_VOLUME__COMPOSITE_ONLY, new SBigDecimal(6000));
		planMap.put(PlanConstants.PLAN_PAYABLE_RATE, new SBigDecimal(1.667));
		planMap.put(PlanConstants.PLAN_COMPOSITE_RATE, new SBigDecimal(1.667));
		planMap.put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY, new SBigDecimal(4.26));
		planMap.put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY, new SBigDecimal(4.26));
		
		planMap.put(PlanConstants.PLAN_TOTAL_COVERED_VOLUME, new SBigDecimal(60000));
		planMap.put(PlanConstants.PLAN_POOLING_POINT, new SBigDecimal(10000));
		planMap.put(PlanConstants.PLAN_AVERAGE_CERTIFICATE, new SBigDecimal(6000));
		planMap.put(PlanConstants.PLAN_CLIENT_POOLING_POINT, new SBigDecimal(6000));
		planMap.put(PlanConstants.PLAN_NON_MEDICAL_MAX, new SBigDecimal(60000.00));
		planMap.put(PlanConstants.PLAN_GUARANTEE_ISSUE, new SBigDecimal(60000.00));
		
		//logic for status
		HashMap activeStatusMap = new HashMap();
		activeStatusMap.put(StatusConstants.STATUS_NON_POOLED_ANNUAL_MANUAL_PREMIUM, new SBigDecimal("18.14"));
		activeStatusMap.put(StatusConstants.STATUS_NON_POOLED_VOLUME, new SBigDecimal("60000"));
		activeStatusMap.put(StatusConstants.STATUS_NON_POOLED_MANUAL_RATE, new SBigDecimal("0.0252"));
		activeStatusMap.put(StatusConstants.STATUS_POOLED_ANNUAL_MANUAL_PREMIUM, new SBigDecimal("0.00"));
		activeStatusMap.put(StatusConstants.STATUS_POOLED_VOLUME, new SBigDecimal("0"));
		activeStatusMap.put(StatusConstants.STATUS_POOLED_MANUAL_RATE, new SBigDecimal("0.0000"));
		activeStatusMap.put(StatusConstants.STATUS_EFFECTIVE_DATE_ADJUSTMENT_DIFFERENCE, new SBigDecimal("22"));
		activeStatusMap.put(StatusConstants.STATUS_EFFECTIVE_DATE_ADJUSTMENT, new SBigDecimal("1.0050"));
		activeStatusMap.put(StatusConstants.STATUS_INDUSTRY_ADJUSTMENT, new SBigDecimal("1.2400"));
		activeStatusMap.put(StatusConstants.STATUS_DENTAL_DISCOUNT, new SBigDecimal("1.00000"));
		activeStatusMap.put(StatusConstants.STATUS_AREA_FACTOR, new SBigDecimal("1.03000"));
		activeStatusMap.put(StatusConstants.STATUS_AVERAGE_SALARY_FACTOR, new SBigDecimal("1.156"));
		activeStatusMap.put(StatusConstants.STATUS_RATE_GUARANTEE, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_OPTIONAL_LIFE_ADJUSTMENT, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_ADD_DISCOUNT, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_DISABILITY_PRODUCT_DISCOUNT, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_LIFE_PLAN_ADJUSTMENT, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_LIVING_BENEFIT_OPTION_ADJUSTMENT, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_WAIVER_OF_PREMIUM, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_WAIVER_OF_PREMIUM_ADJUSTMENT, new SBigDecimal("0.9700"));
		activeStatusMap.put(StatusConstants.STATUS_CONVERSION_ADJUSTMENT, new SBigDecimal("1.0200"));
		activeStatusMap.put(StatusConstants.STATUS_OTHER_NON_POOLED_ADJUSTMENT, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_NON_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM, new SBigDecimal("26.63"));
		activeStatusMap.put(StatusConstants.STATUS_OTHER_POOLED_ADJUSTMENT, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM, new SBigDecimal("1.3500"));
		activeStatusMap.put(StatusConstants.STATUS_NON_POOLED_CAB, new SBigDecimal("1.0000"));
		activeStatusMap.put(StatusConstants.STATUS_POOLED_CAB, new SBigDecimal("1.3500"));
		activeStatusMap.put(StatusConstants.STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIMS, new SBigDecimal("26.63"));
		activeStatusMap.put(StatusConstants.STATUS_NON_POOLED_ANNUAL_EXPECTED_CLAIM_RATE, new SBigDecimal("0.037"));
		activeStatusMap.put(StatusConstants.STATUS_POOLED_ANNUAL_EXPECTED_CLAIMS, new SBigDecimal("0.00"));
		activeStatusMap.put(StatusConstants.STATUS_POOLED_ANNUAL_EXPECTED_CLAIM_RATE, new SBigDecimal("0.000"));
		
		plan.getStatusAggregationMap().put(StatusConstants.STATUS_LIST.get(0), activeStatusMap);
		//logic for age bracket
		for (int i = 0; i< AgeBracketConstants.AGE_BRACKET_LIST.size();i++) {
			String ageBracket = AgeBracketConstants.AGE_BRACKET_LIST.get(i);
			plan.setAgeBracket(ageBracket);
			HashMap ageBracketIndMap = ageBracketIndMap = new HashMap();
			ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_TOTAL_LIVES, new SBigDecimal("10"));
			
			ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_TOTAL_COVERED_VOLUME, new SBigDecimal("6000"));
			ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_PRELIMINARY_RATE, new SBigDecimal("0.00"));
			ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_TABLEIRATE, new SBigDecimal("0.05"));
			ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_CROSSTABLEI, new SBigDecimal("1.00"));
			ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_FINAL_RATE, new SBigDecimal("0.00"));
			//TODO: complete the map
			
			plan.getAgeBracketAggregationMap().put(ageBracket,ageBracketIndMap);
		}
		
	
		//TODO:logic for combined census details 
		
		planMap.put(PlanConstants.PLAN_PRODUCT_LIVES_SALES_OFFICE_DISCOUNT, new SBigDecimal(1.00));
		planMap.put(PlanConstants.PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIMS, new SBigDecimal(26.63));
		planMap.put(PlanConstants.PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIM_RATE, new SBigDecimal(0.037));
		planMap.put(PlanConstants.PLAN_EXPECTED_ANNUAL_CLAIMS_EXPERIENCE, new SBigDecimal(0.0));
		planMap.put(PlanConstants.PLAN_CREDIBILITY, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_BLENDED_EXPECTED_CLAIMS, new SBigDecimal(26.63));
		planMap.put(PlanConstants.PLAN_MARGIN, new SBigDecimal(0.0));
		planMap.put(PlanConstants.PLAN_TOTAL_BENEFIT_CHARGES, new SBigDecimal(26.63));
		planMap.put(PlanConstants.PLAN_BLENDED_CLAIM_RATE, new SBigDecimal(0.037));
		
		planMap.put(PlanConstants.PLAN_AVERAGE_CERTIFICATE, new SBigDecimal(26.63));
		planMap.put(PlanConstants.PLAN_CLIENT_POOLING_POINT, new SBigDecimal(39.45));
		planMap.put(PlanConstants.PLAN_NON_MEDICAL_MAX, new SBigDecimal(0.02709));
		planMap.put(PlanConstants.PLAN_GUARANTEE_ISSUE, new SBigDecimal(0.0550));
		planMap.put(PlanConstants.PLAN_PRODUCT_LIVES_SALES_OFFICE_DISCOUNT, new SBigDecimal(0.150));
		planMap.put(PlanConstants.PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIMS, new SBigDecimal(0.200));
		planMap.put(PlanConstants.PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIM_RATE, new SBigDecimal(0.150));
		planMap.put(PlanConstants.PLAN_EXPECTED_ANNUAL_CLAIMS_EXPERIENCE, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_CREDIBILITY, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_BLENDED_EXPECTED_CLAIMS, new SBigDecimal(0.1489));
		planMap.put(PlanConstants.PLAN_MARGIN, new SBigDecimal(0.000));
		
		//
		planMap.put(PlanConstants.PLAN_BENEFIT_CHARGES_FOR_ALL_PLANS, new SBigDecimal(26.63));
		planMap.put(PlanConstants.PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS, new SBigDecimal(39.45));
		planMap.put(PlanConstants.PLAN_PREMIUM_TAX_FACTOR, new SBigDecimal(0.02709));
		planMap.put(PlanConstants.PLAN_RATE_FILING_EXPENSES, new SBigDecimal(0.2948));
		planMap.put(PlanConstants.PLAN_RATE_FILING_PROFIT, new SBigDecimal(0.0550));
		planMap.put(PlanConstants.PLAN_LEVEL_SCALE_COMMISSIONS, new SBigDecimal(0.150));
		planMap.put(PlanConstants.PLAN_ADDITIONAL_SERVICE_COMMISSIONS, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_REQUESTED_COMMISSION, new SBigDecimal(0.150));
		planMap.put(PlanConstants.PLAN_MAX_ALLOWABLE_COMMISSIONS, new SBigDecimal(0.200));
		planMap.put(PlanConstants.PLAN_COMMISSION_PERCENTAGE, new SBigDecimal(0.150));
		planMap.put(PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION, new SBigDecimal(0.000));
		
		planMap.put(PlanConstants.PLAN_TRAVEL_ASSIST_ADJUSTMENT, new SBigDecimal(0.000));
		planMap.put(PlanConstants.PLAN_TOTAL_RETENTION, new SBigDecimal(0.1489));
		planMap.put(PlanConstants.PLAN_COMPETITIVE_WINDOW_FOR_REPORTING, new SBigDecimal(1.0));
		planMap.put(PlanConstants.PLAN_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING, new SBigDecimal(1200.24));

		plan.setPlanMap(planMap);
		planList.add(plan);
		holding.setListOfPlans(planList);
		return holding;
	}

}
