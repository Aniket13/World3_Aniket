package com.pru.sparc.drools.common.util;

public class BasicLifeConstant {
	public static final int BL_Grandfathered_Pooling_Point = 4500;
	public static final String BL_FACTOR_TABLE_LOCATION = "factorTable//basiclife//";
	public static final String BL_PLAN_LOOP1_DRL = "basiclife//loop1//BL_Plan_Loop1.drl";
	public static final String BL_PLAN_LOOP1_AGENDA_GROUP = "plan-loop1";
	
	
	public static final String BL_PLAN_LOOP7b_DRL = "basiclife//loop7b//BL_Plan_Loop7b.drl";
	public static final String BL_PLAN_LOOP7b_AGENDA_GROUP = "plan-loopb";
	
}
