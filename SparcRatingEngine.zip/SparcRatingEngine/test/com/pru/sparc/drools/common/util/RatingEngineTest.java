package com.pru.sparc.drools.common.util;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ People_Gross_volume_Test.class,
		Plan_Client_Pooling_Point_Test.class, People_Covered_Volume_Test.class })
public class RatingEngineTest {

}
