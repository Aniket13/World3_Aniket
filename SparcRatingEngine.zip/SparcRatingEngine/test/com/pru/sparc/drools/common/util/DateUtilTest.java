package com.pru.sparc.drools.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.TestCase;

import org.junit.Test;

public class DateUtilTest extends TestCase {

	@Test
	public void testGetMonthsDifference1() {
		try {
			Date date1 = new SimpleDateFormat("MM/dd/yyyy").parse("01/01/2012");
			Date date2 = new SimpleDateFormat("MM/dd/yyyy").parse("09/01/2012");
			assertTrue("Date difference not maching",
					DateUtil.getMonthsDifference(date1, date2) == 8);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test
	public void testGetMonthsDifference2() {
		try {
			Date date1 = new SimpleDateFormat("MM/dd/yyyy").parse("01/01/2009");
			Date date2 = new SimpleDateFormat("MM/dd/yyyy").parse("09/01/2012");
			assertTrue("Date difference not maching",
					DateUtil.getMonthsDifference(date1, date2) == 44);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	@Test
	public void testFormatMMddyyyyToEEEMMMddhhmmsszyyyy1(){
		try {
			String date = "01/01/2002";
			String formattedDate = DateUtil.formatMMddyyyyToEEEMMMddhhmmsszyyyy(date);
			System.out.println(formattedDate);
			assertTrue("Date difference not maching",
					formattedDate.equalsIgnoreCase("Tue Jan 01 12:00:00 IST 2002"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testFormatMMddyyyyToEEEMMMddhhmmsszyyyy2(){
		try {
			String date = "12/31/9999";
			String formattedDate = DateUtil.formatMMddyyyyToEEEMMMddhhmmsszyyyy(date);
			System.out.println(formattedDate);
			assertTrue("Date difference not maching",
					formattedDate.equalsIgnoreCase("Fri Dec 31 12:00:00 IST 9999"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Tests condition when date = startDate
	 */
	@Test
	public void testIsBetweenInclStartDate1(){
		try {
			Date date1 = DateUtil.getDateMMddyyy("01/01/2002");
			Date startDate = DateUtil.getDateMMddyyy("01/01/2002");
			Date endDate = DateUtil.getDateMMddyyy("10/01/2002");
			assertTrue("Date difference not maching",
					DateUtil.isBetweenInclStartDate(date1, startDate, endDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Tests condition when date in between start and end date
	 */
	@Test
	public void testIsBetweenInclStartDate2(){
		try {
			Date date1 = DateUtil.getDateMMddyyy("06/01/2002");
			Date startDate = DateUtil.getDateMMddyyy("01/01/2002");
			Date endDate = DateUtil.getDateMMddyyy("10/01/2002");
			assertTrue("Date difference not maching",
					DateUtil.isBetweenInclStartDate(date1, startDate, endDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Tests condition when date = end date
	 */
	@Test
	public void testIsBetweenInclStartDate3(){
		try {
			Date date1 = DateUtil.getDateMMddyyy("10/01/2002");
			Date startDate = DateUtil.getDateMMddyyy("01/01/2002");
			Date endDate = DateUtil.getDateMMddyyy("10/01/2002");
			assertTrue("Date difference not maching",
					!DateUtil.isBetweenInclStartDate(date1, startDate, endDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Test condition when date earlier than start date
	 */
	@Test
	public void testIsBetweenInclStartDate4(){
		try {
			Date date1 = DateUtil.getDateMMddyyy("01/01/2001");
			Date startDate = DateUtil.getDateMMddyyy("01/01/2002");
			Date endDate = DateUtil.getDateMMddyyy("10/01/2002");
			assertTrue("Date difference not maching",
					!DateUtil.isBetweenInclStartDate(date1, startDate, endDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Test condition when date after end date
	 */
	@Test
	public void testIsBetweenInclStartDate5(){
		try {
			Date date1 = DateUtil.getDateMMddyyy("01/01/2008");
			Date startDate = DateUtil.getDateMMddyyy("01/01/2002");
			Date endDate = DateUtil.getDateMMddyyy("10/01/2002");
			assertTrue("Date difference not maching",
					!DateUtil.isBetweenInclStartDate(date1, startDate, endDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
