package com.pru.sparc.drools.common.util;

import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.Collection;

import org.drools.command.assertion.AssertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import com.pru.sparc.drools.model.SparcBigDecimal;

@RunWith(Parameterized.class)
public class SparcRoundingMethodologyTest {
	
	private int roundingSelection;
	private SparcBigDecimal preRoundedVal;
	private SparcBigDecimal expectedResult;
	
	/*@Before
	public void setUp() {
		SparcRoundingMethodology obj = new SparcRoundingMethodology();
	}*/
	
	public SparcRoundingMethodologyTest(int roundingSelection,
			SparcBigDecimal preRoundedVal, SparcBigDecimal expectedResult) {
		this.roundingSelection = roundingSelection;
		this.preRoundedVal = preRoundedVal;
		this.expectedResult = expectedResult;
	}
	
	@Parameterized.Parameters
	   public static Collection primeNumbers() {
	      return Arrays.asList(new Object[][] {
	         { 1, new SparcBigDecimal(30187.0),new SparcBigDecimal(31000.0) },
	         { 2, new SparcBigDecimal(30187.0),new SparcBigDecimal(31000.0) },
	         { 3, new SparcBigDecimal(30187.0),new SparcBigDecimal(31000.0) },
	         { 4, new SparcBigDecimal(30187.0),new SparcBigDecimal(31000.0) },
	         { 11, new SparcBigDecimal(30187.0),new SparcBigDecimal(31000.0) }
	      });
	}
	
	@Test
	public void testRoundingSubMethodology() {
		/*SparcBigDecimal result = SparcRoundingMethodology.roundingSubMethodology(roundingSelection, preRoundedVal);
		System.out.println(result);
		assertThat(result, is(expectedResult));*/
	}
}
