package com.pru.sparc.drools.common.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class Plan_Pooling_Point_Test {

	@Test
	public void test() {
		
	}

}
