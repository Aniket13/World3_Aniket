package com.pru.sparc.drools.common.util;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.Plan_Age_Reduction_Check_0_Volume_Percent;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;

public class People_Custom_Age_Reduction_Percent_Reduction_Amount_Test {

	Plan_Age_Reduction_Check_0_Volume_Percent zeroPercent = new Plan_Age_Reduction_Check_0_Volume_Percent();

	@Test
	public void testPeople_Custom_Age_Reduction_Type_Is_0() {
		Holding hold = new Holding();

		//2.10.1.1.1.1.13.2.2

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("Plan/AgeReductionSchedule", "Sched11");
		planMap1.put("Plan/VolumeType", "FlatAmt");
		
		
		planMap1.put("plan_Custom_Reduction_Age_1", 20.0);
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		List listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);

		// hardcoded list of plans
		hold.setListOfPlans(listOfPlans);

		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		
		Census census = new Census();
		census.setCensusMap(censusMap);

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Age", 14.0);
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);
		ArrayList<Person> peopleList = new ArrayList<Person>();
		peopleList.add(person1);
		census.setListOfPeople(peopleList);
		hold.setCensus(census);

		zeroPercent.invokeRatingEngine(hold);

		assertEquals("Check: People Custom reduction volume",hold.getCensus()
				.getCensusMap().get("people_Custom_Age_Reduction_Type"), hold.getCensus()
				.getCensusMap().get("people_Custom_Age_Reduction_Percent_Reduction_Amount"));

	}
	
	@Test
	public void testPlan_Custom_Reduction_Type_1() {
		Holding hold = new Holding();

		//2.10.1.1.1.1.13.2.2

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("Plan/AgeReductionSchedule", "Sched11");
		planMap1.put("Plan/VolumeType", "FlatAmt");
		
		
		planMap1.put("plan_Custom_Reduction_Age_1", 20.0);
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		List listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);

		// hardcoded list of plans
		hold.setListOfPlans(listOfPlans);

		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		
		Census census = new Census();
		census.setCensusMap(censusMap);

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Age", 14.0);
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);
		ArrayList<Person> peopleList = new ArrayList<Person>();
		peopleList.add(person1);
		census.setListOfPeople(peopleList);
		hold.setCensus(census);

		zeroPercent.invokeRatingEngine(hold);

		assertEquals("Check: People Custom reduction volume",0, hold.getCensus()
				.getCensusMap().get("people_Custom_Age_Reduction_Percent_Reduction_Amount"));

	}
	
	
	@Test
	public void testPlan_Custom_Reduction_Age_1() {
		Holding hold = new Holding();

		//2.10.1.1.1.1.13.2.2

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("Plan/AgeReductionSchedule", "Sched11");
		planMap1.put("Plan/VolumeType", "FlatAmt");
		
		
		planMap1.put("plan_Custom_Reduction_Age_1", 20.0);
		planMap1.put("plan_Custom_Reduction_Age_2", 30.0);
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		List listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);

		// hardcoded list of plans
		hold.setListOfPlans(listOfPlans);

		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		
		Census census = new Census();
		census.setCensusMap(censusMap);

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Age", 14.0);
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);
		ArrayList<Person> peopleList = new ArrayList<Person>();
		peopleList.add(person1);
		census.setListOfPeople(peopleList);
		hold.setCensus(census);

		zeroPercent.invokeRatingEngine(hold);

		assertEquals("Check: People Custom reduction volume",0, hold.getCensus()
				.getCensusMap().get("people_Custom_Age_Reduction_Percent_Reduction_Amount"));

	}
	
	
}
