package com.pru.sparc.drools.common.util;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingPlanAggregationUtilityTest {
	@Test
	public void test_HoldingPlanAggregationUtilityTest() {
		Holding holding = setupData();
		for (int i = 0; i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan = (Plan) holding.getListOfPlans().get(i);
			AggregationUtility.getHoldingPlanAggregation(holding,
					HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS,
					plan, PlanConstants.PLAN_TOTAL_LIVES,
					RuleRatingConstants.ADD_OPERATOR);

			AggregationUtility
					.getHoldingPlanAggregation(
							holding,
							HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS,
							plan, PlanConstants.PLAN_TOTAL_COVERED_VOLUME,
							RuleRatingConstants.MIN_OPERATOR);

			AggregationUtility.getHoldingPlanAggregation(holding,
					HoldingConstants.HOLDING_COMMISSION_DATE, plan,
					PlanConstants.PLAN_COMMISSION_DATE_CHECK,
					RuleRatingConstants.MAX_OPERATOR);

		}
		System.out.println(holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS));
		assertEquals(
				"Check: holding_Total_Lives_For_All_Plans",
				new SBigDecimal("43.5"),
				holding.getHoldingMap()
						.get(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS));
		System.out.println(holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS));
		assertEquals(
				"Check: holding_Total_Covered_Volume_For_All_Plans",
				new SBigDecimal("200001.4"),
				holding.getHoldingMap()
						.get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS));

		System.out.println(holding.getHoldingMap().get(
				HoldingConstants.HOLDING_COMMISSION_DATE));
		assertEquals(
				"Check: holding_Commission_Date",
				new SBigDecimal("123.4"),
				holding.getHoldingMap().get(
						HoldingConstants.HOLDING_COMMISSION_DATE));

	}

	private static Holding setupData() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();

		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("21.4"));
		planMap.put(PlanConstants.PLAN_TOTAL_COVERED_VOLUME, new SBigDecimal(
				"200001.4"));
		planMap.put(PlanConstants.PLAN_COMMISSION_DATE_CHECK, new SBigDecimal(
				"123.4"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);

		listOfPlans.add(plan);

		// Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("22.1"));
		planMap.put(PlanConstants.PLAN_TOTAL_COVERED_VOLUME, new SBigDecimal(
				"444441.478"));
		planMap.put(PlanConstants.PLAN_COMMISSION_DATE_CHECK, new SBigDecimal(
				"123"));

		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);

		return holding;
	}
}
