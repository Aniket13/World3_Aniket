package com.pru.sparc.drools.planloop8;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.pru.sparc.drools.basiclife.Loop8;
import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class executePlanTest {
	private Loop8 loop8 = null;
	private Holding holding = null;
	private Plan plan = null;

	@Before
	public void setUp() {
		holding = setupData();
		plan = (Plan) holding.getListOfPlans().get(0);
		loop8 = new Loop8();

	}

	// test data
	public Holding setupData() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();

		holding.setHoldingMap(holdingMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		holding.setCount(0);
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		census.setCensusMap(censusMap);
		int peopleCount = 10;
		census.setListOfPeople(getCensusWithEmployees(peopleCount));
		plan.setCensus(census);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		return holding;
	}

	private ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
		}

		return peopleList;
	}

	private Person getPersonObject(int position) {
		List<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(22));
		peopleMap1.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap1.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap1.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(1200));
		peopleMap1
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(34));
		peopleMap1.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(22));
		peopleMap2.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap2.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap2.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(2000));
		peopleMap2
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(44));
		peopleMap2.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(26));
		peopleMap3.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap3.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap3.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(2200));
		peopleMap3
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(54));
		peopleMap3.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(28));
		peopleMap4.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap4.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap4.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(4200));
		peopleMap4
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(64));
		peopleMap4.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(30));
		peopleMap5.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap5.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap5.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(200));
		peopleMap5
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(74));
		peopleMap5.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(32));
		peopleMap6.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap6.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap6.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(400));
		peopleMap6
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(84));
		peopleMap6.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(34.0));
		peopleMap7.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap7.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap7.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(300));
		peopleMap7
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(94));
		peopleMap7.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(36));
		peopleMap8.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap8.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap8.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(400));
		peopleMap8
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(12));
		peopleMap8.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(38));
		peopleMap9.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap9.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap9.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(400));
		peopleMap9
				.put(PersonConstants.PEOPLE_RETRIEVE_AGE, new SBigDecimal(22));
		peopleMap9.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(40));
		peopleMap10.put(PersonConstants.PEOPLE_GENDER,
				PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap10.put(PersonConstants.PEOPLE_STATUS,
				PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap10.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME,
				new SBigDecimal(400));
		peopleMap10.put(PersonConstants.PEOPLE_RETRIEVE_AGE,
				new SBigDecimal(32));
		peopleMap10.put(PersonConstants.PEOPLE_LIFE_COUNT, new SBigDecimal(1));
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);
	}

	@Test
	public void execute_Plan_Test_Case() {
		// required input
		holding.getHoldingMap().put(HoldingConstants.RENEWAL, "RenewalYes");
		// required input
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING,
				new SBigDecimal(100));
		// required input
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_RENEWAL_INFORCE_PREMIUM_STEP_7,
				new SBigDecimal(101));
		
		loop8.setPlanFinalRateActionOutStep1(holding, plan);
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_1));
		
		loop8.setPlanFinalRateActionOutStep2(plan);
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_FINAL_RATE_ACTION_OUT_STEP_2));
		
		loop8.setPlanfinalRateActionOut(holding,plan);
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_FINALRATE_ACTION_OUT));
		
		//required input
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_OVERRIDE_75000_PREMIUM_POSTCALC,
				new SBigDecimal(102));
		//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC,
						new SBigDecimal(103));
				//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING,
						new SBigDecimal(104));
				//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS,
						new SBigDecimal(105));
				//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_VOLUME,
						new SBigDecimal(106));
				//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_PREMIUM,
						new SBigDecimal(107));
				//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_MAXIMUM_EXHIBIT_LIVES,
						new SBigDecimal(108));
				//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING,
						new SBigDecimal(109));
				//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING,
						new SBigDecimal(109));
				//required input
				holding.getHoldingMap().put(
						HoldingConstants.HOLDING_CLAIMS_EXPERIENCE_FOR_REPORTING,
						new SBigDecimal(110));
		loop8.assignmentHoldingToPlan(holding,plan);
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_OVERRIDE_75000_PREMIUM_POSTCALC));
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_TOTAL_BL_MANUAL_PREMIUM_FOR_POSTCALC));
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_COMPETETIVE_WINDOW_FOR_POSTCALC));
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS));
		System.out.println(plan.getPlanMap().get(
				PlanConstants.PLAN_MAXIMUM_EXHIBIT_VOLUME));
		System.out.println(plan.getPlanMap().get(
				PlanConstants.PLAN_MAXIMUM_EXHIBIT_PREMIUM));
		System.out.println(plan.getPlanMap().get(
				PlanConstants.PLAN_MAXIMUM_EXHIBIT_LIVES));
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_COMPETITIVE_WINDOW_FOR_REPORTING));
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_TOTAL_ANNUAL_PREMIUM_FOR_REPORTING));
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_CLAIMS_EXPERIENCE_FOR_REPORTING));
		//set dummy value for aggregation
		holding.getHoldingMap().put(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS,
				new SBigDecimal(110));
		
		loop8.setPlanRenewalProductionSumNonAgeBanded(holding,plan);
		System.out.println(plan.getPlanMap()
						.get(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_NON_AGE_BANDED));
		plan.getPlanMap()
		.put(PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED,
				new SBigDecimal(111));
		loop8.setPlanRenewalProductionSumAgeBandedPremium(plan);
		System.out.println(plan.getPlanMap()
						.get(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_AGE_BANDED_PREMIUM));
		
		holding.put(HoldingConstants.HOLDING_SUM_INFORCE_PREM_NONAGEBANDED_ALL_PLANS,
				new SBigDecimal(112));
		loop8.setPlanRenewalProductionSumInforceNonAgeBanded(holding, plan);
		System.out.println(plan.getPlanMap()
						.get(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_NON_AGE_BANDED));
		
		plan.put(RuleRatingConstants.ADD_OPERATOR_KEY+PlanConstants.PLAN_INITIAL_INFORCE_PREM_ALL_AGEBANDED,
		new SBigDecimal(113));
		loop8.setPlanRenewalProductionSumInforceAgeBanded(plan);
		
		System.out.println(plan.getPlanMap()
						.get(PlanConstants.PLAN_RENEWAL_PRODUCTION_SUM_INFORCE_AGE_BANDED));
		//required input
		plan.getPlanMap().put(PlanConstants.BL_AGE_BANDED,"BL_Age_Banded_Yes");
		//required input
		holding
		.getHoldingMap()
		.put(HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_5,
				new SBigDecimal(114));
		//required input
		holding
		.getHoldingMap()
		.put(HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_6,
				new SBigDecimal(115));
		//required input
		holding
		.getHoldingMap()
		.put(HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_7,
				new SBigDecimal(116));
		//required input
		holding
		.getHoldingMap()
		.put(HoldingConstants.HOLDING_RENEWAL_UW_OVERRIDE_PERCENT_OF_MANUAL_STEP_8,
				new SBigDecimal(117));
		loop8.setPlanRenewalPercentofManualSumPremiumsStep9(holding, plan);
		
		System.out.println(plan.getPlanMap()
							.get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_SUM_PREMIUMS_STEP_9));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RATE_METHOD,
				new SBigDecimal(118));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2,
				new SBigDecimal(119));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_UW_OVERRIDE_ALL_AGE_BANDED_SINGLE_RATE,
				new SBigDecimal(120));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_RATES,
				new SBigDecimal(121));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_RATES,
				new SBigDecimal(121));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES,
				new SBigDecimal(122));
		//required input
		holding.getHoldingMap().put(HoldingConstants.HOLDING_RENEWAL_MANUAL_RATE,
				new SBigDecimal(123));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_RATE_NONAGEBANDED,
				new SBigDecimal(124));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_RATE_ALL_AGE_BANDED_SINGLE_RATE,
				new SBigDecimal(125));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_3,
				new SBigDecimal(126));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_MANUAL_RATE,
				new SBigDecimal(127));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME,
				new SBigDecimal(128));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RATE_ACTION_OUT,
				new SBigDecimal(129));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RATE_ACTION_OUT,
				new SBigDecimal(130));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_BL_EXHIBIT_TOTAL_ANNUAL_PREMIUM,
				new SBigDecimal(131));
		//required input
		holding.getHoldingMap().put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS,
				new SBigDecimal(132));
		//required input
		holding.getHoldingMap().put(HoldingConstants.HOLDING_RENEWAL_PLAN_CHANGE_STEP_2,
				new SBigDecimal(133));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_INFORCE_RATE_ALL_AGE_BANDED_SINGLE_RATE,
				new SBigDecimal(134));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_APPEAL_ALL_AGE_BANDED_SINGLE_RATE,
				new SBigDecimal(135));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_RENEWAL_APPEAL_MONTHLY_RATES,
				new SBigDecimal(136));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED,
				new SBigDecimal(137));
		//required input
		plan.getPlanMap().put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_PREMIUM,
				new SBigDecimal(138));
		
		loop8.setPlanRenewalReportingStep(holding, plan);
		System.out.println(plan.getPlanMap()
				.get(PlanConstants.PLAN_RENEWAL_REPORTING_STEP));
		
	}
}
