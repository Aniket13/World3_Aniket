package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanCountFlatAmountPlansTest {
	//line no 489 to 493
	@Test
	public void plan_Count_Flat_Amount_Plans_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/PlanType", "FlatAmt");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Count_Flat_Amount_Plans.xls","plan-count-flat-amount-plans",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Count_Flat_Amount_Plans"));
		assertEquals("Check: plan_Count_Flat_Amount_Plans", new SBigDecimal(1),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Count_Flat_Amount_Plans"));
	}
		
	//line no 489 to 493
	@Test
	public void plan_Count_Flat_Amount_Plans_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/PlanType", "MultipleEarnings");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Count_Flat_Amount_Plans.xls","plan-count-flat-amount-plans",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Count_Flat_Amount_Plans"));
		assertEquals("Check: plan_Count_Flat_Amount_Plans", new SBigDecimal(0),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Count_Flat_Amount_Plans"));
	}
}
