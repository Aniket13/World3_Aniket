package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingTotalLivesForAllPlansTest {
	//line no. 537
	//holding_Total_Lives_For_All_Plans 
	@Test
	public void test_Holding_Total_Lives_For_All_Plans() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("21.4"));
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("22.1"));
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT",
					"basiclife\\loop1\\BL_Holding_Total_Lives_For_All_Plans.xls","", new Object[] {holding});
			
		}
		System.out.println("holding_Total_Lives_For_All_Plans:"+holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS));
		assertEquals("Check: holding_Total_Lives_For_All_Plans", new SBigDecimal("43.5"), holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS));
	}
}
