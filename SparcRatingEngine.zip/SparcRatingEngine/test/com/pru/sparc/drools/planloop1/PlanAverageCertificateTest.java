package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanAverageCertificateTest {
	@Test
	public void test_plan_Average_Certificate() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();

		HashMap<String, Object> planMap = new HashMap<String, Object>();
		// output of line no. 482
		planMap.put("plan_Total_Covered_Volume", new SBigDecimal("100"));
		// output of line no. 478
		planMap.put("plan_Total_Lives__Inverse", new SBigDecimal("10"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT",
				"basiclife\\loop1\\BL_Plan_Average_Certificate.xls",
				"plan-average-certificate", new Object[] { holding, plan });

		System.out.println(((Plan) (holding.getListOfPlans().get(holding
				.getCount()))).getPlanMap().get("plan_Average_Certificate"));
		assertEquals("Check: plan_Average_Certificate", new SBigDecimal(1000),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Average_Certificate"));
	}
}
