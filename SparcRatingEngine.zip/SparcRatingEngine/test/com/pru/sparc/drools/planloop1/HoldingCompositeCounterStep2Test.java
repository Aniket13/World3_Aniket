package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingCompositeCounterStep2Test {
	//line 522 holding_Composite_Counter_Step_2
	@Test
	public void test_holding_Composite_Counter_Step_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("OriginalPlanEffectiveDate", "Sat Jun 30 20:00:00 EDT 2007,Thu Dec 31 11:59:59 IST 9999");
		planMap.put("plan/Composite", "CompositeY");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put("OriginalPlanEffectiveDate", "Sat Jun 30 20:00:00 EDT 2007,Thu Dec 31 11:59:59 IST 9999");
		planMap.put("plan/Composite", "CompositeY");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Commission_Date_Check.xls","Plan_Commission_Date_Check",new Object[]{holding,p});
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Loop_1.xls","plan-loop-1",new Object[]{holding,p});
			System.out.println("plan_Commission_Date_Check:"+p.getPlanMap().get("plan_Commission_Date_Check"));
		}
		System.out.println("Plan Loop count:"+holding.getHoldingMap().get("Plan_Loop_1"));
		System.out.println("holding_Composite_Counter_Step_2:"+holding.getHoldingMap().get("holding_Composite_Counter_Step_2"));
		
		assertEquals("Check: holding_Composite_Counter_Step_2", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Composite_Counter_Step_2"));
	}
}
