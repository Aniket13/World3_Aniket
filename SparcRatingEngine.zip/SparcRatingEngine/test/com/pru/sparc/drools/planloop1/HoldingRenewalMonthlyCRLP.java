package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingRenewalMonthlyCRLP {
	//line no 519
	@Test
	public void test_Holding_Renewal_Monthly_CRLP() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("Renewal_CRLP", new SBigDecimal(36));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Renewal_Monthly_CRLP.xls","holding-renewal-monthly-crlp",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Renewal_Monthly_CRLP"));
		assertEquals("Check: holding_Renewal_Monthly_CRLP", new SBigDecimal(3), holding.getHoldingMap().get("holding_Renewal_Monthly_CRLP"));
	}
}
