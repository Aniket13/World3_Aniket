package com.pru.sparc.drools.planloop1;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Status_Waiver_of_Premium_Adjustment_Test.class,
		Status_Rate_Guarantee_Test.class, Status_Dental_Discount_Test.class,
		Status_Conversion_Adjustment.class, People_Loop1_Test.class,
		Age_Manual_Rate_Test.class,
		Status_ADD_Discount_Test.class,
		Status_ADD_Discount__Active_Only_Test.class,
		Status_Disability_Product_Discount_Active_Only_Test.class})
public class Loop1TestSuit {

}
