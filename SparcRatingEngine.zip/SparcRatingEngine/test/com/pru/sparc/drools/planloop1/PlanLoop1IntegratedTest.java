package com.pru.sparc.drools.planloop1;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.BasicLifeConstant;
import com.pru.sparc.drools.model.Holding;

public class PlanLoop1IntegratedTest {

	TestData obj1 = new TestData();
	@Test
	public void test1() {
		Holding holding = obj1.setup();
		RatingCalculationTest.invokeRatingEngine(holding,
				BasicLifeConstant.BL_PLAN_LOOP1_DRL,
				BasicLifeConstant.BL_PLAN_LOOP1_AGENDA_GROUP);
	}
}
