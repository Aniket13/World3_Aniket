package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanCompsychPremium1Test {
	// line no 471
	@Test
	public void test_Plan_Compsych_Premium_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("CompycheFee", new SBigDecimal("1000"));

		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan_Total_Lives", new SBigDecimal("2"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT",
				"basiclife\\loop1\\BL_Plan_Compsych_Premium.xls",
				"plan-compsych-premium", new Object[] { holding, plan });

		System.out.println(((Plan) (holding.getListOfPlans().get(holding
				.getCount()))).getPlanMap().get(PlanConstants.PLAN_COMPSYCH_PREMIUM));
		assertEquals("Check: plan_Compsych_Premium", new SBigDecimal(2000),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get(PlanConstants.PLAN_COMPSYCH_PREMIUM));
	}

	// line no 473
	@Test
	public void test_Plan_Compsych_Premium_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		// holdingMap.put("holding/CompycheFee", new SBigDecimal("1000"));

		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan_Total_Lives", new SBigDecimal("2"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT",
				"basiclife\\loop1\\BL_Plan_Compsych_Premium.xls",
				"plan-compsych-premium", new Object[] { holding, plan });

		System.out.println(((Plan) (holding.getListOfPlans().get(holding
				.getCount()))).getPlanMap().get("plan_Compsych_Premium"));
		assertEquals("Check: plan_Compsych_Premium", new SBigDecimal(0),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Compsych_Premium"));
	}
}
