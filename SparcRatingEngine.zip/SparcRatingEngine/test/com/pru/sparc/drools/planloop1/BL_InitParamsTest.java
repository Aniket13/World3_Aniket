package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_InitParamsTest {

	@Test
	public void testInitParams() {
		Holding hold = new Holding();
		// Census Map Values
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "SalarySetForAll_No");
		censusMap.put("SalaryEstimate", new SBigDecimal("410000"));

		// People Map Values
		HashMap<String, Object> peopleMap = new HashMap<String, Object>();
		//peopleMap.put("SalaryEstimate", new SBigDecimal("410000"));
		peopleMap.put("people/Salary", new SBigDecimal("20000"));

		// PlanMap Values
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan/ContractState", "OtherProvinces");
		planMap.put("EffectiveDate", "01/01/2016");
		
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap);
		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		hold.setListOfPlans(listOfPlans);
		
		ArrayList<Person> listOfPeople = new ArrayList<Person>();
		Person person = new Person();
		person.setPeopleMap(peopleMap);
		listOfPeople.add(person);
		
		Census census = new Census();
		census.setCensusMap(censusMap);
		census.setListOfPeople(listOfPeople);
		plan1.setCensus(census);
		hold.setCount(0);
		hold.setPeopleCount(0);

		RuleUtility.getInitsData("DT",
				"basiclife\\loop1\\BL_InitParams.xls",
				"init-params", new Object[] { hold,
				plan1 });
		
		assertEquals("Check: plan_Override_75000_Postcalc_Step_1", new SBigDecimal(0),
				(SBigDecimal)((Plan) (hold.getListOfPlans().get(hold.getCount())))
						.getPlanMap().get("plan_Override_75000_Postcalc_Step_1"));
		
		assertEquals("Check: plan_Initial_Inforce_Rate_NonAgeBanded_Step_1", new SBigDecimal(1),
				(SBigDecimal)((Plan) (hold.getListOfPlans().get(hold.getCount())))
						.getPlanMap().get("plan_Initial_Inforce_Rate_NonAgeBanded_Step_1"));
		
		assertEquals("Check: plan_Initial_Inforce_Commission_Percentage_Step_1", new SBigDecimal(0),
				(SBigDecimal)((Plan) (hold.getListOfPlans().get(hold.getCount())))
						.getPlanMap().get("plan_Initial_Inforce_Commission_Percentage_Step_1"));
		
		assertEquals("Check: plan_Count_Plan", new SBigDecimal(1),
				(SBigDecimal)((Plan) (hold.getListOfPlans().get(hold.getCount())))
						.getPlanMap().get("plan_Count_Plan"));
		
		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(hold.getHoldingMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (hold.getListOfPlans()
				.get(hold.getCount()))).getPlanMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(((Plan) (hold.getListOfPlans()
				.get(hold.getCount()))).getCensus().getCensusMap());
		System.out.println("-----------------People Map--------------------");
		RatingCalculationTest.showMap(((Plan) (hold.getListOfPlans()
				.get(hold.getCount()))).getCensus().getListOfPeople().get(0).getPeopleMap());

	}
}
