package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingRatioRetireeToTotalVolumeTest {
	//line no 527 to 531
	@Test
	public void test_Holding_Ratio_Retiree_to_Total_Volume_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Retiree_Covered_Volume", new SBigDecimal(50));
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(25));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal ratio = (SBigDecimal)(((SBigDecimal)holding.getHoldingMap().get("holding_Retiree_Covered_Volume"))).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans")));
		//System.out.println("value:"+ratio.toString());
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Ratio_Retiree_to_Total_Volume.xls","holding-ratio-retiree-to-total-volume",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Volume"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Volume", ratio, holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Volume"));
	}
	
	
	@Test
	public void test_Holding_Ratio_Retiree_to_Total_Volume_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Retiree_Covered_Volume", new SBigDecimal(50));
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Ratio_Retiree_to_Total_Volume.xls","holding-ratio-retiree-to-total-volume",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Volume"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Volume", new SBigDecimal(0), holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Volume"));
	}
}
