package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingTotalFemaleLivesIgnoringCompositeSettingTest {
	@Test
	public void test_holding_Total_Female_Lives_Ignoring_Composite_Setting() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();

		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);

		// Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "MultipleEarnings");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);

		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("people_Average_Salary_Factor_Step_1", "Y");

		census.setCensusMap(censusMap);
		int peopleCount = 10;
		census.setListOfPeople(getCensusWithEmployees(peopleCount));
		plan.setCensus(census);

		holding.setListOfPlans(listOfPlans);

		holding.setHoldingMap(holdingMap);

		for (int i = 1; i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);

			List<Person> people1 = (List<Person>) ((Plan) (holding
					.getListOfPlans().get(holding.getCount()))).getCensus()
					.getListOfPeople();

			for (int j = 0; j < people1.size(); j++) {
				holding.setPeopleCount(j);
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife\\loop1\\BL_Holding_Total_Female_Lives_Ignoring_Composite_Setting.xls",
								"", new Object[] { holding });
			}
		}
		/*System.out.println(holding.getHoldingMap().get(
				HoldingConstants.HOLDING_TOTAL_FEMALE_LIVES));*/

		assertEquals(
				"Check: holding_Total_Female_Lives_Ignoring_Composite_Setting",
				new SBigDecimal("6"),
				holding.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_FEMALE_LIVES));

		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getCensus().getCensusMap());
	}

	private ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
		}

		return peopleList;
	}

	private Person getPersonObject(int position) {
		List<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put(PersonConstants.PEOPLE_GENDER, "Female");
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put(PersonConstants.PEOPLE_GENDER, "Female");
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put(PersonConstants.PEOPLE_GENDER, "male");
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put(PersonConstants.PEOPLE_GENDER, "Female");
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put(PersonConstants.PEOPLE_GENDER, "male");
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put(PersonConstants.PEOPLE_GENDER, "Female");
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put(PersonConstants.PEOPLE_GENDER, "male");
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put(PersonConstants.PEOPLE_GENDER, "Female");
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();

		peopleMap9.put(PersonConstants.PEOPLE_GENDER, "male");
		peopleMap9.put("status", "active");
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put(PersonConstants.PEOPLE_GENDER, "Female");
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);

	}

}
