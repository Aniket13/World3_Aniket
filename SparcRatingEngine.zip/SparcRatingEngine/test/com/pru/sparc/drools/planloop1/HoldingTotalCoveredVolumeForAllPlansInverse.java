package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingTotalCoveredVolumeForAllPlansInverse {
	//line no 532 to 536
	@Test
	public void test_holding_Total_Covered_Volume_For_All_Plans__Inverse_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_holding_Total_Covered_Volume_For_All_Plans__Inverse.xls","holding-total-covered-volume-for-all-plans-inverse",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans__Inverse"));
		assertEquals("Check: holding_Total_Covered_Volume_For_All_Plans__Inverse", new SBigDecimal(0), holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans__Inverse"));
	}
	
	@Test
	public void test_holding_Total_Covered_Volume_For_All_Plans__Inverse_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(1000));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal val = (SBigDecimal)(new SBigDecimal(1)).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans")));
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_holding_Total_Covered_Volume_For_All_Plans__Inverse.xls","holding-total-covered-volume-for-all-plans-inverse",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans__Inverse"));
		assertEquals("Check: holding_Total_Covered_Volume_For_All_Plans__Inverse", val, holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans__Inverse"));
	}
}
