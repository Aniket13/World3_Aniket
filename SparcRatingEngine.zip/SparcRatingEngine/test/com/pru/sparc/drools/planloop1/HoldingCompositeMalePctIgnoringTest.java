package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingCompositeMalePctIgnoringTest {
	//line 548
	@Test
	public void test_Holding_Composite_Male_Pct_Ignoring_Composite_Setting() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Composite_Female_Pct_Ignoring_Composite_Setting", new SBigDecimal("0.58"));
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Male_Pct_Ignoring_Composite_Setting.xls","holding-composite-male-pct-ignoring-composite-setting",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Male_Pct_Ignoring_Composite_Setting"));
		assertEquals("Check: holding_Composite_Male_Pct_Ignoring_Composite_Setting", new SBigDecimal("0.42"), holding.getHoldingMap().get("holding_Composite_Male_Pct_Ignoring_Composite_Setting"));
	}
}
