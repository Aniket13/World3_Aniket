package com.pru.sparc.drools.planloop1;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.PersonConstants;

public class InitParamPeopleTest {

	@Test
	public void test_InitParamPeople() {
		
		//Poeple Map
		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put(PersonConstants.PEOPLE_AGE,24.0);
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		RuleUtility.getInitsData("DT",
				"basiclife\\loop1\\BL_InitParams_People.xls",
				"Init-Params_People", new Object[] {person1});
		
		// Print Data
		System.out.print("-----------------Person Map--------------------");
		RatingCalculationTest.showMap(person1.getPeopleMap());

	}
}
