package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanLoop1UnitTest {
	
	@Test
	public void test_holding_Under_100_Pilot_Case_Indicator() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		holdingMap.put("holding/Life_100_Pilot", "Life_100_Pilot_Yes");
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Under_100_Pilot_Case_Indicator.xls","Under_100_Pilot_Case_Indicator",new Object[]{holding});
		
		assertEquals("Check: testUnder_100_Pilot_Case_Indicator", new SBigDecimal(1), holding
				.getHoldingMap().get("holding_Under_100_Pilot_Case_Indicator"));
	}
	
	@Test
	public void test_plan_Set_Flat_Plan_Type() {
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "FlatAmt");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Set_Flat_Plan_Type.xls","Plan_Set_Flat_Plan_Type",new Object[]{holding,plan});

		assertEquals("Check: Plan_Set_Flat_Plan_Type", 1,
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Set_Flat_Plan_Type"));
	}
	
	@Test
	public void test_plan_Set_Multiple_Plan_Type() {
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "MultipleEarnings");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Set_Multiple_Plan_Type.xls","Plan_Set_Multiple_Plan_Type",new Object[]{holding,plan});

		assertEquals("Check: plan_Set_Multiple_Plan_Type", 1,
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Set_Multiple_Plan_Type"));
	}
	
	@Test
	public void test_plan_Set_Other_Plan_Type() {
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "Grandfathered_Amounts");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Set_Other_Plan_Type.xls","Plan_Set_Other_Plan_Type",new Object[]{holding,plan});

		assertEquals("Check: Plan_Set_Other_Plan_Type", 1,
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Set_Other_Plan_Type"));
	}
	
	//line no 471
	@Test
	public void test_Plan_Compsych_Premium_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding/CompycheFee", new SBigDecimal("1000"));
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan_Total_Lives", new SBigDecimal("2"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Compsych_Premium.xls","plan-compsych-premium",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Compsych_Premium"));
		assertEquals("Check: plan_Compsych_Premium", new SBigDecimal(2000),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Compsych_Premium"));
	}
	
	//line no 473
	@Test
	public void test_Plan_Compsych_Premium_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		//holdingMap.put("holding/CompycheFee", new SBigDecimal("1000"));
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan_Total_Lives", new SBigDecimal("2"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Compsych_Premium.xls","plan-compsych-premium",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Compsych_Premium"));
		assertEquals("Check: plan_Compsych_Premium", new SBigDecimal(0),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Compsych_Premium"));
	}
	
	
	//line no 476
	@Test
	public void test_plan_Total_Lives__Inverse_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		//holdingMap.put("holding/CompycheFee", new SBigDecimal("1000"));
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan_Total_Lives", new SBigDecimal("2"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Total_Lives__Inverse.xls","plan-total-lives-inverse",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Lives__Inverse"));
		assertEquals("Check: plan_Total_Lives__Inverse", new SBigDecimal(0.5),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Lives__Inverse"));
	}
	
	//line no 478
	@Test
	public void test_plan_Total_Lives__Inverse_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		//holdingMap.put("holding/CompycheFee", new SBigDecimal("1000"));
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan_Total_Lives", new SBigDecimal("0"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Total_Lives__Inverse.xls","plan-total-lives-inverse",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Lives__Inverse"));
		assertEquals("Check: plan_Total_Lives__Inverse", new SBigDecimal(0),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Lives__Inverse"));
	}
	
	//line no 480. plan_Total_Gross_Volume already covered refer: BL_Plan_People_Gross_Covered_Volume.xls
	//line no 482. plan_Total_Covered_Volume already covered refer: BL_Plan_People_Gross_Covered_Volume.xls
	
	//line no 483
	@Test
	public void test_plan_Average_Certificate() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan_Total_Covered_Volume", new SBigDecimal("100"));
		//output of line no. 478
		planMap.put("plan_Total_Lives__Inverse", new SBigDecimal("10"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Average_Certificate.xls","plan-average-certificate",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Average_Certificate"));
		assertEquals("Check: plan_Average_Certificate", new SBigDecimal(1000),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Average_Certificate"));
	}
	
	//line no 484 to 488
	@Test
	public void test_plan_Total_Covered_Volume__Inverse_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan_Total_Covered_Volume", new SBigDecimal("100"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Total_Covered_Volume__Inverse.xls","plan-Total_covered-volume-inverse",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Covered_Volume__Inverse"));
		assertEquals("Check: plan_Total_Covered_Volume__Inverse", new SBigDecimal(1000),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Covered_Volume__Inverse"));
	}
	
	//line no 484 to 488
	@Test
	public void test_plan_Total_Covered_Volume__Inverse_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan_Total_Covered_Volume", new SBigDecimal("0"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Total_Covered_Volume__Inverse.xls","plan-Total_covered-volume-inverse",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Covered_Volume__Inverse"));
		assertEquals("Check: plan_Total_Covered_Volume__Inverse", new SBigDecimal(1000),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Covered_Volume__Inverse"));
	}
	
	//line no 489 to 493
	@Test
	public void plan_Count_Flat_Amount_Plans_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/PlanType", "FlatAmt");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Count_Flat_Amount_Plans.xls","plan-count-flat-amount-plans",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Count_Flat_Amount_Plans"));
		assertEquals("Check: plan_Count_Flat_Amount_Plans", new SBigDecimal(1),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Count_Flat_Amount_Plans"));
	}
	
	//line no 489 to 493
	@Test
	public void plan_Count_Flat_Amount_Plans_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/PlanType", "MultipleEarnings");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Count_Flat_Amount_Plans.xls","plan-count-flat-amount-plans",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Count_Flat_Amount_Plans"));
		assertEquals("Check: plan_Count_Flat_Amount_Plans", new SBigDecimal(0),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Count_Flat_Amount_Plans"));
	}
	
	//line no 494 to 498
	@Test
	public void plan_Composite_Counter_Step_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/Composite", "CompositeY");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Composite_Counter_Step_1.xls","plan-composite-counter-step_1",new Object[]{holding,plan});
		
		System.out.println(((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Composite_Counter_Step_1"));
		assertEquals("Check: plan_Composite_Counter_Step_1", new SBigDecimal(1),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Composite_Counter_Step_1"));
	}
	
	
	//line no 500
	@Test
	public void test_Plan_Loop_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/Composite", "CompositeY");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/Composite", "CompositeY");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			//System.out.println("iteration:" + i + " "+holding.getHoldingMap().get("Plan_Loop_1"));
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Loop_1.xls","plan-loop-1",new Object[]{holding,p});
		}
		System.out.println(holding.getHoldingMap().get("Plan_Loop_1"));
		
		assertEquals("Check: Plan_Loop_1", new SBigDecimal("2"), holding.getHoldingMap().get("Plan_Loop_1"));
	}
	
	//line no 502	
	@Test
	public void test_holding_Flat_Plans_Count() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "FlatAmt");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "FlatAmt");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			//System.out.println("iteration:" + i + " "+holding.getHoldingMap().get("Plan_Loop_1"));
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Flat_Plans_Count.xls","holding-flat-plans-count",new Object[]{holding,p});
		}
		System.out.println(holding.getHoldingMap().get("holding_Flat_Plans_Count"));
		System.out.println(holding.getHoldingMap().get("holding_Total_Number_Of_BL_Flat_Amt_Plans"));
		
		assertEquals("Check: holding_Flat_Plans_Count", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Flat_Plans_Count"));
		assertEquals("Check: holding_Total_Number_Of_BL_Flat_Amt_Plans", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Total_Number_Of_BL_Flat_Amt_Plans"));
	}
	
	
	//line no 503	
	@Test
	public void test_holding_Multiple_Plans_Count() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put("plan/PlanType", "FlatAmt");
		planMap.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		//planMap.put("plan/PlanType", "FlatAmt");
		planMap.put("plan/PlanType", "MultipleEarnings");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			//System.out.println("iteration:" + i + " "+holding.getHoldingMap().get("Plan_Loop_1"));
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Multiple_Plans_Count.xls","holding-multiple-plans-count",new Object[]{holding,p});
		}
		System.out.println(holding.getHoldingMap().get("holding_Multiple_Plans_Count"));
		
		assertEquals("Check: holding_Multiple_Plans_Count", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Multiple_Plans_Count"));
	}
	
	//line no 504	
	@Test
	public void test_holding_Other_Plans_Count() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put("plan/PlanType", "FlatAmt");
		planMap.put("plan/PlanType", "Grandfathered_Amounts");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		//planMap.put("plan/PlanType", "FlatAmt");
		planMap.put("plan/PlanType", "Grandfathered_Amounts");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			//System.out.println("iteration:" + i + " "+holding.getHoldingMap().get("Plan_Loop_1"));
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Other_Plans_Count.xls","holding-other-plans-count",new Object[]{holding,p});
		}
		System.out.println(holding.getHoldingMap().get("holding_Other_Plans_Count"));
		
		assertEquals("Check: holding_Other_Plans_Count", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Other_Plans_Count"));
	}
	
    //line no 505 to 515
	@Test
	public void test_holding_Set_Plans_Type_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Flat_Plans_Count", new SBigDecimal("1"));
		holdingMap.put("holding_Multiple_Plans_Count", new SBigDecimal("0"));
		holdingMap.put("holding_Other_Plans_Count", new SBigDecimal("0"));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Set_Plans_Type.xls","holding-set-plans-type",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Set_Plans_Type"));
		System.out.println(holding.getHoldingMap().get("holding_Flat_Plans_Only"));
		assertEquals("Check: holding_Set_Plans_Type", new SBigDecimal("1"), holding.getHoldingMap().get("holding_Set_Plans_Type"));
	}
	
	//line no 505 to 515
	@Test
	public void test_holding_Set_Plans_Type_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Flat_Plans_Count", new SBigDecimal("0"));
		holdingMap.put("holding_Multiple_Plans_Count", new SBigDecimal("1"));
		holdingMap.put("holding_Other_Plans_Count", new SBigDecimal("0"));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Set_Plans_Type.xls","holding-set-plans-type",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Set_Plans_Type"));
		System.out.println(holding.getHoldingMap().get("holding_Multiple_Plans_Only"));
		assertEquals("Check: holding_Set_Plans_Type", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Set_Plans_Type"));
	}
	
	
	//line no 505 to 515
	@Test
	public void test_holding_Set_Plans_Type_3() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Flat_Plans_Count", new SBigDecimal("0"));
		holdingMap.put("holding_Multiple_Plans_Count", new SBigDecimal("0"));
		holdingMap.put("holding_Other_Plans_Count", new SBigDecimal("1"));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Set_Plans_Type.xls","holding-set-plans-type",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Set_Plans_Type"));
		System.out.println(holding.getHoldingMap().get("holding_Other_Plans"));
		assertEquals("Check: holding_Set_Plans_Type", new SBigDecimal("3"), holding.getHoldingMap().get("holding_Set_Plans_Type"));
	}
	
	//line no 505 to 515
	@Test
	public void test_holding_Set_Plans_Type_3_Condition2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Flat_Plans_Count", new SBigDecimal("1"));
		holdingMap.put("holding_Multiple_Plans_Count", new SBigDecimal("1"));
		holdingMap.put("holding_Other_Plans_Count", new SBigDecimal("0"));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Set_Plans_Type.xls","holding-set-plans-type",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Set_Plans_Type"));
		System.out.println(holding.getHoldingMap().get("holding_Other_Plans"));
		assertEquals("Check: holding_Set_Plans_Type", new SBigDecimal("3"), holding.getHoldingMap().get("holding_Set_Plans_Type"));
	}
	
	//line no. 517
	//holding_Average_Salary_Factor_Step_2 : to be covered in line 94 (inside people loop)
		
/*	@Test
	public void test_holding_Average_Salary_Factor_Step_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put("plan/PlanType", "FlatAmt");
		planMap.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		//planMap.put("plan/PlanType", "FlatAmt");
		planMap.put("plan/PlanType", "MultipleEarnings");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			//System.out.println("iteration:" + i + " "+holding.getHoldingMap().get("Plan_Loop_1"));
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Multiple_Plans_Count.xls","holding-multiple-plans-count",new Object[]{holding,p});
		}
		System.out.println(holding.getHoldingMap().get("holding_Multiple_Plans_Count"));
		
		assertEquals("Check: holding_Multiple_Plans_Count", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Multiple_Plans_Count"));
	}*/
	
	//line no. 518
	//holding_Commission_Date : to be covered in line 18 (inside plan loop)
	@Test
	public void test_holding_Commission_Date() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put("OriginalPlanEffectiveDate", "Sat Jun 30 20:00:00 EDT 2007,Thu Dec 31 11:59:59 IST 9999");
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.ORIGINAL_PLAN_EFFECTIVE_DATE, "Sat Jun 30 20:00:00 EDT 2007,Thu Dec 31 11:59:59 IST 9999");
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Commission_Date_Check.xls","Plan_Commission_Date_Check",new Object[]{holding,p});
			System.out.println("plan_Commission_Date_Check:"+p.getPlanMap().get(PlanConstants.PLAN_COMMISSION_DATE_CHECK));
			
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Commission_Date.xls","holding-commission-date",new Object[]{holding,p});
			System.out.println("holding_Commission_Date current value:"+holding.getHoldingMap().get(HoldingConstants.HOLDING_COMMISSION_DATE));
			
		}
		System.out.println("********holding_Commission_Date Min Value********:"+holding.getHoldingMap().get(HoldingConstants.HOLDING_COMMISSION_DATE));
		assertEquals("Check: plan_Commission_Date_Check", new SBigDecimal("2"), holding.getHoldingMap().get(HoldingConstants.HOLDING_COMMISSION_DATE));
	}
	
	//line no 519
	@Test
	public void test_Holding_Renewal_Monthly_CRLP() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding/Renewal_CRLP", new SBigDecimal(36));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Renewal_Monthly_CRLP.xls","holding-renewal-monthly-crlp",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Renewal_Monthly_CRLP"));
		assertEquals("Check: holding_Renewal_Monthly_CRLP", new SBigDecimal(3), holding.getHoldingMap().get("holding_Renewal_Monthly_CRLP"));
	}
	
	//line no. 520
	//holding_Retiree_Covered_Volume : to be covered in line 444 (inside people loop)
	//waiting for aniket
	
	//line 521 to 525
	//holding_Retiree_Lives
	//waiting for aniket
	
	//line 522 holding_Composite_Counter_Step_2
	@Test
	public void test_holding_Composite_Counter_Step_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("OriginalPlanEffectiveDate", "Sat Jun 30 20:00:00 EDT 2007,Thu Dec 31 11:59:59 IST 9999");
		planMap.put("plan/Composite", "CompositeY");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put("OriginalPlanEffectiveDate", "Sat Jun 30 20:00:00 EDT 2007,Thu Dec 31 11:59:59 IST 9999");
		planMap.put("plan/Composite", "CompositeY");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Commission_Date_Check.xls","Plan_Commission_Date_Check",new Object[]{holding,p});
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Loop_1.xls","plan-loop-1",new Object[]{holding,p});
			System.out.println("plan_Commission_Date_Check:"+p.getPlanMap().get("plan_Commission_Date_Check"));
		}
		System.out.println("Plan Loop count:"+holding.getHoldingMap().get("Plan_Loop_1"));
		System.out.println("holding_Composite_Counter_Step_2:"+holding.getHoldingMap().get("holding_Composite_Counter_Step_2"));
		
		assertEquals("Check: holding_Composite_Counter_Step_2", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Composite_Counter_Step_2"));
	}
	
	
	//line no 523 : holding_Total_Female_Lives_Ignoring_Composite_Setting
	//refer HoldingTotalFemaleLivesIgnoringCompositeSettingTest.java
	
	
	
	//holding_Total_Compsych_Premium
	@Test
	public void test_Holding_Total_Compsych_Premium() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding/CompycheFee", new SBigDecimal("1000"));
		
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("2"));
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("2"));
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			holding.setCount(i);
			RuleUtility.getInitsData("DT",
					"basiclife\\loop1\\BL_Plan_Compsych_Premium.xls",
					"plan-compsych-premium", new Object[] { holding, p });
			System.out.println(((Plan) (holding.getListOfPlans().get(holding
					.getCount()))).getPlanMap().get(PlanConstants.PLAN_COMPSYCH_PREMIUM));
			RuleUtility.getInitsData("DT",
					"basiclife\\loop1\\BL_Holding_Total_Compsych_Premium.xls","", new Object[] {holding});
			
		}
		System.out.println("holding_Total_Compsych_Premium:"+holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_COMPSYCH_PREMIUM));
		assertEquals("Check: holding_Total_Compsych_Premium", new SBigDecimal("4000"), holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_COMPSYCH_PREMIUM));
	}
		
	//holding_Total_Covered_Volume_For_All_Plans
	@Test
	public void test_Holding_Total_Covered_Volume_For_All_Plans() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_COVERED_VOLUME, new SBigDecimal("21.4"));
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_COVERED_VOLUME, new SBigDecimal("22.1"));
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT",
					"basiclife\\loop1\\BL_Holding_Total_Covered_Volume_For_All_Plans.xls","", new Object[] {holding});
			
		}
		System.out.println("holding_Total_Covered_Volume_For_All_Plans:"+holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS));
		assertEquals("Check: holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal("43.5"), holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS));
	}
	
	
	//line no 526
	@Test
	public void test_Holding_Compsych_Rate() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Compsych_Premium", new SBigDecimal(1));
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(1));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal compsychRate = (SBigDecimal)((SBigDecimal)holding.getHoldingMap().get("holding_Total_Compsych_Premium")).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans")).divide(new SBigDecimal(1000)));
		//System.out.println("value:"+compsychRate.toString());
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Compsych_Rate.xls","holding-compsych-rate",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Compsych_Rate"));
		assertEquals("Check: holding_Compsych_Rate", compsychRate.toString(), holding.getHoldingMap().get("holding_Compsych_Rate").toString());
	}
	
	
	//line no 527 to 531
	@Test
	public void test_Holding_Ratio_Retiree_to_Total_Volume_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Retiree_Covered_Volume", new SBigDecimal(50));
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(25));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal ratio = (SBigDecimal)(((SBigDecimal)holding.getHoldingMap().get("holding_Retiree_Covered_Volume"))).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans")));
		//System.out.println("value:"+ratio.toString());
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Ratio_Retiree_to_Total_Volume.xls","holding-ratio-retiree-to-total-volume",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Volume"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Volume", ratio, holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Volume"));
	}
	
	
	@Test
	public void test_Holding_Ratio_Retiree_to_Total_Volume_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Retiree_Covered_Volume", new SBigDecimal(50));
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Ratio_Retiree_to_Total_Volume.xls","holding-ratio-retiree-to-total-volume",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Volume"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Volume", new SBigDecimal(0), holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Volume"));
	}
	
	//line no 532 to 536
	@Test
	public void test_holding_Total_Covered_Volume_For_All_Plans__Inverse_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_holding_Total_Covered_Volume_For_All_Plans__Inverse.xls","holding-total-covered-volume-for-all-plans-inverse",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans__Inverse"));
		assertEquals("Check: holding_Total_Covered_Volume_For_All_Plans__Inverse", new SBigDecimal(0), holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans__Inverse"));
	}
	
	@Test
	public void test_holding_Total_Covered_Volume_For_All_Plans__Inverse_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(1000));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal val = (SBigDecimal)(new SBigDecimal(1)).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans")));
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_holding_Total_Covered_Volume_For_All_Plans__Inverse.xls","holding-total-covered-volume-for-all-plans-inverse",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans__Inverse"));
		assertEquals("Check: holding_Total_Covered_Volume_For_All_Plans__Inverse", val, holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans__Inverse"));
	}
	
	//line no. 537
	//holding_Total_Lives_For_All_Plans 
	@Test
	public void test_Holding_Total_Lives_For_All_Plans() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("21.4"));
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("22.1"));
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT",
					"basiclife\\loop1\\BL_Holding_Total_Lives_For_All_Plans.xls","", new Object[] {holding});
			
		}
		System.out.println("holding_Total_Lives_For_All_Plans:"+holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS));
		assertEquals("Check: holding_Total_Lives_For_All_Plans", new SBigDecimal("43.5"), holding.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS));
	}
	
	//line no 538 to 542
	@Test
	public void test_Holding_Ratio_Retiree_to_Total_Lives_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Retiree_Lives", new SBigDecimal(50));
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal(25));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal ratio = (SBigDecimal)(((SBigDecimal)holding.getHoldingMap().get("holding_Retiree_Lives"))).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Lives_For_All_Plans")));
		//System.out.println("value:"+ratio.toString());
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Ratio_Retiree_to_Total_Lives.xls","holding-ratio-retiree-to-total-lives",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Lives"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Lives", ratio, holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Lives"));
	}
	
	
	@Test
	public void test_Holding_Ratio_Retiree_to_Total_Lives_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Retiree_Lives", new SBigDecimal(50));
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Ratio_Retiree_to_Total_Lives.xls","holding-ratio-retiree-to-total-lives",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Lives"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Lives", new SBigDecimal(0), holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Lives"));
	}
	
	
	//line no 543 to 547
	@Test
	public void test_Holding_Composite_Female_Pct_Ignoring_Composite_Setting_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Female_Lives_Ignoring_Composite_Setting", new SBigDecimal(50));
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal(25));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal ratio = (SBigDecimal)(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Female_Lives_Ignoring_Composite_Setting"))).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Lives_For_All_Plans")));
		//System.out.println("value:"+ratio.toString());
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Female_Pct_Ignoring_Composite_Setting.xls","holding-composite-female-pct-ignoring-composite-setting",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Female_Pct_Ignoring_Composite_Setting"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Lives", ratio, holding.getHoldingMap().get("holding_Composite_Female_Pct_Ignoring_Composite_Setting"));
	}
	
	@Test
	public void test_Holding_Composite_Female_Pct_Ignoring_Composite_Setting_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Female_Lives_Ignoring_Composite_Setting", new SBigDecimal(50));
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Female_Pct_Ignoring_Composite_Setting.xls","holding-composite-female-pct-ignoring-composite-setting",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Female_Pct_Ignoring_Composite_Setting"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Lives", new SBigDecimal(0), holding.getHoldingMap().get("holding_Composite_Female_Pct_Ignoring_Composite_Setting"));
	}
	
	//line 548
	@Test
	public void test_Holding_Composite_Male_Pct_Ignoring_Composite_Setting() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Composite_Female_Pct_Ignoring_Composite_Setting", new SBigDecimal("0.58"));
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Male_Pct_Ignoring_Composite_Setting.xls","holding-composite-male-pct-ignoring-composite-setting",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Male_Pct_Ignoring_Composite_Setting"));
		assertEquals("Check: holding_Composite_Male_Pct_Ignoring_Composite_Setting", new SBigDecimal("0.42"), holding.getHoldingMap().get("holding_Composite_Male_Pct_Ignoring_Composite_Setting"));
	}
	
	//line no 502,549	
	@Test
	public void test_Holding_Total_Number_Of_BL_Flat_Amt_Plans() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "FlatAmt");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put("plan/PlanType", "FlatAmt");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			//System.out.println("iteration:" + i + " "+holding.getHoldingMap().get("Plan_Loop_1"));
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Flat_Plans_Count.xls","holding-flat-plans-count",new Object[]{holding,p});
		}
		System.out.println(holding.getHoldingMap().get("holding_Flat_Plans_Count"));
		System.out.println(holding.getHoldingMap().get("holding_Total_Number_Of_BL_Flat_Amt_Plans"));
		
		assertEquals("Check: holding_Flat_Plans_Count", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Flat_Plans_Count"));
		assertEquals("Check: holding_Total_Number_Of_BL_Flat_Amt_Plans", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Total_Number_Of_BL_Flat_Amt_Plans"));
	}
	
	//line no. 550
	//holding_Client_Pooling_Point__Step_2 : to be covered in line 549 (inside plan loop)
	
	//line no. 551
	//holding_Total_Number_Of_Plans : to be covered in line 440 (inside plan loop)
	
	//line no 552 to 557	
	@Test
	public void test_Holding_Composite_Minimum_Premium_Step_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal("0.58"));
		//TODO: need to verify the effective date. as of now added RatingEngineEffectiveDate for unit testing
		holdingMap.put("RatingEngineEffectiveDate", "6/29/2002");
		
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Minimum_Premium_Step_1.xls","holding-composite-min-premium-step-1",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Minimum_Premium_Step_1"));
		assertEquals("Check: holding_Composite_Minimum_Premium_Step_1", new SBigDecimal("0.42"), holding.getHoldingMap().get("holding_Composite_Minimum_Premium_Step_1"));
	}
	
	//line no 558
	@Test
	public void test_Holding_Composite_Minimum_Premium() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Composite_Minimum_Premium_Step_1", new SBigDecimal("0.58"));
		//TODO: need to verify the effective date. as of now added RatingEngineEffectiveDate for unit testing
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal("0.58"));
		
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal val = (SBigDecimal)(((SBigDecimal)holding.getHoldingMap().get("holding_Composite_Minimum_Premium_Step_1")).divide((((SBigDecimal)holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans"))).divide(((new SBigDecimal(1000)).divide(new SBigDecimal(12))))));		
		System.out.println(val);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Minimum_Premium.xls","holding-composite-minimum-premium",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Minimum_Premium"));
		assertEquals("Check: holding_Composite_Minimum_Premium", val, holding.getHoldingMap().get("holding_Composite_Minimum_Premium"));
	}
}
