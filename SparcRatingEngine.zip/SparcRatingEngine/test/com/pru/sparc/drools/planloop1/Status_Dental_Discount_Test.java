package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.BasicLifeConstant;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class Status_Dental_Discount_Test {
	
	RatingCalculationTest objLoop1 = new RatingCalculationTest();

	@Test
	public void testStatus_Dental_Discount() {
		Holding holding = new Holding();

		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		holdingMap.put("holding/Life_100_Pilot", "Life_100_Pilot_Yes");
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put("EffectiveDate", "1/1/2013");
		planMap.put("DentalQuoted", "DentalQuotedY");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT",
				"basiclife//loop1//BL_Status_Dental_Discount.xls",
				"Status_Dental_Discount", new Object[] {holding,plan});
	
		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(holding.getCensus().getCensusMap());
	
		assertEquals("Check: Status_Dental_Discount", new SBigDecimal("0.95"),holding.getCensus().getCensusMap().get("status_Dental_Discount"));
	}
}
