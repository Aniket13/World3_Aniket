package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingCompsychRateTest {
	//line no 526
	@Test
	public void test_Holding_Compsych_Rate() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Compsych_Premium", new SBigDecimal(1));
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal(1));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal a = (SBigDecimal)((SBigDecimal)holding.getHoldingMap().get("holding_Total_Compsych_Premium")).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans")).divide(new SBigDecimal(1000)));
		//System.out.println("value:"+a.toString());
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Compsych_Rate.xls","holding-compsych-rate",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Compsych_Rate"));
		assertEquals("Check: holding_Compsych_Rate", a.toString(), holding.getHoldingMap().get("holding_Compsych_Rate").toString());
	}
}
