package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanTotalCoveredVolumeInverse {
	// line no 484 to 488
	@Test
	public void test_plan_Total_Covered_Volume__Inverse_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();

		HashMap<String, Object> planMap = new HashMap<String, Object>();
		// output of line no. 482
		planMap.put("plan_Total_Covered_Volume", new SBigDecimal("100"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT",
				"basiclife\\loop1\\BL_Plan_Total_Covered_Volume__Inverse.xls",
				"plan-Total_covered-volume-inverse", new Object[] { holding,
						plan });

		System.out.println(((Plan) (holding.getListOfPlans().get(holding
				.getCount()))).getPlanMap().get(
				"plan_Total_Covered_Volume__Inverse"));
		assertEquals("Check: plan_Total_Covered_Volume__Inverse",
				new SBigDecimal(1000),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Covered_Volume__Inverse"));
	}

	// line no 484 to 488
	@Test
	public void test_plan_Total_Covered_Volume__Inverse_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();

		HashMap<String, Object> planMap = new HashMap<String, Object>();
		// output of line no. 482
		planMap.put("plan_Total_Covered_Volume", new SBigDecimal("0"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT",
				"basiclife\\loop1\\BL_Plan_Total_Covered_Volume__Inverse.xls",
				"plan-Total_covered-volume-inverse", new Object[] { holding,
						plan });

		System.out.println(((Plan) (holding.getListOfPlans().get(holding
				.getCount()))).getPlanMap().get(
				"plan_Total_Covered_Volume__Inverse"));
		assertEquals("Check: plan_Total_Covered_Volume__Inverse",
				new SBigDecimal(1000),
				((Plan) (holding.getListOfPlans().get(holding.getCount())))
						.getPlanMap().get("plan_Total_Covered_Volume__Inverse"));
	}
}
