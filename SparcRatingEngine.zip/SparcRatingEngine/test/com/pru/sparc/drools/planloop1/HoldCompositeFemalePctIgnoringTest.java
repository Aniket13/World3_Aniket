package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldCompositeFemalePctIgnoringTest {
	//line no 543 to 547
	@Test
	public void test_Holding_Composite_Female_Pct_Ignoring_Composite_Setting_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Female_Lives_Ignoring_Composite_Setting", new SBigDecimal("50"));
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal("25"));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal ratio = (SBigDecimal)(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Female_Lives_Ignoring_Composite_Setting"))).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Lives_For_All_Plans")));
		//System.out.println("value:"+ratio.toString());
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Female_Pct_Ignoring_Composite_Setting.xls","holding-composite-female-pct-ignoring-composite-setting",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Female_Pct_Ignoring_Composite_Setting"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Lives", ratio, holding.getHoldingMap().get("holding_Composite_Female_Pct_Ignoring_Composite_Setting"));
	}
	
	@Test
	public void test_Holding_Composite_Female_Pct_Ignoring_Composite_Setting_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Total_Female_Lives_Ignoring_Composite_Setting", new SBigDecimal("50"));
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal("0"));
		holding.setHoldingMap(holdingMap);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Female_Pct_Ignoring_Composite_Setting.xls","holding-composite-female-pct-ignoring-composite-setting",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Female_Pct_Ignoring_Composite_Setting"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Lives", new SBigDecimal(0), holding.getHoldingMap().get("holding_Composite_Female_Pct_Ignoring_Composite_Setting"));
	}	
}
