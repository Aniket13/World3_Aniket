package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.BasicLifeConstant;
import com.pru.sparc.drools.common.util.FactLookupUtility;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class People_Gross_volume_Test {

	RatingCalculationTest objLoop1 = new RatingCalculationTest();

	@Test
	public void testPeopleGrossVolumeFinalRule_1() {
		BigDecimal planCaseFlatAmt = new BigDecimal("2000.00");
		BigDecimal planEarningsFactor = new BigDecimal("111.0");
		BigDecimal planMAXAmt = new BigDecimal("5000");
		BigDecimal planMINAmt = new BigDecimal("1000");
		BigDecimal planRoundingSelection = new BigDecimal("100");
		BigDecimal censusSalaryEstimate = new BigDecimal("10000.00");
		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "01/01/2013");
		planMap1.put("plan/RoundingOccurs", "RoundingOccursAfterAmtIsMultiplied");
		planMap1.put("AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		
		plan1.setCensus(census);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_People_Gross_Volume.xls","gross-param-final",new Object[]{holding});
		
		assertEquals("Check: people_Gross_Volume", new SBigDecimal(6262),
				(SBigDecimal)((Person)( ((Plan)(holding.getListOfPlans().get(holding.getCount()))).getCensus().getListOfPeople().get(holding.getPeopleCount()))).getPeopleMap().get("people_Gross_Volume"));
		
		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getCensus().getCensusMap());
		System.out.println("-----------------People Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getCensus().getListOfPeople().get(0).getPeopleMap());
		

	}
	
	@Test
	public void testPeopleGrossVolumeFinalRule_2() {
		BigDecimal planCaseFlatAmt = new BigDecimal("2000.00");
		BigDecimal planEarningsFactor = new BigDecimal("111.0");
		BigDecimal planMAXAmt = new BigDecimal("5000");
		BigDecimal planMINAmt = new BigDecimal("1000");
		BigDecimal planRoundingSelection = new BigDecimal("100");
		BigDecimal censusSalaryEstimate = new BigDecimal("10000.00");
		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "01/01/2013");
		planMap1.put("plan/RoundingOccurs", "NotRoundingOccursAfterAmtIsMultiplied");
		planMap1.put("AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		
		plan1.setCensus(census);
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_People_Gross_Volume.xls","gross-param-final",new Object[]{holding});
		
		assertEquals("Check: people_Gross_Volume", new SBigDecimal(6262),
				(SBigDecimal)((Person)( ((Plan)(holding.getListOfPlans().get(holding.getCount()))).getCensus().getListOfPeople().get(holding.getPeopleCount()))).getPeopleMap().get("people_Gross_Volume"));
		
		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getCensus().getCensusMap());
		System.out.println("-----------------People Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getCensus().getListOfPeople().get(0).getPeopleMap());
		

	}
	
	//@Test
	public  void testPeopleCoveredVolume() {
		BigDecimal planCaseFlatAmt = new BigDecimal("100000.00");
		BigDecimal planEarningsFactor = new BigDecimal("1.0");
		BigDecimal planMAXAmt = new BigDecimal("50000");
		BigDecimal planMINAmt = new BigDecimal("10000");
		BigDecimal planRoundingSelection = new BigDecimal("6");
		BigDecimal censusSalaryEstimate = new BigDecimal("10000.00");
		int peopleCount = 3;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "DE");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		//censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		//((SBigDecimal)(holding.getCensus().getCensusMap().get("people_Census_Salary"))).compareTo(new SBigDecimal("0"));
		// Set census to holding object
		holding.setCensus(census);
		objLoop1.invokeRatingEngine(holding,
				BasicLifeConstant.BL_PLAN_LOOP1_DRL,
				BasicLifeConstant.BL_PLAN_LOOP1_AGENDA_GROUP);;
			
		
		
		/*rateCal.showMap(holding.getCensus().getCensusMap());*/
		
		assertEquals(
				"When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected",
				1, holding.getCensus().censusMap
						.get("people_Average_Salary_Factor_Step_1"));
		

	}
	
	//@Test
	public void testPeopleGrossVolumeMultipleEarningsFinal() {
		BigDecimal planCaseFlatAmt = new BigDecimal("2000.00");
		BigDecimal planEarningsFactor = new BigDecimal("111.0");
		BigDecimal planMAXAmt = new BigDecimal("5000");
		BigDecimal planMINAmt = new BigDecimal("1000");
		BigDecimal planRoundingSelection = new BigDecimal("100");
		BigDecimal censusSalaryEstimate = new BigDecimal("10000.00");
		int peopleCount = 10;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "01/01/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		//((SBigDecimal)(holding.getCensus().getCensusMap().get("people_Census_Salary"))).compareTo(new SBigDecimal("0"));
		// Set census to holding object
		holding.setCensus(census);
		//rateCal.invokeRatingEngine(holding);
	
		/*rateCal.showMap(holding.getCensus().getCensusMap());*/
		
		assertEquals(
				"When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected",
				1, holding.getCensus().censusMap
						.get("people_Average_Salary_Factor_Step_1"));
		

	}
	
/*	@Test
	public void people_Gross_Volume__System_Calculated() {
		BigDecimal planCaseFlatAmt = new BigDecimal("100000.00");
		BigDecimal planEarningsFactor = new BigDecimal("111.0");
		BigDecimal planMAXAmt = new BigDecimal("5000");
		BigDecimal planMINAmt = new BigDecimal("1000");
		BigDecimal planRoundingSelection = new BigDecimal("100");
		BigDecimal censusSalaryEstimate = new BigDecimal("10000.00");
		int peopleCount = 10;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "CensusVolumeInParameters");
		planMap1.put("plan/PlanType", "FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "01/01/2016");
		planMap1.put("plan/RoundingOccurs", "RoundingOccursBeforeAmtIsMultiplied");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		//((SBigDecimal)(holding.getCensus().getCensusMap().get("people_Census_Salary"))).compareTo(new SBigDecimal("0"));
		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding);
		
		rateCal.showMap(holding.getCensus().getCensusMap());
		
		assertEquals(
				"When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected",
				1, holding.getCensus().censusMap
						.get("people_Average_Salary_Factor_Step_1"));
		

	}*/


	private static ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
			FactLookupUtility.showMap(peopleList.get(i).getPeopleMap());
		}
		
		return peopleList;
	}

	private static Person getPersonObject(int position) {
		System.out.println("person object created");
		List<Person> listPerson = new ArrayList<Person>();
		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Salary", new SBigDecimal(31000));
		peopleMap1.put("people/BasicAmt", new SBigDecimal(31000));
		peopleMap1.put("Age", 22.0);
		peopleMap1.put("gender", "male");
		peopleMap1.put("status", "active");
		peopleMap1.put("people_Gross_Volume__Compare_Min_Max",  new SBigDecimal(6262));
		
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put("people/Salary", new SBigDecimal(132000));
		peopleMap2.put("people/BasicAmt", new SBigDecimal(32000));
		peopleMap2.put("Age", 24.0);
		peopleMap2.put("gender", "female");
		peopleMap2.put("status", "active");
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put("people/Salary", new SBigDecimal(33000));
		peopleMap3.put("people/BasicAmt", new SBigDecimal(33000));
		peopleMap3.put("Age", 26.0);
		peopleMap3.put("gender", "male");
		peopleMap3.put("status", "active");
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put("people/Salary", new SBigDecimal(34000));
		peopleMap4.put("people/BasicAmt", new SBigDecimal(34000));
		peopleMap4.put("Age", 28.0);
		peopleMap4.put("gender", "female");
		peopleMap4.put("status", "active");
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put("people/Salary", new SBigDecimal(35000));
		peopleMap5.put("people/BasicAmt", new SBigDecimal(35000));
		peopleMap5.put("Age", 30.0);
		peopleMap5.put("gender", "male");
		peopleMap5.put("status", "active");
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);
		
		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put("people/Salary", new SBigDecimal(36000));
		peopleMap6.put("people/BasicAmt", new SBigDecimal(36000));
		peopleMap6.put("Age", 32.0);
		peopleMap6.put("gender", "female");
		peopleMap6.put("status", "retiree");
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put("people/Salary", new SBigDecimal(37000));
		peopleMap7.put("people/BasicAmt", new SBigDecimal(37000));
		peopleMap7.put("Age", 34.0);
		peopleMap7.put("gender", "female");
		peopleMap7.put("status", "retiree");
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put("people/Salary", new SBigDecimal(38000));
		peopleMap8.put("people/BasicAmt", new SBigDecimal(38000));
		peopleMap8.put("Age", 36.0);
		peopleMap8.put("gender", "female");
		peopleMap8.put("status", "retiree");
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put("people/Salary", new SBigDecimal(39000));
		peopleMap9.put("people/BasicAmt", new SBigDecimal(39000));
		peopleMap9.put("Age", 38.0);
		peopleMap9.put("gender", "female");
		peopleMap9.put("status", "retiree");
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put("people/Salary", new SBigDecimal(140000));
		peopleMap10.put("people/BasicAmt", new SBigDecimal(40000));
		peopleMap10.put("Age", 40.0);
		peopleMap10.put("gender", "female");
		peopleMap10.put("status", "retiree");
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);
		
		SBigDecimal s1 = new SBigDecimal(1);
		SBigDecimal s2 = new SBigDecimal(2);
		

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);

	}
	
	

}
