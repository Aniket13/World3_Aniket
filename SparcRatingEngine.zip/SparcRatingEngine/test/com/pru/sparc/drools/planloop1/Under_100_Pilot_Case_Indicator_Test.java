package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class Under_100_Pilot_Case_Indicator_Test {

	RatingCalculationTest objLoop1 = new RatingCalculationTest();

	@Test
	public void testUnder_100_Pilot_Case_Indicator() {
		Holding holding = new Holding();

		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		holdingMap.put("holding/Life_100_Pilot", "Life_100_Pilot_Yes");
		
		holding.setHoldingMap(holdingMap);
		
		
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Under_100_Pilot_Case_Indicator.xls","Under_100_Pilot_Case_Indicator",new Object[]{holding});
	
		assertEquals("Check: testUnder_100_Pilot_Case_Indicator", new SBigDecimal(1), holding
				.getHoldingMap().get("holding_Under_100_Pilot_Case_Indicator"));
		
		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getCensus().getCensusMap());
		/*System.out.println("-----------------People Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getCensus().getListOfPeople().get(0).getPeopleMap());*/
		
	}
}
