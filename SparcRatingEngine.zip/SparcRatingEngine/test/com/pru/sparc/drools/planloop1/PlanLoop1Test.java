package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanLoop1Test {
	//line no 500
	@Test
	public void test_Plan_Loop_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/Composite", "CompositeY");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		//output of line no. 482
		planMap.put("plan/Composite", "CompositeY");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			//System.out.println("iteration:" + i + " "+holding.getHoldingMap().get("Plan_Loop_1"));
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Loop_1.xls","plan-loop-1",new Object[]{holding,p});
		}
		System.out.println(holding.getHoldingMap().get("Plan_Loop_1"));
		
		assertEquals("Check: Plan_Loop_1", new SBigDecimal("2"), holding.getHoldingMap().get("Plan_Loop_1"));
	}
}
