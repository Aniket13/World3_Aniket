package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingSetPlansTypeTest {
	//line no 505 to 515
	@Test
	public void test_holding_Set_Plans_Type_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Flat_Plans_Count", new SBigDecimal("1"));
		holdingMap.put("holding_Multiple_Plans_Count", new SBigDecimal("0"));
		holdingMap.put("holding_Other_Plans_Count", new SBigDecimal("0"));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Set_Plans_Type.xls","holding-set-plans-type",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Set_Plans_Type"));
		System.out.println(holding.getHoldingMap().get("holding_Flat_Plans_Only"));
		assertEquals("Check: holding_Set_Plans_Type", new SBigDecimal("1"), holding.getHoldingMap().get("holding_Set_Plans_Type"));
	}
		
	//line no 505 to 515
	@Test
	public void test_holding_Set_Plans_Type_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Flat_Plans_Count", new SBigDecimal("0"));
		holdingMap.put("holding_Multiple_Plans_Count", new SBigDecimal("1"));
		holdingMap.put("holding_Other_Plans_Count", new SBigDecimal("0"));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Set_Plans_Type.xls","holding-set-plans-type",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Set_Plans_Type"));
		System.out.println(holding.getHoldingMap().get("holding_Multiple_Plans_Only"));
		assertEquals("Check: holding_Set_Plans_Type", new SBigDecimal("2"), holding.getHoldingMap().get("holding_Set_Plans_Type"));
	}
		
		
	//line no 505 to 515
	@Test
	public void test_holding_Set_Plans_Type_3() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Flat_Plans_Count", new SBigDecimal("0"));
		holdingMap.put("holding_Multiple_Plans_Count", new SBigDecimal("0"));
		holdingMap.put("holding_Other_Plans_Count", new SBigDecimal("1"));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Set_Plans_Type.xls","holding-set-plans-type",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Set_Plans_Type"));
		System.out.println(holding.getHoldingMap().get("holding_Other_Plans"));
		assertEquals("Check: holding_Set_Plans_Type", new SBigDecimal("3"), holding.getHoldingMap().get("holding_Set_Plans_Type"));
	}
		
	//line no 505 to 515
	@Test
	public void test_holding_Set_Plans_Type_3_Condition2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Flat_Plans_Count", new SBigDecimal("1"));
		holdingMap.put("holding_Multiple_Plans_Count", new SBigDecimal("1"));
		holdingMap.put("holding_Other_Plans_Count", new SBigDecimal("0"));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Set_Plans_Type.xls","holding-set-plans-type",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Set_Plans_Type"));
		System.out.println(holding.getHoldingMap().get("holding_Other_Plans"));
		assertEquals("Check: holding_Set_Plans_Type", new SBigDecimal("3"), holding.getHoldingMap().get("holding_Set_Plans_Type"));
	}
}
