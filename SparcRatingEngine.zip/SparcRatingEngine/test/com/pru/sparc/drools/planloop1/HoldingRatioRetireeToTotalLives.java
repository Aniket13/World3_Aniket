package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingRatioRetireeToTotalLives {
	//line no 538 to 542
	@Test
	public void test_Holding_Ratio_Retiree_to_Total_Lives_1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Retiree_Lives", new SBigDecimal(50));
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal(25));
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal ratio = (SBigDecimal)(((SBigDecimal)holding.getHoldingMap().get("holding_Retiree_Lives"))).divide(((SBigDecimal)holding.getHoldingMap().get("holding_Total_Lives_For_All_Plans")));
		//System.out.println("value:"+ratio.toString());
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Ratio_Retiree_to_Total_Lives.xls","holding-ratio-retiree-to-total-lives",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Lives"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Lives", ratio, holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Lives"));
	}
		
		
	@Test
	public void test_Holding_Ratio_Retiree_to_Total_Lives_2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Retiree_Lives", new SBigDecimal(50));
		holdingMap.put("holding_Total_Lives_For_All_Plans", new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Ratio_Retiree_to_Total_Lives.xls","holding-ratio-retiree-to-total-lives",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Lives"));
		assertEquals("Check: holding_Ratio_Retiree_to_Total_Lives", new SBigDecimal(0), holding.getHoldingMap().get("holding_Ratio_Retiree_to_Total_Lives"));
	}
}
