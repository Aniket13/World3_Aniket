package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingCommissionDateTest {
	//line no. 518
	//holding_Commission_Date : to be covered in line 18 (inside plan loop)
	@Test
	public void test_holding_Commission_Date() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put("OriginalPlanEffectiveDate", "Sat Jun 30 20:00:00 EDT 2007,Thu Dec 31 11:59:59 IST 9999");
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		listOfPlans.add(plan);
		
		//Adding one more plan for testing
		planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.ORIGINAL_PLAN_EFFECTIVE_DATE, "Sat Jun 30 20:00:00 EDT 2007");
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			Plan p =  (Plan) holding.getListOfPlans().get(i);
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Plan_Commission_Date_Check.xls","Plan_Commission_Date_Check",new Object[]{holding,p});
			System.out.println("plan_Commission_Date_Check:"+p.getPlanMap().get(PlanConstants.PLAN_COMMISSION_DATE_CHECK));
			
			RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Commission_Date.xls","holding-commission-date",new Object[]{holding,p});
			System.out.println("holding_Commission_Date current value:"+holding.getHoldingMap().get(HoldingConstants.HOLDING_COMMISSION_DATE));
			
		}
		System.out.println("********holding_Commission_Date Min Value********:"+holding.getHoldingMap().get(HoldingConstants.HOLDING_COMMISSION_DATE));
		assertEquals("Check: plan_Commission_Date_Check", new SBigDecimal("2"), holding.getHoldingMap().get(HoldingConstants.HOLDING_COMMISSION_DATE));
	}
}
