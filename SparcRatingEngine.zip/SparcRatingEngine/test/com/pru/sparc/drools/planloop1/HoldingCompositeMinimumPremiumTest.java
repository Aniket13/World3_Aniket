package com.pru.sparc.drools.planloop1;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.SBigDecimal;

public class HoldingCompositeMinimumPremiumTest {
	//line no 558
	@Test
	public void test_Holding_Composite_Minimum_Premium() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put("holding_Composite_Minimum_Premium_Step_1", new SBigDecimal("0.58"));
		//TODO: need to verify the effective date. as of now added RatingEngineEffectiveDate for unit testing
		holdingMap.put("holding_Total_Covered_Volume_For_All_Plans", new SBigDecimal("0.58"));
		
		holding.setHoldingMap(holdingMap);
		
		SBigDecimal val = (SBigDecimal)(((SBigDecimal)holding.getHoldingMap().get("holding_Composite_Minimum_Premium_Step_1")).divide((((SBigDecimal)holding.getHoldingMap().get("holding_Total_Covered_Volume_For_All_Plans"))).divide(((new SBigDecimal(1000)).divide(new SBigDecimal(12))))));		
		System.out.println(val);
		RuleUtility.getInitsData("DT","basiclife\\loop1\\BL_Holding_Composite_Minimum_Premium.xls","holding-composite-minimum-premium",new Object[]{holding});
		System.out.println(holding.getHoldingMap().get("holding_Composite_Minimum_Premium"));
		assertEquals("Check: holding_Composite_Minimum_Premium", val, holding.getHoldingMap().get("holding_Composite_Minimum_Premium"));
	}
}
