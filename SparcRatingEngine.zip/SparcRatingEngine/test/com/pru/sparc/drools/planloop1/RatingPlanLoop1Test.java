package com.pru.sparc.drools.planloop1;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.model.Holding;

public class RatingPlanLoop1Test {
	TestData objTestData = new TestData();
	RatingCalculationTest objLoop1 = new RatingCalculationTest();

	@Test
	public void testUnder_100_Pilot_Case_Indicator() {
		Holding holding = objTestData.setup();
		objLoop1.invokeRatingEngine(holding,"basiclife//loop1//BL_Plan_Loop1.drl", "plan-loop1");
	}
}
