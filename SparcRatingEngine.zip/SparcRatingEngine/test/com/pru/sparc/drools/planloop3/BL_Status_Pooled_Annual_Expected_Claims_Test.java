package com.pru.sparc.drools.planloop3;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.apache.commons.lang.StringUtils;
import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.model.StatusConstants;

public class BL_Status_Pooled_Annual_Expected_Claims_Test {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void test_Status_Pooled_Annual_Expected_Claims() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		holding.setHoldingMap(holdingMap);
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_EFFECTIVEDATE, "4/19/2015");
		planMap.put(PlanConstants.PLAN_EFFECTIVEDATE_TIMESTAMP, "Thu Sep 30 20:00:00 EDT 2004");
		planMap.put(PlanConstants.PLAN_CLIENT_POOLING_POINT, new SBigDecimal("20"));
		planMap.put(PlanConstants.PLAN_POOLED_CAB_STEP_1, new SBigDecimal("20"));
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		
		
		HashMap activeStatusMap = new HashMap();
		plan.getStatusAggregationMap().put(StatusConstants.STATUS_LIST.get(0), activeStatusMap);
		
		HashMap retireeStatusMap = new HashMap();
		plan.getStatusAggregationMap().put(StatusConstants.STATUS_LIST.get(1), retireeStatusMap);
		
		
		activeStatusMap.put(StatusConstants.STATUS_POOLED_CAB, new SBigDecimal("20"));
		activeStatusMap.put(StatusConstants.STATUS_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM, new SBigDecimal("30"));
		
		retireeStatusMap.put(StatusConstants.STATUS_POOLED_CAB, new SBigDecimal("10"));
		retireeStatusMap.put(StatusConstants.STATUS_POOLED_ADJUSTED_ANNUAL_MANUAL_PREMIUM, new SBigDecimal("15"));
		
		
		
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		census.setCensusMap(censusMap);
		plan.setCensus(census);
		
		for(String status : StatusConstants.STATUS_LIST){
			RuleUtility.getInitsData("DT","basiclife//loop3//BL_Status_Pooled_Annual_Expected_Claims.xls","", new Object[] {plan, plan.getStatusAggregationMap().get(status)});
		}
		
		
		for(String status : StatusConstants.STATUS_LIST){
			SBigDecimal val = (SBigDecimal) ((HashMap)plan.getStatusAggregationMap().get(status)).get(StatusConstants.STATUS_POOLED_ANNUAL_EXPECTED_CLAIMS);
			if (StringUtils.equalsIgnoreCase(status, StatusConstants.ACTIVE)) {
				assertEquals("Check: status_Pooled_Annual_Expected_Claims" + status, new SBigDecimal("600"),val);
			} else {
				assertEquals("Check: status_Pooled_Annual_Expected_Claims" + status, new SBigDecimal("150"),val);
			}
		 
		}
	}
}
