package com.pru.sparc.drools.planloop3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_Blended_Expected_Claims {

	@Test
	public void test_plan_Blended_Expected_Claims() {

		SBigDecimal plan_Blended_Expected_Claims__Step_1 = new SBigDecimal(12);
		SBigDecimal PLAN_CREDIBILITY = new SBigDecimal(1.5);
		SBigDecimal plan_Expected_Annual_Claims_Experience = new SBigDecimal(10.5);
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_BLENDED_EXPECTED_CLAIMS_STEP_1,
				plan_Blended_Expected_Claims__Step_1);
		planMap1.put(PlanConstants.PLAN_CREDIBILITY, PLAN_CREDIBILITY);
		planMap1.put(PlanConstants.PLAN_EXPECTED_ANNUAL_CLAIMS_EXPERIENCE, plan_Expected_Annual_Claims_Experience);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop3//BL_plan_Blended_Expected_Claims.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}

}
