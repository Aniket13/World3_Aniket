package com.pru.sparc.drools.planloop3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_Rate_Filing_Profit_Test {

	@Test
	public void test_plan_Rate_Filing_Profit() {

		SBigDecimal HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS = new SBigDecimal(
				2000000);
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS,
				HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS);
		holding.getHoldingMap().put(HoldingConstants.PROPOSALCREATIONDATE,
				"03/25/2004");

		RuleUtility.getInitsData("DT",
				"basiclife//loop3//BL_Plan_Rate_Filing_Profit.xls", "",
				new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);	
	

	}

}
