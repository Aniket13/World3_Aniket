package com.pru.sparc.drools.planloop3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_Composite_Annual_Expected_Claim_Rate {

	@Test
	public void test_plan_Composite_Annual_Expected_Claim_Rate() {

		SBigDecimal plan_Total_Covered_Volume__Inverse = new SBigDecimal(12);
		SBigDecimal plan_Composite_Annual_Expected_Claims = new SBigDecimal(1.5);
		
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_TOTAL_COVERED_VOLUME_INVERSE,
				plan_Total_Covered_Volume__Inverse);
		planMap1.put(PlanConstants.PLAN_COMPOSITE_ANNUAL_EXPECTED_CLAIMS, plan_Composite_Annual_Expected_Claims);
		
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop3//BL_Plan_Composite_Annual_Expected_Claim_Rate.xls", "",
				new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}

}
