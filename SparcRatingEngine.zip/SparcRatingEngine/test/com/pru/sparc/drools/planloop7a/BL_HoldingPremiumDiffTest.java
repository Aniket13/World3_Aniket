package com.pru.sparc.drools.planloop7a;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_HoldingPremiumDiffTest {

	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testHoldingPremiumDiffRule1() {
		Holding holding = setupData1();
			
			RuleUtility.getInitsData("DT","basiclife\\loop7a\\BL_HoldingPremiumDiff.xls",
					"",new Object[]{holding});
			
			System.out.println(holding.getHoldingMap().get(HoldingConstants.HOLDING_PREMIUM_DIFF));
			assertEquals("Check: holding_Premium_Diff", new SBigDecimal("29"),
					holding.getHoldingMap().get(HoldingConstants.HOLDING_PREMIUM_DIFF));
			
	
	}
	
		
	public static Holding setupData1() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		
		holdingMap.put(HoldingConstants.HOLDING_RENEWAL_PREMIUM, new SBigDecimal(6000));
		holdingMap.put(HoldingConstants.HOLDING_INITIAL_INFORCE_PREMIUM, new SBigDecimal(200));
		
		
		holding.setHoldingMap(holdingMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		planMap.put(PlanConstants.PLAN_UW_OVERRIDE_PREMIUM_ALL_AGEBANDED, new SBigDecimal(500));
		planMap.put(PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED, new SBigDecimal(600));
		
		holding.setCount(0);
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		census.setCensusMap(censusMap);
		int peopleCount = 10;
		census.setListOfPeople(getCensusWithEmployees(peopleCount));
		plan.setCensus(census);
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		return holding;
	}
	
		
	//test data
	private static ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
		}

		return peopleList;
	}
	
	private static Person getPersonObject(int position) {
		List<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(22));
		peopleMap1.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap1.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap1.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(1200));
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(24));
		peopleMap2.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap2.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap2.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(2000));
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(26));
		peopleMap3.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap3.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap3.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(2200));
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(28));
		peopleMap4.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap4.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap4.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(4200));
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(30));
		peopleMap5.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap5.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap5.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(200));
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(32));
		peopleMap6.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap6.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap6.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(400));
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(34.0));
		peopleMap7.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap7.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap7.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(300));
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(36));
		peopleMap8.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap8.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap8.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(400));
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(38));
		peopleMap9.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_MALE);
		peopleMap9.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_ACTIVE_STATUS);
		peopleMap9.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(400));
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(40));
		peopleMap10.put(PersonConstants.PEOPLE_GENDER, PersonConstants.PEOPLE_GENDER_FEMALE);
		peopleMap10.put(PersonConstants.PEOPLE_STATUS, PersonConstants.PEOPLE_RETIREE_STATUS);
		peopleMap10.put(PersonConstants.PEOPLE_TOTAL_COVERED_VOLUME, new SBigDecimal(400));
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);
	}
}
