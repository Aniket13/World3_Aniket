package com.pru.sparc.drools.planloop7a;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.AggregationUtility;
import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class AggregationTest {
	@Test
	public void test_AggregationTest1() {
		Holding holding = setupData();
		
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan =  (Plan) holding.getListOfPlans().get(i);
			
			for (int j = 0; j< AgeBracketConstants.AGE_BRACKET_LIST.size();j++) {
				
				String ageBracket = AgeBracketConstants.AGE_BRACKET_LIST.get(j);
				plan.setAgeBracket(ageBracket);
				
				HashMap ageBracketIndMap = (HashMap)plan.getAgeBracketAggregationMap().get(ageBracket);
				if (ageBracketIndMap == null) {
					ageBracketIndMap = new HashMap();
					plan.getAgeBracketAggregationMap().put(ageBracket,ageBracketIndMap);
				}
				
				ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_CHECK_APPEAL_OVERRIDE_USED, new SBigDecimal(722.50));
				
			
				AggregationUtility.aggregationUtilAgeBracket(plan,PlanConstants.PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED, AgeBracketConstants.AGEBRACKET_CHECK_APPEAL_OVERRIDE_USED,RuleRatingConstants.ADD_OPERATOR);
				
			
			
			}
			
			System.out.println(PlanConstants.PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED +" :"+plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED));
			
			assertEquals("Check: "+PlanConstants.PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED, new SBigDecimal("10837.5"),
					plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED));
			
		}
	}
	
	@Test
	public void test_AggregationTest2() {
		Holding holding = setupData();
		
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan =  (Plan) holding.getListOfPlans().get(i);
			
			for (int j = 0; j< AgeBracketConstants.AGE_BRACKET_LIST.size();j++) {
				
				String ageBracket = AgeBracketConstants.AGE_BRACKET_LIST.get(j);
				plan.setAgeBracket(ageBracket);
				
				HashMap ageBracketIndMap = (HashMap)plan.getAgeBracketAggregationMap().get(ageBracket);
				if (ageBracketIndMap == null) {
					ageBracketIndMap = new HashMap();
					plan.getAgeBracketAggregationMap().put(ageBracket,ageBracketIndMap);
				}
				
				
				ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_RENEWAL_PREMIUM_AGE_BANDED, new SBigDecimal(622.50));
				
				AggregationUtility.aggregationUtilAgeBracket(plan,PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED, AgeBracketConstants.AGEBRACKET_RENEWAL_PREMIUM_AGE_BANDED,RuleRatingConstants.ADD_OPERATOR);
				
			
			}
			
			System.out.println(PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED +" :" +plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED));
			/*assertEquals("Check: "+PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED, new SBigDecimal("9637.5"),
					plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED));*/
			
		}
		
	}
	
	@Test
	public void test_AggregationTest3() {
		Holding holding = setupData();
		
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan =  (Plan) holding.getListOfPlans().get(i);
			
			for (int j = 0; j< AgeBracketConstants.AGE_BRACKET_LIST.size();j++) {
				
				String ageBracket = AgeBracketConstants.AGE_BRACKET_LIST.get(j);
				plan.setAgeBracket(ageBracket);
				
				HashMap ageBracketIndMap = (HashMap)plan.getAgeBracketAggregationMap().get(ageBracket);
				if (ageBracketIndMap == null) {
					ageBracketIndMap = new HashMap();
					plan.getAgeBracketAggregationMap().put(ageBracket,ageBracketIndMap);
				}
				
				ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_UW_OVERRIDE_PREMIUM_AGEBANDED, new SBigDecimal(522.50));
				
				AggregationUtility.aggregationUtilAgeBracket(plan,PlanConstants.PLAN_UW_OVERRIDE_PREMIUM_ALL_AGEBANDED, AgeBracketConstants.AGEBRACKET_UW_OVERRIDE_PREMIUM_AGEBANDED,RuleRatingConstants.ADD_OPERATOR);
			}
			
			System.out.println(PlanConstants.PLAN_UW_OVERRIDE_PREMIUM_ALL_AGEBANDED +" :"+plan.getPlanMap().get(PlanConstants.PLAN_UW_OVERRIDE_PREMIUM_ALL_AGEBANDED));
			assertEquals("Check: "+PlanConstants.PLAN_UW_OVERRIDE_PREMIUM_ALL_AGEBANDED, new SBigDecimal("7837.5"),
					plan.getPlanMap().get(PlanConstants.PLAN_UW_OVERRIDE_PREMIUM_ALL_AGEBANDED));
		}
	}
	
	
	@Test
	public void test_AggregationTest4() {
		Holding holding = setupData();
		
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan =  (Plan) holding.getListOfPlans().get(i);
			
			for (int j = 0; j< AgeBracketConstants.AGE_BRACKET_LIST.size();j++) {
				
				String ageBracket = AgeBracketConstants.AGE_BRACKET_LIST.get(j);
				plan.setAgeBracket(ageBracket);
				
				HashMap ageBracketIndMap = (HashMap)plan.getAgeBracketAggregationMap().get(ageBracket);
				if (ageBracketIndMap == null) {
					ageBracketIndMap = new HashMap();
					plan.getAgeBracketAggregationMap().put(ageBracket,ageBracketIndMap);
				}
				
				ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_APPEAL_PREMIUM_AGEBANDED, new SBigDecimal(422.50));
			
				
				AggregationUtility.aggregationUtilAgeBracket(plan,PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED, AgeBracketConstants.AGEBRACKET_APPEAL_PREMIUM_AGEBANDED,RuleRatingConstants.ADD_OPERATOR);
				
			}
			System.out.println(PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED +" :"+plan.getPlanMap().get(PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED));
			assertEquals("Check: "+PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED, new SBigDecimal("6337.5"),
					plan.getPlanMap().get(PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED));
		}
		
		
	}
	
	@Test
	public void test_AggregationTest5() {
		Holding holding = setupData();
		
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan =  (Plan) holding.getListOfPlans().get(i);
			
			for (int j = 0; j< AgeBracketConstants.AGE_BRACKET_LIST.size();j++) {
				
				String ageBracket = AgeBracketConstants.AGE_BRACKET_LIST.get(j);
				plan.setAgeBracket(ageBracket);
				
				HashMap ageBracketIndMap = (HashMap)plan.getAgeBracketAggregationMap().get(ageBracket);
				if (ageBracketIndMap == null) {
					ageBracketIndMap = new HashMap();
					plan.getAgeBracketAggregationMap().put(ageBracket,ageBracketIndMap);
				}
				
				ageBracketIndMap.put(AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_VOLUME_AGE_BANDED, new SBigDecimal(322.50));
			
				
				AggregationUtility.aggregationUtilAgeBracket(plan,PlanConstants.PLAN_RENEWAL_VOLUME_ALL_AGE_BANDED, AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_VOLUME_AGE_BANDED,RuleRatingConstants.ADD_OPERATOR);
				
			}
			System.out.println(PlanConstants.PLAN_RENEWAL_VOLUME_ALL_AGE_BANDED +" :"+plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_VOLUME_ALL_AGE_BANDED));
			assertEquals("Check: "+PlanConstants.PLAN_RENEWAL_VOLUME_ALL_AGE_BANDED, new SBigDecimal("4837.5"),
					plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_VOLUME_ALL_AGE_BANDED));
		}
		
		
	}
	
	@Test
	public void test_AggregationTest6() {
		Holding holding = setupData();
		
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan =  (Plan) holding.getListOfPlans().get(i);
			
			AggregationUtility.aggregationUtilPlanLevel(holding,plan,HoldingConstants.HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS, PlanConstants.PLAN_RENEWAL_PREMIUM_NON_AGE_BANDED,RuleRatingConstants.ADD_OPERATOR);
			
		}
		System.out.println(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS +" :"+holding.getHoldingMap().get(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS));
		assertEquals("Check: "+HoldingConstants.HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS, new SBigDecimal("700"),
				holding.getHoldingMap().get(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_NONAGEBANDED_ALL_PLANS));
	}
	
	@Test
	public void test_AggregationTest7() {
		Holding holding = setupData();
		
		for (int i = 0;i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan =  (Plan) holding.getListOfPlans().get(i);
			
			AggregationUtility.aggregationUtilPlanLevel(holding,plan,HoldingConstants.HOLDING_SUM_RENEWAL_PREM_AGEBANDED_ALL_PLANS, PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED,RuleRatingConstants.ADD_OPERATOR);
			
		}
		System.out.println(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_AGEBANDED_ALL_PLANS +" :"+holding.getHoldingMap().get(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_AGEBANDED_ALL_PLANS));
		assertEquals("Check: "+HoldingConstants.HOLDING_SUM_RENEWAL_PREM_AGEBANDED_ALL_PLANS, new SBigDecimal("900"),
				holding.getHoldingMap().get(HoldingConstants.HOLDING_SUM_RENEWAL_PREM_AGEBANDED_ALL_PLANS));
	}
	
	
	private static Holding setupData() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("21.4"));
		planMap1.put(PlanConstants.PLAN_TOTAL_COVERED_VOLUME, new SBigDecimal("200001.4"));
		planMap1.put(PlanConstants.PLAN_COMMISSION_DATE_CHECK, new SBigDecimal("123.4"));
		planMap1.put(PlanConstants.PLAN_RENEWAL_PREMIUM_NON_AGE_BANDED, new SBigDecimal("200"));
		planMap1.put(PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED, new SBigDecimal("300"));
		
		

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		
		listOfPlans.add(plan1);
		
		//Adding one more plan for testing
		HashMap<String, Object> planMap2 = new HashMap<String, Object>();
		planMap2.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("22.1"));
		planMap2.put(PlanConstants.PLAN_TOTAL_COVERED_VOLUME, new SBigDecimal("444441.478"));
		planMap2.put(PlanConstants.PLAN_COMMISSION_DATE_CHECK, new SBigDecimal("123"));
		planMap2.put(PlanConstants.PLAN_RENEWAL_PREMIUM_NON_AGE_BANDED, new SBigDecimal("500"));
		planMap2.put(PlanConstants.PLAN_RENEWAL_PREMIUM_ALL_AGEBANDED, new SBigDecimal("600"));
		
		Plan plan2 = new Plan();
		plan2.setPlanMap(planMap2);
		listOfPlans.add(plan2);
		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);
		
		return holding;
	}
}
