package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_holding_Total_Monthly_Premium_Test {

	@Test
	public void test_holding_Total_Monthly_Premium()
			throws Exception {
		SBigDecimal holding_Total_Annual_Premium = new SBigDecimal(10);
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM,
				holding_Total_Annual_Premium);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Holding_Total_Monthly_Premium.xls",
						"", new Object[] { holding, plan });

		SparcRatingUtil.showMap(holding.getHoldingMap());
	}
}
