package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_Field_Adjustment_Ratio_Test {

	@Test
	public void test_plan_Field_Adjustment_Ratio() {

		Holding holding = new Holding();
		SBigDecimal PLAN_SRB2_EFFECTIVE_DATE_CHECK = new SBigDecimal(
				10);	

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		planMap1.put(PlanConstants.PLAN_SRB2_EFFECTIVE_DATE_CHECK,
				PLAN_SRB2_EFFECTIVE_DATE_CHECK);	
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Field_Adjustment_Ratio.xls",
				"", new Object[] { plan1 });

		SparcRatingUtil.showMap(planMap1);
	
	}
}
