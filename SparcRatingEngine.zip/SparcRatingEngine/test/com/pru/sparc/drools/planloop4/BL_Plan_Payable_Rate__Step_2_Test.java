package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_Payable_Rate__Step_2_Test {

	@Test
	public void test_Plan_Payable_Rate__Step_2() {

		Holding holding = new Holding();
		SBigDecimal plan_Blended_Claim_Rate = new SBigDecimal("10");
		SBigDecimal PLAN_PAYABLE_RATE_STEP_1_INVERSE = new SBigDecimal("20");
		SBigDecimal PLAN_FIELD_ADJUSTMENT_RATIO = new SBigDecimal("5");

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_BLENDED_CLAIM_RATE,
				plan_Blended_Claim_Rate);
		planMap1.put(PlanConstants.PLAN_PAYABLE_RATE_STEP_1_INVERSE,
				PLAN_PAYABLE_RATE_STEP_1_INVERSE);
		planMap1.put(PlanConstants.PLAN_FIELD_ADJUSTMENT_RATIO,
				PLAN_FIELD_ADJUSTMENT_RATIO);

		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Payable_Rate__Step_2.xls", "",
				new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}
}
