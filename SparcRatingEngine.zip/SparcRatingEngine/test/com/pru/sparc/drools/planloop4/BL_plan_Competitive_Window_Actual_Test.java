package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_plan_Competitive_Window_Actual_Test {

	@Test
	public void test_plan_Competitive_Window_Actual() {

		SBigDecimal PLAN_COMPETITIVE_WINDOW_CHECK_RANGES_STEP_1 = new SBigDecimal(
				"0.1");
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_COMPETITIVE_WINDOW_CHECK_RANGES_STEP_1,
				PLAN_COMPETITIVE_WINDOW_CHECK_RANGES_STEP_1);

		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_plan_Competitive_Window_Actual.xls", "",
				new Object[] { holding });

		RatingCalculationTest.showMap(planMap1);

	}

}
