package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;

public class BL_plan_Comp_Window_Maximum_Allowed_Discount_Test {

	@Test
	public void test_plan_Comp_Window_Maximum_Allowed_Discount() {

		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(HoldingConstants.HOLDING_LIFE_100_PILOT,
				"Life_100_Pilot_Yes");
		holding.getHoldingMap().put(HoldingConstants.PROPOSALEFFECTIVEDATE,
				"10/01/2008");
		holding.getHoldingMap().put(HoldingConstants.HOLDING_OLQUOTED,
				"OLQuotedY");

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_Comp_Window_Maximum_Allowed_Discount.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}

	@Test
	public void test_plan_Comp_Window_Maximum_Allowed_Discount_Rule2() {

		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(HoldingConstants.HOLDING_LIFE_100_PILOT,
				"Life_100_Pilot_No");
		holding.getHoldingMap().put(HoldingConstants.PROPOSALEFFECTIVEDATE,
				"10/01/2015");
		holding.getHoldingMap().put(HoldingConstants.HOLDING_OLQUOTED,
				"OLQuotedN");

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_Comp_Window_Maximum_Allowed_Discount.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}

}
