package com.pru.sparc.drools.planloop4;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class BL_Plan_Total_Manual_Premium_for_Postcalc_Step_1_Test {

	@Test
	public void test_Plan_EstimatedVolume_Composite_Yes()
			throws Exception {
		SBigDecimal plan_Total_Benefit_Charges = new SBigDecimal(10);
		SBigDecimal plan_Total_Retention = new SBigDecimal(10);
		
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		planMap.put(PlanConstants.PLAN_TOTAL_BENEFIT_CHARGES, plan_Total_Benefit_Charges);
		planMap.put(PlanConstants.PLAN_TOTAL_RETENTION, plan_Total_Retention);
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Total_Manual_Premium_for_Postcalc_Step_1.xls","",
				new Object[] { holding, plan });
		SparcRatingUtil.showMap(planMap);

	}	
}
