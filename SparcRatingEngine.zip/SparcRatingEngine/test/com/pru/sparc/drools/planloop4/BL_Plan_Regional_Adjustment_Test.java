package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;

public class BL_Plan_Regional_Adjustment_Test {

	@Test
	public void test_Plan_Regional_Adjustment() {

		Holding holding = new Holding();

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_plan_Regional_VP_Adjustment.xls", "",
				new Object[] { holding });

		RatingCalculationTest.showMap(planMap1);

	}
}
