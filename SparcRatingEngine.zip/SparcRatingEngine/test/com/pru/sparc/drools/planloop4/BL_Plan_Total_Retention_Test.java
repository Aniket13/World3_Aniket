package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.MathUtility;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_Total_Retention_Test {

	@Test
	public void test_Plan_Total_Retention() {

		Holding holding = new Holding();
		SBigDecimal PLAN_PREMIUM_TAX_FACTOR = new SBigDecimal("1");
		SBigDecimal PLAN_ASSESSMENT_FACTOR = new SBigDecimal("1");
		SBigDecimal PLAN_COMMISSION_PERCENTAGE = new SBigDecimal("1");
		SBigDecimal PLAN_RATE_FILING_EXPENSES = new SBigDecimal("1");
		SBigDecimal PLAN_RATE_FILING_PROFIT = new SBigDecimal("1");
		SBigDecimal PLAN_BENEFICIARY_COUNSELING_SERVICE = new SBigDecimal("1");
		SBigDecimal PLAN_TRAVEL_ASSIST_ADJUSTMENT = new SBigDecimal("1");
		SBigDecimal PLAN_ADDITIONAL_ADMINISTRATION = new SBigDecimal("1");
		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_FILING_RETENTION, "FilingRetentionY");
		planMap1.put(PlanConstants.PLAN_PREMIUM_TAX_FACTOR,
				PLAN_PREMIUM_TAX_FACTOR);
		planMap1.put(PlanConstants.PLAN_ASSESSMENT_FACTOR,
				PLAN_ASSESSMENT_FACTOR);
		planMap1.put(PlanConstants.PLAN_COMMISSION_PERCENTAGE,
				PLAN_COMMISSION_PERCENTAGE);
		planMap1.put(PlanConstants.PLAN_RATE_FILING_EXPENSES,
				PLAN_RATE_FILING_EXPENSES);
		planMap1.put(PlanConstants.PLAN_RATE_FILING_PROFIT,
				PLAN_RATE_FILING_PROFIT);
		planMap1.put(PlanConstants.PLAN_BENEFICIARY_COUNSELING_SERVICE,
				PLAN_BENEFICIARY_COUNSELING_SERVICE);
		planMap1.put(PlanConstants.PLAN_TRAVEL_ASSIST_ADJUSTMENT,
				PLAN_TRAVEL_ASSIST_ADJUSTMENT);
		planMap1.put(PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION,
				PLAN_ADDITIONAL_ADMINISTRATION);

		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Total_Retention.xls", "",
				new Object[] { holding });

		RatingCalculationTest.showMap(planMap1);		
		

	}

	@Test
	public void test_plan_Beneficiary_Counseling_Service_Rule2() {

		Holding holding = new Holding();
		SBigDecimal PLAN_PREMIUM_TAX_FACTOR = new SBigDecimal("2");
		SBigDecimal PLAN_ASSESSMENT_FACTOR = new SBigDecimal("2");
		SBigDecimal PLAN_DAC_TAX = new SBigDecimal("2");
		SBigDecimal PLAN_COMMISSION_PERCENTAGE = new SBigDecimal("2");
		SBigDecimal PLAN_CLAIM_ADMINISTRATION = new SBigDecimal("2");
		SBigDecimal PLAN_REGULAR_ADMINISTRATION = new SBigDecimal("2");
		SBigDecimal PLAN_ADDITIONAL_ADMINISTRATION = new SBigDecimal("2");
		SBigDecimal PLAN_CONTRIBUTION_TO_SURPLUS = new SBigDecimal("2");
		SBigDecimal PLAN_UNDERWRITING_CHARGE = new SBigDecimal("2");
		SBigDecimal PLAN_TRAVEL_ASSIST_ADJUSTMENT = new SBigDecimal("2");

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_FILING_RETENTION, "FilingRetentionN");

		planMap1.put(PlanConstants.PLAN_PREMIUM_TAX_FACTOR,
				PLAN_PREMIUM_TAX_FACTOR);
		planMap1.put(PlanConstants.PLAN_ASSESSMENT_FACTOR,
				PLAN_ASSESSMENT_FACTOR);
		planMap1.put(PlanConstants.PLAN_DAC_TAX, PLAN_DAC_TAX);
		planMap1.put(PlanConstants.PLAN_COMMISSION_PERCENTAGE,
				PLAN_COMMISSION_PERCENTAGE);
		planMap1.put(PlanConstants.PLAN_CLAIM_ADMINISTRATION,
				PLAN_CLAIM_ADMINISTRATION);
		planMap1.put(PlanConstants.PLAN_REGULAR_ADMINISTRATION,
				PLAN_REGULAR_ADMINISTRATION);
		planMap1.put(PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION,
				PLAN_ADDITIONAL_ADMINISTRATION);
		planMap1.put(PlanConstants.PLAN_CONTRIBUTION_TO_SURPLUS,
				PLAN_CONTRIBUTION_TO_SURPLUS);
		planMap1.put(PlanConstants.PLAN_UNDERWRITING_CHARGE,
				PLAN_UNDERWRITING_CHARGE);
		planMap1.put(PlanConstants.PLAN_TRAVEL_ASSIST_ADJUSTMENT,
				PLAN_TRAVEL_ASSIST_ADJUSTMENT);

		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Total_Retention.xls", "",
				new Object[] { holding });

		RatingCalculationTest.showMap(planMap1);

	}

	@Test
	public void test_plan_Beneficiary_Counseling_Service_Rule3() {

		Holding holding = new Holding();

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_FILING_RETENTION, "FilingRetention");

		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Total_Retention.xls", "",
				new Object[] { holding });

		RatingCalculationTest.showMap(planMap1);

	}

}
