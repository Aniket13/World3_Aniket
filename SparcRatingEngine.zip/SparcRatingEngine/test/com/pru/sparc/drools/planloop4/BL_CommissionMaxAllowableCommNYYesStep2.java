package com.pru.sparc.drools.planloop4;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Comission;
import com.pru.sparc.drools.model.CommissionConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_CommissionMaxAllowableCommNYYesStep2 {

	RatingCalculationTest rateCal = new RatingCalculationTest();

	@Test
	public void test_BL_CommissionMaxAllowableCommNYYesStep2_Rule_1() {

		// Here Input from holding map and output to plan map required

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		//planMap1.put(PlanConstants.PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS,
		//		new SBigDecimal("35000.01"));
		planMap1.put(PlanConstants.PLAN_CONTRACT_STATE, "NY");
		//planMap1.put(PlanConstants.ORIGINAL_PLAN_EFFECTIVE_DATE, "Tue Jul 31 20:00:00 EDT 2007");
		//planMap1.put(PlanConstants.PLAN_EFFECTIVEDATE, "07/27/2016");*/
		//planMap1.put(PlanConstants.PLAN_INITIAL_INFORCE_COMMISSION_PERCENTAGE_STEP_1, new SBigDecimal("100"));
		
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();
		 /*holding.getHoldingMap().put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS,new
		 SBigDecimal("0"));
		 holding.getHoldingMap().put(HoldingConstants.RATING_TYPE,"PIA");*/
		/*holding.getHoldingMap().put(HoldingConstants.HOLDING_COMMISSION_DATE, new SBigDecimal(
				1));*/
		
		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Initiate Commission parameters
		// Initiate Plan parameters
				HashMap<String, Object> commissionMap1 = new HashMap<String, Object>();
				Comission commission1 = new Comission();
				commission1.getCommissionMap().put(CommissionConstants.COMMISSION_LEVEL_SCALE_COMMISSIONS,new SBigDecimal(
						1));
				commission1.getCommissionMap().put(CommissionConstants.COMMISSION_ADDITIONAL_SERVICE_COMMISSION,new SBigDecimal(
						2));
				
				
		// Set Commission to holding object
		List<Comission> listOfCommisions = new ArrayList<Comission>();	
		listOfCommisions.add(commission1);
		plan1.setListOfComission(listOfCommisions);

		
		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Commission_Max_Allowable_Comm__NY_Yes_Step_2.xls",
						"", new Object[] { holding,plan1,commission1});

		assertEquals(
				CommissionConstants.COMMISSION_MAX_ALLOWABLE_COMM__NY_YES_STEP_1,
				new SBigDecimal("1"),
				commission1.getCommissionMap().get(CommissionConstants.COMMISSION_MAX_ALLOWABLE_COMM__NY_YES_STEP_1));
		
		assertEquals(
				CommissionConstants.COMMISSION_MAX_ALLOWABLE_COMM__NY_YES_STEP_2,
				new SBigDecimal("3"),
				commission1.getCommissionMap().get(CommissionConstants.COMMISSION_MAX_ALLOWABLE_COMM__NY_YES_STEP_2));

		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(holding.getCensus().getCensusMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());
		System.out.print("-----------------Commission Map--------------------");
		RatingCalculationTest.showMap(((Comission)(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getListOfComission().get(((Plan) (holding.getListOfPlans()
						.get(holding.getCount()))).getCommisionCount()))).getCommissionMap());

	}

	
	private ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
			// FactLookupUtility.showMap(peopleList.get(i).getPeopleMap());
		}

		return peopleList;
	}

	private Person getPersonObject(int position) {
		// System.out.println("person object created");
		List<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Salary", new BigDecimal(31000));
		peopleMap1.put("people/BasicAmt", new BigDecimal(31000));
		peopleMap1.put("Age", 22.0);
		peopleMap1.put("gender", "male");
		peopleMap1.put("status", "retiree");
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put("people/Salary", new BigDecimal(32000));
		peopleMap2.put("people/BasicAmt", new BigDecimal(32000));
		peopleMap2.put("Age", 24.0);
		peopleMap2.put("gender", "female");
		peopleMap2.put("status", "retiree");
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put("people/Salary", new BigDecimal(33000));
		peopleMap3.put("people/BasicAmt", new BigDecimal(33000));
		peopleMap3.put("Age", 26.0);
		peopleMap3.put("gender", "male");
		peopleMap3.put("status", "active");
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put("people/Salary", new BigDecimal(34000));
		peopleMap4.put("people/BasicAmt", new BigDecimal(34000));
		peopleMap4.put("Age", 28.0);
		peopleMap4.put("gender", "female");
		peopleMap4.put("status", "retiree");
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put("people/Salary", new BigDecimal(35000));
		peopleMap5.put("people/BasicAmt", new BigDecimal(35000));
		peopleMap5.put("Age", 30.0);
		peopleMap5.put("gender", "male");
		peopleMap5.put("status", "active");
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put("people/Salary", new BigDecimal(36000));
		peopleMap6.put("people/BasicAmt", new BigDecimal(36000));
		peopleMap6.put("Age", 32.0);
		peopleMap6.put("gender", "female");
		peopleMap6.put("status", "retiree");
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put("people/Salary", new BigDecimal(37000));
		peopleMap7.put("people/BasicAmt", new BigDecimal(37000));
		peopleMap7.put("Age", 34.0);
		peopleMap7.put("gender", "male");
		peopleMap7.put("status", "active");
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put("people/Salary", new BigDecimal(38000));
		peopleMap8.put("people/BasicAmt", new BigDecimal(38000));
		peopleMap8.put("Age", 36.0);
		peopleMap8.put("gender", "female");
		peopleMap8.put("status", "retiree");
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put("people/Salary", new BigDecimal(39000));
		peopleMap9.put("people/BasicAmt", new BigDecimal(39000));
		peopleMap9.put("Age", 38.0);
		peopleMap9.put("gender", "male");
		peopleMap9.put("status", "active");
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put("people/Salary", new BigDecimal(40000));
		peopleMap10.put("people/BasicAmt", new BigDecimal(40000));
		peopleMap10.put("Age", 40.0);
		peopleMap10.put("gender", "female");
		peopleMap10.put("status", "retiree");
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);

	}

}
