package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_holding_Blended_Area_Factor_Step_3_Test {

	@Test
	public void test_holding_Blended_Area_Factor_Step_3() throws Exception {
		SBigDecimal holding_Blended_Area_Factor_Step_2 = new SBigDecimal(10);
		SBigDecimal holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse = new SBigDecimal(9);
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_BLENDED_AREA_FACTOR_STEP_2,
				holding_Blended_Area_Factor_Step_2);
		holding.getHoldingMap()
				.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS_COMPOSITE_ONLY_INVERSE,
						holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Holding_Blended_Area_Factor_Step_3.xls",
				"", new Object[] { holding, plan });

		SparcRatingUtil.showMap(holding.getHoldingMap());
	}

	@Test
	public void test_holding_Blended_Area_Factor_Step_3_Rule2()
			throws Exception {
		SBigDecimal holding_Blended_Area_Factor_Step_2 = new SBigDecimal(10);
		SBigDecimal holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse = new SBigDecimal(9);
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeN");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_BLENDED_AREA_FACTOR_STEP_2,
				holding_Blended_Area_Factor_Step_2);
		holding.getHoldingMap()
				.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS_COMPOSITE_ONLY_INVERSE,
						holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Holding_Blended_Area_Factor_Step_3.xls",
				"", new Object[] { holding, plan });

		SparcRatingUtil.showMap(holding.getHoldingMap());
	}

	@Test
	public void test_holding_Blended_Area_Factor_Step_3_Rule3()
			throws Exception {
		SBigDecimal holding_Blended_Area_Factor_Step_2 = new SBigDecimal(10);
		SBigDecimal holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse = new SBigDecimal(9);
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "Composite");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_BLENDED_AREA_FACTOR_STEP_2,
				holding_Blended_Area_Factor_Step_2);
		holding.getHoldingMap()
				.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS_COMPOSITE_ONLY_INVERSE,
						holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Holding_Blended_Area_Factor_Step_3.xls",
				"", new Object[] { holding, plan });

		SparcRatingUtil.showMap(holding.getHoldingMap());
	}
}
