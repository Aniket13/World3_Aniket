package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_Certificate_Type_Load_Test {

	@SuppressWarnings("deprecation")
	@Test
	public void test_Plan_Certificate_Type_Load() {

		Holding holding = new Holding();
		SBigDecimal planAdditionalAdministrationStep2 = new SBigDecimal("0");

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION_STEP2,
				planAdditionalAdministrationStep2);
		planMap1.put(PlanConstants.PLAN_EFFECTIVEDATE, "07/20/2004");
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		holding.getHoldingMap().put(HoldingConstants.CERTIFICATE_TYPE,"PDF");
		holding.getHoldingMap().put(HoldingConstants.PROPOSALEFFECTIVEDATE,
				"10/01/2002");

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_Certificate_Type_Load.xls",
						"", new Object[] { holding });

		SparcRatingUtil.showMap(planMap1);
	

	}

	@Test
	public void test_Plan_Certificate_Type_Load_Integrated() {

		Holding holding = new Holding();
		SBigDecimal holdingTotalLivesForAllPlans = new SBigDecimal("105");

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_EFFECTIVEDATE, "07/20/2004");
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		holding.getHoldingMap().put(HoldingConstants.DV_BILLMETHOD, "Roster");
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS,
				holdingTotalLivesForAllPlans);
		holding.getHoldingMap()
				.put(HoldingConstants.ROSTER_BILL_METHOD, "Mail");
		holding.getHoldingMap().put(HoldingConstants.PROPOSALEFFECTIVEDATE,
				"10/01/2006");
		holding.getHoldingMap().put(HoldingConstants.CERTIFICATE_TYPE,"PDF");

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_Additional_Administration_Step2.xls",
						"", new Object[] { holding,plan1});
		RuleUtility
		.getInitsData(
				"DT",
				"basiclife//loop4//BL_Plan_Certificate_Type_Load.xls",
				"", new Object[] { holding });

		//RatingCalculationTest.showMap(planMap1);
		SparcRatingUtil.showMap(planMap1);

	}

}
