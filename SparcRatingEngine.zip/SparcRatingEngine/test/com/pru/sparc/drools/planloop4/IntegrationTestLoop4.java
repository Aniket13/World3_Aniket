package com.pru.sparc.drools.planloop4;

import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Comission;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.CommissionConstants;
import com.pru.sparc.drools.model.StatusConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.service.impl.RatingDroolsHelper;
import com.pru.sparc.drools.common.util.*;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.drools.RuleBase;

import com.pru.sparc.drools.common.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.model.SBigDecimal;

public class IntegrationTestLoop4 {

	/**
	 * @param holding
	 */
	public void execute(Holding holding) {

		final Logger logger = LoggerFactory.getLogger("BL_Plan_Loop4.drl");
		logger.debug("-----Calling IntegrationTest Execute for Loop 4------");
		long start = System.nanoTime();
		
		final String PlanPayableRateroundStep1EndDate = "06/29/2002";
		final String PlanPayableRateroundStep2StartDate = "06/29/2002";
		final String PlanPayableRateroundStep2EndDate = "10/11/2002";
		final String PlanPayableRateroundStep3StartDate = "10/11/2002";
		
		List plans = (List) (holding.getListOfPlans());

		for (int i = 0; i < plans.size(); i++) {

			logger.debug("Begin: Plan Loop" + (i + 1));
			holding.setCount(i);
			// plan object to be passed to DT
			// Plan plan =(Plan)(holding.getListOfPlans().get(i));
			Plan plan = (Plan) (holding.getListOfPlans()
					.get(holding.getCount()));

			logger.debug("Value of HOLDING_TOTAL_BENEFIT_CHARGES "
					+ holding.getHoldingMap().get(
							HoldingConstants.HOLDING_TOTAL_BENEFIT_CHARGES));
			logger.debug("Begin:BLPlanEstimatedAnnualPremiumForAllPlansStep1");
			// #plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_1 output
			// from BLPlanEstimatedAnnualPremiumForAllPlansStep1 DT
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BLPlanEstimatedAnnualPremiumForAllPlansStep1.xls",
							"plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_1",
							new Object[] { holding, plan });
			logger.debug("Value of PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_1 "
					+ plan.getPlanMap()
							.get(PlanConstants.PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_1));

			logger.debug("End: BLPlanEstimatedAnnualPremiumForAllPlansStep1");
			logger.debug("Begin: Plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2");
			// #Plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2 output
			// from Plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2 DT
			// RuleUtility.getInitsData("DT","basiclife//loop4//Plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2.xls","",
			// new Object[] {holding,plan });

			if (plan.getPlanMap()
					.get(PlanConstants.PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_1) != null) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2,
								(new SBigDecimal(1)).subtract((SBigDecimal) (plan
										.getPlanMap()
										.get(PlanConstants.PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_1))));

			}

			logger.debug("Value of PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2 "
					+ plan.getPlanMap()
							.get(PlanConstants.PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2));
			logger.debug("End: Plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2");
			logger.debug("Begin:  Plan_Plan_Est_Annrual_Premium_For_All_Plans__Step_2__Inverse");
			// #Plan_Plan_Est_Annual_Premium_For_All_Plans__Step_2__Inverse
			// output from
			// Plan_Plan_Est_Annual_Premium_For_All_Plans__Step_2__Inverse DT
			// RuleUtility.getInitsData("DT","basiclife//loop4//Plan_Plan_Est_Annual_Premium_For_All_Plans__Step_2__Inverse.xls","",
			// new Object[] {holding,plan });
			if (plan.getPlanMap()
					.get(PlanConstants.PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2) != null
					&& ((SBigDecimal) plan
							.getPlanMap()
							.get(PlanConstants.PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2))
							.doubleValue() != 0) {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_EST_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2__INVERSE,
								(new SBigDecimal(1))
										.divide((SBigDecimal) plan
												.getPlanMap()
												.get(PlanConstants.PLAN_PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2)));
			} else {
				plan.getPlanMap()
						.put(PlanConstants.PLAN_EST_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2__INVERSE,
								new SBigDecimal(0));
			}

			logger.debug("Value of PLAN_EST_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2__INVERSE "
					+ plan.getPlanMap()
							.get(PlanConstants.PLAN_EST_ANNUAL_PREMIUM_FOR_ALL_PLANS__STEP_2__INVERSE));
			logger.debug("End:  Plan_Plan_Est_Annrual_Premium_For_All_Plans__Step_2__Inverse");
			logger.debug("Begin:  plan_Plan_Estimated_Annual_Premium_For_All_Plans");
			// #Plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2 output
			// from plan_Plan_Estimated_Annual_Premium_For_All_Plans DT
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//plan_Plan_Estimated_Annual_Premium_For_All_Plans.xls",
							"", new Object[] { holding, plan });
			logger.debug("Value of Plan_Plan_Estimated_Annual_Premium_For_All_Plans__Step_2 : "
					+ plan.get(PlanConstants.PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS));
			logger.debug("End:  plan_Plan_Estimated_Annual_Premium_For_All_Plans");
			logger.debug("Begin: plan_Plan_Est_Annual_Premium_For_All_Plans__Inverse");
			// #plan_Plan_Est_Annual_Premium_For_All_Plans__Inverse output from
			// plan_Plan_Est_Annual_Premium_For_All_Plans__Inverse DT
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//plan_Plan_Est_Annual_Premium_For_All_Plans__Inverse.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: plan_Plan_Est_Annual_Premium_For_All_Plans__Inverse");
			logger.debug("Begin:  Plan_Rate_Filing_Expenses");
			// #plan_Rate_Filing_Expenses output from Plan_Rate_Filing_Expenses
			// DT
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//Plan_Rate_Filing_Expenses.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: Plan_Rate_Filing_Expenses");

			List commissions = (List) (plan.getListOfComission());
			/*
			 * logger.debug("Plan object Before calculation Start");
			 * SparcRatingUtil.showMap(plan.getPlanMap());
			 * logger.debug("Plan object Before calculation End");
			 */
			for (int j = 0; j < commissions.size(); j++) {
				logger.debug("Begin: Comission Loop" + (j + 1));
				plan.setCommisionCount(j);

				Comission commission = (Comission) (plan.getListOfComission()
						.get(j));
				/*
				 * logger.debug(
				 * "Commission object Before calculation Start for loop" +
				 * (j+1));
				 * SparcRatingUtil.showMap(commission.getCommissionMap());
				 * logger
				 * .debug("Commission object Before calculation End for loop" +
				 * (j+1));
				 */
				logger.debug("Begin: BL_Commission_Level_Scale_Commissions");

				// TODO: Remove below line.
				plan.put(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS,
						new SBigDecimal(3));

				if (plan.get(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS) != null
						&& ((SBigDecimal) plan
								.get(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS))
								.doubleValue() > 0) {
					commission
							.put(CommissionConstants.COMMISSION_DATE_RANGE,
									holding.get(HoldingConstants.HOLDING_COMMISSION_DATE));
				}

				logger.debug("Value of PLAN_TOTAL_COLLECTIVE_BARGAINS "
						+ plan.get(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS));
				if (plan.get(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS) != null) {
					RuleUtility
							.getInitsData(
									"DT",
									"basiclife//loop4//BL_Commission_Level_Scale_Commissions.xls",
									"", new Object[] { holding, plan,
											commission });
					logger.debug("End: BL_Commission_Level_Scale_Commissions");
					logger.debug("Begin: Aggregation for commission_Level_Scale_Commissions");

					logger.debug("End: Aggregation for commission_Level_Scale_Commissions");
					logger.debug("Begin: BL_Commission_Level_Scale_Union_Scale_Step_1");
					RuleUtility
							.getInitsData(
									"DT",
									"basiclife//loop4//BL_Commission_Level_Scale_Union_Scale_Step1.xls",
									"commission_Level_Scale__Union_Scale_Step_1",
									new Object[] { holding, plan, commission });
					logger.debug("End: BL_Commission_Level_Scale_Union_Scale_Step_1");
					logger.debug("Begin: BL_Commission_Level_Scale_Union_Scale_Step_2");
					RuleUtility
							.getInitsData(
									"DT",
									"basiclife//loop4//BL_Commission_Level_Scale_Union_Scale_Step2.xls",
									"commission_Level_Scale__Union_Scale_Step_2",
									new Object[] { plan, commission });
					logger.debug("End: BL_Commission_Level_Scale_Union_Scale_Step_2");
				}

				logger.debug("Start: commission_Level_Scale_Commissions");
				if (plan.get(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS) != null
						&& ((SBigDecimal) plan
								.get(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS))
								.doubleValue() > 0) {
					commission
							.put(CommissionConstants.COMMISSION_LEVEL_SCALE_COMMISSIONS,
									commission
											.get(CommissionConstants.COMMISSION_LEVEL_SCALE__UNION_SCALE_STEP_2));
					logger.debug("Value of COMMISSION_LEVEL_SCALE_COMMISSIONS :"
							+ commission
									.get(CommissionConstants.COMMISSION_LEVEL_SCALE_COMMISSIONS));
				}
				logger.debug("End: commission_Level_Scale_Commissions");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Level_Scale__Scale_B_Check.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Level_Scale_Scale_B_Check");

				logger.debug("Start: commission_Level_Scale_Commissions");
				if (plan.get(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS) != null
						&& ((SBigDecimal) plan
								.get(PlanConstants.PLAN_TOTAL_COLLECTIVE_BARGAINS))
								.doubleValue() < 0) {
					commission
							.put(CommissionConstants.COMMISSION_LEVEL_SCALE_COMMISSIONS,
									commission
											.get(CommissionConstants.COMMISSION_LEVEL_SCALE__SCALE_B_CHECK));
					logger.debug("Value of COMMISSION_LEVEL_SCALE_COMMISSIONS :"
							+ commission
									.get(CommissionConstants.COMMISSION_LEVEL_SCALE_COMMISSIONS));
				}
				logger.debug("End: commission_Level_Scale_Commissions");

				// Aggregation for commission_Level_Scale_Commissions
				// (COMMISSION_LEVEL_SCALE_COMMISSIONS) at plan level
				AggregationUtility.aggregationUtil(plan, commission,
						CommissionConstants.COMMISSION_LEVEL_SCALE_COMMISSIONS,
						RuleRatingConstants.ADD_OPERATOR);
				logger.debug("Begin: BL_Commission_Level_Scale_Scale_B_Step_1");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Level_Scale__Scale_B_Step_1.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Level_Scale_Scale_B_Step_1");
				logger.debug("Begin: BL_Commission_Level_Scale_Scale_B_Step_2");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Level_Scale__Scale_B_Step_2.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Level_Scale_Scale_B_Step_2");
				logger.debug("Begin: BL_Commission_Level_Scale_Scale_C_Step_1");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Level_Scale__Scale_C_Step_1.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Level_Scale_Scale_C_Step_1");
				logger.debug("Begin: BL_Commission_Level_Scale_Scale_C_Step_2");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Level_Scale__Scale_C_Step_2.xls",
								"commission_Level_Scale__Scale_C_Step_2",
								new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Level_Scale_Scale_C_Step_2");

				logger.debug("Begin: BL_Commission_Addtl_Service_Comm__Benefit_Admin_System_Design");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Addtl_Service_Comm__Benefit_Admin_System_Design.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Addtl_Service_Comm__Benefit_Admin_System_Design");

				logger.debug("Begin: BL_Commission_Addtl_Service_Comm__Supervising_General_Agent");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Addtl_Service_Comm__Supervising_General_Agent.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Addtl_Service_Comm_Supervising_General_Agent");
				logger.debug("Begin: BL_Commission_Addtl_Service_Comm_Step_2");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Addtl_Service_Comm__Step_2.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Addtl_Service_Comm_Step_2");

				logger.debug("Begin: BL_Commission_Additional_Service_Commission");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Additional_Service_Commission.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Additional_Service_Commission");

				if (commission
						.get(CommissionConstants.COMMISSION_ADDTL_SERVICE_COMM__SUPERVISING_GENERAL_AGENT) != null
						&& commission
								.get(CommissionConstants.COMMISSION_ADDITIONAL_SERVICE_COMMISSION) != null
						&& ((SBigDecimal) commission
								.get(CommissionConstants.COMMISSION_ADDTL_SERVICE_COMM__SUPERVISING_GENERAL_AGENT))
								.doubleValue() < ((SBigDecimal) commission
								.get(CommissionConstants.COMMISSION_ADDITIONAL_SERVICE_COMMISSION))
								.doubleValue()) {

					commission
							.put(CommissionConstants.COMMISSION_ADDITIONAL_SERVICE_COMMISSION,
									(SBigDecimal) commission
											.get(CommissionConstants.COMMISSION_ADDTL_SERVICE_COMM__SUPERVISING_GENERAL_AGENT));
				}

				// TODO:Shift
				logger.debug("Begin: Aggregation for commission_Additional_Service_Commission");
				// Aggregation for commission_Additional_Service_Commission
				// (COMMISSION_ADDITIONAL_SERVICE_COMMISSION) at plan level
				AggregationUtility
						.aggregationUtil(
								plan,
								commission,
								CommissionConstants.COMMISSION_ADDITIONAL_SERVICE_COMMISSION,
								RuleRatingConstants.ADD_OPERATOR);
				logger.debug("End: Aggregation for commission_Additional_Service_Commission");

				logger.debug("Begin: BL_Commission_Requested_Commission_Flat_Percent, This DT set value for commission_Requested_Commission__Level,commission_Requested_Commission__Flat_Amt and commission_Requested_Commission__Flat_Percent");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Requested_Commission__Flat_Percent.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Requested_Commission_Flat_Percent");
				logger.debug("Begin: BL_Commission_Requested_Commission");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Requested_Commission.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Requested_Commission");
				logger.debug("Begin: Aggregation for commission_Requested_Commission");
				// Aggregation for commission_Requested_Commission
				// (COMMISSION_REQUESTED_COMMISSION) at plan level
				AggregationUtility.aggregationUtil(plan, commission,
						CommissionConstants.COMMISSION_REQUESTED_COMMISSION,
						RuleRatingConstants.ADD_OPERATOR);
				logger.debug("End: Aggregation for commission_Requested_Commission");

				logger.debug("Begin: BL_Commission_Set_To_Inforce_Value");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Set_To_Inforce_Value.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Set_To_Inforce_Value");
				logger.debug("End: BL_Commission_Max_Allowable_Comm_NY_Yes_Step_2");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Commission_Max_Allowable_Comm__NY_Yes_Step_2.xls",
								"", new Object[] { holding, plan, commission });
				logger.debug("End: BL_Commission_Max_Allowable_Comm_NY_Yes_Step_2");

				logger.debug("Begin: commission_Commission_Percentage");
				// # commission_Commission_Percentage :get
				// commission_Commission_Percentage from Loop 4 and assign it to
				// commission_Commission_Percentage
				SBigDecimal commissionCommissionPercentage = MathUtility
						.min((SBigDecimal) commission
								.getCommissionMap()
								.get(CommissionConstants.COMMISSION_MAX_ALLOWABLE_COMM__NY_NO_STEP_2),
								(SBigDecimal) commission
										.getCommissionMap()
										.get(CommissionConstants.COMMISSION_REQUESTED_COMMISSION));
				if (commissionCommissionPercentage != null) {
					commission
							.getCommissionMap()
							.put(CommissionConstants.COMMISSION_COMMISSION_PERCENTAGE,
									commissionCommissionPercentage);
					logger.debug("Value of COMMISSION_COMMISSION_PERCENTAGE:"
							+ commission
									.getCommissionMap()
									.get(CommissionConstants.COMMISSION_COMMISSION_PERCENTAGE));
				}
				logger.debug("End: commission_Commission_Percentage");

				logger.debug("Begin: Aggregation for commission_Max_Allowable_Commissions");
				// Aggregation for commission_Max_Allowable_Commissions
				// (COMMISSION_MAX_ALLOWABLE_COMMISSIONS) at plan level
				AggregationUtility
						.aggregationUtil(
								plan,
								commission,
								CommissionConstants.COMMISSION_MAX_ALLOWABLE_COMMISSIONS,
								RuleRatingConstants.ADD_OPERATOR);
				logger.debug("End: Aggregation for commission_Max_Allowable_Commissions");

				logger.debug("Begin: Aggregation for commission_Max_Allowable_Comm__NY_No_Step_2");
				// Aggregation for commission_Max_Allowable_Comm__NY_No_Step_2
				// (COMMISSION_MAX_ALLOWABLE_COMM__NY_NO_STEP_2) at plan level
				AggregationUtility
						.aggregationUtil(
								plan,
								commission,
								CommissionConstants.COMMISSION_MAX_ALLOWABLE_COMM__NY_NO_STEP_2,
								RuleRatingConstants.MIN_OPERATOR);
				logger.debug("End: Aggregation for commission_Max_Allowable_Comm__NY_No_Step_2");

				logger.debug("End: Comission Loop" + (j + 1));
				// SparcRatingUtil.showMap(commission.getCommissionMap());

				logger.debug("Commission object After calculation Start for loop"
						+ (j + 1));
				SparcRatingUtil.showMap(commission.getCommissionMap());
				logger.debug("Commission object After calculation End for loop"
						+ (j + 1));

			}

			// Commission Aggregation Start
			logger.debug("Begin: plan_Level_Scale_Commissions");
			// # plan_Level_Scale_Commissions :get
			// commission_Level_Scale_Commissions salary from Loop 4 and assign
			// it to plan_Level_Scale_Commissions
			SBigDecimal sumOfCommissionLevelScaleCommissions = (SBigDecimal) plan
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ CommissionConstants.COMMISSION_LEVEL_SCALE_COMMISSIONS);
			if (sumOfCommissionLevelScaleCommissions != null) {
				plan.getPlanMap().put(PlanConstants.PLAN_TOTAL_SALARY,
						sumOfCommissionLevelScaleCommissions);
				logger.debug("Value of PLAN_TOTAL_SALARY:"
						+ plan.getPlanMap()
								.get(PlanConstants.PLAN_TOTAL_SALARY));
			}
			logger.debug("End: plan_Level_Scale_Commissions");
			logger.debug("Begin: plan_Additional_Service_Commissions");
			// # plan_Additional_Service_Commissions :get
			// commission_Additional_Service_Commission salary from Loop 4 and
			// assign it to plan_Additional_Service_Commissions
			SBigDecimal sumOfCommissionAdditionalServiceCommission = (SBigDecimal) plan
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ CommissionConstants.COMMISSION_ADDITIONAL_SERVICE_COMMISSION);
			if (sumOfCommissionAdditionalServiceCommission != null) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_ADDITIONAL_SERVICE_COMMISSIONS,
						sumOfCommissionAdditionalServiceCommission);
				logger.debug("Value of PLAN_ADDITIONAL_SERVICE_COMMISSIONS:"
						+ plan.getPlanMap()
								.get(PlanConstants.PLAN_ADDITIONAL_SERVICE_COMMISSIONS));
			}
			logger.debug("End: plan_Additional_Service_Commissions");
			logger.debug("Begin: plan_Requested_Commission");
			// # plan_Requested_Commission :get commission_Requested_Commission
			// salary from Loop 4 and assign it to plan_Requested_Commission
			SBigDecimal sumOfCommissionRequestedCommission = (SBigDecimal) plan
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ CommissionConstants.COMMISSION_REQUESTED_COMMISSION);
			if (sumOfCommissionRequestedCommission != null) {
				plan.getPlanMap().put(PlanConstants.PLAN_REQUESTED_COMMISSION,
						sumOfCommissionRequestedCommission);
				logger.debug("Value of PLAN_REQUESTED_COMMISSION:"
						+ plan.getPlanMap().get(
								PlanConstants.PLAN_REQUESTED_COMMISSION));
			}
			logger.debug("End: plan_Requested_Commission");

			// TODO:SHIFT AGGR
			logger.debug("Begin: Aggregation for plan_Requested_Commission ");

			// Aggregation for plan_Requested_Commission
			// (PLAN_REQUESTED_COMMISSION) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_REQUESTED_COMMISSION,
					RuleRatingConstants.MIN_OPERATOR);

			logger.debug("End: Aggregation for plan_Requested_Commission ");

			logger.debug("Begin: plan_Max_Allowable_Commissions");
			// # plan_Max_Allowable_Commissions :get
			// commission_Max_Allowable_Commissions salary from Loop 4 and
			// assign it to plan_Max_Allowable_Commissions
			SBigDecimal sumOfcommissionMaxAllowableCommissions = (SBigDecimal) plan
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ CommissionConstants.COMMISSION_MAX_ALLOWABLE_COMMISSIONS);
			if (sumOfcommissionMaxAllowableCommissions != null) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_MAX_ALLOWABLE_COMMISSIONS,
						sumOfcommissionMaxAllowableCommissions);
				logger.debug("Value of PLAN_MAX_ALLOWABLE_COMMISSIONS:"
						+ plan.getPlanMap().get(
								PlanConstants.PLAN_MAX_ALLOWABLE_COMMISSIONS));
			}
			logger.debug("End: plan_Max_Allowable_Commissions");

			logger.debug("Begin: plan_Commission_Percentage");

			// # plan_Commission_Percentage :get plan_Requested_Commission
			// salary from Loop 4 and assign it to plan_Commission_Percentage
			SBigDecimal minOfplanRequestedCommission = MathUtility.min(
					(SBigDecimal) plan.getPlanMap().get(
							PlanConstants.PLAN_REQUESTED_COMMISSION),
					(SBigDecimal) plan.getPlanMap().get(
							PlanConstants.PLAN_MAX_ALLOWABLE_COMMISSIONS));
			if (minOfplanRequestedCommission != null) {
				plan.getPlanMap().put(PlanConstants.PLAN_COMMISSION_PERCENTAGE,
						minOfplanRequestedCommission);
				logger.debug("Value of PLAN_COMMISSION_PERCENTAGE:"
						+ plan.getPlanMap().get(
								PlanConstants.PLAN_COMMISSION_PERCENTAGE));
			}
			
		
			
			
			
			// TODO :MIN AGGREGATION OF PLAN_COMMISSION_PERCENTAGE IS NOT
			// WORKING, SETTING DUMMY VALUE FOR NOW
			plan.getPlanMap().put(PlanConstants.PLAN_COMMISSION_PERCENTAGE,
					new SBigDecimal("0.106"));

			logger.debug("End: plan_Commission_Percentage");
			// Commission Aggregation End

			logger.debug("Begin: BL_Plan_Claim_Administration");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Claim_Administration.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Claim_Administration");

			logger.debug("Begin: Premium_Axis");
			if (plan.get(PlanConstants.PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS) != null) {
				plan.put(
						PlanConstants.PREMIUM_AXIS,
						(SBigDecimal) plan
								.get(PlanConstants.PLAN_ESTIMATED_ANNUAL_PREMIUM_FOR_ALL_PLANS));
			}

			logger.debug("End: Premium_Axis");

			// TotalLivesforAllPlans : This is intermediate variable. Assigned
			// skipped for this variable. Value can be fetch from
			// holding_Total_Lives_For_All_Plans

			logger.debug("Begin: BL_Plan_Regular_Administration");
			// RuleUtility.getInitsData("DT","basiclife//loop4//BL_Plan_Regular_Administration.xls","",
			// new Object[] { holding,plan });
			// TODO: Dummy Value should be replaced by New Factor Tables
			plan.put(PlanConstants.PLAN_REGULAR_ADMINISTRATION,
					new SBigDecimal("0.1858"));
			logger.debug("End: BL_Plan_Regular_Administration");

			logger.debug("Begin: BL_Plan_Additional_Administration_Step2");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Additional_Administration_Step2.xls",
							"", new Object[] { holding, plan });
			logger.debug("PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION_STEP2 : "
					+ plan.getPlanMap().get(
							PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION_STEP2));
			logger.debug("End: BL_Plan_Additional_Administration_Step2");
			logger.debug("Begin: BL_Plan_Certificate_Type_Load");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Certificate_Type_Load.xls", "",
					new Object[] { holding });
			logger.debug("End: BL_Plan_Certificate_Type_Load");
			// plan_Additional_Administration pending

			logger.debug("Begin: plan_Additional_Administration");

			if (plan.get(PlanConstants.PLAN_CERTIFICATE_TYPE_LOAD) != null) {

				plan.put(PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION,
						(SBigDecimal) plan
								.get(PlanConstants.PLAN_CERTIFICATE_TYPE_LOAD));
			}

			logger.debug("End: plan_Additional_Administration");

			logger.debug("Begin: BL_Plan_Contribution_To_Surplus");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Contribution_To_Surplus.xls",
					"", new Object[] { holding });
			logger.debug("End: BL_Plan_Contribution_To_Surplus");
			logger.debug("Begin: BL_Plan_Underwriting_Charge");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Underwriting_Charge.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Underwriting_Charge");

			logger.debug("Begin: BL_Plan_Travel_Assist_Adjustment");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Travel_Assist_Adjustment.xls",
					"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Travel_Assist_Adjustment");
			logger.debug("Begin: BL_Plan_Beneficiary_Counseling_Service");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Beneficiary_Counseling_Service.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Beneficiary_Counseling_Service");
			logger.debug("Begin: BL_Plan_Total_Retention");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Total_Retention.xls", "",
					new Object[] { holding, plan });

			SBigDecimal valueFilingRetentionY = MathUtility
					.add(plan.get(PlanConstants.PLAN_PREMIUM_TAX_FACTOR),
							MathUtility.add(
									plan.get(PlanConstants.PLAN_ASSESSMENT_FACTOR),
									MathUtility.add(
											plan.get(PlanConstants.PLAN_DAC_TAX),
											MathUtility.add(
													plan.get(PlanConstants.PLAN_COMMISSION_PERCENTAGE),
													MathUtility.add(
															plan.get(PlanConstants.PLAN_CLAIM_ADMINISTRATION),
															MathUtility.add(
																	plan.get(PlanConstants.PLAN_REGULAR_ADMINISTRATION),
																	MathUtility
																			.add(plan
																					.get(PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION),
																					MathUtility
																							.add(plan
																									.get(PlanConstants.PLAN_CONTRIBUTION_TO_SURPLUS),
																									MathUtility
																											.add(plan
																													.get(PlanConstants.PLAN_UNDERWRITING_CHARGE),
																													plan.get(PlanConstants.PLAN_TRAVEL_ASSIST_ADJUSTMENT))))))))));
			logger.debug("Begin: valueFilingRetentionY of BL_Plan_Total_Retention"
					+ valueFilingRetentionY);
			SBigDecimal valueFilingRetentionN = MathUtility
					.add(plan.get(PlanConstants.PLAN_PREMIUM_TAX_FACTOR),
							MathUtility.add(
									plan.get(PlanConstants.PLAN_ASSESSMENT_FACTOR),
									MathUtility.add(
											plan.get(PlanConstants.PLAN_DAC_TAX),
											MathUtility.add(
													plan.get(PlanConstants.PLAN_CLAIM_ADMINISTRATION),
													MathUtility.add(
															plan.get(PlanConstants.PLAN_REGULAR_ADMINISTRATION),
															MathUtility.add(
																	plan.get(PlanConstants.PLAN_ADDITIONAL_ADMINISTRATION),
																	MathUtility
																			.add(plan
																					.get(PlanConstants.PLAN_CONTRIBUTION_TO_SURPLUS),
																					MathUtility
																							.add(plan
																									.get(PlanConstants.PLAN_UNDERWRITING_CHARGE),
																									plan.get(PlanConstants.PLAN_TRAVEL_ASSIST_ADJUSTMENT)))))))));
			logger.debug("Begin: valueFilingRetentionN of BL_Plan_Total_Retention"
					+ valueFilingRetentionN);

			logger.debug("End: BL_Plan_Total_Retention");

			logger.debug("Begin: BL_CompWindow_Date_Check");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_CompWindow_Date_Check.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: BL_CompWindow_Date_Check");
			if ((plan.getPlanMap()
					.get(PlanConstants.PLAN_COMPWINDOW_DATE_CHECK) != null)
					&& (((SBigDecimal) (plan.getPlanMap()
							.get(PlanConstants.PLAN_COMPWINDOW_DATE_CHECK)))
							.compareTo(new SBigDecimal("0")) == 0)) {
				logger.debug("Begin: BL_Plan_Competitive_Window_Requested");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_Competitive_Window_Requested.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_Competitive_Window_Requested");
				logger.debug("Begin: BL_Plan_Competitive_Window_User_Override");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_Competitive_Window_User_Override.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_Competitive_Window_User_Override");
				logger.debug("Begin: BL_Plan_Competitive_Window__Check_Ranges_step_1");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_Competitive_Window__Check_Ranges_step_1.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_Competitive_Window__Check_Ranges_step_1");
				logger.debug("Begin: BL_plan_Competitive_Window__Check_Ranges");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_plan_Competitive_Window__Check_Ranges.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_plan_Competitive_Window__Check_Ranges");
				logger.debug("Begin: BL_plan_Competitive_Window_Actual");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_plan_Competitive_Window_Actual.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_plan_Competitive_Window_Actual");
				logger.debug("Begin: BL_Plan_SBR2_Effective_Date_Check");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_SBR2_Effective_Date_Check.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_SBR2_Effective_Date_Check");

			} else {

				logger.debug("Begin: BL_plan_Regional_VP_Adjustment");
				RuleUtility.getInitsData("DT",
						"basiclife//loop4//BL_plan_Regional_VP_Adjustment.xls",
						"", new Object[] { holding, plan });
				logger.debug("End: BL_plan_Regional_VP_Adjustment");
				logger.debug("Begin: BL_Plan_Regional_VP_Adjustment_Ratio");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_Regional_VP_Adjustment_Ratio.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_Regional_VP_Adjustment_Ratio");
				logger.debug("Begin: BL_plan_Regional_VP_Adjustment_For_Composite_Plans");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_plan_Regional_VP_Adjustment_For_Composite_Plans.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_plan_Regional_VP_Adjustment_For_Composite_Plans");
				logger.debug("Begin: Aggregation for plan_Regional_VP_Adjustment_For_Composite_Plans");
				// Aggregation for
				// plan_Regional_VP_Adjustment_For_Composite_Plans
				// (PLAN_REGIONAL_VP_ADJUSTMENT_FOR_COMPOSITE_PLANS) at plan
				// level
				AggregationUtility
						.getHoldingPlanAggregation(
								holding,
								plan,
								PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_FOR_COMPOSITE_PLANS,
								RuleRatingConstants.ADD_OPERATOR);
				logger.debug("End: Aggregation for plan_Regional_VP_Adjustment_For_Composite_Plans");
				logger.debug("Begin: BL_Plan_Final_UW_Adjustment_Ratio");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_Final_UW_Adjustment_Ratio.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_Final_UW_Adjustment_Ratio");
				logger.debug("Begin: BL_Plan_Final_UW_Adjustment_For_Composite_Plans");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_Final_UW_Adjustment_For_Composite_Plans.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_Final_UW_Adjustment_For_Composite_Plans");
				logger.debug("Begin: Aggregation for plan_Final_UW_Adjustment_For_Composite_Plans");

				// Aggregation for plan_Final_UW_Adjustment_For_Composite_Plans
				// (PLAN_FINAL_UW_ADJUSTMENT_FOR_COMPOSITE_PLANS) at plan level
				AggregationUtility
						.getHoldingPlanAggregation(
								holding,
								plan,
								PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_FOR_COMPOSITE_PLANS,
								RuleRatingConstants.ADD_OPERATOR);
				logger.debug("End: Aggregation for plan_Final_UW_Adjustment_For_Composite_Plans");
				logger.debug("Begin: BL_Plan_Comp_Window_Maximum_Allowed_Discount");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_Comp_Window_Maximum_Allowed_Discount.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_Comp_Window_Maximum_Allowed_Discount");
				logger.debug("Begin: BL_Plan_SBR2_Effective_Date_Check");
				RuleUtility
						.getInitsData(
								"DT",
								"basiclife//loop4//BL_Plan_SBR2_Effective_Date_Check.xls",
								"", new Object[] { holding, plan });
				logger.debug("End: BL_Plan_SBR2_Effective_Date_Check");
			}

			logger.debug("Begin: BL_Plan_Field_Adjustment_Ratio");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Field_Adjustment_Ratio.xls", "",
					new Object[] { plan });
			logger.debug("End: BL_Plan_Field_Adjustment_Ratio");
			logger.debug("Begin: BL_Plan_UW_Adjustment_Box_2");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: BL_Plan_UW_Adjustment_Box_2");
			logger.debug("Begin: BL_Plan_UW_Adjustment_Box_r2_Calc_Discount_For_Pilot_Step_1");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Calc_Discount_For_Pilot_Step_1.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_UW_Adjustment_Box_2_Calc_Discount_For_Pilot_Step_1");
			logger.debug("Begin: BL_Plan_UW_Adjustment_Box_2_Calc_Discount_For_Pilot_Step_2");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Calc_Discount_For_Pilot_Step_2.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_UW_Adjustment_Box_2_Calc_Discount_For_Pilot_Step_2");
			logger.debug("Begin: BL_Plan_UW_Adjustment_Box_2_Ratio");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Ratio.xls",
					"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_UW_Adjustment_Box_2_Ratio");
			logger.debug("Begin: BL_Plan_UW_Adjustment_Box_2_Ratio_Sum");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Ratio_Sum.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_UW_Adjustment_Box_2_Ratio_Sum");
			logger.debug("Begin: Aggregation for plan_UW_Adjustment_Box_2_Ratio_Sum");
			// Aggregation for plan_UW_Adjustment_Box_2_Ratio_Sum
			// (PLAN_UW_ADJUSTMENT_BOX_2_RATIO_SUM) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO_SUM,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End: Aggregation for plan_UW_Adjustment_Box_2_Ratio_Sum");
			logger.debug("Begin: BL_Plan_Appeal_Adjustment_Box_Original_Rate");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Appeal_Adjustment_Box_Original_Rate.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Appeal_Adjustment_Box_Original_Rate");
			logger.debug("Begin: BL_Plan_Appeal_Adjustment_Box_Ratio");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Appeal_Adjustment_Box_Ratio.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Appeal_Adjustment_Box_Ratio");
			logger.debug("Begin: BL_Plan_Appeal_Adjustment_Box_Ratio_Sum");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Appeal_Adjustment_Box_Ratio_Sum.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Appeal_Adjustment_Box_Ratio_Sum");
			logger.debug("Begin: BL_Plan_Version_28_UW_Box_Date_Check");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Version_28_UW_Box_Date_Check.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Version_28_UW_Box_Date_Check");
			logger.debug("Begin: BL_Plan_Payable_Rate__Step_1");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Payable_Rate__Step_1.xls", "",
					new Object[] { holding, plan });
			logger.debug("End:BL_Plan_Payable_Rate__Step_1");
			logger.debug("Begin: BL_Plan_Payable_Rate__Step_1_Inverse");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Payable_Rate__Step_1_Inverse.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Payable_Rate__Step_1_Inverse");
			logger.debug("Begin: BL_Plan_Payable_Rate__Step_2");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Payable_Rate__Step_2.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Payable_Rate__Step_2");
			logger.debug("Begin: BL_Plan_Minimum_Premium");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Minimum_Premium.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Minimum_Premium");
			logger.debug("Begin: BL_Plan_Payable_Rate__Step_3");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Payable_Rate__Step_3.xls", "",
					new Object[] { holding, plan });
			logger.debug("End:BL_Plan_Payable_Rate__Step_3 ");
			logger.debug("Begin: BL_plan_Payable_Rate__Step_4");
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_plan_Payable_Rate__Step_4.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: BL_plan_Payable_Rate__Step_4");

			logger.debug("Begin: plan_Payable_Rate_round_Step1,plan_Payable_Rate_round_Step2,plan_Payable_Rate_round_Step3,plan_Payable_Rate_Step_5");

			if (plan.get(PlanConstants.PLAN_PAYABLE_RATE_STEP_4) != null) {

				if (holding.getHoldingMap().get(
						HoldingConstants.PROPOSALCREATIONDATE) != null) {
					String proposalCreationDateString = (String) holding
							.getHoldingMap().get(
									HoldingConstants.PROPOSALCREATIONDATE);
					try {
						if (new SimpleDateFormat("MM/dd/yyyy")
								.parse(proposalCreationDateString)
								.before(new SimpleDateFormat("MM/dd/yyyy")
										.parse(PlanPayableRateroundStep1EndDate))) {
							
							plan.getPlanMap()
							.put(PlanConstants.PLAN_PAYABLE_RATE_ROUND_STEP_1,
									new SBigDecimal(
											RatingFunctions
													.roundNearest(((SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_PAYABLE_RATE_STEP_4)).doubleValue(),3)));
							
							plan.getPlanMap()
									.put(PlanConstants.PLAN_PAYABLE_RATE_STEP_5,
											(SBigDecimal) plan
													.getPlanMap()
													.get(PlanConstants.PLAN_PAYABLE_RATE_ROUND_STEP_1));
						} else {
							if (new SimpleDateFormat("MM/dd/yyyy")
									.parse(proposalCreationDateString)
									.after(new SimpleDateFormat("MM/dd/yyyy")
											.parse(PlanPayableRateroundStep2StartDate))
									&& new SimpleDateFormat("MM/dd/yyyy")
											.parse(proposalCreationDateString)
											.before(new SimpleDateFormat(
													"MM/dd/yyyy")
													.parse(PlanPayableRateroundStep2EndDate))) {
							
								plan.getPlanMap()
								.put(PlanConstants.PLAN_PAYABLE_RATE_ROUND_STEP_2,
										new SBigDecimal(
												RatingFunctions
														.roundNearest(((SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_PAYABLE_RATE_STEP_4)).doubleValue(),2)));
								
								plan.getPlanMap()
										.put(PlanConstants.PLAN_PAYABLE_RATE_STEP_5,
												(SBigDecimal) plan
														.getPlanMap()
														.get(PlanConstants.PLAN_PAYABLE_RATE_ROUND_STEP_2));
							} else {
								if (new SimpleDateFormat("MM/dd/yyyy")
										.parse(proposalCreationDateString)
										.after(new SimpleDateFormat(
												"MM/dd/yyyy")
												.parse(PlanPayableRateroundStep3StartDate))) {				
									
									
									plan.getPlanMap()
									.put(PlanConstants.PLAN_PAYABLE_RATE_ROUND_STEP_3,
											new SBigDecimal(
													RatingFunctions
															.roundNearest(((SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_PAYABLE_RATE_STEP_4)).doubleValue(),3)));
									
									plan.getPlanMap()
											.put(PlanConstants.PLAN_PAYABLE_RATE_STEP_5,
													(SBigDecimal) plan
															.getPlanMap()
															.get(PlanConstants.PLAN_PAYABLE_RATE_ROUND_STEP_3));
								}
							}

						}
					} catch (ParseException e) {

						e.printStackTrace();
					}
					System.out.println("Value of PLAN_PAYABLE_RATE_STEP_5 :"
							+ plan.getPlanMap().get(
									PlanConstants.PLAN_PAYABLE_RATE_STEP_5));
				}

			}

			logger.debug("Begin: plan_Payable_Rate_round_Step1,plan_Payable_Rate_round_Step2,plan_Payable_Rate_round_Step3,plan_Payable_Rate_Step_5");

			logger.debug("Begin: BL_Plan_Annual_Premium_Step_1");
			// plan_Payable_Rate_round_Step1,plan_Payable_Rate_round_Step2,plan_Payable_Rate_round_Step3,plan_Payable_Rate_Step_5
			// pending
			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Annual_Premium_Step_1.xls", "",
					new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Annual_Premium_Step_1");
			logger.debug("Begin: Aggregation for plan_Annual_Premium_Step_1");
			// Aggregation for plan_Annual_Premium_Step_1
			// (PLAN_ANNUAL_PREMIUM_STEP_1) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_ANNUAL_PREMIUM_STEP_1,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End: Aggregation for plan_Annual_Premium_Step_1");
			logger.debug("Begin: BL_Plan_Monthly_Premium_For_RFP_Display_Step_1");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Monthly_Premium_For_RFP_Display_Step_1.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Monthly_Premium_For_RFP_Display_Step_1");
			// verify this step
			logger.debug("Begin: BL_Plan_Competitive_Window_for_Reporting__Step_1");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Competitive_Window_for_Reporting__Step_1.xls",
							"", new Object[] { holding, plan });
			logger.debug("End:BL_Plan_Competitive_Window_for_Reporting__Step_1 ");
			logger.debug("Begin:  Aggregation for plan_Competitive_Window_for_Reporting__Step_1");
			// Aggregation for plan_Competitive_Window_for_Reporting__Step_1
			// (PLAN_COMPETITIVE_WINDOW_FOR_REPORTING_STEP_1) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_COMPETITIVE_WINDOW_FOR_REPORTING_STEP_1,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End:  Aggregation for plan_Competitive_Window_for_Reporting__Step_1");
			logger.debug("Begin: plan_Total_Salary");
			// # plan_Total_Salary :get people_Census_Salary salary from Loop 1
			// and assign it to plan_Total_Salary
			SBigDecimal sumOfPeopleCensusSalary = (SBigDecimal) plan
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PersonConstants.PEOPLE_CENSUS_SALARY);
			if (sumOfPeopleCensusSalary != null) {
				plan.getPlanMap().put(PlanConstants.PLAN_TOTAL_SALARY,
						sumOfPeopleCensusSalary);
			}
			logger.debug("End: plan_Total_Salary");
			logger.debug("Begin: plan_Lowest_Salary_Over_50K");
			// # plan_Lowest_Salary_Over_50K : get min of
			// people_Census_Salary_Over_50K from Plan Loop 1 and assign it to
			// plan_Lowest_Salary_Over_50K
			SBigDecimal peopleCensusSalaryOver50K = (SBigDecimal) plan
					.get(RuleRatingConstants.MIN_OPERATOR
							+ PersonConstants.PEOPLE_CENSUS_SALARY_OVER_50K);
			if (peopleCensusSalaryOver50K != null) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_LOWEST_SALARY_OVER_50K,
						peopleCensusSalaryOver50K);
			}
			// # plan_Average_5_Lowest_Salary : get sum of people census salary
			// from Plan Loop 1, total number of person, calculate average and
			// assign it to plan average lowest salary
			logger.debug("End: plan_Lowest_Salary_Over_50K");
			logger.debug("Begin: PLAN_AVERAGE_5_LOWEST_SALARY");
			SBigDecimal totalNoOfPeople = (SBigDecimal) plan
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PersonConstants.PEOPLE_LIFE_COUNT);
			if (sumOfPeopleCensusSalary != null && totalNoOfPeople != null) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_AVERAGE_5_LOWEST_SALARY,
						sumOfPeopleCensusSalary.divide(totalNoOfPeople));
			}
			logger.debug("End: PLAN_AVERAGE_5_LOWEST_SALARY");
			logger.debug("Begin: plan_Highest_Salary");
			// # plan_Highest_Salary :get min of people census salary from Plan
			// Loop 1 and assign it to plan highest salary
			SBigDecimal minOfPeopleCensusSalary = (SBigDecimal) plan
					.get(RuleRatingConstants.MAX_OPERATOR
							+ PersonConstants.PEOPLE_CENSUS_SALARY);
			if (minOfPeopleCensusSalary != null) {
				plan.getPlanMap().put(PlanConstants.PLAN_HIGHEST_SALARY,
						minOfPeopleCensusSalary);
			}
			logger.debug("End: plan_Highest_Salary");
			logger.debug("Begin: BL_Plan_Total_Manual_Premium_for_Postcalc_Step_1");

			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Total_Manual_Premium_for_Postcalc_Step_1.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Total_Manual_Premium_for_Postcalc_Step_1");
			logger.debug("Begin: plan_Total_Lives__Composite_Yes");
			// # plan_Total_Lives__Composite_Yes : get sum of people_Count_Life
			// from Plan Loop 1 and assign it to plan_Total_Lives__Composite_Yes

			if (totalNoOfPeople != null) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_TOTAL_LIVES__COMPOSITE_YES,
						totalNoOfPeople);
			}
			logger.debug("End: plan_Total_Lives__Composite_Yes");
			logger.debug("Begin: Aggregation for plan_Total_Lives__Composite_Yes");
			// Aggregation for plan_Total_Lives__Composite_Yes
			// (PLAN_TOTAL_LIVES__COMPOSITE_YES) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_TOTAL_LIVES__COMPOSITE_YES,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End: Aggregation for plan_Total_Lives__Composite_Yes");
			logger.debug("Begin: plan_Total_Covered_Volume__Composite_Yes");
			// # plan_Total_Covered_Volume__Composite_Yes : get sum of
			// people_Covered_Volume from Plan Loop 1 and assign it to
			// plan_Total_Covered_Volume__Composite_Yes
			SBigDecimal sumOfPeopleCoveredVolume = (SBigDecimal) plan
					.get(RuleRatingConstants.ADD_OPERATOR_KEY
							+ PersonConstants.PEOPLE_COVERED_VOLUME);
			if (sumOfPeopleCoveredVolume != null) {
				plan.getPlanMap().put(
						PlanConstants.PLAN_TOTAL_COVERED_VOLUME__COMPOSITE_YES,
						sumOfPeopleCoveredVolume);
			}
			logger.debug("End: plan_Total_Covered_Volume__Composite_Yes");
			logger.debug("Begin:  Aggregation for plan_Total_Covered_Volume__Composite_Yes");
			// Aggregation for plan_Total_Covered_Volume__Composite_Yes
			// (PLAN_TOTAL_COVERED_VOLUME__COMPOSITE_YES) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_TOTAL_COVERED_VOLUME__COMPOSITE_YES,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End:  Aggregation for plan_Total_Covered_Volume__Composite_Yes");
			logger.debug("Begin: BL_Plan_EstimatedVolume_Composite_Yes");

			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_EstimatedVolume_Composite_Yes.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_EstimatedVolume_Composite_Yes");
			logger.debug("Begin: Aggregation for plan_EstimatedVolume_Composite_Yes");
			// Aggregation for plan_EstimatedVolume_Composite_Yes
			// (PLAN_ESTIMATEDVOLUME_COMPOSITE_YES) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_ESTIMATEDVOLUME_COMPOSITE_YES,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End: Aggregation for plan_EstimatedVolume_Composite_Yes");
			logger.debug("Begin: Aggregation for plan_Annual_Premium__Composite_Yes");
			// plan_Annual_Premium__Composite_Yes verify

			// Aggregation for plan_Annual_Premium__Composite_Yes
			// (PLAN_ANNUAL_PREMIUM_COMPOSITE_YES) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_ANNUAL_PREMIUM_COMPOSITE_YES,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End: Aggregation for plan_Annual_Premium__Composite_Yes");
			logger.debug("Begin: BL_Plan_Blended_Area_Factor_Step_1");
			// plan_Monthly_Premium__Composite_Only pending

			RuleUtility.getInitsData("DT",
					"basiclife//loop4//BL_Plan_Blended_Area_Factor_Step_1.xls",
					"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Blended_Area_Factor_Step_1");
			logger.debug("Begin: Aggregation for plan_Annual_Premium__Composite_Yes");
			// Aggregation for plan_Annual_Premium__Composite_Yes
			// (PLAN_ANNUAL_PREMIUM_COMPOSITE_YES) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_ANNUAL_PREMIUM_COMPOSITE_YES,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End: Aggregation for plan_Annual_Premium__Composite_Yes");
			logger.debug("Begin: BL_Plan_Blended_Rate_Guarantee_Factor_Step_1");
			RuleUtility
					.getInitsData(
							"DT",
							"basiclife//loop4//BL_Plan_Blended_Rate_Guarantee_Factor_Step_1.xls",
							"", new Object[] { holding, plan });
			logger.debug("End: BL_Plan_Blended_Rate_Guarantee_Factor_Step_1");
			logger.debug("Begin: Aggregation for plan_Blended_Rate_Guarantee_Factor_Step_1");
			// Aggregation for plan_Blended_Rate_Guarantee_Factor_Step_1
			// (PLAN_BLENDED_RATE_GUARANTEE_FACTOR_STEP_1) at plan level
			AggregationUtility.getHoldingPlanAggregation(holding, plan,
					PlanConstants.PLAN_BLENDED_RATE_GUARANTEE_FACTOR_STEP_1,
					RuleRatingConstants.ADD_OPERATOR);
			logger.debug("End: Aggregation for plan_Blended_Rate_Guarantee_Factor_Step_1");

			// SparcRatingUtil.showMap(((Plan)(holding.getListOfPlans().get(holding.getCount()))).getPlanMap());
			/*
			 * SparcRatingUtil.showMap(plan.getStatusAggregationMap());
			 * SparcRatingUtil.showMap(plan.getGenderAggregationMap());
			 * SparcRatingUtil.showMap(plan.getAgeBracketAggregationMap());
			 * SparcRatingUtil.showMap(plan.getAgeAggregationMap());
			 * SparcRatingUtil
			 * .showMap(plan.getStatus_gender_ageB_age_AggregationMap());
			 */
			System.out.print("End: Plan Loop" + (i + 1));
			logger.debug("Plan object Before calculation Start for loop"
					+ (i + 1));
			SparcRatingUtil.showMap(plan.getPlanMap());
			logger.debug("Plan object Before calculation End for loop"
					+ (i + 1));

		}

		// Plan Loop should close here
		// Keep below block of code out of plan loop
		logger.debug("Begin: holding_Regional_VP_Adjustment_Ratio_Sum");
		// TODO: Added Aggregation for
		// plan_Regional_VP_Adjustment_For_Composite_Plans in Loop 4. Comment:
		// Added, Output verification pending
		// # holding_Regional_VP_Adjustment_Ratio_Sum: get the sum of
		// plan_Regional_VP_Adjustment_For_Composite_Plans from Plan Loop4 and
		// assign it to holding_Regional_VP_Adjustment_Ratio_Sum
		SBigDecimal sumOfPlanRegionalVPAdjustmentForCompositePlans = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_FOR_COMPOSITE_PLANS);
		if (sumOfPlanRegionalVPAdjustmentForCompositePlans != null) {
			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_REGIONAL_VP_ADJUSTMENT_RATIO_SUM,
					sumOfPlanRegionalVPAdjustmentForCompositePlans);
		}
		logger.debug("End: holding_Regional_VP_Adjustment_Ratio_Sum");
		logger.debug("Begin: holding_UW_Adjustment_Box_2_Ratio_Sum");
		// TODO: Add Aggregation for plan_UW_Adjustment_Box_2_Ratio_Sum in Loop
		// 4.Comment: Added, Verify output.
		// # holding_UW_Adjustment_Box_2_Ratio_Sum : get the sum of
		// plan_UW_Adjustment_Box_2_Ratio_Sum from Plan Loop 4 and assign it to
		// holding_UW_Adjustment_Box_2_Ratio_Sum
		SBigDecimal sumOfPlanUWAdjustmentBox2RatioSum = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO_SUM);
		if (sumOfPlanUWAdjustmentBox2RatioSum != null) {
			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_UW_ADJUSTMENT_BOX_2_RATIO_SUM,
					sumOfPlanUWAdjustmentBox2RatioSum);
		}
		logger.debug("End: holding_UW_Adjustment_Box_2_Ratio_Sum");
		logger.debug("Begin: holding_Final_UW_Adjustment_Ratio_Sum");
		// TODO: Add Aggregation for
		// plan_Final_UW_Adjustment_For_Composite_Plans in Loop 4.Comment:
		// Added, Output verification pending
		// # holding_Final_UW_Adjustment_Ratio_Sum : get the sum of
		// plan_Final_UW_Adjustment_For_Composite_Plans from Plan Loop 4 and
		// assign it to holding_Final_UW_Adjustment_Ratio_Sum

		SBigDecimal sumOfplanFinalUWAdjustmentForCompositePlans = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_FOR_COMPOSITE_PLANS);
		if (sumOfplanFinalUWAdjustmentForCompositePlans != null) {
			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_FINAL_UW_ADJUSTMENT_RATIO_SUM,
					sumOfplanFinalUWAdjustmentForCompositePlans);
		}
		logger.debug("End: holding_Final_UW_Adjustment_Ratio_Sum");
		logger.debug("Begin: holding_Total_Annual_Premium");
		// TODO: Add Aggregation for plan_Annual_Premium_Step_1 in Loop 4
		// .Comment: Added, Output verification pending
		// # holding_Total_Annual_Premium : get the sum of
		// plan_Annual_Premium_Step_1 from Plan Loop 4 and assign it to
		// holding_Total_Annual_Premium

		SBigDecimal sumOfplanAnnualPremiumStep1 = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_ANNUAL_PREMIUM_STEP_1);
		if (sumOfplanAnnualPremiumStep1 != null) {
			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_TOTAL_ANNUAL_PREMIUM,
					sumOfplanAnnualPremiumStep1);
		}
		logger.debug("End: holding_Total_Annual_Premium");
		logger.debug("Begin: holding_Non_Pooled_Manual_Rate_Step_2");
		// # holding_Non_Pooled_Manual_Rate_Step_2 : get the sum of
		// status_Non_Pooled_Manual_Rate_Step_1 from Plan Loop 3 and assign it
		// to holding_Non_Pooled_Manual_Rate_Step_2
		SBigDecimal sumOfstatusNonPooledManualRateStep1 = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ StatusConstants.STATUS_NON_POOLED_MANUAL_RATE_STEP_1);
		if (sumOfstatusNonPooledManualRateStep1 != null) {
			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_NON_POOLED_MANUAL_RATE_STEP_2,
					sumOfstatusNonPooledManualRateStep1);
		}
		logger.debug("End: holding_Non_Pooled_Manual_Rate_Step_2");
		logger.debug("Begin: holding_Competitive_Window_for_Reporting__Step_2");
		// TODO: Add Aggregation for
		// plan_Competitive_Window_for_Reporting__Step_1 in Loop 4. Comment:
		// Added, Output verification pending
		// # holding_Competitive_Window_for_Reporting__Step_2 : get the sum of
		// plan_Competitive_Window_for_Reporting__Step_1 from Plan Loop 4 and
		// assign it to holding_Competitive_Window_for_Reporting__Step_2
		SBigDecimal sumOfplanCompetitiveWindowforReportingStep1 = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_COMPETITIVE_WINDOW_FOR_REPORTING_STEP_1);
		if (sumOfplanCompetitiveWindowforReportingStep1 != null) {
			holding.getHoldingMap()
					.put(HoldingConstants.HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING__STEP_2,
							sumOfplanCompetitiveWindowforReportingStep1);
		}
		logger.debug("End: holding_Competitive_Window_for_Reporting__Step_2");
		logger.debug("Begin: holding_Competitive_Window_for_Reporting");
		// # holding_Competitive_Window_for_Reporting : assign sum of
		// plan_Annual_Premium_Step_1 to
		// holding_Competitive_Window_for_Reporting
		if (sumOfplanAnnualPremiumStep1 != null) {
			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_COMPETITIVE_WINDOW_FOR_REPORTING,
					sumOfplanAnnualPremiumStep1);
		}
		logger.debug("End: holding_Competitive_Window_for_Reporting");
		logger.debug("Begin: holding_Total_Lives_For_All_Plans__Composite_Only");

		// TODO: Add Aggregation for plan_Total_Lives__Composite_Yes in Loop 4.
		// Comment: Added, Output verification pending
		// # holding_Total_Lives_For_All_Plans__Composite_Only : get the sum of
		// plan_Total_Lives__Composite_Yes from Plan Loop 4 and assign it to
		// holding_Total_Lives_For_All_Plans__Composite_Only
		SBigDecimal sumOfplanTotalLivesCompositeYes = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_TOTAL_LIVES__COMPOSITE_YES);
		if (sumOfplanTotalLivesCompositeYes != null) {
			holding.getHoldingMap()
					.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,
							sumOfplanTotalLivesCompositeYes);
		}
		logger.debug("End:holding_Total_Lives_For_All_Plans__Composite_Only ");
		logger.debug("Begin: holding_Total_Covered_Volume_For_All_Plans__Composite_Only");
		// TODO: Add Aggregation for plan_Total_Covered_Volume__Composite_Yes in
		// Loop 4. Comment: Added, Output verification pending
		// # holding_Total_Covered_Volume_For_All_Plans__Composite_Only : get
		// the sum of plan_Total_Covered_Volume__Composite_Yes from Plan Loop 4
		// and assign it to
		// holding_Total_Covered_Volume_For_All_Plans__Composite_Only
		SBigDecimal sumOfplanTotalCoveredVolumeCompositeYes = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_TOTAL_COVERED_VOLUME__COMPOSITE_YES);
		if (sumOfplanTotalCoveredVolumeCompositeYes != null) {
			holding.getHoldingMap()
					.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMPOSITE_ONLY,
							sumOfplanTotalCoveredVolumeCompositeYes);
		}
		logger.debug("End:holding_Total_Covered_Volume_For_All_Plans__Composite_Only ");
		logger.debug("Begin: BL_GetCoveredVolumeForAllCompOnlyPlans_Zero");
		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_GetCoveredVolumeForAllCompOnlyPlans_Zero.xls",
						"", new Object[] { holding });
		logger.debug("End: BL_GetCoveredVolumeForAllCompOnlyPlans_Zero");
		logger.debug("Begin: holding_Total_Estimated_Volume_Composite_Only");
		// TODO: Add Aggregation for plan_EstimatedVolume_Composite_Yes in Loop
		// 4. Comment: Added, Output verification pending
		// # holding_Total_Estimated_Volume_Composite_Only : get the sum of
		// plan_EstimatedVolume_Composite_Yes from Plan Loop 4 and assign it to
		// holding_Total_Estimated_Volume_Composite_Only
		SBigDecimal sumOfplanEstimatedVolumeCompositeYes = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_ESTIMATEDVOLUME_COMPOSITE_YES);
		if (sumOfplanEstimatedVolumeCompositeYes != null) {
			holding.getHoldingMap()
					.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,
							sumOfplanEstimatedVolumeCompositeYes);
		}
		logger.debug("End: holding_Total_Estimated_Volume_Composite_Only");
		logger.debug("Begin: holding_Annual_Premium_For_All_Plans__Composite_Only");

		// TODO: Add Aggregation for plan_Annual_Premium__Composite_Yes in Loop
		// 4. Comment: Added, Output verification pending
		// # holding_Annual_Premium_For_All_Plans__Composite_Only : get the sum
		// of plan_Annual_Premium__Composite_Yes from Plan Loop 4 and assign it
		// to holding_Annual_Premium_For_All_Plans__Composite_Only
		SBigDecimal sumOfplanAnnualPremiumCompositeYes = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_ANNUAL_PREMIUM_COMPOSITE_YES);
		if (sumOfplanAnnualPremiumCompositeYes != null) {
			holding.getHoldingMap()
					.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
							sumOfplanAnnualPremiumCompositeYes);
		}
		logger.debug("End: holding_Annual_Premium_For_All_Plans__Composite_Only");
		logger.debug("Begin: BL_Holding_Monthly_Premium_For_All_Plans__Composite_Only");

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Holding_Monthly_Premium_For_All_Plans__Composite_Only.xls",
						"", new Object[] { holding });
		logger.debug("End: BL_Holding_Monthly_Premium_For_All_Plans__Composite_Only");
		logger.debug("Begin: BL_Holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse");
		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse.xls",
						"", new Object[] { holding });
		logger.debug("End: BL_Holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse");
		logger.debug("Begin: holding_Blended_Area_Factor_Step_2");

		// TODO: Add Aggregation for plan_Blended_Area_Factor_Step_1 in Loop 4.
		// Comment: Added, Output verification pending
		// # holding_Blended_Area_Factor_Step_2 : get the sum of
		// plan_Blended_Area_Factor_Step_1 from Plan Loop 4 and assign it to
		// holding_Blended_Area_Factor_Step_2
		SBigDecimal sumOfplanBlendedAreaFactorStep1 = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_ANNUAL_PREMIUM_COMPOSITE_YES);
		if (sumOfplanBlendedAreaFactorStep1 != null) {
			holding.getHoldingMap().put(
					HoldingConstants.HOLDING_BLENDED_AREA_FACTOR_STEP_2,
					sumOfplanBlendedAreaFactorStep1);
		}
		logger.debug("End: holding_Blended_Area_Factor_Step_2");
		logger.debug("Begin: BL_Holding_Blended_Area_Factor_Step_3");
		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Holding_Blended_Area_Factor_Step_3.xls",
				"", new Object[] { holding });
		logger.debug("End: BL_Holding_Blended_Area_Factor_Step_3");
		logger.debug("Begin: holding_Blended_Rate_Guarantee_Factor_Step_2");
		// TODO: Add Aggregation for plan_Blended_Rate_Guarantee_Factor_Step_1
		// in Loop 4. Comment: Added, Output verification pending
		// # holding_Blended_Rate_Guarantee_Factor_Step_2 : get the sum of
		// plan_Blended_Rate_Guarantee_Factor_Step_1 from Plan Loop 4 and assign
		// it to holding_Blended_Rate_Guarantee_Factor_Step_2
		SBigDecimal sumOfplanBlendedRateGuaranteeFactorStep1 = (SBigDecimal) holding
				.get(RuleRatingConstants.ADD_OPERATOR_KEY
						+ PlanConstants.PLAN_BLENDED_RATE_GUARANTEE_FACTOR_STEP_1);
		if (sumOfplanBlendedRateGuaranteeFactorStep1 != null) {
			holding.getHoldingMap()
					.put(HoldingConstants.HOLDING_BLENDED_RATE_GUARANTEE_FACTOR_STEP_2,
							sumOfplanBlendedRateGuaranteeFactorStep1);
		}
		logger.debug("End: holding_Blended_Rate_Guarantee_Factor_Step_2");
		logger.debug("Begin: BL_Holding_Blended_Rate_Guarantee_Factor_Step_3");
		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Holding_Blended_Rate_Guarantee_Factor_Step_3.xls",
						"", new Object[] { holding });
		logger.debug("End: BL_Holding_Blended_Rate_Guarantee_Factor_Step_3");
		logger.debug("Begin: BL_Holding_Total_Monthly_Premium");
		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Holding_Total_Monthly_Premium.xls", "",
				new Object[] { holding });
		logger.debug("End: BL_Holding_Total_Monthly_Premium");
		logger.debug("Plan Loop 4 Holding Keys Start");
		SparcRatingUtil.showMap(holding.getHoldingMap());
		logger.debug("Plan Loop 4 Holding Keys End");
		long endTime = System.nanoTime();
		logger.debug("Plan Loop 4 Completed at : " + endTime);
		logger.debug("Total time for Loop 4 execution (ms):"
				+ (endTime - start) / 1000000);

	}

}
