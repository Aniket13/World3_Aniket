package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;


public class BL_holding_Monthly_Premium_For_All_Plans__Composite_Only_Test {

	@Test
	public void test_holding_Blended_Rate_Guarantee_Factor_Step_3()
			throws Exception {
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Holding_Monthly_Premium_For_All_Plans__Composite_Only.xls", "",
				new Object[] { holding, plan });

		SparcRatingUtil.showMap(holding.getHoldingMap());
	}
}
