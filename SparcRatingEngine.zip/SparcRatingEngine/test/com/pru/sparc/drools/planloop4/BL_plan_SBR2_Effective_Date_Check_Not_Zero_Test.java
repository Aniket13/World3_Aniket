package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_plan_SBR2_Effective_Date_Check_Not_Zero_Test {

	@Test
	public void test_plan_SBR2_Effective_Date_Check_Not_Zero() {

		SBigDecimal PLAN_FIELD_ADJUSTMENT_OVERRIDE = new SBigDecimal("0.1");
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_FIELD_ADJUSTMENT_OVERRIDE,
				PLAN_FIELD_ADJUSTMENT_OVERRIDE);

		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_SBR2_Effective_Date_Check_Not_Zero.xls",
						"", new Object[] { holding,plan1 });

		SparcRatingUtil.showMap(planMap1);

	}

}
