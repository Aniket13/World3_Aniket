package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_UW_Adjustment_Box_2_Ratio {

	@Test
	public void test_plan_UW_Adjustment_Box_2_Ratio_Rule1() {

		SBigDecimal HOLDING_100_PILOT_CASE_INDICATOR = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE = new SBigDecimal("10");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE = new SBigDecimal("15");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1 = new SBigDecimal("0.01");
		

		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_100_PILOT_CASE_INDICATOR,
				HOLDING_100_PILOT_CASE_INDICATOR);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Ratio.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}	
	
	@Test
	public void test_plan_UW_Adjustment_Box_2_Ratio_Rule2() {

		SBigDecimal HOLDING_100_PILOT_CASE_INDICATOR = new SBigDecimal("10");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE = new SBigDecimal("10");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE = new SBigDecimal("15");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1 = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2 = new SBigDecimal("100");
		

		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_100_PILOT_CASE_INDICATOR,
				HOLDING_100_PILOT_CASE_INDICATOR);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Ratio.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}	
	
	
	@Test
	public void test_plan_UW_Adjustment_Box_2_Ratio_Rule3() {

		SBigDecimal HOLDING_100_PILOT_CASE_INDICATOR = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE = new SBigDecimal("0");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE = new SBigDecimal("0");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1 = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2 = new SBigDecimal("100");
		

		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_100_PILOT_CASE_INDICATOR,
				HOLDING_100_PILOT_CASE_INDICATOR);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Ratio.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}	
	

	@Test
	public void test_plan_UW_Adjustment_Box_2_Ratio_Rule4() {

		SBigDecimal HOLDING_100_PILOT_CASE_INDICATOR = new SBigDecimal("0");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1 = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2 = new SBigDecimal("100");
		

		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_100_PILOT_CASE_INDICATOR,
				HOLDING_100_PILOT_CASE_INDICATOR);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Ratio.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}
	

	@Test
	public void test_plan_UW_Adjustment_Box_2_Ratio_Rule5() {

		SBigDecimal HOLDING_100_PILOT_CASE_INDICATOR = new SBigDecimal("0");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE = new SBigDecimal("10");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1 = new SBigDecimal("1");
		SBigDecimal PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2 = new SBigDecimal("100");
		

		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_DESIRED_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE,
				PLAN_UW_ADJUSTMENT_BOX_2_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_1);
		planMap1.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2,
				PLAN_UW_ADJUSTMENT_BOX_2_CALC_DISCOUNT_FOR_PILOT_STEP_2);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_100_PILOT_CASE_INDICATOR,
				HOLDING_100_PILOT_CASE_INDICATOR);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4//BL_Plan_UW_Adjustment_Box_2_Ratio.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}	
	
	
	
	
}
