package com.pru.sparc.drools.planloop4;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;


public class BL_holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse_Test {

	@Test
	public void test_holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse() throws Exception {
		SBigDecimal holding_Annual_Premium_For_All_Plans__Composite_Only = new SBigDecimal(
				10);

		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);

		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap()
				.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
						holding_Annual_Premium_For_All_Plans__Composite_Only);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse.xls", "",
				new Object[] { holding });

		SparcRatingUtil.showMap(holding.getHoldingMap());


	}

	@Test
	public void test_holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse_Rule2() throws Exception {
		SBigDecimal holding_Annual_Premium_For_All_Plans__Composite_Only = new SBigDecimal(
				0);

		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);

		holding.setListOfPlans(listOfPlans);
		holding.getHoldingMap()
				.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
						holding_Annual_Premium_For_All_Plans__Composite_Only);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Holding_Annual_Premium_For_All_Plans__Composite_Only_Inverse.xls", "",
				new Object[] { holding});

		SparcRatingUtil.showMap(holding.getHoldingMap());


	}

}
