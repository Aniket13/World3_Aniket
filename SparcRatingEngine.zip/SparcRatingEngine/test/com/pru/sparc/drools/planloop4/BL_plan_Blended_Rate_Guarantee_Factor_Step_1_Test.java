package com.pru.sparc.drools.planloop4;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;



public class BL_plan_Blended_Rate_Guarantee_Factor_Step_1_Test {
	
	@Test
	public void test_plan_Blended_Rate_Guarantee_Factor_Step_1()
			throws Exception {
		SBigDecimal plan_Guarantee_Issue = new SBigDecimal(0.5);
		SBigDecimal plan_Annual_Premium_Step_1 = new SBigDecimal(0.5);
		
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		planMap.put(PlanConstants.PLAN_GUARANTEE_ISSUE, plan_Guarantee_Issue);
		planMap.put(PlanConstants.PLAN_ANNUAL_PREMIUM_STEP_1, plan_Annual_Premium_Step_1);
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);


		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Blended_Rate_Guarantee_Factor_Step_1.xls","",
				new Object[] { holding, plan });
		SparcRatingUtil.showMap(planMap);

	}
	
	@Test
	public void test_plan_Blended_Rate_Guarantee_Factor_Step_1_rule2()
			throws Exception {
		SBigDecimal plan_Guarantee_Issue = new SBigDecimal(10);
		SBigDecimal plan_Annual_Premium_Step_1 = new SBigDecimal(10);
		
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeN");
		planMap.put(PlanConstants.PLAN_GUARANTEE_ISSUE, plan_Guarantee_Issue);
		planMap.put(PlanConstants.PLAN_ANNUAL_PREMIUM_STEP_1, plan_Annual_Premium_Step_1);
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Blended_Rate_Guarantee_Factor_Step_1.xls","",
				new Object[] { holding, plan });
		SparcRatingUtil.showMap(planMap);

	}
	
	@Test
	public void test_plan_Blended_Rate_Guarantee_Factor_Step_1_rule3()
			throws Exception {
		SBigDecimal plan_Guarantee_Issue = new SBigDecimal(10);
		SBigDecimal plan_Annual_Premium_Step_1 = new SBigDecimal(10);
		
		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "Composite");
		planMap.put(PlanConstants.PLAN_GUARANTEE_ISSUE, plan_Guarantee_Issue);
		planMap.put(PlanConstants.PLAN_ANNUAL_PREMIUM_STEP_1, plan_Annual_Premium_Step_1);
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Blended_Rate_Guarantee_Factor_Step_1.xls","",
				new Object[] { holding, plan });
		SparcRatingUtil.showMap(planMap);

	}
}
