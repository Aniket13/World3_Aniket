package com.pru.sparc.drools.planloop4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_Appeal_Adjustment_Box_Ratio_Test {

	@Test
	public void test_Plan_Appeal_Adjustment_Box_Ratio() {

		SBigDecimal PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE = new SBigDecimal(0);
		SBigDecimal PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE= new SBigDecimal(10);
		
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE,PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE,PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		
		holding.getHoldingMap().put(HoldingConstants.RENEWAL, "RenewalYes");

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Appeal_Adjustment_Box_Ratio.xls", "",
				new Object[] { holding,plan1});

		SparcRatingUtil.showMap(planMap1);

	}
	
	@Test
	public void test_Plan_Appeal_Adjustment_Box_Ratio_Rule_2() {

		SBigDecimal PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE = new SBigDecimal(10);
		SBigDecimal PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE= new SBigDecimal(10);
		
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE,PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE,PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		
		holding.getHoldingMap().put(HoldingConstants.RENEWAL, "RenewalYes");

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Appeal_Adjustment_Box_Ratio.xls", "",
				new Object[] { holding,plan1});

		SparcRatingUtil.showMap(planMap1);

	}
	@Test
	public void test_Plan_Appeal_Adjustment_Box_Ratio_Rule_3() {

		SBigDecimal PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE = new SBigDecimal(101);
		SBigDecimal PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE= new SBigDecimal(10);
		
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE,PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE,PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		
		holding.getHoldingMap().put(HoldingConstants.RENEWAL, "RenewalYes");

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Appeal_Adjustment_Box_Ratio.xls", "",
				new Object[] { holding,plan1});

		SparcRatingUtil.showMap(planMap1);

	}
	
	@Test
	public void test_Plan_Appeal_Adjustment_Box_Ratio_Rule_4() {

		SBigDecimal PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE = new SBigDecimal(101);
		SBigDecimal PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE= new SBigDecimal(10);
		
		Holding holding = new Holding();

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE,PLAN_APPEAL_ADJUSTMENT_BOX_ORIGINAL_RATE);
		planMap1.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE,PLAN_APPEAL_ADJUSTMENT_BOX_DESIRED_RATE);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		
		holding.getHoldingMap().put(HoldingConstants.RENEWAL, "RenewalNo");

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_Appeal_Adjustment_Box_Ratio.xls", "",
				new Object[] { holding,plan1});

		SparcRatingUtil.showMap(planMap1);

	}

}
