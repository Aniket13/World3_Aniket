package com.pru.sparc.drools.planloop4;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_Plan_EstimatedVolume_Composite_Yes_Test {

	@Test
	public void test_Plan_EstimatedVolume_Composite_Yes()
			throws Exception {
		SBigDecimal plan_Estimated_Volume = new SBigDecimal(10);
		SBigDecimal plan_Annual_Premium_Step_1 = new SBigDecimal(10);

		Holding holding = new Holding();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		planMap.put(PlanConstants.PLAN_ESTIMATED_VOLUME, plan_Estimated_Volume);
		planMap.put(PlanConstants.PLAN_ANNUAL_PREMIUM_STEP_1,
				plan_Annual_Premium_Step_1);
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4//BL_Plan_EstimatedVolume_Composite_Yes.xls", "",
				new Object[] { holding, plan });

		SparcRatingUtil.showMap(planMap);

	}
}
