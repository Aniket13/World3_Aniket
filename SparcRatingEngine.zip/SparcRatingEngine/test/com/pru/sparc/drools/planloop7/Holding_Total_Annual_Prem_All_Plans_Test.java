package com.pru.sparc.drools.planloop7;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.basiclife.Loop7;
import com.pru.sparc.drools.common.util.RuleRatingConstants;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.AgeBracketConstants;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Holding_Total_Annual_Prem_All_Plans_Test {
	Loop7 loop7 = new Loop7();

	@Test
	public void test_HoldingPlanAggregationUtilityTest() {
		Holding holding = setupData();
		for (int i = 0; i < holding.getListOfPlans().size(); i++) {
			holding.setCount(i);
			Plan plan = (Plan) holding.getListOfPlans().get(i);
			loop7.setPlan_Loop_7(plan, holding);
			loop7.setHolding_Total_Annual_Prem_All_Plans(plan, holding);
			loop7.setHolding_Total_Monthly_Prem_All_Plans(plan, holding);
			loop7.setPlan_Loop_Rate_Disk_Total(plan, holding);
			loop7.setHolding_Sum_Inforce_Prem_NonAgeBanded_All_Plans(plan,
					holding);
			loop7.setHolding_Sum_Manual_Prem_NonAgeBanded_All_Plans(plan,
					holding);
			loop7.setHolding_Sum_Inforce_Prem_AgeBanded_All_Plans(plan, holding);
			loop7.setHolding_Sum_Manual_Prem_AgeBanded_All_Plans(plan, holding);
			loop7.setHolding_Initial_Inforce_Premium(holding, plan);
			loop7.setHolding_Initial_Manual_Premium(holding, plan);
			loop7.setHolding_Inforce_to_Manual_Prem_Ratio(holding, plan);
			loop7.setHolding_Rate_Action_RAT(holding, plan);
			loop7.setHolding_Rate_Action_Max_Step_1(holding, plan);
			loop7.setHolding_Rate_Action_Max_Step_2(holding, plan);
			loop7.setHolding_Rate_Action_Max(holding, plan);

		}
		SparcRatingUtil.showMap(holding.getHoldingMap());
		assertEquals(
				"Check: HOLDING_TOTAL_ANNUAL_PREM_ALL_PLANS",
				new SBigDecimal("42.8"),
				holding.getHoldingMap().get(
						HoldingConstants.HOLDING_TOTAL_ANNUAL_PREM_ALL_PLANS));

	}

	private static Holding setupData() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal(0));
		holdingMap.put(HoldingConstants.RENEWAL, "RenewalYes");
		List<Plan> listOfPlans = new ArrayList<Plan>();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_ANNUAL_PREMIUM, new SBigDecimal("21.4"));
		planMap.put(PlanConstants.PLAN_EFFECTIVEDATE, "05/02/2016");
		planMap.put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY,
				new SBigDecimal("211.4"));
		planMap.put(
				PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
				new SBigDecimal("211.4"));
		planMap.put(PlanConstants.PLAN_RATE_DISK_TOTAL_MONTHLY_PREM,
				new SBigDecimal("200.4"));
		planMap.put(
				PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED,
				new SBigDecimal("100"));
		planMap.put(PlanConstants.PLAN_INITIAL_MANUAL_PREMIUM_NONAGEBANDED,
				new SBigDecimal("50"));
		planMap.put(
				RuleRatingConstants.ADD_OPERATOR_KEY
						+ AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED,
				new SBigDecimal("510"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);

		listOfPlans.add(plan);

		// Adding one more plan for testing
	planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_ANNUAL_PREMIUM, new SBigDecimal("21.4"));
		planMap.put(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_RFP_DISPLAY,
				new SBigDecimal("221.1"));
		planMap.put(
				PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,
				new SBigDecimal("200"));
		planMap.put(PlanConstants.PLAN_RATE_DISK_TOTAL_MONTHLY_PREM,
				new SBigDecimal("200.4"));
		planMap.put(
				PlanConstants.PLAN_INITIAL_INFORCE_RENEWAL_PREMIUM_NONAGEBANDED,
				new SBigDecimal("100"));
		planMap.put(
				RuleRatingConstants.ADD_OPERATOR_KEY
						+ AgeBracketConstants.AGEBRACKET_INITIAL_INFORCE_PREMIUM_AGEBANDED,
				new SBigDecimal("510"));
		planMap.put(
				RuleRatingConstants.ADD_OPERATOR_KEY
						+ AgeBracketConstants.AGEBRACKET_INITIAL_MANUAL_PREMIUM_AGEBANDED,
				new SBigDecimal("1510"));
		planMap.put(PlanConstants.PLAN_EFFECTIVEDATE, "01/01/2006");
		plan = new Plan();
		plan.setPlanMap(planMap);
		listOfPlans.add(plan);

		holding.setListOfPlans(listOfPlans);
		holding.setHoldingMap(holdingMap);

		return holding;
	}
}
