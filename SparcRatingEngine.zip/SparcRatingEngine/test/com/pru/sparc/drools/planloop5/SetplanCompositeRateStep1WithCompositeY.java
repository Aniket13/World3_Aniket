package com.pru.sparc.drools.planloop5;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.pru.sparc.drools.basiclife.Loop5;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class SetplanCompositeRateStep1WithCompositeY {
	private Loop5 loop5 = null;
	private Holding holding = null;
	private Plan plan = null;
	 @Before
	public void setUp() {
		 holding = new Holding();
		 loop5= new Loop5();
		 HashMap<String,Object> holdingMap = new HashMap<String,Object>();
			
			holdingMap.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS, new SBigDecimal("5444.00"));
			holdingMap.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM, new SBigDecimal("54.00"));
			
			
			HashMap<String, Object> planMap = new HashMap<String, Object>();
			planMap.put("EffectiveDate", "1/1/2013");
			planMap.put("Quoted", "QuotedY");
			plan = new Plan();
			plan.setPlanMap(planMap);
			List<Plan> listOfPlans = new ArrayList<Plan>();
			listOfPlans.add(plan);
			holding.setListOfPlans(listOfPlans);
			holding.setHoldingMap(holdingMap);
	 }
	
	
	 
		@Test
		public void setplanCompositeRateStep1WithCompositeYPositiveTest(){
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM ,
					new SBigDecimal(100));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS ,
					new SBigDecimal(101));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(102));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE,"CompositeN");
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,new SBigDecimal(103));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMP_ONLY__INVERSE,new SBigDecimal(104));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(105));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(106));
			loop5.setplanCompositeRateStep1WithCompositeY(holding,plan);
			System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1));
			assertEquals("Check: setplanCompositeRateStep1WithCompositeYPositiveTest", new SBigDecimal(106),
					plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1));
			System.out.println((SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP1));
			assertEquals("Check: setplanCompositeRateStep1WithCompositeYPositiveTest", new SBigDecimal("909999.999999999999"),
					(SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP1));
		}
		@Test
		public void setplanCompositeRateStep1WithCompositeYZeroTest(){
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM ,
					new SBigDecimal(0));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS ,
					new SBigDecimal(0));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(0));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE,"CompositeN");
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,new SBigDecimal(0));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMP_ONLY__INVERSE,new SBigDecimal(0));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(0));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(0));
			loop5.setplanCompositeRateStep1WithCompositeY(holding,plan);
			System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1));
			assertEquals("Check: setplanCompositeRateStep1WithCompositeYZeroTest", new SBigDecimal(0),
					(SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1));
			System.out.println((SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP1));
			assertEquals("Check: setplanCompositeRateStep1WithCompositeYZeroTest", new SBigDecimal("0E-16"),
					(SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP1));
		}
		@Test
		public void setplanCompositeRateStep1WithCompositeYWhen_Plan_Composite_Not_Equal_CompositeN_PositiveTest(){
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM ,
					new SBigDecimal(100));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS ,
					new SBigDecimal(101));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(102));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE,"Composite");
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,new SBigDecimal(103));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMP_ONLY__INVERSE,new SBigDecimal(104));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(105));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(106));
			loop5.setplanCompositeRateStep1WithCompositeY(holding,plan);
			System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1));
			assertEquals("Check: setplanCompositeRateStep1WithCompositeYWhen_Plan_Composite_Not_Equal_CompositeN_PositiveTest", new SBigDecimal(0),
					plan.getPlanMap().get(PlanConstants.PLAN_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY_STEP_1));
			System.out.println((SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP1));
			assertEquals("Check: setplanCompositeRateStep1WithCompositeYWhen_Plan_Composite_Not_Equal_CompositeN_PositiveTest", new SBigDecimal("-12345"),
					(SBigDecimal)plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP1));
		}
}
