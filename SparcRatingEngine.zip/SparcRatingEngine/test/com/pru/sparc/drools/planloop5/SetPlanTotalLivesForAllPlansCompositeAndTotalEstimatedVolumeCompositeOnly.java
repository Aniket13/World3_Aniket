package com.pru.sparc.drools.planloop5;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.pru.sparc.drools.basiclife.Loop5;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class SetPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnly {
	private Loop5 loop5 = null;
	private Holding holding = null;
	private Plan plan = null;
	 @Before
	public void setUp() {
		 holding = new Holding();
		 loop5= new Loop5();
		 HashMap<String,Object> holdingMap = new HashMap<String,Object>();
			
			holdingMap.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS, new SBigDecimal("5444.00"));
			holdingMap.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM, new SBigDecimal("54.00"));
			
			
			HashMap<String, Object> planMap = new HashMap<String, Object>();
			planMap.put("EffectiveDate", "1/1/2013");
			planMap.put("Quoted", "QuotedY");
			plan = new Plan();
			plan.setPlanMap(planMap);
			List<Plan> listOfPlans = new ArrayList<Plan>();
			listOfPlans.add(plan);
			holding.setListOfPlans(listOfPlans);
			holding.setHoldingMap(holdingMap);
	 }
	
	
	 
		@Test
		public void setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyPositiveTest(){
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE,
					"");
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM ,
					new SBigDecimal(21522));
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS ,
					new SBigDecimal(4852));
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(4852));
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,new SBigDecimal(4852));
			loop5.setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnly(holding,plan);
			System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
			assertEquals("Check: setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyEmptyTest", new SBigDecimal(4852.0),
					plan.getPlanMap().get(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
			System.out.println(holding
					.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
			assertEquals("Check: setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyEmptyTest", new SBigDecimal(4852.0),
					holding
					.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
		}
		@Test
		public void setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyWithPlanCompositeAsCompositeNPositiveTest(){
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE,
					"CompositeN");
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM ,
					new SBigDecimal(21522));
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS ,
					new SBigDecimal(4852));
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(4852));
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,new SBigDecimal(4852));
			loop5.setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnly(holding,plan);
			
			assertEquals("Check: setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyWithPlanCompositeAsCompositeNPositiveTest", new SBigDecimal(0),
					plan.getPlanMap().get(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
			
			assertEquals("Check: setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyWithPlanCompositeAsCompositeNPositiveTest", new SBigDecimal(0),
					plan.getPlanMap().get(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
		}
		@Test
		public void setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyZeroTest(){
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM ,
					new SBigDecimal(0));
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS ,
					new SBigDecimal(0));
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(0));
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,new SBigDecimal(0));
			loop5.setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnly(holding,plan);
			System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
			assertEquals("Check: setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyZeroTest", new SBigDecimal(0),
					plan.getPlanMap().get(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
			System.out.println(holding
					.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
			assertEquals("Check: setPlanTotalLivesForAllPlansCompositeAndTotalEstimatedVolumeCompositeOnlyZeroTest", new SBigDecimal(0),
					holding
					.getHoldingMap().get(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY));
		}
}
