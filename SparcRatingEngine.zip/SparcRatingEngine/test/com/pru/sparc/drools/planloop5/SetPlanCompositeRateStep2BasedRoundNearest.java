package com.pru.sparc.drools.planloop5;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.pru.sparc.drools.basiclife.Loop5;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class SetPlanCompositeRateStep2BasedRoundNearest {
	private Loop5 loop5 = null;
	private Holding holding = null;
	private Plan plan = null;
	 @Before
	public void setUp() {
		 holding = new Holding();
		 loop5= new Loop5();
		 HashMap<String,Object> holdingMap = new HashMap<String,Object>();
			
			holdingMap.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS, new SBigDecimal("5444.00"));
			holdingMap.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM, new SBigDecimal("54.00"));
			
			
			HashMap<String, Object> planMap = new HashMap<String, Object>();
			planMap.put("EffectiveDate", "1/1/2013");
			planMap.put("Quoted", "QuotedY");
			plan = new Plan();
			plan.setPlanMap(planMap);
			List<Plan> listOfPlans = new ArrayList<Plan>();
			listOfPlans.add(plan);
			holding.setListOfPlans(listOfPlans);
			holding.setHoldingMap(holdingMap);
	 }
	
	
	 
		@Test
		public void setPlanCompositeRateStep2BasedRoundNearestPositiveTest() throws ParseException{
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM ,
					new SBigDecimal(100));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS ,
					new SBigDecimal(101));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(102));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE,"CompositeN");
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,new SBigDecimal(103));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMP_ONLY__INVERSE,new SBigDecimal(104));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(105));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(106));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_COMPOSITE_MINIMUM_PREMIUM ,
					new SBigDecimal(107));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_STEP1 ,
					new SBigDecimal(108));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK ,
					new SBigDecimal(1));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.PROPOSALEFFECTIVEDATE ,
					"08/03/2016");
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_STEP2 ,
					new SBigDecimal(109));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP1 ,
					new SBigDecimal(110));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP2 ,
					new SBigDecimal(111));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP3 ,
					new SBigDecimal(112));
			loop5.setPlanCompositeRateStep2BasedRoundNearest(holding,plan);
			System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2));
			
			assertEquals("Check: setPlanCompositeRateStep2BasedRoundNearestPositiveTest", new SBigDecimal(110),
					plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2));
		
			
		}
		@Test
		public void setPlanCompositeRateStep2BasedRoundNearestZeroTest() throws ParseException{
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_MONTHLY_PREMIUM ,
					new SBigDecimal(0));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS ,
					new SBigDecimal(0));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(0));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE,"CompositeN");
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_ESTIMATED_VOLUME_COMPOSITE_ONLY,new SBigDecimal(0));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS_COMP_ONLY__INVERSE,new SBigDecimal(0));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_ANNUAL_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(0));
			//required input 
			holding
			.getHoldingMap()
			.put(HoldingConstants.HOLDING_MONTHLY_PREMIUM_FOR_ALL_PLANS__COMPOSITE_ONLY,new SBigDecimal(0));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.HOLDING_COMPOSITE_MINIMUM_PREMIUM ,
					new SBigDecimal(0));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_STEP1 ,
					new SBigDecimal(0));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK ,
					new SBigDecimal(1));
			//required input 
			holding.getHoldingMap()
			.put(HoldingConstants.PROPOSALEFFECTIVEDATE ,
					"08/03/2016");
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_STEP2 ,
					new SBigDecimal(0));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP1 ,
					new SBigDecimal(0));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP2 ,
					new SBigDecimal(0));
			//required input 
			plan.getPlanMap()
			.put(PlanConstants.PLAN_COMPOSITE_RATE_ROUND_STEP3 ,
					new SBigDecimal(0));
			loop5.setPlanCompositeRateStep2BasedRoundNearest(holding,plan);
			System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2));
			
			assertEquals("Check: setPlanCompositeRateStep2BasedRoundNearestPositiveTest", new SBigDecimal(0),
					plan.getPlanMap().get(PlanConstants.PLAN_COMPOSITE_RATE_STEP2));
		
			
		}
}
