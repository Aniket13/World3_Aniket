package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Plan_Renewal_Rate_NonAgeBanded_Out_Step_1Test {
	
	@Test
	public void plan_Renewal_Rate_NonAgeBanded_Out_Step_1Test() {
	Holding holding = new Holding();
	HashMap<String,Object> holdingMap = new HashMap<String,Object>();
	holding.setHoldingMap(holdingMap);
	holding.setCount(1);
	HashMap<String, Object> planMap = new HashMap<String, Object>();
	planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_RATE, new SBigDecimal("405.9"));
	planMap.put(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2, new SBigDecimal("408.75"));
	
	Plan plan = new Plan();
	plan.setPlanMap(planMap);
	List<Plan> listOfPlans = new ArrayList<Plan>();
	listOfPlans.add(plan);
	holding.setListOfPlans(listOfPlans);
	RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Rate_NonAgeBanded_Out_Step_1.xls",
							"",new Object[]{holding,plan});
	
	System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_RATE_NONAGEBANDED_OUT_STEP_1));
	assertEquals("Check: plan_Renewal_Rate_NonAgeBanded_Out_Step_1", new SBigDecimal("166317.525"),
			plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_RATE_NONAGEBANDED_OUT_STEP_1));
	}
}
