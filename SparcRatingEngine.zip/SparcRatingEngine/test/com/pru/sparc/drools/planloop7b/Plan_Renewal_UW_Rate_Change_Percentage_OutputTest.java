package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Plan_Renewal_UW_Rate_Change_Percentage_OutputTest {
	final Logger logger = LoggerFactory.getLogger("Plan_Renewal_UW_Rate_Change_Percentage_OutputTest");
	
	@Test
	public void test_plan_Renewal_UW_Rate_Change_Percentage_case1() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.RENEWAL,"RenewalNo");
		holding.setHoldingMap(holdingMap);
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_RATE, new SBigDecimal(5000.5));
		//planMap.put(PlanConstants.PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE, new SBigDecimal(500));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_UW_Rate_Change_Percentage_Output.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE_OUTPUT, 
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE_OUTPUT));
		assertEquals("Check: plan_Renewal_UW_Rate_Change_Percentage_Output", new SBigDecimal("5000.5"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE_OUTPUT));
	}
	
	
	@Test
	public void test_plan_Renewal_UW_Rate_Change_Percentage_case2() {
		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.RENEWAL,"RenewalY");
		holding.setHoldingMap(holdingMap);
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_RATE, new SBigDecimal(5000.5));
		planMap.put(PlanConstants.PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE, new SBigDecimal(99.01));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		
		
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_UW_Rate_Change_Percentage_Output.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE_OUTPUT, 
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE_OUTPUT));
		assertEquals("Check: plan_Renewal_UW_Rate_Change_Percentage_Output", new SBigDecimal("9801.00000000000051"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_UW_RATE_CHANGE_PERCENTAGE_OUTPUT));
	}

}
