package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanRateActionOutStep2Test {
	@Test
	public void plan_Rate_Action_Out_Step_2_testCase1() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		
		holding.setHoldingMap(holdingMap);
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.BL_AGE_BANDED, "BL_Age_Banded_Yes");
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION_AGE_BANDED_OVERRIDDEN, new SBigDecimal("408.75"));
		planMap.put(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1, new SBigDecimal("4789.75"));
		planMap.put(PlanConstants.PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED, new SBigDecimal("0.1"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_2.xls",
				"",new Object[]{holding,plan});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2));
		assertEquals("Check: plan_Rate_Action_Out_Step_2", new SBigDecimal("408.75"),
				plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2));
	}
	
	@Test
	public void plan_Rate_Action_Out_Step_2_testCase2() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		
		holding.setHoldingMap(holdingMap);
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.BL_AGE_BANDED, "BL_Age_Banded_Yes");
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION_AGE_BANDED_OVERRIDDEN, new SBigDecimal("408.75"));
		planMap.put(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1, new SBigDecimal("408.75"));
		//planMap.put(PlanConstants.PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED, new SBigDecimal("0"));
		planMap.put(PlanConstants.PLAN_RENEWAL_AGE_BANDED_OVERRIDES_USED, new SBigDecimal("10"));

		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_2.xls",
				"",new Object[]{holding,plan});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2));
		assertEquals("Check: plan_Rate_Action_Out_Step_2", new SBigDecimal("408.75"),
				plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_2));
	}
}
