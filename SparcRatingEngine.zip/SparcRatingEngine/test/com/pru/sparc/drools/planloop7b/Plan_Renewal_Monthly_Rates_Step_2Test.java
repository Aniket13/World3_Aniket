package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Plan_Renewal_Monthly_Rates_Step_2Test {
	
	final Logger logger = LoggerFactory.getLogger("Plan_Renewal_Monthly_Rates_Step_2Test");
	
	@Test
	public void test_plan_Renewal_Monthly_Rates_Step_2_Case1() {
		Holding holding = new Holding();
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK, new SBigDecimal(0));
		
		
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		planMap.put(PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE, new SBigDecimal(1000));
		
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeN");
		planMap.put(PlanConstants.PLAN_PLAN_MINIMUM_RATE, new SBigDecimal(2200));

		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Monthly_Rates_Step_2.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_MONTHLY_RATES_STEP_2, plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_MONTHLY_RATES_STEP_2));
		
		assertEquals("Check: plan_Renewal_Monthly_Rates_Step_2", new SBigDecimal("0"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_MONTHLY_RATES_STEP_2));
	}
	
	@Test
	public void test_plan_Renewal_Monthly_Rates_Step_2_Case2() {
		Holding holding = new Holding();
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put(PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK, new SBigDecimal(0));
		
		
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		planMap.put(PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE, new SBigDecimal(1000));
		
		//planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeN");
		//planMap.put(PlanConstants.PLAN_PLAN_MINIMUM_RATE, new SBigDecimal(2200));

		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Monthly_Rates_Step_2.xls",
				"",new Object[]{holding,plan});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_MONTHLY_RATES_STEP_2));
		assertEquals("Check: plan_Renewal_Monthly_Rates_Step_2", new SBigDecimal("1000"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_MONTHLY_RATES_STEP_2));
	}
	
	@Test
	public void test_plan_Renewal_Monthly_Rates_Step_2_Case3() {
		Holding holding = new Holding();
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put(PlanConstants.PLAN_VERSION_28_UW_BOX_DATE_CHECK, new SBigDecimal(0));
		
		
		//planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		//planMap.put(PlanConstants.PLAN_COMPOSITE_MINIMUM_RATE, new SBigDecimal(1000));
		
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeN");
		planMap.put(PlanConstants.PLAN_PLAN_MINIMUM_RATE, new SBigDecimal(2200));

		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Monthly_Rates_Step_2.xls",
				"",new Object[]{holding,plan});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_MONTHLY_RATES_STEP_2));
		assertEquals("Check: plan_Renewal_Monthly_Rates_Step_2", new SBigDecimal("2200"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_MONTHLY_RATES_STEP_2));
	}
}
