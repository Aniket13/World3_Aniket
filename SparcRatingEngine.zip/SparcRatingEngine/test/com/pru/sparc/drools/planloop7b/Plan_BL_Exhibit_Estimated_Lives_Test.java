package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Plan_BL_Exhibit_Estimated_Lives_Test {
	
	final Logger logger = LoggerFactory.getLogger("Plan_BL_Exhibit_Estimated_Lives_Test");
	
	@Test
	public void test_Plan_BL_Exhibit_Estimated_Lives_case1() {
		Holding holding = new Holding();
		holding.setCount(0);
		
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.RENEWAL, "RenewalYes");
		holdingMap.put(HoldingConstants.HOLDING_CV_CASE_LIVES, new SBigDecimal(0));
		holdingMap.put(HoldingConstants.RENEWAL_LIVES, new SBigDecimal(20));
		holding.setHoldingMap(holdingMap);
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Lives.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES, 
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
		
		assertEquals("Check: plan_BL_Exhibit_Estimated_Lives", new SBigDecimal("20"),
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
	}
	
	@Test
	public void test_Plan_BL_Exhibit_Estimated_Lives_case2() {
		Holding holding = new Holding();
		holding.setCount(0);
		
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.RATING_TYPE, "Rating_Type_PIA");
		holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);

		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_LIVES, new SBigDecimal(500));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Lives.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES, 
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
		
		assertEquals("Check: plan_BL_Exhibit_Estimated_Lives", new SBigDecimal("500"),
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
	}

	@Test
	public void test_Plan_BL_Exhibit_Estimated_Lives_case3() {
		Holding holding = new Holding();
		holding.setCount(0);
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES_FOR_ALL_PLANS__COMPOSITE_ONLY, new SBigDecimal("1900"));

		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Lives.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES, 
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
		
		assertEquals("Check: plan_BL_Exhibit_Estimated_Lives", new SBigDecimal("1900"),
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
	}
	
	@Test
	public void test_Plan_BL_Exhibit_Estimated_Lives_case4() {
		Holding holding = new Holding();
		holding.setCount(0);
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeN");
		planMap.put(PlanConstants.PLAN_TOTAL_LIVES, new SBigDecimal("2345"));

		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Lives.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES, 
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
		
		assertEquals("Check: plan_BL_Exhibit_Estimated_Lives", new SBigDecimal("2345"),
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES));
	}

}
