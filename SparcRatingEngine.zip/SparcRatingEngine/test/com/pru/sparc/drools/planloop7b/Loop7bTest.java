package com.pru.sparc.drools.planloop7b;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.basiclife.Loop7b;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Loop7bTest {
	@Test
	public void testLoop7b() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		holdingMap.put(HoldingConstants.RATING_ENGINE_EFFECTIVE_DATE, new SBigDecimal("50")); 
		holdingMap.put(HoldingConstants.HOLDING_AGE_BANDED_RATIO, new SBigDecimal("10")); 
		holdingMap.put(HoldingConstants.HOLDING_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal("0")); 
		holdingMap.put(HoldingConstants.HOLDING_RENEWAL_MONTHLY_CRLP, new SBigDecimal("205.75")); 
		
		holdingMap.put(HoldingConstants.RENEWAL, "RenewalYes"); 
		holdingMap.put(HoldingConstants.RATING_TYPE, "Rating_Type_PIA"); 
		holding.setHoldingMap(holdingMap);
		Plan plan = new Plan();
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_FIELD_ADJUSTMENT_RATIO, new SBigDecimal("0.5")); 
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME, new SBigDecimal("50")); 
		planMap.put(PlanConstants.PLAN_REGIONAL_VP_ADJUSTMENT_RATIO, new SBigDecimal("0.5")); 
		planMap.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO, new SBigDecimal("0.5"));
		planMap.put(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_RATIO, new SBigDecimal("0.5")); 
		planMap.put(PlanConstants.PLAN_RENEWAL_APPEAL_MONTHLY_RATES, new SBigDecimal("500")); 
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_MONTHLY_RATES_STEP_5, new SBigDecimal("1500")); 
		planMap.put(PlanConstants.PLAN_TABLE_K_MONTHLY_PREMIUM_STEP_1, new SBigDecimal("2300")); 
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION, new SBigDecimal("12.50")); 
		planMap.put(PlanConstants.PLAN_APPEAL_PREMIUM_ALL_AGEBANDED, new SBigDecimal("210.70")); 
		planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_PREMIUM, new SBigDecimal("450.75")); 
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_LIVES, new SBigDecimal("80000"));
		planMap.put(PlanConstants.PLAN_APPEAL_ADJUSTMENT_BOX_RATIO, new SBigDecimal("0.5"));
		planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_RATE, new SBigDecimal("25000"));
		planMap.put(PlanConstants.BL_AGE_BANDED, "BL_Age_Banded_No"); 
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		planMap.put(PlanConstants.PLAN_FINAL_PREMIUM_OVERRIDE_STEP_2, new SBigDecimal("99999"));
		planMap.put(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2, new SBigDecimal("12345"));
		planMap.put(PlanConstants.PLAN_RENEWAL_PREMIUM_NON_AGE_BANDED, new SBigDecimal("5678"));
		planMap.put(PlanConstants.PLAN_ESTIMATED_VOLUME, new SBigDecimal("9876"));

		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		Loop7b objLoop7b = new Loop7b();
		objLoop7b.executePlan(holding,plan);
		SparcRatingUtil.showMap(plan.getPlanMap());
		SparcRatingUtil.showMap(holding.getHoldingMap());
		
		objLoop7b.executePlanStep2(holding,plan);
		SparcRatingUtil.showMap(plan.getPlanMap());
		SparcRatingUtil.showMap(holding.getHoldingMap());
	}
}
