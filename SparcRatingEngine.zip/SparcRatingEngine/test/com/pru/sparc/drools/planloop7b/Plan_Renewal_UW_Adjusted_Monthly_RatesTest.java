package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Plan_Renewal_UW_Adjusted_Monthly_RatesTest {
	
	final Logger logger = LoggerFactory.getLogger("Plan_Renewal_Premium_NonAgeBanded_OutTest");
	
	@Test
	public void plan_Renewal_UW_Adjusted_Monthly_RatesTest() {
		Holding holding = new Holding();
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_RENEWAL_MONTHLY_RATES_STEP_3, new SBigDecimal(500));
		planMap.put(PlanConstants.PLAN_UW_ADJUSTMENT_BOX_2_RATIO, new SBigDecimal(0.5));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_UW_Adjusted_Monthly_Rates.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_RATES, plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_RATES));
		
		assertEquals("Check: plan_Renewal_UW_Adjusted_Monthly_Rates", new SBigDecimal("250.0"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_RATES));
	}


}
