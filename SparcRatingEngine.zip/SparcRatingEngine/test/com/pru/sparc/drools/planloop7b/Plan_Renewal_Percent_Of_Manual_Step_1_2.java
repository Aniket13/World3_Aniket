package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Plan_Renewal_Percent_Of_Manual_Step_1_2 {
	final Logger logger = LoggerFactory.getLogger("Plan_Renewal_Percent_Of_Manual_Step_1_2");
	
	@Test
	public void test_Plan_Renewal_Percent_Of_Manual_Step_1_2() {
		Holding holding = new Holding();
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_PREMIUM, new SBigDecimal(500));
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeY");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Percent_Of_Manual_Step_1_2.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_1, 
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_1));
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2, 
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2));
		
		assertEquals("Check: plan_Renewal_Percent_Of_Manual_Step_1", new SBigDecimal("500"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_1));
		assertEquals("Check: plan_Renewal_Percent_Of_Manual_Step_2", new SBigDecimal("0"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2));
	}
	
	
	@Test
	public void test_Plan_Renewal_Percent_Of_Manual_Step_1_2_Case2() {
		Holding holding = new Holding();
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_RENEWAL_UW_ADJUSTED_MONTHLY_PREMIUM, new SBigDecimal(500));
		planMap.put(PlanConstants.PLAN_COMPOSITE, "CompositeN");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Percent_Of_Manual_Step_1_2.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_1, 
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_1));
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2, 
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2));
		
		assertEquals("Check: plan_Renewal_Percent_Of_Manual_Step_1", new SBigDecimal("0"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_1));
		assertEquals("Check: plan_Renewal_Percent_Of_Manual_Step_2", new SBigDecimal("500"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_PERCENT_OF_MANUAL_STEP_2));
	}
}
