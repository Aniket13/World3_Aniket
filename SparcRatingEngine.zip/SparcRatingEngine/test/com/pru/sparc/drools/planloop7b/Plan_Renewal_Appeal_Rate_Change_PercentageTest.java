package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Plan_Renewal_Appeal_Rate_Change_PercentageTest {
	final Logger logger = LoggerFactory.getLogger("Plan_Renewal_UW_Rate_Change_PercentageTest");
	
	@Test
	public void test_Plan_Renewal_Appeal_Rate_Change_Percentage_case1() {
		Holding holding = new Holding();
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ALL_AGE_BANDED_SINGLE_RATE, new SBigDecimal(5000.5));
		planMap.put(PlanConstants.PLAN_INFORCE_RATE_ALL_AGE_BANDED_SINGLE_RATE, new SBigDecimal(500));
		planMap.put(PlanConstants.BL_AGE_BANDED,"BL_Age_Banded_Yes");
		
		
		//planMap.put(PlanConstants.PLAN_RENEWAL_APPEAL_MONTHLY_RATES, new SBigDecimal(500));
		//planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_RATE_NONAGEBANDED_STEP_1, new SBigDecimal(500));
		//planMap.put(PlanConstants.BL_AGE_BANDED,"BL_Age_Banded_No");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Appeal_Rate_Change_Percentage.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_APPEAL_RATE_CHANGE_PERCENTAGE, 
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_APPEAL_RATE_CHANGE_PERCENTAGE));
		assertEquals("Check: plan_Renewal_Appeal_Rate_Change_Percentage", new SBigDecimal("10.001"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_APPEAL_RATE_CHANGE_PERCENTAGE));
	}
	
	
	@Test
	public void test_Plan_Renewal_Appeal_Rate_Change_Percentage_case2() {
		Holding holding = new Holding();
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ALL_AGE_BANDED_SINGLE_RATE, new SBigDecimal(5000.5));
		//planMap.put(PlanConstants.PLAN_INFORCE_RATE_ALL_AGE_BANDED_SINGLE_RATE, new SBigDecimal(500));
		//planMap.put(PlanConstants.BL_AGE_BANDED,"BL_Age_Banded_Yes");
		
		
		planMap.put(PlanConstants.PLAN_RENEWAL_APPEAL_MONTHLY_RATES, new SBigDecimal(500));
		planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_RATE_NONAGEBANDED_STEP_1, new SBigDecimal(500));
		planMap.put(PlanConstants.BL_AGE_BANDED,"BL_Age_Banded_No");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Appeal_Rate_Change_Percentage.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_RENEWAL_APPEAL_RATE_CHANGE_PERCENTAGE, 
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_APPEAL_RATE_CHANGE_PERCENTAGE));
		assertEquals("Check: plan_Renewal_Appeal_Rate_Change_Percentage", new SBigDecimal("1"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_APPEAL_RATE_CHANGE_PERCENTAGE));
	}

}
