package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanRateActionOutStep1Test {
	@Test
	public void test_Plan_Rate_Action_Out_Step_1() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		//holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal("0"));
		//holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_MAX, new SBigDecimal("10"));
		//holdingMap.put(HoldingConstants.AGED_CENSUS, "AgedCensusYes");
		
		//holdingMap.put(HoldingConstants.HOLDING_PREMIUM_DIFF,  new SBigDecimal("100"));
		//holdingMap.put(HoldingConstants.RENEWAL_PREMIUM_PERCENTAGE, new SBigDecimal("10"));
		//holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_RAT, new SBigDecimal("100"));
		
		
		holding.setHoldingMap(holdingMap);
		holding.setCount(0);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION_OVERRIDE, new SBigDecimal("405.9"));
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION, new SBigDecimal("408.75"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_1.xls",
				"",new Object[]{holding});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
		assertEquals("Check: plan_Rate_Action_Out_Step_1", new SBigDecimal("408.75"),
				plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
	}
	
	
	
	@Test
	public void test_Plan_Rate_Action_Out_Step_2() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal("0"));
		holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_MAX, new SBigDecimal("2050589.12"));
		//holdingMap.put(HoldingConstants.AGED_CENSUS, "AgedCensusYes");
		
		//holdingMap.put(HoldingConstants.HOLDING_PREMIUM_DIFF,  new SBigDecimal("100"));
		//holdingMap.put(HoldingConstants.RENEWAL_PREMIUM_PERCENTAGE, new SBigDecimal("10"));
		//holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_RAT, new SBigDecimal("100"));
		
		
		holding.setHoldingMap(holdingMap);
		holding.setCount(0);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION_OVERRIDE, new SBigDecimal("9999"));
		//planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION, new SBigDecimal("408.75"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_1.xls",
				"",new Object[]{holding});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
		assertEquals("Check: plan_Rate_Action_Out_Step_1", new SBigDecimal("2050589.12"),
				plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
	}
	
	
	@Test
	public void test_Plan_Rate_Action_Out_Step_3() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		//holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal("0"));
		holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_MAX, new SBigDecimal("879.546"));
		holdingMap.put(HoldingConstants.AGED_CENSUS, "AgedCensusYes");
		
		holdingMap.put(HoldingConstants.HOLDING_PREMIUM_DIFF,  new SBigDecimal("100"));
		holdingMap.put(HoldingConstants.RENEWAL_PREMIUM_PERCENTAGE, new SBigDecimal("10"));
		//holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_RAT, new SBigDecimal("100"));
		
		
		holding.setHoldingMap(holdingMap);
		holding.setCount(0);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION_OVERRIDE, new SBigDecimal("9999"));
		//planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION, new SBigDecimal("408.75"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_1.xls",
				"",new Object[]{holding});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
		assertEquals("Check: plan_Rate_Action_Out_Step_1", new SBigDecimal("879.546"),
				plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
	}
	
	
	@Test
	public void test_Plan_Rate_Action_Out_Step_4() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		//holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal("0"));
		//holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_MAX, new SBigDecimal("10"));
		holdingMap.put(HoldingConstants.AGED_CENSUS, "AgedCensusNo");
		
		holdingMap.put(HoldingConstants.HOLDING_PREMIUM_DIFF,  new SBigDecimal("10012"));
		holdingMap.put(HoldingConstants.RENEWAL_PREMIUM_PERCENTAGE, new SBigDecimal("100"));
		holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_RAT, new SBigDecimal("2345.55"));
		
		
		holding.setHoldingMap(holdingMap);
		holding.setCount(0);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION_OVERRIDE, new SBigDecimal("9999"));
		//planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION, new SBigDecimal("408.75"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_1.xls",
				"",new Object[]{holding});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
		assertEquals("Check: plan_Rate_Action_Out_Step_1", new SBigDecimal("2345.55"),
				plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
	}
	
	
	@Test
	public void test_Plan_Rate_Action_Out_Step_5() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		//holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal("0"));
		//holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_MAX, new SBigDecimal("10"));
		//holdingMap.put(HoldingConstants.AGED_CENSUS, "AgedCensusNo");
		
		holdingMap.put(HoldingConstants.HOLDING_PREMIUM_DIFF,  new SBigDecimal("100.1"));
		holdingMap.put(HoldingConstants.RENEWAL_PREMIUM_PERCENTAGE, new SBigDecimal("10012"));
		//holdingMap.put(HoldingConstants.HOLDING_RATE_ACTION_RAT, new SBigDecimal("2345.55"));
		
		
		holding.setHoldingMap(holdingMap);
		holding.setCount(0);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		//planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION_OVERRIDE, new SBigDecimal("9999"));
		//planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ACTION, new SBigDecimal("408.75"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		
		
		
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Rate_Action_Out_Step_1.xls",
				"",new Object[]{holding});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
		assertEquals("Check: plan_Rate_Action_Out_Step_1", new SBigDecimal("0"),
				plan.getPlanMap().get(PlanConstants.PLAN_RATE_ACTION_OUT_STEP_1));
	}
	
}
