package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class Plan_BL_Exhibit_Estimated_Volume_Test {
	
	final Logger logger = LoggerFactory.getLogger("Plan_BL_Exhibit_Estimated_Volume_Test");
	
	@Test
	public void test_Plan_BL_Exhibit_Estimated_Volume_Test_case1() {
		Holding holding = new Holding();
		holding.setCount(0);
		
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.RENEWAL, "RenewalYes");
		holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_RENEWAL, new SBigDecimal(2510));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Volume.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME, 
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME));
		
		assertEquals("Check: plan_BL_Exhibit_Estimated_Volume", new SBigDecimal("2510"),
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME));
	}
	
	@Test
	public void test_Plan_BL_Exhibit_Estimated_Volume_Test_case2() {
		Holding holding = new Holding();
		holding.setCount(0);
		
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.RATING_TYPE, "Rating_Type_PIA");
		holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME, new SBigDecimal("879.51"));
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Volume.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME, 
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME));
		
		assertEquals("Check: plan_BL_Exhibit_Estimated_Volume", new SBigDecimal("879.51"),
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME));
	}
	
	
	@Test
	public void test_Plan_BL_Exhibit_Estimated_Volume_Test_case3() {
		Holding holding = new Holding();
		holding.setCount(0);
		
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.RENEWAL, "RenewalNo");
		holdingMap.put(HoldingConstants.RATING_TYPE, "");
		//holdingMap.put(HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS, new SBigDecimal(200));
		holding.setHoldingMap(holdingMap);
		
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME_STEP_1, new SBigDecimal("521.24"));
		//planMap.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME, new SBigDecimal(879.51));
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_BL_Exhibit_Estimated_Volume.xls",
				"",new Object[]{holding,plan});
		
		logger.debug("Key : {}| Value: {}", PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME, 
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME));
		
		assertEquals("Check: plan_BL_Exhibit_Estimated_Volume", new SBigDecimal("521.24"),
				plan.getPlanMap().get(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME));
	}
}
