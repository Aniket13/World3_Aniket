package com.pru.sparc.drools.planloop7b;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanRenewalRateActionAgeBandedOverriddenTest {
	@Test
	public void test_Plan_Renewal_Rate_Action_Age_Banded_Overridden_1() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		holdingMap.put(HoldingConstants.RENEWAL, "RenewalYes");
		holding.setHoldingMap(holdingMap);
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ALL_AGE_BANDED_SINGLE_RATE, new SBigDecimal("405.9"));
		planMap.put(PlanConstants.PLAN_INFORCE_RATE_ALL_AGE_BANDED_SINGLE_RATE, new SBigDecimal("408.75"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Rate_Action_Age_Banded_Overridden.xls",
				"",new Object[]{holding,plan});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_RATE_ACTION_AGE_BANDED_OVERRIDDEN));
		assertEquals("Check: plan_Renewal_Rate_Action_Age_Banded_Overridden", new SBigDecimal("0.993027522935779817"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_RATE_ACTION_AGE_BANDED_OVERRIDDEN));
	}
	
	@Test
	public void test_Plan_Renewal_Rate_Action_Age_Banded_Overridden_2() {
		Holding holding = new Holding();
		HashMap<String,Object> holdingMap = new HashMap<String,Object>();
		holdingMap.put(HoldingConstants.RENEWAL, "RenewalNo");
		holding.setHoldingMap(holdingMap);
		holding.setCount(1);
		HashMap<String, Object> planMap = new HashMap<String, Object>();
		planMap.put(PlanConstants.PLAN_RENEWAL_RATE_ALL_AGE_BANDED_SINGLE_RATE, new SBigDecimal("405.9"));
		planMap.put(PlanConstants.PLAN_INFORCE_RATE_ALL_AGE_BANDED_SINGLE_RATE, new SBigDecimal("408.75"));
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);
		RuleUtility.getInitsData("DT","basiclife\\loop7b\\BL_Plan_Renewal_Rate_Action_Age_Banded_Overridden.xls",
				"",new Object[]{holding,plan});
		
		System.out.println(plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_RATE_ACTION_AGE_BANDED_OVERRIDDEN));
		assertEquals("Check: plan_Renewal_Rate_Action_Age_Banded_Overridden", new SBigDecimal("0"),
				plan.getPlanMap().get(PlanConstants.PLAN_RENEWAL_RATE_ACTION_AGE_BANDED_OVERRIDDEN));
	}
	
}
