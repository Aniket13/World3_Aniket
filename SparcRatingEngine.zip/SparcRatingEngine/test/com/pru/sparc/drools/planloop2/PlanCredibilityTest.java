package com.pru.sparc.drools.planloop2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanCredibilityTest {

	@Test
	public void testPlan_Credibility() {

		SBigDecimal planCredibility = new SBigDecimal("10000");
		SBigDecimal planMargin = new SBigDecimal("24510");

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/Margin", planMargin);
		planMap1.put("plan/Credibility", planCredibility);
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		Holding holding = new Holding();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_Plan_Credibility.xls",
				"agenda_plan_credibility", new Object[] { holding });
		RatingCalculationTest.showMap(planMap1);

	}

}
