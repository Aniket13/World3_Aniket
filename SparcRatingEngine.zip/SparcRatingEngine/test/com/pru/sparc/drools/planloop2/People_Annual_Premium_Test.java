package com.pru.sparc.drools.planloop2;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.PersonConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class People_Annual_Premium_Test {

	final static Logger logger = LoggerFactory.getLogger(People_Annual_Premium_Test.class);

	@Test
	public void test_People_Pooled_Annual_Premium() {
		Holding holding = new Holding();
		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.setCount(0);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		census.setCensusMap(censusMap);
		plan1.setCensus(census);
		//People Map
		ArrayList<Person> peopleList ;

		int count = 6;
		peopleList = getCensusWithEmployees(count);
		census.setListOfPeople(peopleList);

		for(int i=0; i<count; i++){
			RuleUtility.getInitsData("DT",
					"basiclife\\loop2\\BL_Plan_People_Annual_Prem.xls",
					"Annual_Premium", 
					new Object[] { ((Plan)holding.getListOfPlans().get(holding.getCount())).getCensus().getListOfPeople().get(i)});

		}

		printOutput(holding, count);

		SBigDecimal pooledExpectedValues[] = new SBigDecimal[count] ;
		pooledExpectedValues[0] = new SBigDecimal("36.0360");
		pooledExpectedValues[1] = new SBigDecimal("120.0600");
		pooledExpectedValues[2] = new SBigDecimal("36.0120");
		pooledExpectedValues[3] = new SBigDecimal("144.0360");
		pooledExpectedValues[4] = new SBigDecimal("180.0360");
		pooledExpectedValues[5] = new SBigDecimal("216.0360");


		SBigDecimal nonPooledExpectedValues[] = new SBigDecimal[count] ;
		nonPooledExpectedValues[0] = new SBigDecimal("36.0360");
		nonPooledExpectedValues[1] = new SBigDecimal("120.0600");
		nonPooledExpectedValues[2] = new SBigDecimal("36.0120");
		nonPooledExpectedValues[3] = new SBigDecimal("144.0360");
		nonPooledExpectedValues[4] = new SBigDecimal("180.0360");
		nonPooledExpectedValues[5] = new SBigDecimal("216.0360");

		for(int i=0; i<count; i++){
			Person currPerson = (Person)((Plan)holding.getListOfPlans().get(holding.getCount())).getCensus().getListOfPeople().get(i);
			assertEquals("Check: Annual Pooled Premium", pooledExpectedValues[i],
					currPerson.getPeopleMap().get(PersonConstants.ANNUAL_POOLED_PREMIUM));

			assertEquals("Check: Annual Non Pooled Premium", nonPooledExpectedValues[i],
					currPerson.getPeopleMap().get(PersonConstants.ANNUAL_NON_POOLED_PREMIUM));

		}

	}


	public static void printOutput(Holding holding, int count){
		// Print Data
		for(int i=0; i<count; i++){

			logger.debug("-----------------Person Map-"+i+" --------------------");
			SparcRatingUtil.showMap(((Person)((Plan)holding.getListOfPlans().get(holding.getCount())).getCensus().getListOfPeople().get(i))
					.getPeopleMap());
		}

		logger.debug("-----------------Plan Map--------------------");
		SparcRatingUtil.showMap(((Plan) (holding.getListOfPlans()
				.get(0))).getPlanMap());

	}

	private static ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList(getPersonList().subList(0, count%11));
		return peopleList;
	}

	private static ArrayList<Person> getPersonList() {
		ArrayList<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		SBigDecimal buffer = new SBigDecimal("100.00");
		buffer =  new SBigDecimal("100000.00").add(buffer);

		peopleMap1.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(22));
		peopleMap1.put(PersonConstants.PEOPLE_GENDER, "male");
		peopleMap1.put(PersonConstants.PEOPLE_STATUS, "active");
		peopleMap1.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap1.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap1.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.03"));
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(24));
		peopleMap2.put(PersonConstants.PEOPLE_GENDER, "female");
		peopleMap2.put(PersonConstants.PEOPLE_STATUS, "retiree");
		peopleMap2.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap2.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap2.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.05"));
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(26));
		peopleMap3.put(PersonConstants.PEOPLE_GENDER, "male");
		peopleMap3.put(PersonConstants.PEOPLE_STATUS, "active");
		peopleMap3.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap3.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap3.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.01"));
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(28));
		peopleMap4.put(PersonConstants.PEOPLE_GENDER, "female");
		peopleMap4.put(PersonConstants.PEOPLE_STATUS, "retiree");
		peopleMap4.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap4.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap4.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.03"));
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put(PersonConstants.PEOPLE_AGE,new SBigDecimal(30));
		peopleMap5.put(PersonConstants.PEOPLE_GENDER, "male");
		peopleMap5.put(PersonConstants.PEOPLE_STATUS, "active");
		peopleMap5.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap5.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap5.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.03"));
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(32));
		peopleMap6.put(PersonConstants.PEOPLE_GENDER, "female");
		peopleMap6.put(PersonConstants.PEOPLE_STATUS, "retiree");
		peopleMap6.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap6.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap6.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.03"));
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put(PersonConstants.PEOPLE_AGE,new SBigDecimal(62));
		peopleMap7.put(PersonConstants.PEOPLE_GENDER, "male");
		peopleMap7.put(PersonConstants.PEOPLE_STATUS, "active");
		peopleMap7.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap7.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap7.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.03"));
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(63));
		peopleMap8.put(PersonConstants.PEOPLE_GENDER, "female");
		peopleMap8.put(PersonConstants.PEOPLE_STATUS, "retiree");
		peopleMap8.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap8.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap8.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.09"));
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(77));
		peopleMap9.put(PersonConstants.PEOPLE_GENDER, "male");
		peopleMap9.put(PersonConstants.PEOPLE_STATUS, "active");
		peopleMap9.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap9.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap9.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.03"));
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		buffer =  new SBigDecimal("100000.00").add(buffer);
		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put(PersonConstants.PEOPLE_AGE, new SBigDecimal(85));
		peopleMap10.put(PersonConstants.PEOPLE_GENDER, "female");
		peopleMap10.put(PersonConstants.PEOPLE_STATUS, "retiree");
		peopleMap10.put(PersonConstants.PEOPLE_POOLED_VOLUME, buffer);
		peopleMap10.put(PersonConstants.PEOPLE_NON_POOLED_VOLUME, buffer);
		peopleMap10.put(PersonConstants.PEOPLE_AGE_MANUAL_RATE, new SBigDecimal("0.03"));
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		peopleMap1.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("3.0030"));
		peopleMap1.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("3.0030"));
		peopleMap2.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("10.0050"));
		peopleMap2.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("10.0050"));
		peopleMap3.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("3.0010"));
		peopleMap3.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("3.0010"));
		peopleMap4.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("12.0030"));
		peopleMap4.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("12.0030"));
		peopleMap5.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("15.0030"));
		peopleMap5.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("15.0030"));
		peopleMap6.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("18.0030"));
		peopleMap6.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("18.0030"));
		peopleMap7.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("10.0050"));
		peopleMap7.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("10.0050"));
		peopleMap8.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("12.0030"));
		peopleMap8.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("12.0030"));
		peopleMap9.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("15.0030"));
		peopleMap9.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("15.0030"));
		peopleMap10.put(PersonConstants.MONTHLY_POOLED_PREMIUM, new SBigDecimal("18.0030"));
		peopleMap10.put(PersonConstants.MONTHLY_NON_POOLED_PREMIUM, new SBigDecimal("18.0030"));


		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson;

	}

}
