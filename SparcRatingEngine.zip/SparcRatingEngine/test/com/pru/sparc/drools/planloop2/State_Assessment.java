package com.pru.sparc.drools.planloop2;

public class State_Assessment {

}
