package com.pru.sparc.drools.planloop2;

public class Plan_Premium_Tax_Factor {

}
