package com.pru.sparc.drools.planloop2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class AgeBracketBasedCalculationTest {
	RatingCalculationTest rateCal = new RatingCalculationTest();
	
	
	@Test
	public void ageBracketBasedCalculationTest(){
		SBigDecimal planCaseFlatAmt = new SBigDecimal("2000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("1.0");
		SBigDecimal planMAXAmt = new SBigDecimal("5000.00");
		SBigDecimal planMINAmt = new SBigDecimal("500.00");
		SBigDecimal planRoundingSelection = new SBigDecimal("8");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("0.00");
		int peopleCount = 10;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "AK");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "Thu Sep 30 20:00:00 EST 1992");
		planMap1.put("plan/RoundingOccurs", "RoundingOccursAfterAmountIsMultiplied");// confirm
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		planMap1.put("state/StateAllocationFactor", new SBigDecimal(5));
		
		
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		
		List<String> states=new ArrayList<String>();
		states.add("AB");
		states.add("AL");
		states.add("AK");
		censusMap.put("censusStates", states);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,"basiclife//loop2//BL_Plan_Loop2.drl","plan-loop2");
		
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */


	}
	
	
	private ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
			//FactLookupUtility.showMap(peopleList.get(i).getPeopleMap());
		}

		return peopleList;
	}
	private Person getPersonObject(int position) {
		//System.out.println("person object created");
		List<Person> listPerson = new ArrayList<Person>();
		
		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Salary", new SBigDecimal(31000));
		peopleMap1.put("people/BasicAmt", new SBigDecimal(31000));
		peopleMap1.put("Age", 22.0);
		peopleMap1.put("gender", "male");
		peopleMap1.put("status", "active");
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		
		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put("people/Salary", new SBigDecimal(32000));
		peopleMap2.put("people/BasicAmt", new SBigDecimal(32000));
		peopleMap2.put("Age", 24.0);
		peopleMap2.put("gender", "female");
		peopleMap2.put("status", "retiree");
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put("people/Salary", new SBigDecimal(33000));
		peopleMap3.put("people/BasicAmt", new SBigDecimal(33000));
		peopleMap3.put("Age", 26.0);
		peopleMap3.put("gender", "male");
		peopleMap3.put("status", "active");
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put("people/Salary", new SBigDecimal(34000));
		peopleMap4.put("people/BasicAmt", new SBigDecimal(34000));
		peopleMap4.put("Age", 28.0);
		peopleMap4.put("gender", "female");
		peopleMap4.put("status", "retiree");
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put("people/Salary", new SBigDecimal(35000));
		peopleMap5.put("people/BasicAmt", new SBigDecimal(35000));
		peopleMap5.put("Age", 26.0);
		peopleMap5.put("gender", "male");
		peopleMap5.put("status", "active");
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put("people/Salary", new SBigDecimal(36000));
		peopleMap6.put("people/BasicAmt", new SBigDecimal(36000));
		peopleMap6.put("Age", 26.0);
		peopleMap6.put("gender", "female");
		peopleMap6.put("status", "retiree");
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put("people/Salary", new SBigDecimal(37000));
		peopleMap7.put("people/BasicAmt", new SBigDecimal(37000));
		peopleMap7.put("Age", 22.0);
		peopleMap7.put("gender", "male");
		peopleMap7.put("status", "active");
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put("people/Salary", new SBigDecimal(38000));
		peopleMap8.put("people/BasicAmt", new SBigDecimal(38000));
		peopleMap8.put("Age", 24.0);
		peopleMap8.put("gender", "female");
		peopleMap8.put("status", "retiree");
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put("people/Salary", new SBigDecimal(39000));
		peopleMap9.put("people/BasicAmt", new SBigDecimal(39000));
		peopleMap9.put("Age", 27.0);
		peopleMap9.put("gender", "male");
		peopleMap9.put("status", "active");
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put("people/Salary", new SBigDecimal(40000));
		peopleMap10.put("people/BasicAmt", new SBigDecimal(40000));
		peopleMap10.put("Age", 25.0);
		peopleMap10.put("gender", "female");
		peopleMap10.put("status", "retiree");
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);

	}
}
