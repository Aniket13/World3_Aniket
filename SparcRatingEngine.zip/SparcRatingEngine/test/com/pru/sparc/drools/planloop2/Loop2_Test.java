package com.pru.sparc.drools.planloop2;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class Loop2_Test {

	RatingCalculationTest rateCal = new RatingCalculationTest();

	@Test
	public void test_plan_Average_Salary_Factor_Step_3() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");

		SBigDecimal holding_Average_Salary_Factor_Step_2 = new SBigDecimal(
				"11.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("holding_Average_Salary_Factor_Step_2",
				holding_Average_Salary_Factor_Step_2);

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);

		 RuleUtility.getInitsData("DT","basiclife//loop2//BL_plan_Average_Salary_Factor_Step_3.xls","plan-Average-Salary-Factor-Step-3",new
		 Object[]{plan1,holding});

		/*rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
*/
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Compsych_Rate() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");

		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");

		SBigDecimal holding_Ratio_Retiree_to_Total_Lives = new SBigDecimal(
				"122.00");
		SBigDecimal holding_Ratio_Retiree_to_Total_Volume = new SBigDecimal(
				"123.00");
		SBigDecimal holding_Client_Pooling_Point__Step_2 = new SBigDecimal(
				"124.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("holding_Compsych_Rate",
				holding_Compsych_Rate);

		holding.getHoldingMap().put("holding_Ratio_Retiree_to_Total_Lives",
				holding_Ratio_Retiree_to_Total_Lives);
		holding.getHoldingMap().put("holding_Ratio_Retiree_to_Total_Volume",
				holding_Ratio_Retiree_to_Total_Volume);
		holding.getHoldingMap().put("holding_Client_Pooling_Point__Step_2",
				holding_Client_Pooling_Point__Step_2);

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Initial_Inforce_Rate_Rule1() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("100011.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("20000.00");
		SBigDecimal planGuaranteeIssueDollarAmt = new SBigDecimal("40");
		SBigDecimal plan_Non_Medical_Max = new SBigDecimal("444440");
		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");
		SBigDecimal plan_Guarantee_Issue__Step_1 = new SBigDecimal("4005.00");
		SBigDecimal People_Loop_1 = new SBigDecimal("3005.00");

		SBigDecimal plan_Initial_Inforce_Rate_NonAgeBanded_Step_1 = new SBigDecimal(
				"0");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/GuaranteeIssueDollarAmt",
				planGuaranteeIssueDollarAmt);
		planMap1.put("plan_Non_Medical_Max", plan_Non_Medical_Max);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		planMap1.put("plan_Guarantee_Issue__Step_1",
				plan_Guarantee_Issue__Step_1);
		planMap1.put("People_Loop_1", People_Loop_1);
		planMap1.put("plan_Initial_Inforce_Rate_NonAgeBanded_Step_1",
				plan_Initial_Inforce_Rate_NonAgeBanded_Step_1);

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("holding/Renewal", "RenewalYes");

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");

		/*
		 *  * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Initial_Inforce_Rate_Rule2() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");
		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("100011.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("20000.00");
		SBigDecimal planGuaranteeIssueDollarAmt = new SBigDecimal("40");
		SBigDecimal plan_Non_Medical_Max = new SBigDecimal("444440");
		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");
		SBigDecimal plan_Guarantee_Issue__Step_1 = new SBigDecimal("4005.00");
		SBigDecimal People_Loop_1 = new SBigDecimal("3005.00");

		SBigDecimal plan_Initial_Inforce_Rate_NonAgeBanded_Step_1 = new SBigDecimal(
				"1");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/GuaranteeIssueDollarAmt",
				planGuaranteeIssueDollarAmt);
		planMap1.put("plan_Non_Medical_Max", plan_Non_Medical_Max);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		planMap1.put("plan_Guarantee_Issue__Step_1",
				plan_Guarantee_Issue__Step_1);
		planMap1.put("People_Loop_1", People_Loop_1);
		planMap1.put("plan_Initial_Inforce_Rate_NonAgeBanded_Step_1",
				plan_Initial_Inforce_Rate_NonAgeBanded_Step_1);

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("holding/Renewal", "RenewalYes");

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");

		/*
		 *  * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Initial_Inforce_Rate_Rule3() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");
		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("100011.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("20000.00");
		SBigDecimal planGuaranteeIssueDollarAmt = new SBigDecimal("40");
		SBigDecimal plan_Non_Medical_Max = new SBigDecimal("444440");
		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");
		SBigDecimal plan_Guarantee_Issue__Step_1 = new SBigDecimal("4005.00");
		SBigDecimal People_Loop_1 = new SBigDecimal("3005.00");

		SBigDecimal plan_Initial_Inforce_Rate_NonAgeBanded_Step_1 = new SBigDecimal(
				"0");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/GuaranteeIssueDollarAmt",
				planGuaranteeIssueDollarAmt);
		planMap1.put("plan_Non_Medical_Max", plan_Non_Medical_Max);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		planMap1.put("plan_Guarantee_Issue__Step_1",
				plan_Guarantee_Issue__Step_1);
		planMap1.put("People_Loop_1", People_Loop_1);
		planMap1.put("plan_Initial_Inforce_Rate_NonAgeBanded_Step_1",
				plan_Initial_Inforce_Rate_NonAgeBanded_Step_1);

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("holding/Rating_Type", "Rating_Type_PIA");

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");

		/*
		 *  * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Initial_Inforce_Rate_Rule4() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");
		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("100011.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("20000.00");
		SBigDecimal planGuaranteeIssueDollarAmt = new SBigDecimal("40");
		SBigDecimal plan_Non_Medical_Max = new SBigDecimal("444440");
		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");
		SBigDecimal plan_Guarantee_Issue__Step_1 = new SBigDecimal("4005.00");
		SBigDecimal People_Loop_1 = new SBigDecimal("3005.00");

		SBigDecimal plan_Initial_Inforce_Rate_NonAgeBanded_Step_1 = new SBigDecimal(
				"1");

		SBigDecimal holding_Total_Lives_For_All_Plans = new SBigDecimal("0");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/GuaranteeIssueDollarAmt",
				planGuaranteeIssueDollarAmt);
		planMap1.put("plan_Non_Medical_Max", plan_Non_Medical_Max);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		planMap1.put("plan_Guarantee_Issue__Step_1",
				plan_Guarantee_Issue__Step_1);
		planMap1.put("People_Loop_1", People_Loop_1);
		planMap1.put("plan_Initial_Inforce_Rate_NonAgeBanded_Step_1",
				plan_Initial_Inforce_Rate_NonAgeBanded_Step_1);

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("holding/Rating_Type", "Rating_Type_PIA");
		holding.getHoldingMap().put("holding_Total_Lives_For_All_Plans",
				holding_Total_Lives_For_All_Plans);

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");

		/*
		 *  * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Initial_Inforce_Rate_Rule5() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("100011.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("20000.00");
		SBigDecimal planGuaranteeIssueDollarAmt = new SBigDecimal("40");
		SBigDecimal plan_Non_Medical_Max = new SBigDecimal("444440");
		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");
		SBigDecimal plan_Guarantee_Issue__Step_1 = new SBigDecimal("4005.00");
		SBigDecimal People_Loop_1 = new SBigDecimal("3005.00");

		SBigDecimal plan_Initial_Inforce_Rate_NonAgeBanded_Step_1 = new SBigDecimal(
				"1");

		SBigDecimal holding_Total_Lives_For_All_Plans = new SBigDecimal("1");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/GuaranteeIssueDollarAmt",
				planGuaranteeIssueDollarAmt);
		planMap1.put("plan_Non_Medical_Max", plan_Non_Medical_Max);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		planMap1.put("plan_Guarantee_Issue__Step_1",
				plan_Guarantee_Issue__Step_1);
		planMap1.put("People_Loop_1", People_Loop_1);
		planMap1.put("plan_Initial_Inforce_Rate_NonAgeBanded_Step_1",
				plan_Initial_Inforce_Rate_NonAgeBanded_Step_1);

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("holding/Renewal", "NotRenewalYes");
		holding.getHoldingMap()
				.put("holding/Rating_Type", "NotRating_Type_PIA");
		holding.getHoldingMap().put("holding_Total_Lives_For_All_Plans",
				holding_Total_Lives_For_All_Plans);

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");

		/*
		 *  * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Pooling_Point() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"251000");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put(
				"holding_Total_Covered_Volume_For_All_Plans",
				holding_Total_Covered_Volume_For_All_Plans);

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");

		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Non_Medical_Max__Step_1_Rule1() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Client_Pooling_Point__Step_2 = new SBigDecimal(
				"305.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);

		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Non_Medical_Max__Step_1_Rule2() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("200000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Client_Pooling_Point__Step_2 = new SBigDecimal(
				"305.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);

		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Non_Medical_Max_Rule1() {

		// Here Input from holding map and output to plan map required

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("1000.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("10000.00");

		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");

		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");

		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		// planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Non_Medical_Max_Rule2() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("10001.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("10000.00");

		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");

		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");

		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		// planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Non_Medical_Max_Rule3() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("1000.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("10000.00");

		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");

		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");

		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		// planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Non_Medical_Max_Rule4() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("10001.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("10000.00");

		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");

		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");

		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		// planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Guarantee_Issue__Step_1_Rule1() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("100011.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("20000.00");
		SBigDecimal planGuaranteeIssueDollarAmt = new SBigDecimal("20");
		SBigDecimal plan_Non_Medical_Max = new SBigDecimal("444440");
		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/GuaranteeIssueDollarAmt",
				planGuaranteeIssueDollarAmt);
		planMap1.put("plan_Non_Medical_Max", plan_Non_Medical_Max);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Guarantee_Issue__Step_1_Rule2() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("100011.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("20000.00");
		SBigDecimal planGuaranteeIssueDollarAmt = new SBigDecimal("40");
		SBigDecimal plan_Non_Medical_Max = new SBigDecimal("444440");
		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/GuaranteeIssueDollarAmt",
				planGuaranteeIssueDollarAmt);
		planMap1.put("plan_Non_Medical_Max", plan_Non_Medical_Max);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	@Test
	public void Test_plan_Guarantee_Issue() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("500000.00");

		SBigDecimal plan_Non_Medical_Max__Step_1 = new SBigDecimal("100011.00");
		SBigDecimal plan_Non_Medical_Max__Step_2 = new SBigDecimal("20000.00");
		SBigDecimal planGuaranteeIssueDollarAmt = new SBigDecimal("40");
		SBigDecimal plan_Non_Medical_Max = new SBigDecimal("444440");
		SBigDecimal planMAXAmt = new SBigDecimal("2000000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Compsych_Rate = new SBigDecimal("121.00");
		SBigDecimal holding_Total_Covered_Volume_For_All_Plans = new SBigDecimal(
				"3005.00");
		SBigDecimal plan_Guarantee_Issue__Step_1 = new SBigDecimal("4005.00");
		SBigDecimal People_Loop_1 = new SBigDecimal("3005.00");

		int peopleCount = 1;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/VolumeType", "SystemCalculated");
		planMap1.put("plan/PlanType", "MultipleEarnings_FlatAmt");
		planMap1.put("plan/CaseFlatAmt", planCaseFlatAmt);
		planMap1.put("plan_Non_Medical_Max__Step_1",
				plan_Non_Medical_Max__Step_1);
		planMap1.put("plan_Non_Medical_Max__Step_2",
				plan_Non_Medical_Max__Step_2);
		planMap1.put("plan/GuaranteeIssueDollarAmt",
				planGuaranteeIssueDollarAmt);
		planMap1.put("plan_Non_Medical_Max", plan_Non_Medical_Max);
		planMap1.put("plan/MAX", planMAXAmt);
		planMap1.put("plan/EarningsFactor", planEarningsFactor);
		planMap1.put("plan/ContractState", "OtherProvinces");
		planMap1.put("plan/MIN", planMINAmt);
		planMap1.put("RoundingSelection", planRoundingSelection);
		planMap1.put("EffectiveDate", "07/30/2016");
		planMap1.put("plan/RoundingOccurs", "DoesNotApply");
		planMap1.put("plan/AgeReductionSchedule", "Sched1");
		planMap1.put("plan_Guarantee_Issue__Step_1",
				plan_Guarantee_Issue__Step_1);
		planMap1.put("People_Loop_1", People_Loop_1);

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object
		holding.setCensus(census);
		rateCal.invokeRatingEngine(holding,
				"basiclife//loop2//BL_Plan_Loop2.drl", "plan-loop2");
		/*
		 * assertEquals(
		 * "When:people_Census_Salary=0 Calculated people_Average_Salary_Factor_Step_1 not matched with expected"
		 * , 1, holding.getCensus().censusMap
		 * .get("people_Average_Salary_Factor_Step_1"));
		 */

	}

	private ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
			// FactLookupUtility.showMap(peopleList.get(i).getPeopleMap());
		}

		return peopleList;
	}

	private Person getPersonObject(int position) {
		// System.out.println("person object created");
		List<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Salary", new BigDecimal(31000));
		peopleMap1.put("people/BasicAmt", new BigDecimal(31000));
		peopleMap1.put("Age", 22.0);
		peopleMap1.put("gender", "male");
		peopleMap1.put("status", "active");
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put("people/Salary", new BigDecimal(32000));
		peopleMap2.put("people/BasicAmt", new BigDecimal(32000));
		peopleMap2.put("Age", 24.0);
		peopleMap2.put("gender", "female");
		peopleMap2.put("status", "retiree");
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put("people/Salary", new BigDecimal(33000));
		peopleMap3.put("people/BasicAmt", new BigDecimal(33000));
		peopleMap3.put("Age", 26.0);
		peopleMap3.put("gender", "male");
		peopleMap3.put("status", "active");
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put("people/Salary", new BigDecimal(34000));
		peopleMap4.put("people/BasicAmt", new BigDecimal(34000));
		peopleMap4.put("Age", 28.0);
		peopleMap4.put("gender", "female");
		peopleMap4.put("status", "retiree");
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put("people/Salary", new BigDecimal(35000));
		peopleMap5.put("people/BasicAmt", new BigDecimal(35000));
		peopleMap5.put("Age", 30.0);
		peopleMap5.put("gender", "male");
		peopleMap5.put("status", "active");
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put("people/Salary", new BigDecimal(36000));
		peopleMap6.put("people/BasicAmt", new BigDecimal(36000));
		peopleMap6.put("Age", 32.0);
		peopleMap6.put("gender", "female");
		peopleMap6.put("status", "retiree");
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put("people/Salary", new BigDecimal(37000));
		peopleMap7.put("people/BasicAmt", new BigDecimal(37000));
		peopleMap7.put("Age", 34.0);
		peopleMap7.put("gender", "male");
		peopleMap7.put("status", "active");
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put("people/Salary", new BigDecimal(38000));
		peopleMap8.put("people/BasicAmt", new BigDecimal(38000));
		peopleMap8.put("Age", 36.0);
		peopleMap8.put("gender", "female");
		peopleMap8.put("status", "retiree");
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put("people/Salary", new BigDecimal(39000));
		peopleMap9.put("people/BasicAmt", new BigDecimal(39000));
		peopleMap9.put("Age", 38.0);
		peopleMap9.put("gender", "male");
		peopleMap9.put("status", "active");
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put("people/Salary", new BigDecimal(40000));
		peopleMap10.put("people/BasicAmt", new BigDecimal(40000));
		peopleMap10.put("Age", 40.0);
		peopleMap10.put("gender", "female");
		peopleMap10.put("status", "retiree");
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);

	}

}
