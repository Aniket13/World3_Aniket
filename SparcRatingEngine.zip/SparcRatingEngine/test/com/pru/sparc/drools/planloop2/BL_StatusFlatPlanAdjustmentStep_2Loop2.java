package com.pru.sparc.drools.planloop2;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_StatusFlatPlanAdjustmentStep_2Loop2 {

	RatingCalculationTest rateCal = new RatingCalculationTest();

	@Test
	public void testStatusFlatPlanAdjustmentStep_2_Rule1() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");

		SBigDecimal holding_Average_Salary_Factor_Step_2 = new SBigDecimal(
				"11.00");

		int peopleCount = 2;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("PlanType", "FlatAmt");
		planMap1.put("EffectiveDate", "07/23/2016");
		planMap1.put("State", "AL");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		censusMap.put("status_Optional_Life_Adjustment_Step_2",
				new SBigDecimal("1000"));

		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("OLQuoted", "OLQuotedY");
		holding.getHoldingMap().put("Life_100_Pilot", "Life_100_Pilot_Yes");
		holding.getHoldingMap().put("holding_Total_Number_Of_Plans",
				new SBigDecimal("1"));

		// holding.getHoldingMap().put("holding/Life_100_Pilot","Life_100_Pilot_No");

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		// Set census to holding object

		holding.setCensus(census);
		holding.setCount(0);

		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_StatusFlatPlanAdjustmentStep_2Loop2.xls",
				"", new Object[] { holding });

		assertEquals("Check:status_Flat_Plan_Adjustment_Step_2",
				new SBigDecimal("1.08"), ((SBigDecimal) census.getCensusMap()
						.get("status_Flat_Plan_Adjustment_Step_2")));

		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(holding.getCensus().getCensusMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());

	}

	@Test
	public void testStatusFlatPlanAdjustmentStep_2_Rule2() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");

		SBigDecimal holding_Average_Salary_Factor_Step_2 = new SBigDecimal(
				"11.00");

		int peopleCount = 2;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("PlanType", "MultipleEarnings");
		planMap1.put("EffectiveDate", "07/23/2016");
		planMap1.put("State", "AL");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		censusMap.put("status_Optional_Life_Adjustment_Step_2",
				new SBigDecimal("1000"));

		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("OLQuoted", "OLQuotedY");
		holding.getHoldingMap().put("Life_100_Pilot", "Life_100_Pilot_Yes");
		holding.getHoldingMap().put("holding_Total_Number_Of_Plans",
				new SBigDecimal("1"));

		// holding.getHoldingMap().put("holding/Life_100_Pilot","Life_100_Pilot_No");

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		// Set census to holding object

		holding.setCensus(census);
		holding.setCount(0);

		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_StatusFlatPlanAdjustmentStep_2Loop2.xls",
				"", new Object[] { holding });

		assertEquals(
				"Check:status_Flat_Plan_Adjustment_Step_2",
				new SBigDecimal("1"),
				((SBigDecimal) census.getCensusMap().get(
						"status_Flat_Plan_Adjustment_Step_2")));

		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(holding.getCensus().getCensusMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());

	}

	private ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
			// FactLookupUtility.showMap(peopleList.get(i).getPeopleMap());
		}

		return peopleList;
	}

	private Person getPersonObject(int position) {
		// System.out.println("person object created");
		List<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Salary", new BigDecimal(31000));
		peopleMap1.put("people/BasicAmt", new BigDecimal(31000));
		peopleMap1.put("Age", 22.0);
		peopleMap1.put("gender", "Male");
		peopleMap1.put("status", "Retiree");
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put("people/Salary", new BigDecimal(32000));
		peopleMap2.put("people/BasicAmt", new BigDecimal(32000));
		peopleMap2.put("Age", 24.0);
		peopleMap2.put("gender", "Female");
		peopleMap2.put("status", "Active");
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put("people/Salary", new BigDecimal(33000));
		peopleMap3.put("people/BasicAmt", new BigDecimal(33000));
		peopleMap3.put("Age", 26.0);
		peopleMap3.put("gender", "Male");
		peopleMap3.put("status", "Active");
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put("people/Salary", new BigDecimal(34000));
		peopleMap4.put("people/BasicAmt", new BigDecimal(34000));
		peopleMap4.put("Age", 28.0);
		peopleMap4.put("gender", "female");
		peopleMap4.put("status", "retiree");
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put("people/Salary", new BigDecimal(35000));
		peopleMap5.put("people/BasicAmt", new BigDecimal(35000));
		peopleMap5.put("Age", 30.0);
		peopleMap5.put("gender", "male");
		peopleMap5.put("status", "active");
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put("people/Salary", new BigDecimal(36000));
		peopleMap6.put("people/BasicAmt", new BigDecimal(36000));
		peopleMap6.put("Age", 32.0);
		peopleMap6.put("gender", "female");
		peopleMap6.put("status", "retiree");
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put("people/Salary", new BigDecimal(37000));
		peopleMap7.put("people/BasicAmt", new BigDecimal(37000));
		peopleMap7.put("Age", 34.0);
		peopleMap7.put("gender", "male");
		peopleMap7.put("status", "active");
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put("people/Salary", new BigDecimal(38000));
		peopleMap8.put("people/BasicAmt", new BigDecimal(38000));
		peopleMap8.put("Age", 36.0);
		peopleMap8.put("gender", "female");
		peopleMap8.put("status", "retiree");
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put("people/Salary", new BigDecimal(39000));
		peopleMap9.put("people/BasicAmt", new BigDecimal(39000));
		peopleMap9.put("Age", 38.0);
		peopleMap9.put("gender", "male");
		peopleMap9.put("status", "active");
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put("people/Salary", new BigDecimal(40000));
		peopleMap10.put("people/BasicAmt", new BigDecimal(40000));
		peopleMap10.put("Age", 40.0);
		peopleMap10.put("gender", "female");
		peopleMap10.put("status", "retiree");
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);

	}

}
