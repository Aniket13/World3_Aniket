package com.pru.sparc.drools.planloop2;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;


public class BL_StatusFlatPlanAdjustmentStep_3Loop2 {

	RatingCalculationTest rateCal = new RatingCalculationTest();

	@Test
	public void testStatusFlatPlanAdjustmentStep3Rule_1() {

		
		SBigDecimal planCaseFlatAmt = new SBigDecimal("1");

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("PlanType", "MultipleEarnings");
		planMap1.put("EffectiveDate", "07/23/2016");
		planMap1.put("ContractState", "AL");
		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);

		// Initiate holding object
		Holding holding = new Holding();

		holding.getHoldingMap().put("OLQuoted", "OLQuotedY");
		holding.getHoldingMap().put("Life_100_Pilot",
				"Life_100_Pilot_Yes");
		//holding.getHoldingMap().put("holding_Under_100_Pilot_Case_Indicator", planCaseFlatAmt);
		holding.getHoldingMap().put("holding_Set_Plans_Type", new SBigDecimal("3.0"));
		
		

		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
		holding.setCount(0);
		holding.setPeopleCount(0);
		

		// set people attributes
		
		Census census = new Census();
		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Salary", new BigDecimal(31000));
		peopleMap1.put("people/BasicAmt", new BigDecimal(31000));
		peopleMap1.put("Age", 22.0);
		peopleMap1.put("gender", "Male");
		peopleMap1.put("status", "Active");
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);
		ArrayList<Person> listOfPeople = new ArrayList<Person>();
		listOfPeople.add(person1);
		census.setListOfPeople(listOfPeople);
		//holding.setCensus(census);
		plan1.setCensus(census);
		
		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_StatusFlatPlanAdjustmentStep_3Loop2.xls",
				"", new Object[] {holding,plan1});
		
		assertEquals(
				"Check:status_Flat_Plan_Adjustment_Step_3",
				new SBigDecimal("1"),
				((SBigDecimal) census.getCensusMap().get(
						"status_Flat_Plan_Adjustment_Step_3")));

		/*System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(holding.getCensus().getCensusMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());*/

	}
	

}
