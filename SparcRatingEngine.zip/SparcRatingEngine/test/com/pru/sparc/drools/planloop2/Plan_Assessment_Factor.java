package com.pru.sparc.drools.planloop2;

public class Plan_Assessment_Factor {

}
