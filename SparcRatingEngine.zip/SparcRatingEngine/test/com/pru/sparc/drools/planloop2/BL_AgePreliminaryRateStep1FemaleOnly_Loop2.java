package com.pru.sparc.drools.planloop2;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Census;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Person;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.SBigDecimal;

public class BL_AgePreliminaryRateStep1FemaleOnly_Loop2 {

	RatingCalculationTest rateCal = new RatingCalculationTest();

	@Test
	public void test_AgePreliminaryRateStep1FemaleOnly_Rule_1() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Average_Salary_Factor_Step_2 = new SBigDecimal(
				"11.00");

		SBigDecimal holding_Total_Lives_For_All_Plans = new SBigDecimal("2345");
		SBigDecimal holding_Composite_Female_Pct_Ignoring_Composite_Setting = new SBigDecimal("200");

		int peopleCount = 2;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/PlanType", "MultipleEarnings");
		planMap1.put("EffectiveDate", "07/25/2016");
		planMap1.put("plan/DisabilitySchedule", "DisabilityNone");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();
		
		holding.getHoldingMap().put("holding/Life_100_Pilot","Life_100_Pilot_Yes");
		holding.getHoldingMap().put("holding_Composite_Female_Pct_Ignoring_Composite_Setting",holding_Composite_Female_Pct_Ignoring_Composite_Setting);

		
		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object

		holding.setCensus(census);
		
		Person person = (Person)holding.getCensus().getListOfPeople().get(0);
		
		census.setListOfPeople(getCensusWithEmployees(peopleCount));
		
		

		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_AgePreliminaryRateStep1FemaleOnly.xls",
				"age-preliminary-rate-step1-female-only", new Object[] {holding,plan,person});

		assertEquals(
				"Check:age_Preliminary_Rate_Step1_FemaleOnly",
				new SBigDecimal("3.000"),
				((SBigDecimal)holding.getCensus().getCensusMap().get("age_Preliminary_Rate_Step1_FemaleOnly")));

		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(holding.getCensus().getCensusMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());

	}
	
	@Test
	public void test_AgePreliminaryRateStep1FemaleOnly_Rule_2() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Average_Salary_Factor_Step_2 = new SBigDecimal(
				"11.00");

		SBigDecimal holding_Total_Lives_For_All_Plans = new SBigDecimal("2345");
		SBigDecimal holding_Composite_Female_Pct_Ignoring_Composite_Setting = new SBigDecimal("300");

		int peopleCount = 2;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/PlanType", "MultipleEarnings");
		planMap1.put("EffectiveDate", "07/25/2016");
		planMap1.put("plan/DisabilitySchedule", "NotDisabilityNone");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();
		
		holding.getHoldingMap().put("holding/Life_100_Pilot","Life_100_Pilot_Yes");
		holding.getHoldingMap().put("holding_Composite_Female_Pct_Ignoring_Composite_Setting",holding_Composite_Female_Pct_Ignoring_Composite_Setting);

		
		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object

		holding.setCensus(census);
		
		Person person = (Person)holding.getCensus().getListOfPeople().get(0);
		
		census.setListOfPeople(getCensusWithEmployees(peopleCount));
		
		

		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_AgePreliminaryRateStep1FemaleOnly.xls",
				"age-preliminary-rate-step1-female-only", new Object[] {holding,plan,person});

		assertEquals(
				"Check:age_Preliminary_Rate_Step1_FemaleOnly",
				new SBigDecimal("4.800"),
				((SBigDecimal)holding.getCensus().getCensusMap().get("age_Preliminary_Rate_Step1_FemaleOnly")));

		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(holding.getCensus().getCensusMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());

	}
	
	@Test
	public void test_AgePreliminaryRateStep1FemaleOnly_Rule_3() {

		SBigDecimal planCaseFlatAmt = new SBigDecimal("100000.00");
		SBigDecimal planEarningsFactor = new SBigDecimal("111.0");
		SBigDecimal planMAXAmt = new SBigDecimal("1000000.00");
		SBigDecimal planMINAmt = new SBigDecimal("1");
		SBigDecimal planRoundingSelection = new SBigDecimal("6");
		SBigDecimal censusSalaryEstimate = new SBigDecimal("10000.00");
		SBigDecimal holding_Average_Salary_Factor_Step_2 = new SBigDecimal(
				"11.00");

		SBigDecimal holding_Total_Lives_For_All_Plans = new SBigDecimal("2345");
		int peopleCount = 2;

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put("plan/PlanType", "MultipleEarnings");
		planMap1.put("EffectiveDate", "07/25/2016");
		planMap1.put("plan/DisabilitySchedule", "NotDisabilityNone");
		
		Plan plan = new Plan();
		plan.setPlanMap(planMap1);

		// Initiate Census parameters
		Census census = new Census();
		HashMap<String, Object> censusMap = new HashMap<String, Object>();
		censusMap.put("SalarySetForAll", "Y");
		censusMap.put("SalaryEstimate", censusSalaryEstimate);
		censusMap.put("people_Census_Salary", 0);
		census.setCensusMap(censusMap);
		census.setListOfPeople(getCensusWithEmployees(peopleCount));

		// Initiate holding object
		Holding holding = new Holding();
		
		holding.getHoldingMap().put("holding/Life_100_Pilot","Life_100_Pilot_Yes");
		

		
		// Set plan to holding object
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan);
		holding.setListOfPlans(listOfPlans);

		// Set census to holding object

		holding.setCensus(census);
		
		Person person = (Person)holding.getCensus().getListOfPeople().get(1);
		
		census.setListOfPeople(getCensusWithEmployees(peopleCount));
		
		

		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_AgePreliminaryRateStep1FemaleOnly.xls",
				"age-preliminary-rate-step1-female-only", new Object[] {holding,plan,person});

		assertEquals(
				"Check:age_Preliminary_Rate_Step1_FemaleOnly",
				new SBigDecimal("0"),
				((SBigDecimal)holding.getCensus().getCensusMap().get("age_Preliminary_Rate_Step1_FemaleOnly")));

		System.out.println("-----------------Holding Map--------------------");
		RatingCalculationTest.showMap(holding.getHoldingMap());
		System.out.println("-----------------Census Map--------------------");
		RatingCalculationTest.showMap(holding.getCensus().getCensusMap());
		System.out.print("-----------------Plan Map--------------------");
		RatingCalculationTest.showMap(((Plan) (holding.getListOfPlans()
				.get(holding.getCount()))).getPlanMap());

	}

	private ArrayList<Person> getCensusWithEmployees(int count) {
		ArrayList<Person> peopleList = new ArrayList<Person>();
		for (int i = 0; i < count; i++) {
			peopleList.add(getPersonObject(i % 10));
			// FactLookupUtility.showMap(peopleList.get(i).getPeopleMap());
		}

		return peopleList;
	}

	private Person getPersonObject(int position) {
		// System.out.println("person object created");
		List<Person> listPerson = new ArrayList<Person>();

		HashMap<String, Object> peopleMap1 = new HashMap<String, Object>();
		peopleMap1.put("people/Salary", new SBigDecimal("31000"));
		peopleMap1.put("people/BasicAmt", new SBigDecimal("31000"));
		peopleMap1.put("Age",  22.0);
		peopleMap1.put("gender", "Female");
		peopleMap1.put("status", "retiree");
		Person person1 = new Person();
		person1.setPeopleMap(peopleMap1);

		HashMap<String, Object> peopleMap2 = new HashMap<String, Object>();
		peopleMap2.put("people/Salary", new SBigDecimal("32000"));
		peopleMap2.put("people/BasicAmt", new SBigDecimal("32000"));
		peopleMap2.put("Age", 24.0);
		peopleMap2.put("gender", "Male");
		peopleMap2.put("status", "retiree");
		Person person2 = new Person();
		person2.setPeopleMap(peopleMap2);

		HashMap<String, Object> peopleMap3 = new HashMap<String, Object>();
		peopleMap3.put("people/Salary", new SBigDecimal("33000"));
		peopleMap3.put("people/BasicAmt", new SBigDecimal("33000"));
		peopleMap3.put("Age", new BigDecimal(26.0));
		peopleMap3.put("gender", "Female");
		peopleMap3.put("status", "active");
		Person person3 = new Person();
		person3.setPeopleMap(peopleMap3);

		HashMap<String, Object> peopleMap4 = new HashMap<String, Object>();
		peopleMap4.put("people/Salary", new SBigDecimal("34000"));
		peopleMap4.put("people/BasicAmt", new SBigDecimal("34000"));
		peopleMap4.put("Age", 28.0);
		peopleMap4.put("gender", "female");
		peopleMap4.put("status", "retiree");
		Person person4 = new Person();
		person4.setPeopleMap(peopleMap4);

		HashMap<String, Object> peopleMap5 = new HashMap<String, Object>();
		peopleMap5.put("people/Salary", new SBigDecimal("35000"));
		peopleMap5.put("people/BasicAmt", new SBigDecimal("35000"));
		peopleMap5.put("Age", 30.0);
		peopleMap5.put("gender", "male");
		peopleMap5.put("status", "active");
		Person person5 = new Person();
		person5.setPeopleMap(peopleMap5);

		HashMap<String, Object> peopleMap6 = new HashMap<String, Object>();
		peopleMap6.put("people/Salary", new SBigDecimal("36000"));
		peopleMap6.put("people/BasicAmt", new SBigDecimal("36000"));
		peopleMap6.put("Age", 32.0);
		peopleMap6.put("gender", "female");
		peopleMap6.put("status", "retiree");
		Person person6 = new Person();
		person6.setPeopleMap(peopleMap6);

		HashMap<String, Object> peopleMap7 = new HashMap<String, Object>();
		peopleMap7.put("people/Salary", new SBigDecimal("37000"));
		peopleMap7.put("people/BasicAmt", new SBigDecimal("37000"));
		peopleMap7.put("Age", 34.0);
		peopleMap7.put("gender", "male");
		peopleMap7.put("status", "active");
		Person person7 = new Person();
		person7.setPeopleMap(peopleMap7);

		HashMap<String, Object> peopleMap8 = new HashMap<String, Object>();
		peopleMap8.put("people/Salary", new SBigDecimal("38000"));
		peopleMap8.put("people/BasicAmt", new SBigDecimal("38000"));
		peopleMap8.put("Age", 36.0);
		peopleMap8.put("gender", "female");
		peopleMap8.put("status", "retiree");
		Person person8 = new Person();
		person8.setPeopleMap(peopleMap8);

		HashMap<String, Object> peopleMap9 = new HashMap<String, Object>();
		peopleMap9.put("people/Salary", new SBigDecimal("39000"));
		peopleMap9.put("people/BasicAmt", new SBigDecimal("39000"));
		peopleMap9.put("Age", 38.0);
		peopleMap9.put("gender", "male");
		peopleMap9.put("status", "active");
		Person person9 = new Person();
		person9.setPeopleMap(peopleMap9);

		HashMap<String, Object> peopleMap10 = new HashMap<String, Object>();
		peopleMap10.put("people/Salary", new SBigDecimal("40000"));
		peopleMap10.put("people/BasicAmt", new SBigDecimal("40000"));
		peopleMap10.put("Age", 40.0);
		peopleMap10.put("gender", "female");
		peopleMap10.put("status", "retiree");
		Person person10 = new Person();
		person10.setPeopleMap(peopleMap10);

		listPerson.add(person1);
		listPerson.add(person2);
		listPerson.add(person3);
		listPerson.add(person4);
		listPerson.add(person5);
		listPerson.add(person6);
		listPerson.add(person7);
		listPerson.add(person8);
		listPerson.add(person9);
		listPerson.add(person10);
		return listPerson.get(position);

	}

}
