package com.pru.sparc.drools.planloop2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;

public class PlanTotalBenefitChargesTest {

	@Test
	public void testPlanTotalBenefitCharges() {

		SBigDecimal planMargin = new SBigDecimal("5");

		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put(PlanConstants.PLAN_MARGIN, planMargin);

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		Holding holding = new Holding();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
	
		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_plan_Total_Benefit_Charges__Step_1.xls",
				"agenda_plan_Total_Benefit_Charges__Step_1",
				new Object[] { holding });
		
		RatingCalculationTest.showMap(planMap1);
		

	}
}
