package com.pru.sparc.drools.planloop2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

import com.pru.sparc.drools.aggregator.RatingCalculationTest;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;

public class PlanMiscellaneousTaxTest {

	@Test
	public void TestPlanMiscellaneousTax() {



		// Initiate Plan parameters
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		planMap1.put(PlanConstants.PLAN_EFFECTIVEDATE, "07/30/1991");
		planMap1.put(PlanConstants.PLAN_CONTRACT_STATE, "OtherProvinces");
		

		Plan plan1 = new Plan();
		plan1.setPlanMap(planMap1);
		Holding holding = new Holding();
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);
	
		RuleUtility.getInitsData("DT",
				"basiclife//loop2//BL_Plan_Miscellaneous_Tax.xls",
				"agenda_plan_Miscellaneous_Tax",
				new Object[] { holding });
		
		RatingCalculationTest.showMap(planMap1);
		
		
		

	}
}
