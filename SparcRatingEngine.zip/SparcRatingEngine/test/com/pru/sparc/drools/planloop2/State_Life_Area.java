package com.pru.sparc.drools.planloop2;

public class State_Life_Area {

}
