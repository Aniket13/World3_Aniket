package com.pru.sparc.drools.overRide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.junit.Test;
import com.pru.sparc.drools.common.util.RuleUtility;
import com.pru.sparc.drools.common.util.SparcRatingUtil;
import com.pru.sparc.drools.model.Holding;
import com.pru.sparc.drools.model.HoldingConstants;
import com.pru.sparc.drools.model.Plan;
import com.pru.sparc.drools.model.PlanConstants;
import com.pru.sparc.drools.model.SBigDecimal;
import com.pru.sparc.drools.model.StatusConstants;

public class BL_OverRideFeilds_Test {
	@Test
	public void test_BL_OverRideFeilds_Test() {

		SBigDecimal plan_Final_UW_Adjustment_Desired_Rate = new SBigDecimal(
				"200");

		Holding holding = new Holding();
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		HashMap<String, Object> overRideMap = new HashMap<String, Object>();

		overRideMap.put(PlanConstants.PLAN_FINAL_UW_ADJUSTMENT_DESIRED_RATE,
				plan_Final_UW_Adjustment_Desired_Rate);
		plan1.setOverRideMap(overRideMap);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);

		holding.setListOfPlans(listOfPlans);
		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4_Override//BL_plan_Regional_VP_Adjustment.xls",
						"", new Object[] { plan1 });
		SparcRatingUtil.showMap(plan1.getPlanMap());
	}

	@Test
	public void test_InitParams() {

		SBigDecimal plan_Override_75000_Postcalc_Step_1 = new SBigDecimal(
				"2100");
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Holding holding = new Holding();
		Plan plan1 = new Plan();
		HashMap<String, Object> overRideMap = new HashMap<String, Object>();

		overRideMap.put(PlanConstants.PLAN_OVERRIDE_75000_POSTCALC_STEP_1,
				plan_Override_75000_Postcalc_Step_1);
		plan1.setOverRideMap(overRideMap);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4_Override//BL_InitParams1.xls", "",
				new Object[] { plan1, holding });
		SparcRatingUtil.showMap(planMap1);
	}

	/*
	 * @Test public void test_Plan_Non_Medical_Max() {
	 * 
	 * SBigDecimal plan_Non_Medical_Max = new SBigDecimal( "210007");
	 * 
	 * Holding holding = new Holding();
	 * 
	 * HashMap<String, Object> overRideMap = new HashMap<String, Object>();
	 * 
	 * overRideMap.put(PlanConstants.PLAN_NON_MEDICAL_MAX,
	 * plan_Non_Medical_Max); holding.setOverRideMap(overRideMap);
	 * holding.getHoldingMap
	 * ().put(HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS, new
	 * SBigDecimal(1)); HashMap<String, Object> planMap1 = new HashMap<String,
	 * Object>(); Plan plan1 = new Plan();
	 * 
	 * plan1.setPlanMap(planMap1); List<Plan> listOfPlans = new
	 * ArrayList<Plan>(); listOfPlans.add(plan1);
	 * holding.setListOfPlans(listOfPlans);
	 * 
	 * RuleUtility.getInitsData("DT",
	 * "basiclife//loop4_Override//BL_plan_Non_Medical_Max.xls", "", new
	 * Object[] { holding });
	 * 
	 * SparcRatingUtil.showMap(planMap1);
	 * 
	 * }
	 */

	@Test
	public void test_Plan_Pooling_Point() {

		SBigDecimal plan_Pooling_Point = new SBigDecimal("210007");

		Holding holding = new Holding();

		HashMap<String, Object> overRideMap = new HashMap<String, Object>();

		overRideMap.put(PlanConstants.PLAN_POOLING_POINT, plan_Pooling_Point);

		holding.getHoldingMap().put(
				HoldingConstants.HOLDING_TOTAL_COVERED_VOLUME_FOR_ALL_PLANS,
				new SBigDecimal(1));
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		plan1.setOverRideMap(overRideMap);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4_Override//BL_plan_Pooling_Point.xls", "",
				new Object[] { plan1, holding });
		SparcRatingUtil.showMap(planMap1);
	}

	@Test
	public void test_Plan_BL_Exhibit_Estimated_Volume() {

		SBigDecimal Maximum_Allowable_Commissions = new SBigDecimal("210");

		Holding holding = new Holding();
		HashMap<String, Object> holdingMap = new HashMap<String, Object>();
		holdingMap.put(HoldingConstants.RENEWAL, "RenewalYes");

		holdingMap.put(
				HoldingConstants.HOLDING_TOTAL_TOTAL_LIVES_FOR_ALL_PLANS,
				new SBigDecimal(0));
		holding.setHoldingMap(holdingMap);
		HashMap<String, Object> overRideMap = new HashMap<String, Object>();

		overRideMap.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME,
				Maximum_Allowable_Commissions);

		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME_RENEWAL,
				new SBigDecimal(25));
		planMap1.put(PlanConstants.PLAN_INITIAL_INFORCE_VOLUME,
				new SBigDecimal(50));
		planMap1.put(PlanConstants.PLAN_BL_EXHIBIT_ESTIMATED_VOLUME_STEP_1,
				new SBigDecimal(75));

		plan1.setPlanMap(planMap1);
		plan1.setOverRideMap(overRideMap);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility
				.getInitsData(
						"DT",
						"basiclife//loop4_Override//BL_Plan_BL_Exhibit_Estimated_Volume.xls",
						"", new Object[] { holding, plan1 });

		SparcRatingUtil.showMap(planMap1);

	}

	@Test
	public void test_Status_Industry_Adjustment() {
		String status = "Active";
		SBigDecimal status_industry_adjustment = new SBigDecimal("210007");

		Holding holding = new Holding();

		HashMap<String, Object> overRideMap = new HashMap<String, Object>();

		overRideMap.put(StatusConstants.STATUS_INDUSTRY_ADJUSTMENT,
				status_industry_adjustment);

		holding.getHoldingMap().put(HoldingConstants.SIC_CODE,
				new SBigDecimal(1));
		HashMap<String, Object> planMap1 = new HashMap<String, Object>();
		Plan plan1 = new Plan();
		planMap1.put(PlanConstants.PLAN_EFFECTIVEDATE, "02/02/2015");
		HashMap<Object, Object> statusAggregationMap = new HashMap<Object, Object>();

		plan1.setStatus_gender_ageB_age_AggregationMap(statusAggregationMap);
		plan1.setOverRideMap(overRideMap);
		plan1.setPlanMap(planMap1);
		List<Plan> listOfPlans = new ArrayList<Plan>();
		listOfPlans.add(plan1);
		holding.setListOfPlans(listOfPlans);

		RuleUtility.getInitsData("DT",
				"basiclife//loop4_Override//BL_Status_Industry_Adjustment.xls",
				"",
				new Object[] { holding, plan1, statusAggregationMap, status });
		// System.out.println(plan1.getStatusAggregationMap());
		SparcRatingUtil.showMap(plan1.getStatusAggregationMap());

	}

}
