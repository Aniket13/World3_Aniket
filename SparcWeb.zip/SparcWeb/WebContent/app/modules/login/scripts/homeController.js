var homeController = function($scope, $rootScope) {
	$rootScope.actionNav='Actions';
};
