var loginController = function($scope, $rootScope, context, $location,
		$timeout, $state, $window, $localStorage) {
	
	$localStorage.actionNav='';
	$localStorage.clientIdAttr='';
	$localStorage.sicCode = '';
	$localStorage.selectedCensus='';
	$scope.disableLink = true;
	$localStorage.enableCensus=false;
	$localStorage.proposalIdAttr='';
	$localStorage.selectedField='';
	$localStorage.versionNumber='';
	$localStorage.versionIndexNum='';
	$localStorage.versionDescription='';
	$localStorage.versionStatus='';
	$localStorage.productName='';
	$localStorage.planNumber='';
	$localStorage.planDescription='';
	$localStorage.selectedCensusId='';
	$scope.locationPath = $location.path();
	if ($scope.locationPath == "/welcomePage" && $localStorage.loginUser!="") {
		 $timeout(function() {
			openOnce('#/roles', 'New Window');
		}, 1000);
	}
	
	
	function openOnce(url, target){
	    // open a blank "target" window
	    // or get the reference to the existing "target" window
		$window.close();
	    var winref = window.open('', target, "scrollbars=yes, left=0, resizable=yes, top=0, height=690, width=1018");
	    // if the "target" window was just opened, change its url
	    if(winref.location.href === 'about:blank'){
	        winref.location.href = url;
	    }
	    //return winref;
	    winref.focus();

	}
	
	
	
	$scope.fnOnLogin = function() {
		var xId = $scope.loginname;
		var password = $scope.password;
		if (xId != null && password != null) {
			$location.path("welcomePage");
			$localStorage.loginUser = xId;
		}
		;
	};
};
