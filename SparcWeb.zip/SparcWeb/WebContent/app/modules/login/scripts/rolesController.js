var rolesController = function($scope, $rootScope, context, $location, $state, appService) {
	$scope.fnOnRadio = function() {

		$location.path("\welcomeHome");
		
		//create new session on welcome home
		appService.fetchData("mvc/newSession").then(function(data){
			console.log("New session is created");
		});
	};

};
