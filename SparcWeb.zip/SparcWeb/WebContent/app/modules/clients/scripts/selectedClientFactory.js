var selectedClientFactory = [ '$resource', 'context', '$rootScope',
		function($resource, context, $rootScope) {

			var selectedClient = [];
			
			return {
				setSelectedClient : function(data) {
					selectedClient = data;
					$rootScope.$broadcast('Selected_client_Changed');
				},
				getSelectedClient : function() {
					return selectedClient;
				},
				removeSelectedClient : function() {
					selectedClient = [];
					$rootScope.$broadcast('Selected_client_Changed');
				}
			};
		} ];