var selectedClientController = function($scope, $rootScope, context, appService, $location, selectedClientFactory,$localStorage) {
	$scope.selectedClientData=[];
	$scope.selectedClientData.push(selectedClientFactory.getSelectedClient());
	$scope.proposalActivityList = [];
	$scope.clientName = selectedClientFactory.getSelectedClient().clientName;
	$scope.createnNewDisabled=false;
	
	
	$scope.showProposalActivity = function() {
		var clientId = parseInt(selectedClientFactory.getSelectedClient().clientId);
		appService.fetchDataWithParams("mvc/proposalActivity",clientId).then(function(data){
			$scope.isCollapsedProposal = !$scope.isCollapsedProposal;
			var i = 0;
			angular.forEach(data,function(listObj){
				$scope.proposalActivityList[i]=listObj;
				i = i + 1;
			});
		});
	};
	
	$scope.createNewProposal = function() {
		selectedClientFactory.setSelectedClient($scope.selectedClientData);
		$localStorage.createProposal = true;
		$localStorage.versionNumber='';
		$localStorage.versionIndexNum='';
		$localStorage.versionDescription='';
		$localStorage.versionStatus='';
		$localStorage.productName='';
		$localStorage.planNumber='';
		$localStorage.planDescription='';
		$location.path("\/basicInformation");
	};
	
	$scope.loadClient = function (clientId) { 
		appService.fetchDataWithParams("mvc/loadClient", clientId).then(function(data){
			$scope.selectedClientData[0] = data;
			if($scope.selectedClientData==''){
				$scope.createnNewDisabled=true;
			}else{
				$scope.createnNewDisabled=false;
			}
		});
	};
	if($localStorage.clientIdAttr){
		$scope.loadClient($localStorage.clientIdAttr);
	}
	if($scope.selectedClientData==''){
		$scope.createnNewDisabled=true;
	}
	
	$scope.searchClient = function() {
		$localStorage.searchFromSelectedClient = true;
		$location.path("\searchClient");
	};
	
	$scope.openProposal = function(val) {
		appService.fetchDataWithParams("mvc/getProposalDetails", val.proposalId).then(function(data){
			$scope.info = data;
			$localStorage.proposalIdAttr = $scope.info.proposalId;
			$localStorage.createProposal = false;
			$rootScope.$broadcast('proposalIdCreated');
			$localStorage.versionNumber='';
			$localStorage.versionIndexNum='';
			$localStorage.versionDescription='';
			$localStorage.versionStatus='';
			$localStorage.productName='';
			$localStorage.planNumber='';
			$localStorage.planDescription='';
			angular.forEach($scope.info.salesOffice,function(value){
				if(value.salesOfficeId == $scope.info.salesOffVal){
					$localStorage.selSalesOffice=value.description;
					$localStorage.selSalesRegion = value.salesRegionValues.regName;
				}
			});
			$location.path("\/basicInformation");
		});
		
	};
	
	
};
