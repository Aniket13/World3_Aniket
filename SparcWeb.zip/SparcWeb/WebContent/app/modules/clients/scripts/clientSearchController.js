var searchClientController = function($scope, $rootScope, context, appService, $location,selectedClientFactory,$localStorage) {
	
	$scope.sales = {};
	$scope.sales.address = [{}];
	$scope.search = {
			name:'',
			dba:'',
			proposalID:'',
			control:'',
			state:'',
			dAndB:'',
			sic:''
	};
	$scope.searchData={};
	$scope.editFlag = false;
	$scope.disableAddNewBtn=true;
	$scope.showEditClient = false;
	$scope.isSearchCriteriaError = true;
	$scope.showClientPreview= false;
	$scope.editClientDisabled=true;
	$scope.errorMsg='';
	$scope.proposalStates = [];
	$scope.proposalCountry = [];
	document.getElementById('searchName').focus();
	$scope.getStates = function() {
		var json = {
				lookupType : "",
				lookupCategory : "'STATES','COUNTRY'",
				code : "",
				description : ""
		};
		appService.fetchDataWithParams("mvc/getLookupDetails", json).then(function(data) {
			console.log(data);
			var i = 0, j = 0;
			angular.forEach(data,function(listObj){
				if(listObj.lookupCategory == 'STATES'){
					$scope.proposalStates[i]=listObj;
					i++;
				} else if(listObj.lookupCategory == 'COUNTRY'){
					$scope.proposalCountry[j]=listObj;
					j++;
				} 
			});
		});
	};
	
	//calling the function getStates() on load
	$scope.getStates();
	
	$scope.addNewClient = function() {
		$scope.editFlag = false;
		$scope.showEditClient = true;
		$scope.showClientPreview = false;
		$scope.editClientDisabled=false;
		$scope.sales = {address:[{}]};
		$scope.sicDescription='';
		appService.fetchData("mvc/getClientId").then(function(data){
			$scope.sales.clientId = data+1;
		});
	};

	$scope.searchResultReset = function() {
		$localStorage.clientIdAttr = '';
		$localStorage.sicCode = '';
		$location.path("\selectedClient");
		//$scope.searchData={};
	};

	$scope.selectClient = function(clientData) {
		$location.path("\selectedClient");
		/*var sessionClient = {
			clientId : clientData.clientId,
			sic : clientData.sic,
			contractState : clientData.contractState
		};*/
		$localStorage.clientIdAttr = clientData.clientId;
		$localStorage.sicCode = clientData.sic;
		$localStorage.selectedCensus = '';
		$localStorage.clientNameAttr = clientData.clientName;
		appService.fetchDataWithParams("mvc/selectClient",clientData).then(function(data){});
		selectedClientFactory.setSelectedClient(clientData);
		$localStorage.enableCensus=true;
	};

	$scope.fnSearch = function() {
		$scope.showClientPreview=false;
		$scope.sales = {};
		$scope.searchData = {};
		$scope.disableAddNewBtn=true;
		$scope.minLenMsgNm="Name- minimum 3 character(s) are required";
		$scope.minLenMsgDba="DBA- minimum 3 character(s) are required";
		$scope.minLenMsgPID="Proposal ID#- minimum 6 character(s) are required";
		$scope.minLenMsgCtr="Control#- minimum 5 character(s) are required";
		$scope.numCtrMsg="Control# must be numeric.";
		$scope.numPIDMsg="Proposal ID# must be numeric.";
		$scope.blankInput="At least one required field must be specified and be of the required length:\nName- minimum 3 character(s) \nDBA- minimum 3 character(s) \nProposal ID#- minimum 6 character(s) \nControl#- minimum 5 character(s)";
		
		
		var searchParams = {
				clientName : $scope.search.name,
				dba : $scope.search.dba,
				city : $scope.search.city,
				proposalId : $scope.search.proposalID,
				controlNo : $scope.search.control,
				state : $scope.search.state,
				dAndB : $scope.search.dAndB,
				sic : $scope.search.sic
		};
		if((searchParams.clientName==""||searchParams.clientName==null||searchParams.clientName==undefined) 
				&& (searchParams.proposalId==""||searchParams.proposalId==null||searchParams.proposalId==undefined)
				&& (searchParams.controlNo==""||searchParams.controlNo==null||searchParams.controlNo==undefined)
						&& (searchParams.dba==""||searchParams.dba==null||searchParams.dba==undefined)){
			
			alert($scope.blankInput);
			return false;
			
		}else{
			if((searchParams.clientName).length<3 && (searchParams.dba).length<3 && (searchParams.proposalId).length<6 && (searchParams.controlNo).length<5){
				alert($scope.blankInput);
				return false;
			
			}else if( (searchParams.clientName).length<3 && (searchParams.controlNo).length<5 && (searchParams.dba).length<3 && !$scope.numberPattern.test((searchParams.proposalId))){
					alert($scope.numPIDMsg);
					return false;
				
			}else if( (searchParams.clientName).length<3 && (searchParams.proposalId).length<5 && (searchParams.dba).length<3 && !$scope.numberPattern.test((searchParams.controlNo))){
					alert($scope.numCtrMsg);
					return false;
				
			}else {
				$scope.isSearchCriteriaError = false;
			}
		}
		if(!$scope.isSearchCriteriaError){
			$scope.isSearchCriteriaError = true;
			appService.fetchDataWithParams("mvc/searchClient",searchParams).then(function(data){
				console.log(data);
				$scope.disableAddNewBtn=false;
				angular.forEach(data,function(listObj){
					$scope.searchData[listObj.clientId]=listObj;
				});
			});
		}
		
	};

	$scope.fnReset = function() {
		var clientId = $scope.sales.clientId;
		//$scope.sales = {address:[{}]};
		$scope.sales.clientId = clientId;
		if($scope.editClientDisabled){
			$scope.sales.sic='';
			$scope.sales.contractState='';
			$scope.sales.sicDesc='';
		}else{
			$scope.sales = {address:[{}]};
		}
	};

	$scope.fnSrchReset = function() {
		$scope.search = {};
	};

	$scope.cancleNewClient = function() {
		$scope.showEditClient = false;
		if($scope.editFlag){
			$scope.showClientPreview=true;
		}
		$scope.searchData={};
		$scope.search = {};
		$scope.disableAddNewBtn=true;
	};

	$scope.fnSubmit = function() {
		if ($scope.editForm.$valid) {
		var client = {
				clientId : $scope.sales.clientId,
				clientName : $scope.sales.clientName,
				parentCompany : $scope.sales.parentCompany,
				fullLegalName : $scope.sales.fullLegalName,
				dba : $scope.sales.dba,
				dAndB : $scope.sales.dAndB,
				duns : "null",
				sic : $scope.sales.sic,
				natureOfBusiness : $scope.sales.natureOfBusiness,
				contractState : $scope.sales.contractState,
				nonErisa : $scope.sales.nonErisa,
				tin : $scope.sales.tin,
				contactName : $scope.sales.contactName,
				contactEmail : $scope.sales.contactEmail,
				address:[{
					address : $scope.sales.address[0].address,
					address2 : $scope.sales.address[0].address2,
					city : $scope.sales.address[0].city,
					country : $scope.sales.address[0].country,
					state : $scope.sales.address[0].state,
					zipcode : $scope.sales.address[0].zipcode,
					phone : $scope.sales.address[0].phone,
					fax : $scope.sales.address[0].fax,
					otherCountryVal : $scope.sales.address[0].otherCountryVal}],	
		};
		if($scope.editFlag){
			appService.fetchDataWithParams("mvc/editClient",client).then(function(data){
				console.log(data);
				if(data != null){
					
					if(data.errorMsg!=null){
						//$scope.errorMsg=data.errorMsg;
						if(typeof(data.errorMsg)=='string'){
							$scope.createTbl = data.errorMsg;
						}else{
							$scope.createTbl = $scope.createErrorTable(data.errorMsg); 
							$scope.createTbl =$scope.createTbl.outerHTML;
						}
						var newWindow = window.open('','errorWindow',"width=600,height=300, top=80,scrollbars=1,resizable=1");
						newWindow.document.body.innerHTML = $scope.createTbl;
						newWindow.document.title = 'Fields Required';
					}
					else{
						$scope.sales = data;
						console.log($scope.sales);
						$location.path("\selectedClient");
						appService.fetchDataWithParams("mvc/selectClient",$scope.sales).then(function(data){});
						selectedClientFactory.setSelectedClient($scope.sales);
					}
					
				}
			});
		}
		else {
			appService.fetchDataWithParams("mvc/addClient?event=PB.save.task",client).then(function(data){
				console.log(data, data.errorMsg);
				if(data != null){
					if(data.errorMsg!=null){
						//$scope.errorMsg=data.errorMsg;
						if(typeof(data.errorMsg)=='string'){
							$scope.createTbl = data.errorMsg;
						}else{
							$scope.createTbl = $scope.createErrorTable(data.errorMsg); 
							$scope.createTbl =$scope.createTbl.outerHTML;
						}
						var newWindow = window.open('','errorWindow',"width=600,height=300, top=80,scrollbars=1,resizable=1");
						newWindow.document.body.innerHTML = $scope.createTbl;
						newWindow.document.title = 'Fields Required';
					}
					else{
						$scope.sales = data;
						appService.fetchDataWithParams("mvc/selectClient",$scope.sales).then(function(data){});
						selectedClientFactory.setSelectedClient($scope.sales);
						$localStorage.clientIdAttr = $scope.sales.clientId;
						$localStorage.sicCode = $scope.sales.sic;
						$location.path("\selectedClient");
					}
				}
			});
		}
	}else{
		if($scope.editForm.$error.pattern){
			alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
			return false;
		}
	}
	};
	
	$scope.sicDescription='';
	$scope.editClient=function(data){
		$scope.editFlag = true;
		$scope.sales=data; 
		$scope.showEditClient=true;
		$scope.showClientPreview=false;
		$scope.editClientDisabled=true;
		/*var sicNum= '1080';
		appService.fetchDataWithParams("mvc/getDesc",sicNum).then(function(val){
			$scope.sicDescription=val;
		});*/
	};
	
	$scope.showClient=function(data){
		$scope.sales=data; 
		$scope.showClientPreview=true;
	};
	


	if($localStorage.searchFromSelectedClient){
		$scope.sales=selectedClientFactory.getSelectedClient();
		$scope.showClientPreview=true;
		$localStorage.searchFromSelectedClient = false;
	}
};
