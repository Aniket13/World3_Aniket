var planDetailsFactory = [ '$resource', 'context','$rootScope',
		function($resource, context,$rootScope) {

			var tab=1;

			return {
				setTabValue : function(tabVal) {
					tab = tabVal;
					$rootScope.$broadcast('tabValChanged');
				},
				getTabValue : function() {
					return tab;
				}
			};
		} ];