var proposalDetailsPlanController = function($scope, $rootScope, planDetailsFactory,appService, $localStorage, $timeout) {
	
	$rootScope.headTopLists=[];
	$scope.headerDetails={};
	$scope.versionDetails={};
	$scope.getHeadTopLists = function (proposalIdVal, clientIdVal) { 
		var proposal = {
				proposalId : proposalIdVal,
				clientId: clientIdVal
		};
		appService.fetchDataWithParams("mvc/getHeaderDetails",proposal).then(function(data) {
			$scope.headerDetails = data;
			$scope.getVersionDetails($localStorage.proposalIdAttr,$localStorage.versionNumber);
		});
		
		
	};
	
	$scope.getHeadTopLists($localStorage.proposalIdAttr,$localStorage.clientIdAttr);
	
	$scope.getVersionDetails = function(proposalId, versionNumber) {
		var quotation = {
				proposalId : proposalId,
				versionNumber : versionNumber
		};
		appService.fetchDataWithParams("mvc/getVersionDetails",quotation).then(function(data){
			$scope.versionDetails = data;
			$rootScope.headTopLists=[ {name : 'Proposol ID', value : $scope.headerDetails.proposalId},
			                      {name : 'Client Name', value : $scope.headerDetails.clientName},
			                      {name : 'Proposal Status',value : $scope.headerDetails.proposalStatusVal},
			                      {name : 'Version Number',value : $localStorage.versionIndexNumber}, 
			                      {name : 'Version Description',value :  $localStorage.versionDescription},
			                      {name : 'Version Status',value : $localStorage.versionStatus}, 
			                      {name : 'Product',value : $localStorage.productName}
			                     //{name : 'Plan Number',value : $scope.versionDetails.productList[$localStorage.productId-1].plan.planId}, 
			                     //{name : 'Plan Description',value : $scope.versionDetails.productList[$localStorage.productId-1].plan.planDesc} 
			                    ];
		});
	};
	
	
	$scope.disProvisionTab = {};
	$scope.planContriTab = {};
	$scope.isCheck = false;
	$rootScope.isPlanSelected="No Plan Selected";
	$scope.selectedPlan='';
	$rootScope.selectedPlanIndex='';
	$rootScope.planList = [];
	$rootScope.planEarningMsg='Earnings: This is the gross amount of money paid to you by the Employer in cash for performing the duties required of your job. Bonuses, overtime pay, Earnings for more than 40 hours per week, and all other benefits are not included.';
	$rootScope.list=[];
	$rootScope.listOverrides=[];
	$scope.inputList = {
			proposalId:$localStorage.proposalIdAttr,
			proposalVersionId:$localStorage.versionNumber,
			prodCode:$localStorage.productId
	};
	$scope.planListData={};
	
	scrollPos=0;
	//Get list of plans
	$scope.getPlanList = function(listData) {
		appService.fetchDataWithParams("mvc/getVersionPlans", listData).then(function(data) {
			console.log(data);
			$rootScope.planList = [];
			$scope.planListData = data.planDetailsAggregatorList;
			angular.forEach($scope.planListData, function(listVal, listKey) {
				var planNum=listKey+1;
				var planDesc='';
				var effDate='';
				angular.forEach(listVal.listOfPlanField, function(val, key) {
					if(val.fieldKey=='plan_Description'){
						planDesc=val.fieldValue;
					}
					if(val.fieldKey=='effective_Date'){
						effDate=val.fieldValue;
					}
				});
				
				$rootScope.planList.push({planNum:planNum, planDesc: planDesc, effDate:effDate});
			});
			console.log($rootScope.planList);
			
		});
	};
	$scope.getPlanList($scope.inputList);
	
	
	//Get plan details on click of plan
	$scope.getPlanDetails = function(listData, index) {
		
		var inputList = listData;
		delete inputList.listOfPlanField;
		delete inputList.commission;
		delete inputList.planEligibility;
		inputList.brokerId=1;
		inputList.clientId=$localStorage.clientIdAttr;
		inputList.sicCode=$localStorage.sicCode;
		inputList.selectedCensusId = $localStorage.selectedCensusId;
		$rootScope.selectedPlanIndex=index+1;
		appService.fetchDataWithParams("mvc/getAllPlanDetails", inputList).then(function(data) {
			console.log(data);
			$rootScope.headTopLists[7]={name : 'Plan Number',value : index+1};
			$localStorage.planNumber = index+1;
			$scope.selectedPlan=listData.planId;
			$scope.showPlan=true;
			planDetailsFactory.setTabValue(1);
			$scope.getPlanData(data);
			
		});
	};
	
	$scope.getPlanData = function(data){
		console.log($rootScope.selectedPlanIndex);
		$rootScope.list=[];
		$rootScope.list=data;
		angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
			if(listVal.fieldType=='Date'){
				$rootScope.list.listOfPlanField[listKey].fieldValue=new Date(listVal.fieldValue);
			}
			
			if(listVal.fieldType=='Dropdown'){
	           listVal.visibleValues=[];
	           angular.forEach(listVal.altValues, function(val, key) {
	              if(val.visibleFlag=='Yes'){
	                 listVal.visibleValues.push(val);
	              }
	           });
	           /*if(listVal.tabId=='4' && listVal.overriddenFlag=='N'){
	        	 // if(listVal.tabId=='4'){
	        	   angular.forEach($rootScope.list.listOfPlanField, function(val, key) {
	        		   if(listVal.originalField==val.fieldKey){
	        			   listVal.fieldValue=val.fieldValue;
		        	   }
	 	           });
	           }*/
	        	 
	      }
			
			
			/*if(listVal.tabId=='4' && listVal.overriddenFlag=='Y'){
		        	   angular.forEach($rootScope.list.listOfPlanField, function(val, key) {
		        		   if(listVal.originalField==val.fieldKey){
		        			   if ($scope.tab == 1) {
		        				   //listVal.fieldValue=val.fieldValue;
		        				} else if ($scope.tab == 4) {
		        					 val.fieldValue=listVal.fieldValue;
				        			 val.overriddenFlag='Y';
		        				}
		        			  
			        	   }
		 	           });
			 }*/
			
		});
		$timeout(function(){
			//if($rootScope.list.listOfPlanField==undefined){
			//	$scope.disableCheckbox($rootScope.list.planDetailsAggregator.listOfPlanField);
			//}else{
			//	if($rootScope.list.listOfPlanField!=undefined){
					$scope.disableCheckbox($rootScope.list.listOfPlanField);
					document.documentElement.scrollTop=scrollPos;
			//	}
			//}
			
        }, 0);
		if($rootScope.list.commission!=null){
			$rootScope.selCommissionSplit=$rootScope.list.commission.commissionSplit;
		}
		
	};
	
	$scope.disableCheckbox = function(list){
		console.log($rootScope.selectedPlanIndex);
		angular.forEach(list, function(listVal, listKey) {
			if(listVal.fieldKey=='Field_Level_Exceptions_Apply_Attribute' && listVal.fieldValue=='true'){
				document.getElementById('Field_Level_Exceptions_Apply_Attribute').disabled=true;
			}
			if(listVal.fieldKey=='pru_Value_Exceptions' && listVal.fieldValue=='true'){
				document.getElementById('pru_Value_Exceptions').disabled=true;
			}
			if(listVal.overriddenFlag=='Y' && listVal.tabId=='4'){
				document.getElementById(''+listVal.fieldKey+'_Overriden').disabled=true;
			}
			if(listVal.fieldKey=='plan_Description'){
				$rootScope.planList[$rootScope.selectedPlanIndex-1].planDesc = listVal.fieldValue;
				$rootScope.isPlanSelected = listVal.fieldValue;
				$rootScope.headTopLists[8]={name : 'Plan Description',value :  $rootScope.isPlanSelected};
				$localStorage.planDescription = $rootScope.isPlanSelected;
			}
		});
	};
	
	// Add new plan
	$scope.addNewPlan = function() {
		$rootScope.isPlanSelected=''; 
		$scope.showPlan=true;
		var inputListPlan = {
				proposalId:$localStorage.proposalIdAttr,
				proposalVersionId:$localStorage.versionNumber,
				prodCode:$localStorage.productId,
				clientId:$localStorage.clientIdAttr,
				sicCode:$localStorage.sicCode,
				selectedCensusId:$localStorage.selectedCensusId
		};
		
		appService.fetchDataWithParams("mvc/createNewPlan", inputListPlan).then(function(data) {
			console.log(data);
			$scope.getPlanList($scope.inputList);
			$rootScope.list=[];
			$rootScope.list=data;
			angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
				if(listVal.fieldType=='Date'){
					$rootScope.list.listOfPlanField[listKey].fieldValue=new Date(listVal.fieldValue);
				}
				if(listVal.fieldType=='Dropdown'){
			           listVal.visibleValues=[];
			           angular.forEach(listVal.altValues, function(val, key) {
			              if(val.visibleFlag=='Yes'){
			                 listVal.visibleValues.push(val);
			              }
			           });
			           if(listVal.tabId=='4' && listVal.overriddenFlag=='N'){
			          // if(listVal.tabId=='4'){
			        	   angular.forEach($rootScope.list.listOfPlanField, function(val, key) {
			        		   if(listVal.originalField==val.fieldKey){
			        			   listVal.fieldValue=val.fieldValue;
				        	   }
			 	           });
			           }
			          /* if(listVal.tabId=='4' && listVal.overriddenFlag=='Y'){
			        	   angular.forEach($rootScope.list.listOfPlanField, function(val, key) {
			        		   if(listVal.originalField==val.fieldKey){
			        			   val.fieldValue=listVal.fieldValue;
				        	   }
			 	           });
			           }*/
			      }
			});
		
			
			$scope.selectedPlan=$rootScope.list.planId;
			$rootScope.isPlanSelected='';
			$rootScope.headTopLists[7]={name : 'Plan Number',value : $rootScope.planList.length+1};
			$rootScope.headTopLists[8]={name : 'Plan Description',value :  $rootScope.isPlanSelected};
			$localStorage.planNumber = $rootScope.planList.length+1;
			$localStorage.planDescription = $rootScope.isPlanSelected;
			$rootScope.selectedPlanIndex = $rootScope.planList.length+1;
			planDetailsFactory.setTabValue(1);
			
			if($rootScope.list.commission.advaceCommissionOccurs==null || $rootScope.list.commission.advaceCommissionOccurs ==undefined){
				$rootScope.list.commission.advaceCommissionOccurs='First Year';
			}
			if($rootScope.list.commission.arrangement==null || $rootScope.list.commission.arrangement ==undefined){
				$rootScope.list.commission.arrangement='Level Scale';
			}
			if($rootScope.list.commission.commissionPaidTo==null || $rootScope.list.commission.commissionPaidTo ==undefined){
				$rootScope.list.commission.commissionPaidTo='Individual';
			}
			if($rootScope.list.commission.commissionSplit==null || $rootScope.list.commission.commissionSplit ==undefined){
				$rootScope.list.commission.commissionSplit=0;
			}
			if($rootScope.list.commission.advanceCommissionFlag==null){
				$rootScope.list.commission.advanceCommissionFlag='N';
			}
			if($rootScope.list.commission!=null){
				$rootScope.selCommissionSplit=$rootScope.list.commission.commissionSplit;
			}
		});
	};
	
	
	//onblur validateEffDate() for effDate and isPositiveReal() for positive real val
	$rootScope.onChangeFlag=false;
	$scope.onBlurFn = function(val) {
		if(val.fieldValue!=$scope.oldValue){
			$rootScope.onChangeFlag=false;
			if(val.onBlur=='validateEffDate()'){
				$scope.validateEffDate(val);
			} else if(val.onBlur=='isPositiveReal()'){
				$scope.isPositiveReal(val);
			}else if(val.onBlur=='onChangeFn(value)'){
				$scope.onChangeFn(val);
			}else if(val.onBlur=='isPositiveReal(),onChangeFn(value)'){
				$rootScope.onChangeFlag=true;
				$scope.isPositiveReal(val);
			}else if(val.onBlur=='rateGuaranteeChange()'){
				$scope.rateGuaranteeChange(val);
			}
		}
	};
	
	$scope.caseEffDate='';
	var propInputList = $localStorage.proposalIdAttr;
	appService.fetchDataWithParams("mvc/getProposalDetails",propInputList).then(function(data){
		//$scope.caseEffDate=data.effDate;
		var propEffDate = new Date(data.effDate);
		var dd = propEffDate.getDate();
		var mm = propEffDate.getMonth()+1; 
		var yyyy = propEffDate.getFullYear();
		if(dd<10){
		    dd='0'+dd;
		} 
		if(mm<10){
		    mm='0'+mm;
		} 
		$scope.caseEffDate = mm+'/'+dd+'/'+yyyy;
	});
	
	$rootScope.validateEffDateFlag=true;
	$scope.validateEffDate = function(val) {
		//$scope.caseEffDate = '10/10/2016';
		$rootScope.validateEffDateFlag=true;
		$scope.caseEffDateComp= new Date($scope.caseEffDate);
		$scope.caseEffDateComp.setDate($scope.caseEffDateComp.getDate() - 1);
		var formatVal = document.getElementById(val.fieldKey).value;
		if(val.fieldValue==undefined || val.fieldValue==''){
			alert(''+formatVal+' is an invalid date. \nDates must be in the form:\n\nmm/dd/yyyy');
			$rootScope.validateEffDateFlag=false;
			return false;
		}else if(val.fieldValue<=$scope.caseEffDateComp){
			alert('The Effective Date for this plan must be on or after the Case Effective Date ('+$scope.caseEffDate+').');
			$rootScope.validateEffDateFlag=false;
			return false;
		}
	};
	
	
	//onfocus setOldVal()
	$scope.onFocusFn = function(val) {
		if(val.onFocus=='setOldVal()'){
			$scope.setOldVal(val);
		}
	};
	
	$scope.oldValue ='';
	$scope.setOldVal = function(val) {
		$scope.oldValue=val.fieldValue;
	};
	
	//positive real check
	$scope.isPositiveReal = function(listData) {
		if(!$scope.numericPattern.test(listData.fieldValue) || listData.fieldValue==''){
			alert(''+listData.fieldValue+' is not valid type: positive real');
			listData.fieldValue=$scope.oldValue;
		}else{
			if(listData.tabId=='4' || $rootScope.onChangeFlag){
				$scope.onChangeFn(listData);
			}
		}
	};
	
	//Rate guarantee onblur
	$scope.rateGuaranteeChange = function(listData) {
		if(confirm('If Rate Guarantee is not 12 or 24 months for SIC Code other than Preferred* (Not 2833-2836 or 4812-4822 or 4832-4841 or 4899 or 7371-7379 or 8711-8713 or 8731-8734 or 8741-8748) or Rate Guarantee is not 12, 24 or 36 months and/or does not match between Non-Grandfathering BL Plans and LTD Plans on the Version for Preferred* SIC Code (2833-2836 or 4812-4822 or 4832-4841 or 4899 or 7371-7379 or 8711-8713 or 8731-8734 or 8741-8748), submit the Proposal to the Underwriter.')){
			if(!$scope.integerPattern.test(listData.fieldValue) || listData.fieldValue==''){
				alert(''+listData.fieldValue+' is not valid type: int');
				listData.fieldValue=$scope.oldValue;
			}
		}else{
			listData.fieldValue=$scope.oldValue;
		}
		
	};
	
	
	//type of case onchange
	$scope.confirmPruValueChange = function(listData) {
		if(confirm('Warning! Changing Type of Case will reset all selections to comply with the appropriate rules. Continue?')){
			$scope.onChangeFn(listData);
		}else{
			listData.fieldValue=$scope.oldValue;
		}
	};
	
	//contract state onchange
	$scope.confirmStateChange = function(listData) {
		if(confirm('Warning! Changing Contract State will reset all selections to comply with State regulations. Continue?')){
			$scope.onChangeFn(listData);
		}else{
			listData.fieldValue=$scope.oldValue;
		}
	};
	
	//field level exception onclick
	$scope.doFLException = function(listData) {
		if(listData.fieldValue=='true'){
			if(confirm('Warning! Clicking yes will make this plan a Field Level Exception plan, and it will not be able to be changed back. Continue?')){
				document.getElementById('Field_Level_Exceptions_Apply_Attribute').disabled=true;
				$scope.onChangeFn(listData);
			}else{
				listData.fieldValue=$scope.oldValue;
			}
		}
	};
	
	
	//pruvalue exception onclick
	$scope.doPVException = function(listData) {
		if(listData.fieldValue=='true'){
			if(confirm('Warning! Clicking yes will make this plan a PruValue Exception and will not be able to be changed back. Continue?')){
				document.getElementById('pru_Value_Exceptions').disabled=true;
				$scope.onChangeFn(listData);
			}else{
				listData.fieldValue=$scope.oldValue;
			}
		}
	};
	
	
	//ASO onchange
	$scope.doASO = function(listData) {
		if(confirm('Warning! This selection will change the current plan to ASO plan and cannot be undone. Continue?')){
			$scope.onChangeFn(listData);
		}else{
			listData.fieldValue=$scope.oldValue;
		}
	};
	
	//va vdi plan onchange
	$scope.doCAVDI = function(listData) {
		if(confirm('Warning! This selection will change the current plan to an CA VDI plan and cannot be undone. Continue?')){
			$scope.onChangeFn(listData);
		}else{
			listData.fieldValue=$scope.oldValue;
		}
	};
	
	
	//statutory plan onchange
	$scope.confirmStatutoryPlanHandlingChange = function(listData) {
		if(confirm('Warning! Changing Statutory Plan Handling will reset all selections to comply with the appropriate rules. Continue?')){
			$scope.onChangeFn(listData);
		}else{
			listData.fieldValue=$scope.oldValue;
		}
	};
	
	//sub product onchange
	$scope.confirmSubProductChange = function(listData) {
		if(confirm('Warning! Changing SubProduct will reset all selections to comply with the appropriate rules. Continue?')){
			$scope.onChangeFn(listData);
		}else{
			listData.fieldValue=$scope.oldValue;
		}
	};
	
	
	//contract written onchange
	$scope.confirmContractWrittenOnChange = function(listData) {
		if(confirm('Warning! Changing Contract Written On will reset all selections to comply with the appropriate rules. Continue?')){
			$scope.onChangeFn(listData);
		}else{
			listData.fieldValue=$scope.oldValue;
		}
	};
	
	
	//Plan underwritten by onchange
	$scope.confirmUnderwrittenByChange = function(listData) {
		if(confirm('Warning! Changing Plan Underwritten By will reset all selections to comply with the appropriate rules. Continue?')){
			$scope.onChangeFn(listData);
		}else{
			listData.fieldValue=$scope.oldValue;
		}
	};
	
	
	
	//Plan contribution percentage by onchange
	$scope.contributionPercentageChange = function(listData) {
		if(listData.fieldValue=='Contribution_Arrangement__Contributory_Shared'){
			if(confirm('Contribution Percentage must be at least 20% to select this option.')){
				$scope.onChangeFn(listData);
			}else{
				listData.fieldValue=$scope.oldValue;
			}
		}else{
			$scope.onChangeFn(listData);
		}
		
	};
	
	//Earning Definition onchange
	$scope.earningDefinitionChange = function(listData) {
		if(listData.fieldValue=='Earnings_Definition__Standard'){
			$scope.onChangeFn(listData);
			$rootScope.planEarningMsg='Earnings: This is the gross amount of money paid to you by the Employer in cash for performing the duties required of your job. Bonuses, overtime pay, Earnings for more than 40 hours per week, and all other benefits are not included. ';
		}else if(listData.fieldValue=='Earnings_Definition__Prior_Year_W2'){
			alert('Underwriting Approval is required  for this selection.');
			$scope.onChangeFn(listData);
			$rootScope.planEarningMsg='Earnings: This is the gross amount of money paid to you by the Employer in cash for performing the duties required of your job as reported on your W-2 form for the year prior to your death. If you did not receive a W-2 form from the Employer, Earnings is the gross amount of money paid to you by the Employer in cash for performing the duties required of your job during your period of employment. ';
		}else if(listData.fieldValue=='Earnings_Definition__Prior_Year_K1'){
			alert('Underwriting Approval is required  for this selection.\nPrior Year K-1 earnings definition is not available if the client is organized as as entity other than a Partnership or S-Corporation.');
			$scope.onChangeFn(listData);
			$rootScope.planEarningMsg='Earnings: This is the gross amount of money paid to you by the Employer in cash for performing the duties required of your job as reported on your K-1 form for the year prior to your death. If your did not receive a K-1 form from the Employer, Earnings is the gross amount of money paid to you by the Employer in cash for performing the duties required of your job during your period of employment.';
		}else if(listData.fieldValue=='Earnings_Definition__Match_Existing'){
			alert('Underwriting Approval is required  for this selection.');
			$scope.onChangeFn(listData);
			$rootScope.planEarningMsg='';
		}else if(listData.fieldValue=='Earnings_Definition__None'){
			$scope.onChangeFn(listData);
			$rootScope.planEarningMsg='';
		}
		
	};
	
	
	
	//Onchange of fields
	$scope.onChangeFn = function(listData) {
		scrollPos = document.documentElement.scrollTop;
		var inputList = angular.copy($rootScope.list);
		inputList.clientId=$localStorage.clientIdAttr;
		inputList.sicCode=$localStorage.sicCode;
		inputList.selectedCensusId = $localStorage.selectedCensusId;
		
		angular.forEach(inputList.listOfPlanField, function(listVal, listKey) {
			if(listVal.fieldSeqId==listData.fieldSeqId){
				inputList.listOfPlanField[listKey].fieldIndicator='C';
				console.log('current tab ID: '+listData.tabId);
				inputList.currentTabId = listData.tabId;
			}else{
				inputList.listOfPlanField[listKey].fieldIndicator='';
			}
			if(listVal.fieldType=='Date'){
				inputList.listOfPlanField[listKey].fieldValue=document.getElementById(listVal.fieldKey).value;
			}
			
			if(listVal.visibleValues!=undefined){
	           delete listVal.visibleValues;
	      	}
			
		});
		appService.fetchDataWithParams("mvc/onChangePlanDetails", inputList).then(function(data) {
			/*angular.forEach(data, function(val, key) {
				if(val.fieldIndicator=='A'){
					$rootScope.list.listOfPlanField.push(val);
				}else if(val.fieldIndicator=='C'){
					angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
						if(listVal.fieldSeqId==val.fieldSeqId){
							$rootScope.list.listOfPlanField[listKey].fieldValue=val.fieldValue;
							$rootScope.list.listOfPlanField[listKey].altValues=val.altValues;
						}
					});
				}else if(val.fieldIndicator=='R'){
					angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
						if(listVal.fieldSeqId==val.fieldSeqId){
							$rootScope.list.listOfPlanField.splice($rootScope.list.listOfPlanField.indexOf(listVal),1);
						}
					});
				}
				angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
					$rootScope.list.listOfPlanField[listKey].fieldIndicator='';
					if(listVal.fieldType=='Date'){
						$rootScope.list.listOfPlanField[listKey].fieldValue=new Date(listVal.fieldValue);
					}
					if(listVal.fieldType=='Dropdown'){
			           listVal.visibleValues=[];
			           angular.forEach(listVal.altValues, function(val, key) {
			              if(val.visibleFlag=='Yes'){
			                 listVal.visibleValues.push(val);
			              }
			           });
			      }
				});
				
				
		    });*/
			
			$scope.getPlanData(data);
			/*$rootScope.list=[];
			$rootScope.list=data;
			angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
				if(listVal.fieldType=='Date'){
					$rootScope.list.listOfPlanField[listKey].fieldValue=new Date(listVal.fieldValue);
				}
				if(listVal.fieldType=='Dropdown'){
			           listVal.visibleValues=[];
			           angular.forEach(listVal.altValues, function(val, key) {
			              if(val.visibleFlag=='Yes'){
			                 listVal.visibleValues.push(val);
			              }
			           });
			           
			           //if(listVal.tabId=='4' && listVal.overriddenFlag=='N'){
			           if(listVal.tabId=='4'){
			        	   angular.forEach($rootScope.list.listOfPlanField, function(val, key) {
			        		   if(listVal.originalField==val.fieldKey){
			        			   listVal.fieldValue=val.fieldValue;
				        	   }
			 	           });
			           }
			           if(listVal.tabId=='4' && listVal.overriddenFlag=='Y'){
			        	   angular.forEach($rootScope.list.listOfPlanField, function(val, key) {
			        		   if(listVal.originalField==val.fieldKey){
			        			   val.fieldValue=listVal.fieldValue;
				        	   }
			 	           });
			           }
			      }
			});*/
			
		});
	};
	
	//$rootScope.inputListSave=[];
	$scope.saveInputList=function(){
		var inputListSave = angular.copy($rootScope.list);
		angular.forEach(inputListSave.listOfPlanField, function(listVal, listKey) {
			if(listVal.fieldType=='Date'){
				inputListSave.listOfPlanField[listKey].fieldValue=document.getElementById(listVal.fieldKey).value;
			}
			if(listVal.visibleValues!=undefined){
	           delete listVal.visibleValues;
	      	}
		});
		return inputListSave;
	};
	
	//Save Plan Details
	$scope.savePlan = function() {
		angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
			if(listVal.fieldType=='Date'){
				$scope.validateEffDate(listVal);
			}
		});
		if($rootScope.validateEffDateFlag){
			var inputListSave = $scope.saveInputList();
			appService.fetchDataWithParams("mvc/savePlanDetails", inputListSave).then(function(data) {
				$scope.getPlanData(data);
			});
		}
		
	};
	
		
	
	//Save Plan Overrrides
	$scope.savePlanOverrides = function() {
		var inputListSave = $scope.saveInputList();
		inputListSave.clientId=$localStorage.clientIdAttr;
		inputListSave.sicCode=$localStorage.sicCode;
		inputListSave.selectedCensusId = $localStorage.selectedCensusId;
		appService.fetchDataWithParams("mvc/overridePlanDetails", inputListSave).then(function(data) {
			$scope.getPlanData(data.planDetailsAggregator);
		});
		
	};
	
	
	//Tab Functionality
	$scope.nextTab = function() {
		if ($scope.tab == 1) {
			angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
				if(listVal.fieldType=='Date'){
					$scope.validateEffDate(listVal);
				}
			});
			if($rootScope.validateEffDateFlag){
				planDetailsFactory.setTabValue(2);
			}
		} else if ($scope.tab == 4) {
			planDetailsFactory.setTabValue(5);
		}
	};

	$scope.isOverridden = function(key) {
		var isOver = false;
		//if ($scope.tab != 4 && $rootScope.planInitData[key].isOverRidden) {
		if ($scope.tab != 4 && $rootScope.list[key].isOverRidden) {
			isOver = true;
		}
		return isOver;
	};
	
	$scope.setTab = function(tabVal) {
		if(tabVal==4){
			var activeOverride = false;
			angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
				//if(listVal.fieldKey=='Field_Level_Exceptions' &&  listVal.fieldValue=='true'){ // Commented for key mismatch
					if(listVal.fieldKey=='Field_Level_Exceptions_Apply_Attribute' &&  listVal.fieldValue=='true'){
					activeOverride = true;
					return false;
				}
			});
			if(activeOverride){			
			}else{
				alert('This plan must first be made a Field Level Exception plan before this tab can be visited.');
				return false;
			}
			
		}
		$scope.tab = tabVal;
		planDetailsFactory.setTabValue(tabVal);
	};

	$scope.$on('tabValChanged', function() {
		$scope.tab = planDetailsFactory.getTabValue();
	});
	
	$scope.submitCriateria=function(){
		$scope.showPlan=true;
		console.log($scope.sales);
	};
	
	
	//Save Plan Eligibility
	
	$scope.saveEligibleClasses=function(){
		if($scope.eligibleClassesForm.minimumHours.$error.required){
			alert('Please input a value for "Minimum Hours Required" field.');
			return false;
		};
		if($scope.eligibleClassesForm.$error.pattern || $scope.minimumHours=='.' ){
			alert('Please enter Numeric value.');
			return false;
		};
		var inputListSave = $scope.saveInputList();
		appService.fetchDataWithParams("mvc/saveEligibilityDetails", inputListSave).then(function(data) {
			$scope.getPlanData(data.planDetailsAggregator);
		});
	};

	
	$scope.selectAllClasses=function(){
		angular.forEach($rootScope.list.planEligibility.censusClassList, function(listVal, listKey) {
			listVal.classSelected=true;
		});
	};
	
	//Commission
	$scope.selectedProducers='';
	$scope.producers=[];
	$rootScope.errorMsgComm='';
	$rootScope.selCommissionSplit='';
	
	appService.fetchData("mvc/getProducer").then(function(data){
		console.log('producer:'+data);
		$scope.selectedProducers=data[0].producerName;
		$scope.producers.push($scope.selectedProducers);
	
	});
	
	$scope.arrangements= ['Level Scale','Flat Amount','Flat %','Direct','None'];
	$scope.paidTo = ['Individual', 'Firm'];
	$scope.advaceCommissionOccurs = ['First Year','First Year and Renewal','Renewal'];
	$scope.ascList = [
	 	             {
	 	            	 ascId:1,
	 	            	 description : 'Design of policy holder\'s benefit administration system.',
	 	            	 pct : 3.0
	 	             },
	 	             {
	 	            	 ascId:2,
	 	            	 description : 'Participation in programs of communication and education for control.',
	 	            	 pct : 2.0
	 	             },
	 	             {
	 	            	 ascId:3,
	 	            	 description : 'Consultation in correction with rate change or alternate plans of insurance.',
	 	            	 pct : 2.0
	 	             },
	 	             {
	 	            	 ascId:4,
	 	            	 description : 'Review of contractual provisions.',
	 	            	 pct : 3.0
	 	             },
	 	             {
	 	            	 ascId:5,
	 	            	 description : 'Assistance in enrollment meeting (not related to trade association or multiple employer groups) or site visits to managed medical operations.',
	 	            	 pct : 2.0
	 	             },
	 	             {
	 	            	 ascId:6,
	 	            	 description : 'Assembly and analysis of claim experience.',
	 	            	 pct : 2.0
	 	             },
	 	             {
	 	            	 ascId:7,
	 	            	 description : 'Assistance in the development and preparation of plan announcement material, employee benefit booklets or other plan documents.',
	 	            	 pct : 2.0
	 	             },
	 	             {
	 	            	 ascId:8,
	 	            	 description : 'Customer Satisfaction Monitors',
	 	            	 pct : 2.0
	 	             },
	 	             {
	 	            	 ascId:9,
	 	            	 description : 'Maintain Premium and Statistic Records',
	 	            	 pct : 3.0
	 	             },
	 	             {
	 	            	 ascId:10,
	 	            	 description : 'Supervising General Agent',
	 	            	 pct : 3.0
	 	             },
	 	             {
	 	            	 ascId:11,
	 	            	 description : 'Collective Bargaining Consultation',
	 	            	 pct : 2.0
	 	             }
	 	   ];
	 	
	 	$scope.sum = 0;
	 	$scope.calcSum = function($event, id) {
	         var checkbox = $event.target;

	        if (checkbox.checked) {
	            $scope.sum += parseInt(checkbox.value);   
	         } else {
	            $scope.sum -= parseInt(checkbox.value);    
	         }  
	 	};
	 	
	 	$scope.saveLifeComm= function(){
			//alert($scope.lifeComm.flatPct+''+$scope.lifeComm.flatAmt);
			
			var flatPct = document.getElementById('flatPct');
			var advCommPct = document.getElementById('advCommPct');
			if(!isNaN(flatPct.value) && flatPct.value<0 || !isNaN(flatPct.value) && flatPct.value>100 || !isNaN(advCommPct.value) && advCommPct.value<0 || !isNaN(advCommPct.value) && advCommPct.value>100){
				alert('Entered value must be in the range of 0 to 100. Please try again.');
				return false;
			}
			if($scope.proposalDetailsPlanCommisionForm.$error.pattern){
				if(!$scope.specCharPattern.test(document.getElementById('commSplit').value)){
					alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
				}else{
						alert('Entered value does not appear to be a numeric. Please try again.');
				}
				return false;
			};
			
			$rootScope.errorMsgComm = '';
			
			var inputListSave = $scope.saveInputList();
			if(document.getElementById('commSplit').value==''){
				inputListSave.commission.commissionSplit = $rootScope.selCommissionSplit;
			}
			
			inputListSave.commission.commissionSplit = parseFloat(inputListSave.commission.commissionSplit);
			inputListSave.commission.flatAmount = parseFloat(inputListSave.commission.flatAmount);
			inputListSave.commission.flatPercentage = parseFloat(inputListSave.commission.flatPercentage);
			inputListSave.commission.advanceCommission = parseFloat(inputListSave.commission.advanceCommission);
			
			appService.fetchDataWithParams("mvc/savePlanCommission", inputListSave).then(function(data) {
				if(data != null){
					if(data.errorMsg!=null){
						if(typeof(data.errorMsg)=='string'){
							$rootScope.errorMsgComm = data.errorMsg;
							return false;
						}else{
							$scope.createTbl = $scope.createErrorTable(data.errorMsg); 
							$scope.createTbl =$scope.createTbl.outerHTML;
						}
						var newWindow = window.open('','errorWindow',"width=600,height=300, top=80,scrollbars=1,resizable=1");
						newWindow.document.body.innerHTML = $scope.createTbl;
						newWindow.document.title = 'Fields Required';
					}else{
						$scope.getPlanData(data.planDetailsAggregator);
					}
				}
				
			});
		};
		
		
		$scope.changeArrangement = function(){
			if($rootScope.list.commission.arrangement!='Flat Amount'){
				$rootScope.list.commission.flatAmount = 0;
			}
			if($rootScope.list.commission.arrangement!='Flat %'){
				$rootScope.list.commission.flatPercentage = 0;
			}
			
		};
		
		
	
	//inforce information
	$scope.inforceRate='0.000';
	$scope.renewalRate='0.000';
	$scope.inforceCarrierData=[{inforceCarrier:'Accordia',percOfCoverage:100,yearsInforce:0,curEstPartLives:0,curEstPartPerc:0,comments:''}];
	$scope.inforceCarrierList=['A.A.A.A.','Accordia','Aetna','AFLAC'];
	
	
	$scope.addInforce=function(){
		alert('Underwriting review is required if an inforce carrier is deleted.');
		$scope.inforceCarrierData.push({inforceCarrier:'',percOfCoverage:100,yearsInforce:0,curEstPartLives:0,curEstPartPerc:0,comments:''});
	};
	
	$scope.deleteInforce=function(){
		alert('Underwriting review is required if an inforce carrier is deleted.');
		$scope.inforceCarrierData.pop();
	};
	
	$scope.saveInforce=function(){
		if($scope.inforceInformationForm.$error.pattern){
			alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
			return false;
		}
	};
	
	

};
