var planlDetailsController = [
		'$scope',
		'$rootScope',
		'planDetailsFactory',
		'appService','$localStorage',
		function($scope, $rootScope, planDetailsFactory, appService,$localStorage) {

			$scope.eligibleClassesData = [ {
				className : "All Employees",
				EstimateLives : "300"
			}, {
				className : "IMS BU",
				EstimateLives : "100"
			} ];
			$scope.$on('tabValChanged', function() {
				//$scope.tab = planDetailsFactory.getTabValue();
					if($scope.tab==1){
						$scope.getDataOnLoad($scope.inputList);
					} else if($scope.tab==4){
						$scope.getDataOnLoadOverrides($scope.inputList);
					}
			});

			//$rootScope.planInitData = {};
			//$rootScope.list=[];
			
			$rootScope.list=[];
			$rootScope.listOverrides=[];
			$scope.inputList = {
					proposalId:$localStorage.proposalIdAttr,
					ProposalVersionId:$localStorage.versionNumber,
					prodCode:$localStorage.productId,
					listOfPlanField:[{}]
			};

			
			
			$scope.getDataOnLoad = function(listData) {
				//var planBO = {};
				//planBO = listData;
				appService.fetchDataWithParams("mvc/createNewPlan", listData).then(function(data) {
							console.log(data)
							/*data={
								proposalId:'1234234',
								ProposalVersionId:1,
								prodCode:1,
								planId:1,
								listOfPlanField:[{
										fieldSeqId:1,
										fieldKey:'',
										fieldName:'Contract State',
										fieldType:'Dropdown',
										defaultValue:'AL',
										visibleFlag:'Y',
										altValues:[{code:'AL',value:'Alabama'}],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A',
										infoMessage:'For PruValue cases, the plan contract state selected here must be DE unless state is an extra territorial state. (AR, CO, CT, GA, ID, LA, MD, ME, MN, MS, MT, NH, NM, NY, NC, ND, OK, OR, PA, SC, SD, TX, UT, VT, WA, WI, and WV).'
									},{
										fieldSeqId:2,
										fieldKey:'planEffDate',
										fieldName:'Plan Effective Date',
										fieldType:'Date',
										defaultValue:'10/10/2016',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'validateEffDate()',
										fieldIndicator:'A'
									},{
										fieldSeqId:3,
										fieldKey:'',
										fieldName:'Plan Description',
										fieldType:'Textbox',
										defaultValue:'',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'Y',
										maxlength:'100',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:4,
										fieldKey:'',
										fieldName:'Type of Case',
										fieldType:'Dropdown',
										defaultValue:'PruValue LDSM',
										visibleFlag:'Y',
										altValues:[{code:'PruValue GA',value:'PruValue GA'},
										           {code:'PruValue IFS',value:'PruValue IFS'},
										           {code:'PruValue LDSM',value:'PruValue LDSM'},
										           {code:'PruValue Third Party Administrator',value:'PruValue Third Party Administrator'},
										           {code:'Non-PruValue',value:'Non-PruValue'},
										           {code:'Grandfathering',value:'Grandfathering'}],
										overriddenFlag:'Y',
										maxlength:'',
										onfocus:'setOldVal()',
										onchange:'confirmPruValueChange(value)',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:5,
										fieldKey:'',
										fieldName:'PruValue Exception',
										fieldType:'Checkbox',
										defaultValue:'false',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:6,
										fieldKey:'fieldLevelExceptions',
										fieldName:'Field Level Exceptions',
										fieldType:'Checkbox',
										defaultValue:'false',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:7,
										fieldKey:'',
										fieldName:'Contribution Arrangement ',
										fieldType:'Dropdown',
										defaultValue:'Non-Contributory',
										visibleFlag:'Y',
										altValues:[{code:'Contributory',value:'Contributory'},
										           {code:'Non-Contributory',value:'Non-Contributory'}],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'setOldVal()',
										onchange:'contributionPercentageChange(value)',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:9,
										fieldKey:'',
										fieldName:'Employee_Contribution_Flat_Amount',
										fieldType:'Textbox',
										defaultValue:'0.00',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:10,
										fieldKey:'',
										fieldName:'Employee_Contribution_Percentage',
										fieldType:'Textbox',
										defaultValue:'0.00',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'setOldVal()',
										onchange:'',
										onblur:'isPositiveReal()',
										fieldIndicator:'A'
									}]
							};*/
							$rootScope.list=[];
							$rootScope.list=data;
							angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
								if(listVal.fieldType=='Date'){
									$rootScope.list.listOfPlanField[listKey].defaultValue=new Date(listVal.defaultValue);
								}
							});
							
						});
			};
			
			//$scope.getDataOnLoad($scope.inputList);
			
			$scope.getDataOnLoadOverrides = function(listData) {
				var planBO = {};
				planBO = listData;
				appService.fetchDataWithParams("mvc/loadPlanDetails", planBO).then(function(data) {
							console.log(data)
							data=[{
										fieldSeqId:1,
										fieldKey:'',
										fieldName:'Contract State',
										fieldType:'Dropdown',
										defaultValue:'AL',
										visibleFlag:'Y',
										altValues:[{code:'AL',value:'Alabama'}],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:2,
										fieldKey:'planEffDate',
										fieldName:'Plan Effective Date',
										fieldType:'Date',
										defaultValue:'10/10/2016',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'validateEffDate()',
										fieldIndicator:'A'
									},{
										fieldSeqId:3,
										fieldKey:'',
										fieldName:'Plan Description',
										fieldType:'Textbox',
										defaultValue:'',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'Y',
										maxlength:'100',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:4,
										fieldKey:'',
										fieldName:'Type of Case',
										fieldType:'Dropdown',
										defaultValue:'PruValue LDSM',
										visibleFlag:'Y',
										altValues:[{code:'PruValue GA',value:'PruValue GA'},
										           {code:'PruValue IFS',value:'PruValue IFS'},
										           {code:'PruValue LDSM',value:'PruValue LDSM'},
										           {code:'PruValue Third Party Administrator',value:'PruValue Third Party Administrator'},
										           {code:'Non-PruValue',value:'Non-PruValue'},
										           {code:'Grandfathering',value:'Grandfathering'}],
										overriddenFlag:'Y',
										maxlength:'',
										onfocus:'setOldVal()',
										onchange:'confirmPruValueChange(value)',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:5,
										fieldKey:'',
										fieldName:'PruValue Exception',
										fieldType:'Checkbox',
										defaultValue:'false',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:6,
										fieldKey:'',
										fieldName:'Field Level Exceptions',
										fieldType:'Checkbox',
										defaultValue:'false',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:7,
										fieldKey:'',
										fieldName:'Contribution Arrangement ',
										fieldType:'Dropdown',
										defaultValue:'Non-Contributory',
										visibleFlag:'Y',
										altValues:[{code:'Contributory',value:'Contributory'},
										           {code:'Non-Contributory',value:'Non-Contributory'}],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'setOldVal()',
										onchange:'contributionPercentageChange(value)',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:9,
										fieldKey:'',
										fieldName:'Employee_Contribution_Flat_Amount',
										fieldType:'Textbox',
										defaultValue:'0.00',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'',
										onchange:'',
										onblur:'',
										fieldIndicator:'A'
									},{
										fieldSeqId:10,
										fieldKey:'',
										fieldName:'Employee_Contribution_Percentage',
										fieldType:'Textbox',
										defaultValue:'0.00',
										visibleFlag:'Y',
										altValues:[],
										overriddenFlag:'N',
										maxlength:'',
										onfocus:'setOldVal()',
										onchange:'',
										onblur:'isPositiveReal()',
										fieldIndicator:'A'
									}];
							$rootScope.listOverrides=[];
							$rootScope.listOverrides=data;
							angular.forEach($rootScope.listOverrides.listOfPlanField, function(listVal, listKey) {
								if(listVal.fieldType=='Date'){
									$rootScope.listOverrides.listOfPlanField[listKey].defaultValue=new Date(listVal.defaultValue);
								}
							});
							
						});
			};

			
			
			
			
			$scope.onBlurFn = function(val) {
				if(val.onblur=='validateEffDate()'){
					$scope.validateEffDate(val);
				} else if(val.onblur=='isPositiveReal()'){
					$scope.isPositiveReal(val);
				}
				
				
			};
			$scope.validateEffDate = function(val) {
				$scope.caseEffDate = '10/10/2016';
				$scope.caseEffDateComp= new Date($scope.caseEffDate);
				$scope.caseEffDateComp.setDate($scope.caseEffDateComp.getDate() - 1);
				var formatVal = document.getElementById(val.fieldKey).value;
				if(val.defaultValue==undefined || val.defaultValue==''){
					alert(''+formatVal+' is an invalid date. \nDates must be in the form:\n\nmm/dd/yyyy');
					return false;
				}else if(val.defaultValue<=$scope.caseEffDateComp){
					alert('The Effective Date for this plan must be on or after the Case Effective Date ('+$scope.caseEffDate+').');
					return false;
				}
			};
			
			
			
			$scope.onFocusFn = function(val) {
				if(val.onfocus=='setOldVal()'){
					$scope.setOldVal(val);
				}
			};
			
			$scope.oldValue ='';
			$scope.setOldVal = function(val) {
				$scope.oldValue=val.defaultValue;
			};
			
			$scope.confirmPruValueChange = function(listData) {
				if(confirm('Warning! Changing Type of Case will reset all selections to comply with the appropriate rules. Continue?')){
					//$scope.onChangeFn(listData);
				}else{
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.confirmStateChange = function(listData) {
				if(confirm('Warning! Changing Contract State will reset all selections to comply with State regulations. Continue?')){
					//$scope.onChangeFn(listData);
				}else{
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.doFLException = function(listData) {
				if(confirm('Warning! Clicking yes will make this plan a Field Level Exception plan, and it will not be able to be changed back. Continue?')){
					//$scope.onChangeFn(listData);
				}else{
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.doPVException = function(listData) {
				if(confirm('Warning! Clicking yes will make this plan a PruValue Exception and will not be able to be changed back. Continue?')){
					//$scope.onChangeFn(listData);
				}else{
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.confirmStatutoryPlanHandlingChange = function(listData) {
				if(confirm('Warning! Changing Statutory Plan Handling will reset all selections to comply with the appropriate rules. Continue?')){
					//$scope.onChangeFn(listData);
				}else{
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.confirmSubProductChange = function(listData) {
				if(confirm('Warning! Changing SubProduct will reset all selections to comply with the appropriate rules. Continue?')){
					//$scope.onChangeFn(listData);
				}else{
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.confirmContractWrittenOnChange = function(listData) {
				if(confirm('Warning! Changing Contract Written On will reset all selections to comply with the appropriate rules. Continue?')){
					//$scope.onChangeFn(listData);
				}else{
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.confirmUnderwrittenByChange = function(listData) {
				if(confirm('Warning! Changing Plan Underwritten By will reset all selections to comply with the appropriate rules. Continue?')){
					//$scope.onChangeFn(listData);
				}else{
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.isPositiveReal = function(listData) {
				if(!$scope.numericPattern.test(listData.defaultValue) || listData.defaultValue==''){
					alert(''+listData.defaultValue+' is not valid type: positive real');
					listData.defaultValue=$scope.oldValue;
				}
			};
			
			$scope.contributionPercentageChange = function(listData) {
				if(listData.defaultValue=='Contributory'){
					if(confirm('Contribution Percentage must be at least 20% to select this option.')){
						//$scope.onChangeFn(listData);
					}else{
						listData.defaultValue=$scope.oldValue;
					}
				}
				
			};
			
			
			$scope.onChangeFn = function(listData) {
				angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
					if(listVal.fieldSeqId==listData.fieldSeqId){
						$rootScope.list.listOfPlanField[listKey].fieldIndicator='C';
					}
					if(listVal.fieldType=='Date'){
						$rootScope.list.listOfPlanField[listKey].defaultValue=document.getElementById(listVal.fieldKey).value;
					}
				});
				
				appService.fetchDataWithParams("mvc/changePlanDetails", $rootScope.list).then(function(data) {
					data=[{
								fieldSeqId:8,
								fieldKey:'',
								fieldName:'Employee_Contribution_Type',
								fieldType:'Dropdown',
								defaultValue:'',
								visibleFlag:'Y',
								altValues:[{code:'',value:'Choose One'},
								           {code:'Flat Amount',value:'Flat Amount'},
								           {code:'Percentage',value:'Percentage'}],
								overriddenFlag:'N',
								maxlength:'',
								onfocus:'',
								onchange:'',
								onblur:'',
								fieldIndicator:'A'
							},{
								fieldSeqId:11,
								fieldKey:'',
								fieldName:'Minimum Participation Percentage',
								fieldType:'Textbox',
								defaultValue:'100.00',
								visibleFlag:'Y',
								altValues:[],
								overriddenFlag:'N',
								maxlength:'',
								onfocus:'',
								onchange:'',
								onblur:'',
								fieldIndicator:'A'
							},{
								fieldSeqId:4,
								fieldKey:'',
								defaultValue:'PruValue IFS',
								altValues:[{code:'PruValue GA',value:'PruValue GA'},
								           {code:'PruValue IFS',value:'PruValue IFS'},
								           {code:'PruValue LDSM',value:'PruValue LDSM'},
								           {code:'PruValue Third Party Administrator',value:'PruValue Third Party Administrator'},
								           {code:'Non-PruValue',value:'Non-PruValue'},
								           {code:'Grandfathering',value:'Grandfathering'}],
								fieldIndicator:'C'
							},{
								fieldSeqId:10,
								fieldKey:'',
								defaultValue:'45',
								altValues:[],
								fieldIndicator:'C'
							},{
								fieldSeqId:9,
								fieldKey:'',
								fieldIndicator:'R'
							},{
								fieldSeqId:6,
								fieldKey:'',
								fieldIndicator:'R'
							}];
					
					angular.forEach(data, function(val, key) {
						if(val.fieldIndicator=='A'){
							$rootScope.list.listOfPlanField.push(val);
						}else if(val.fieldIndicator=='C'){
							angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
								if(listVal.fieldSeqId==val.fieldSeqId){
									$rootScope.list.listOfPlanField[listKey].defaultValue=val.defaultValue;
									$rootScope.list.listOfPlanField[listKey].altValues=val.altValues;
								}
							});
						}else if(val.fieldIndicator=='R'){
							angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
								if(listVal.fieldSeqId==val.fieldSeqId){
									$rootScope.list.listOfPlanField.splice($rootScope.list.listOfPlanField.indexOf(listVal),1);
								}
							});
						}
						angular.forEach($rootScope.list.listOfPlanField, function(listVal, listKey) {
							$rootScope.list.listOfPlanField[listKey].fieldIndicator='A';
							if(listVal.fieldType=='Date'){
								$rootScope.list.listOfPlanField[listKey].defaultValue=new Date(listVal.defaultValue);
							}
						});
						
						/*console.log(val,key);
						if(key=='addField'){
							angular.forEach(val, function(addVal, addKey) {
								$rootScope.list.push(addVal);
							});
						}else if(key=='changeField'){
							angular.forEach(val, function(changeVal, changeKey) {
								angular.forEach($rootScope.list, function(listVal, listKey) {
									if(listVal.fieldSeqId==changeVal.fieldSeqId){
										$rootScope.list[listKey].defaultValue=changeVal.defaultValue;
										$rootScope.list[listKey].altValues=changeVal.altValues;
									}
								});
							});
							
						}else if(key=='removeField'){
							angular.forEach(val, function(removeVal, removeKey) {
								angular.forEach($rootScope.list, function(listVal, listKey) {
									if(listVal.fieldSeqId==removeVal.fieldSeqId){
										$rootScope.list.splice($rootScope.list.indexOf(listVal),1);
									}
								});
							});
						}
						*/
				    });
					
				});
			};
			
			
			$scope.onChangeFnOverrides = function(listData) {
				angular.forEach($rootScope.listOverrides.listOfPlanField, function(listVal, listKey) {
					if(listVal.fieldSeqId==listData.fieldSeqId){
						$rootScope.listOverrides.listOfPlanField[listKey].fieldIndicator='C';
					}
					if(listVal.fieldType=='Date'){
						$rootScope.listOverrides.listOfPlanField[listKey].defaultValue=document.getElementById(listVal.fieldKey).value;
					}
				});
				
				appService.fetchDataWithParams("mvc/changePlanDetails", $rootScope.listOverrides).then(function(data) {
					data=[{
								fieldSeqId:8,
								fieldKey:'',
								fieldName:'Employee_Contribution_Type',
								fieldType:'Dropdown',
								defaultValue:'',
								visibleFlag:'Y',
								altValues:[{code:'',value:'Choose One'},
								           {code:'Flat Amount',value:'Flat Amount'},
								           {code:'Percentage',value:'Percentage'}],
								overriddenFlag:'N',
								maxlength:'',
								onfocus:'',
								onchange:'',
								onblur:'',
								fieldIndicator:'A'
							},{
								fieldSeqId:11,
								fieldKey:'',
								fieldName:'Minimum Participation Percentage',
								fieldType:'Textbox',
								defaultValue:'100.00',
								visibleFlag:'Y',
								altValues:[],
								overriddenFlag:'N',
								maxlength:'',
								onfocus:'',
								onchange:'',
								onblur:'',
								fieldIndicator:'A'
							},{
								fieldSeqId:4,
								fieldKey:'',
								defaultValue:'PruValue IFS',
								altValues:[{code:'PruValue GA',value:'PruValue GA'},
								           {code:'PruValue IFS',value:'PruValue IFS'},
								           {code:'PruValue LDSM',value:'PruValue LDSM'},
								           {code:'PruValue Third Party Administrator',value:'PruValue Third Party Administrator'},
								           {code:'Non-PruValue',value:'Non-PruValue'},
								           {code:'Grandfathering',value:'Grandfathering'}],
								fieldIndicator:'C'
							},{
								fieldSeqId:10,
								fieldKey:'',
								defaultValue:'45',
								altValues:[],
								fieldIndicator:'C'
							},{
								fieldSeqId:9,
								fieldKey:'',
								fieldIndicator:'R'
							},{
								fieldSeqId:6,
								fieldKey:'',
								fieldIndicator:'R'
							}];
					
					angular.forEach(data, function(val, key) {
						if(val.fieldIndicator=='A'){
							$rootScope.listOverrides.listOfPlanField.push(val);
						}else if(val.fieldIndicator=='C'){
							angular.forEach($rootScope.listOverrides.listOfPlanField, function(listVal, listKey) {
								if(listVal.fieldSeqId==val.fieldSeqId){
									$rootScope.listOverrides.listOfPlanField[listKey].defaultValue=val.defaultValue;
									$rootScope.listOverrides.listOfPlanField[listKey].altValues=val.altValues;
								}
							});
						}else if(val.fieldIndicator=='R'){
							angular.forEach($rootScope.listOverrides.listOfPlanField, function(listVal, listKey) {
								if(listVal.fieldSeqId==val.fieldSeqId){
									$rootScope.listOverrides.listOfPlanField.splice($rootScope.listOverrides.listOfPlanField.indexOf(listVal),1);
								}
							});
						}
						angular.forEach($rootScope.listOverrides.listOfPlanField, function(listVal, listKey) {
							$rootScope.listOverrides.listOfPlanField[listKey].fieldIndicator='A';
							if(listVal.fieldType=='Date'){
								$rootScope.listOverrides.listOfPlanField[listKey].defaultValue=new Date(listVal.defaultValue);
							}
						});
						
				    });
					
				});
			};

			$scope.nextTab = function() {
				if ($scope.tab == 1) {
					planDetailsFactory.setTabValue(2);
				} else if ($scope.tab == 4) {
					planDetailsFactory.setTabValue(5);
				}
			};

			$scope.isOverridden = function(key) {
				var isOver = false;
				//if ($scope.tab != 4 && $rootScope.planInitData[key].isOverRidden) {
				if ($scope.tab != 4 && $rootScope.list[key].isOverRidden) {
					isOver = true;
				}
				return isOver;
			};

			$scope.savePlan = function() {
				//.saveList = {};
				//angular.forEach($rootScope.list, function(val, key) {
					 //$scope.saveList[val.fieldKey]=val.defaultValue;
			        // $scope.saveList[val.fieldSeqId]=val.defaultValue;
			    //});
				//console.log($scope.saveList);
				appService.fetchDataWithParams("mvc/savePlanDetails", $rootScope.list).then(function(data) {
					$scope.getDataOnLoad($scope.inputList);
				});
				
			};
			$scope.savePlanOverrides = function() {
				appService.fetchDataWithParams("mvc/savePlanDetails", $rootScope.listOverrides).then(function(data) {
					$scope.getDataOnLoadOverrides($scope.inputList);
				});
				
			};
		} ];
