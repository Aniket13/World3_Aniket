var quickQuotesController = ['$scope', '$rootScope', 'appService', '$localStorage','$location',
                             function($scope,$rootScope, appService,$localStorage, $location){
	

	$scope.getHeadTopLists = function (proposalIdVal, clientIdVal) { 
		var proposal = {
				proposalId : proposalIdVal,
				clientId: clientIdVal
		};
		appService.fetchDataWithParams("mvc/getHeaderDetails",proposal).then(function(data) {
			$scope.headerDetails = data;
			$scope.headTopLists=[ {name : 'Proposol ID', value : $scope.headerDetails.proposalId},
			                      {name : 'Client Name', value : $scope.headerDetails.clientName},
			                      {name : 'Proposal Status',value : $scope.headerDetails.proposalStatusVal}
			                    ];
		});
	};
	$scope.getHeadTopLists($localStorage.proposalIdAttr,$localStorage.clientIdAttr);
	
	//method to return the total number of versions of a proposal
	$scope.proposalVersionsCount='';
	$scope.getProposalVersionsCount = function() {
		var proposal = {
				proposalId : $localStorage.proposalIdAttr
		};
		appService.fetchDataWithParams("mvc/getProposalVersionsCount",proposal).then(function(data){
			$scope.proposalVersionsCount = data;
			console.log($scope.proposalVersionsCount);
			//create a new version by default if there is no version available
			if ($scope.proposalVersionsCount!= null && $scope.proposalVersionsCount!= undefined && $scope.proposalVersionsCount === 0) {
				//create a new version if there are no versions
				console.log($scope.proposalVersionsCount);
				//create a new version if there are no versions available for current proposal
				$scope.newVersion(0);
			} else if($scope.proposalVersionsCount>1){
				$scope.getProposalVersions();
				$scope.hasVersionDetails = false;
				//if($localStorage.versionNumber!=undefined && $localStorage.versionNumber!=''){
				//	$scope.getVersionDetails($localStorage.proposalIdAttr,$localStorage.versionNumber,$localStorage.versionIndexNum);
				//}
			}else{
				//calling first version details
				$scope.getProposalVersions();
				//if($localStorage.versionNumber!=undefined && $localStorage.versionNumber!=''){
				//	$scope.getVersionDetails($localStorage.proposalIdAttr,$localStorage.versionNumber,0);
				//}
				
			}
		});	
	};
	
	//calling the function getProposalVersionsCount() on load
	$scope.getProposalVersionsCount();
	$rootScope.isCollapsedVersion = false;
	$rootScope.selectedVersion = '';
	
	$scope.showVersion = function() {
		$rootScope.isCollapsedVersion = !$rootScope.isCollapsedVersion;
	};
	//logic to get the proposal versions
	$rootScope.proposalVersions = [];
	$scope.getProposalVersions = function() {
		var proposal = {
				proposalId : $localStorage.proposalIdAttr
		};
		appService.fetchDataWithParams("mvc/getProposalVersions",proposal).then(function(data){
			$rootScope.proposalVersions = data;
			$scope.proposalVersionsCount = data.length;
			if(data.length==1){
				$localStorage.versionNumber = data[0].versionNumber;
				$scope.getVersionDetails($localStorage.proposalIdAttr,$localStorage.versionNumber,0);
			}else{
				if($localStorage.versionNumber!=undefined && $localStorage.versionNumber!=''){
					$scope.getVersionDetails($localStorage.proposalIdAttr,$localStorage.versionNumber,$localStorage.versionIndexNum);
				}
			}
			console.log($rootScope.proposalVersions);
		});
	};
	
	//create new version start
	$scope.hasVersionDetails = false;
	$scope.newVersionFlag=false;
	$scope.newVersion = function(val) {
		var proposal = {
				proposalId : $localStorage.proposalIdAttr,
				clientId : $localStorage.clientIdAttr
	};
		var versionNumber=val;
		$scope.newVersionFlag =true;
		if(val!=0){
			versionNumber  = versionNumber+1;
			$localStorage.versionIndexNum = versionNumber;
		}
		$rootScope.selectedQuoteReasons = {
				reasons: []
			};
			$rootScope.selectedQuoteProducts = {
				products: []
			};
			$localStorage.productName='';
			$localStorage.planNumber='';
		appService.fetchDataWithParams("mvc/createNewQuotation",proposal).then(function(data){
			$rootScope.versionDetails = data;
			$scope.hasVersionDetails = true;
			$localStorage.versionNumber = $rootScope.versionDetails.versionNumber;
			//calling method $scope.getVersionDetails()
			$scope.getProposalVersions();
			
			//$scope.getVersionDetails($rootScope.versionDetails.proposalId,$rootScope.versionDetails.versionNumber, versionNumber);
		});
		$rootScope.isCollapsedVersion = true;
		
	};
	//create new version end
	
	//save the current version details start
	$scope.saveVersion =  function (quotation) {
		console.log("Inside saveVersion Method");
		if($rootScope.selectedQuoteReasons.reasons.length<1){
			alert('No Quote Reason Code has been entered for this version. Please select a Quote Reason Code and save.');
			return false;
		}
		if($rootScope.versionDetails.selectedCensus=="" || isNaN($rootScope.versionDetails.selectedCensus)){
			alert('Please select census.');
			return false;
		}
		quotation.proposalId = $localStorage.proposalIdAttr;
		quotation.selectedQuoteReasons = $rootScope.selectedQuoteReasons.reasons;
		quotation.selectedQuoteProducts = $rootScope.selectedQuoteProducts.products;
		console.log(quotation);
		// ajax call to back end
		appService.fetchDataWithParams("mvc/saveQuotation",quotation).then(function(data){
			$rootScope.versionDetails = data;
			//calling the function to get the latest details
			$localStorage.versionNumber = $rootScope.versionDetails.versionNumber;
			$scope.getProposalVersions();
			//$scope.getVersionDetails($rootScope.versionDetails.proposalId,$rootScope.versionDetails.versionNumber, $localStorage.versionIndexNum);
		});
	};
	
	$rootScope.selectedQuoteReasons = {
		reasons: []
	};
	$rootScope.selectedQuoteProducts = {
		products: []
	};
	$scope.toggleSelection = function toggleSelection(val, type) {
		if (type === 'product') {
  		  var idx =$scope.selectedQuoteProducts.products.indexOf(val);
  		  // is currently selected
		  if (idx > -1) {
		    $scope.selectedQuoteProducts.products.splice(idx, 1);
		  }
		  // is newly selected
		  else {
			  $scope.selectedQuoteProducts.products.push(val);
		  }
		} else if (type === 'quote') {
	  		  var idx =$scope.selectedQuoteReasons.reasons.indexOf(val);
	  		  // is currently selected
			  if (idx > -1) {
			    $scope.selectedQuoteReasons.reasons.splice(idx, 1);
			  }
			  // is newly selected
			  else {
				  $scope.selectedQuoteReasons.reasons.push(val);
			  }
		} 
	};
	
	//save the current version details end
	
	//select the current version details start
	$scope.versionIndex=$localStorage.versionIndexNum;
	
	$scope.getVersionDetails = function(proposalId, versionNumber, versionIndex) {
		$localStorage.versionIndexNum=versionIndex;
		if($scope.proposalVersionsCount<=versionIndex && versionIndex!=0){
			$scope.versionIndex=versionIndex;
		}else if($scope.proposalVersionsCount==0 || $scope.proposalVersionsCount==1){
			$scope.versionIndex=1;
		}else{
			$scope.versionIndex = $scope.proposalVersionsCount - versionIndex;
		}
		
		var quotation = {
				proposalId : proposalId,
				versionNumber : versionNumber,
				clientId : $localStorage.clientIdAttr
		};
		$localStorage.versionNumber=versionNumber;
		
		appService.fetchDataWithParams("mvc/getVersionDetails",quotation).then(function(data){
			console.log(data);
			$rootScope.selectedQuoteReasons = {
					reasons: []
				};
				$rootScope.selectedQuoteProducts = {
					products: []
				};
			$rootScope.versionDetails = data;
			if($scope.newVersionFlag){
				var createCommission={
						proposalPlanID : $localStorage.proposalIdAttr,
						brokerID : $localStorage.selBrokerId,
						versionNumber:$rootScope.versionDetails.versionNumber
				};
				appService.fetchDataWithParams("mvc/createNewCommission",createCommission).then(function(data){
					$scope.getCommissionDetails();
				});
				$scope.newVersionFlag =false;
			}else{
				$scope.getCommissionDetails();
			}
			angular.forEach($rootScope.versionDetails.selectedQuoteReasons,function(val){
				$rootScope.selectedQuoteReasons.reasons.push(val);
			});
			angular.forEach($rootScope.versionDetails.selectedQuoteProducts,function(val){
				$rootScope.selectedQuoteProducts.products.push(val);
			});
			if($scope.versionDetails.versionStatus==null || $scope.versionDetails.versionStatus ==undefined){
				$scope.versionDetails.versionStatus='Pending Rate Calculation';
			}
			//$rootScope.selectedQuoteProducts.products = $rootScope.versionDetails.selectedQuoteProducts;
			if($scope.versionDetails.documentFormat==null || $scope.versionDetails.documentFormat ==undefined){
				$scope.versionDetails.documentFormat='PDF';
			}
			if($scope.versionDetails.billingMethod==null || $scope.versionDetails.billingMethod ==undefined){
				$scope.versionDetails.billingMethod='Roster';
			}
			if($scope.versionDetails.billingDeliveryMethod==null || $scope.versionDetails.billingDeliveryMethod ==undefined){
				$scope.versionDetails.billingDeliveryMethod='Mail';
			}
			if($scope.versionDetails.atpVoucher==null || $scope.versionDetails.atpVoucher ==undefined){
				$scope.versionDetails.atpVoucher='No';
			}
			$scope.versionDetails.selectedCensus = parseInt($scope.versionDetails.selectedCensus);
			if ($rootScope.versionDetails != null && $rootScope.versionDetails != undefined) {
				console.log($rootScope.versionDetails);
				$scope.hasVersionDetails = true;
				$rootScope.isCollapsedVersion = true;
				$rootScope.selectedVersion = $rootScope.versionDetails.versionDesc;
			}
			$localStorage.versionDescription= $rootScope.versionDetails.versionDesc;
			$localStorage.versionIndexNumber = $scope.versionIndex;
			$localStorage.versionStatus = $scope.versionDetails.versionStatus;
			//var versionHeadDetails={name : 'Version Number',value : $scope.versionDetails.versionNumber}, 
           // {name : 'Version Description',value :  $scope.versionDetails.versionDesc},
            //{name : 'Version Status',value : $scope.versionDetails.versionStatus};
			$scope.headTopLists[3]={name : 'Version Number',value : $scope.versionIndex};
			$scope.headTopLists[4]={name : 'Version Description',value :  $scope.versionDetails.versionDesc};
			$scope.headTopLists[5]={name : 'Version Status',value : $scope.versionDetails.versionStatus};
			
			if($localStorage.productName!=undefined && $localStorage.productName!=''){
					$scope.headTopLists[6]=	 {name : 'Product',value : $localStorage.productName};
					if($localStorage.planNumber!=undefined && $localStorage.planNumber!=''){
						$scope.headTopLists[7]={name : 'Plan Number',value : $localStorage.planNumber};
						$scope.headTopLists[8]={name : 'Plan Description',value :  $localStorage.planDescription};
					}
			}else{
				$scope.headTopLists[6]={};
				$scope.headTopLists[7]={};
				$scope.headTopLists[8]={};
			}
				
            
		});
	};
	
	//select the current version details end
	
	//Commission
	
	
	$scope.lifeComm = {};
	$scope.errorMsgComm='';
	$scope.selectedProducers='';
	$scope.producers=[];
	$scope.selCommissionSplit=0;
	$scope.getCommissionDetails = function(){
		var proposal = {
				proposalPlanID : $localStorage.proposalIdAttr,
				brokerID : $localStorage.selBrokerId,
				versionNumber:$localStorage.versionNumber
		};
		appService.fetchDataWithParams("mvc/getCommission",proposal).then(function(data){
			$scope.lifeComm=data;
			if($scope.lifeComm.advaceCommissionOccurs==null || $scope.lifeComm.advaceCommissionOccurs ==undefined){
				$scope.lifeComm.advaceCommissionOccurs='First Year';
			}
			if($scope.lifeComm.arrangement==null || $scope.lifeComm.arrangement ==undefined){
				$scope.lifeComm.arrangement='Level Scale';
			}
			if($scope.lifeComm.commissionPaidTo==null || $scope.lifeComm.commissionPaidTo ==undefined){
				$scope.lifeComm.commissionPaidTo='Individual';
			}
			if($scope.lifeComm.commissionSplit==null || $scope.lifeComm.commissionSplit ==undefined){
				$scope.lifeComm.commissionSplit=0;
			}
			if($scope.lifeComm.advanceCommissionFlag==null){
				$scope.lifeComm.advanceCommissionFlag='N';
			}
			$scope.selCommissionSplit = $scope.lifeComm.commissionSplit;
		});
		
	};
	
	appService.fetchData("mvc/getProducer").then(function(data){
		console.log('producer:'+data);
		$scope.selectedProducers=data[0].producerName;
		$scope.producers.push($scope.selectedProducers);
	
	});
	
	
	$scope.arrangements= ['Level Scale','Flat Amount','Flat %','Direct','None'];
	$scope.paidTo = ['Individual', 'Firm'];
	$scope.advaceCommissionOccurs = ['First Year','First Year and Renewal','Renewal'];
	
	$scope.ascList = [
	             {
	            	 ascId:1,
	            	 description : 'Design of policy holder\'s benefit administration system.',
	            	 pct : 3.0
	             },
	             {
	            	 ascId:2,
	            	 description : 'Participation in programs of communication and education for control.',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:3,
	            	 description : 'Consultation in correction with rate change or alternate plans of insurance.',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:4,
	            	 description : 'Review of contractual provisions.',
	            	 pct : 3.0
	             },
	             {
	            	 ascId:5,
	            	 description : 'Assistance in enrollment meeting (not related to trade association or multiple employer groups) or site visits to managed medical operations.',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:6,
	            	 description : 'Assembly and analysis of claim experience.',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:7,
	            	 description : 'Assistance in the development and preparation of plan announcement material, employee benefit booklets or other plan documents.',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:8,
	            	 description : 'Customer Satisfaction Monitors',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:9,
	            	 description : 'Maintain Premium and Statistic Records',
	            	 pct : 3.0
	             },
	             {
	            	 ascId:10,
	            	 description : 'Supervising General Agent',
	            	 pct : 3.0
	             },
	             {
	            	 ascId:11,
	            	 description : 'Collective Bargaining Consultation',
	            	 pct : 2.0
	             }
	   ];
	
	$scope.sum = 0;
	$scope.calcSum = function($event, id) {
        var checkbox = $event.target;

       if (checkbox.checked) {
           $scope.sum += parseInt(checkbox.value);   
        } else {
           $scope.sum -= parseInt(checkbox.value);    
        }  
	};
	
	$scope.validateFn= function(){
		$scope.saveVersion($rootScope.versionDetails);
		$scope.saveLifeComm();
	};
	$scope.saveLifeComm= function(){
		//alert($scope.lifeComm.flatPct+''+$scope.lifeComm.flatAmt);
		
		var flatPct = document.getElementById('flatPct');
		var advCommPct = document.getElementById('advCommPct');
		if(!isNaN(flatPct.value) && flatPct.value<0 || !isNaN(flatPct.value) && flatPct.value>100 || !isNaN(advCommPct.value) && advCommPct.value<0 || !isNaN(advCommPct.value) && advCommPct.value>100){
			alert('Entered value must be in the range of 0 to 100. Please try again.');
			return false;
		}
		if($scope.lifeCommisionForm.$error.pattern){
			if(!$scope.specCharPattern.test(document.getElementById('commSplit').value)){
				alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
			}else{
					alert('Entered value does not appear to be a numeric. Please try again.');
			}
			return false;
		};
		if(document.getElementById('commSplit').value==''){
			$scope.lifeComm.commissionSplit = $scope.selCommissionSplit;
		}
		
		$scope.lifeComm.commissionSplit = parseFloat($scope.lifeComm.commissionSplit);
		$scope.lifeComm.flatAmount = parseFloat($scope.lifeComm.flatAmount);
		$scope.lifeComm.flatPercentage = parseFloat($scope.lifeComm.flatPercentage);
		$scope.lifeComm.advanceCommission = parseFloat($scope.lifeComm.advanceCommission);
		$scope.errorMsgComm = '';
		appService.fetchDataWithParams("mvc/saveCommission",$scope.lifeComm).then(function(data){
			if(data != null){
				if(data.errorMsg!=null){
					if(typeof(data.errorMsg)=='string'){
						$scope.errorMsgComm = data.errorMsg;
						return false;
					}else{
						$scope.createTbl = $scope.createErrorTable(data.errorMsg); 
						$scope.createTbl =$scope.createTbl.outerHTML;
					}
					var newWindow = window.open('','errorWindow',"width=600,height=300, top=80,scrollbars=1,resizable=1");
					newWindow.document.body.innerHTML = $scope.createTbl;
					newWindow.document.title = 'Fields Required';
				}
			}
			
		});
	};
	
	
	$scope.changeArrangement = function(){
		if($scope.lifeComm.arrangement!='Flat Amount'){
			$scope.lifeComm.flatAmount = 0;
		}
		if($scope.lifeComm.arrangement!='Flat %'){
			$scope.lifeComm.flatPercentage = 0;
		}
		
	};
	$scope.planDetails = function(versionNumber, productId){
		//return false; //stop plan page for demo
		$localStorage.versionNumber = versionNumber;
		$localStorage.productId = productId;
		$localStorage.versionStatus=$rootScope.versionDetails.versionStatus;
		$localStorage.productName = $rootScope.versionDetails.productList[$localStorage.productId-1].productDesc;
		$localStorage.selectedCensusId = $rootScope.versionDetails.selectedCensus;
		var json = {
			versionNumber : versionNumber,
			productId : productId
		};
		appService.fetchDataWithParams("mvc/setVersionInSession",json).then(function(data){});
		$location.path("/plan");
	};
	
}];