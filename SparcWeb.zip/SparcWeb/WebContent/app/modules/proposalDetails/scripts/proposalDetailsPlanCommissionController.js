var proposalDetailsPlanCommissionController = ['$scope', '$rootScope', 'appService', '$localStorage','$location',
                             function($scope,$rootScope, appService,$localStorage, $location){
	
	
	
//Commission
	
	
	$scope.lifeComm = {};
	$scope.errorMsgComm='';
	$scope.selectedProducers='';
	$scope.producers=[];
	$scope.selCommissionSplit=0;
	$scope.getCommissionDetails = function(){
		var proposal = {
				proposalPlanID : $localStorage.proposalIdAttr,
				brokerID : $localStorage.selBrokerId,
				versionNumber:$localStorage.versionNumber
		};
		appService.fetchDataWithParams("mvc/getCommission",proposal).then(function(data){
			$scope.lifeComm=data;
			if($scope.lifeComm.advaceCommissionOccurs==null || $scope.lifeComm.advaceCommissionOccurs ==undefined){
				$scope.lifeComm.advaceCommissionOccurs='First Year';
			}
			if($scope.lifeComm.arrangement==null || $scope.lifeComm.arrangement ==undefined){
				$scope.lifeComm.arrangement='Level Scale';
			}
			if($scope.lifeComm.commissionPaidTo==null || $scope.lifeComm.commissionPaidTo ==undefined){
				$scope.lifeComm.commissionPaidTo='Individual';
			}
			if($scope.lifeComm.commissionSplit==null || $scope.lifeComm.commissionSplit ==undefined){
				$scope.lifeComm.commissionSplit=0;
			}
			if($scope.lifeComm.advanceCommissionFlag==null){
				$scope.lifeComm.advanceCommissionFlag='N';
			}
			$scope.selCommissionSplit = $scope.lifeComm.commissionSplit;
		});
		
		appService.fetchData("mvc/getProducer").then(function(data){
			console.log('producer:'+data);
			$scope.selectedProducers=data[0].producerName;
			$scope.producers.push($scope.selectedProducers);
		
		});
	};
	
	
	
	$scope.arrangements= ['Level Scale','Flat Amount','Flat %','Direct','None'];
	$scope.paidTo = ['Individual', 'Firm'];
	$scope.advaceCommissionOccurs = ['First Year','First Year and Renewal','Renewal'];
	
	$scope.ascList = [
	             {
	            	 ascId:1,
	            	 description : 'Design of policy holders benefit administration system',
	            	 pct : 3.0
	             },
	             {
	            	 ascId:2,
	            	 description : 'Participation in programs of communication and education for control',
	            	 pct : 3.0
	             },
	             {
	            	 ascId:3,
	            	 description : 'Consultation in correction with rate change or alternate plans of insurance',
	            	 pct : 3.0
	             },
	             {
	            	 ascId:4,
	            	 description : 'Review of contractual provisions',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:5,
	            	 description : 'Assistance in enrollment meeting (not related to trade association or multiple employeer groups) or site visits to managed medical operations',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:6,
	            	 description : 'Assembly and analysis of claim experience',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:7,
	            	 description : 'Assistance in the development and preparation of plan announcement material, employee benefit booklets or other plan documents.',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:8,
	            	 description : 'Customer Satisfaction Monitors',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:9,
	            	 description : 'Maintain premium and Statistic Records',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:10,
	            	 description : 'Supervising General Agent',
	            	 pct : 2.0
	             },
	             {
	            	 ascId:11,
	            	 description : 'Collective Bargaining Consultation',
	            	 pct : 2.0
	             }
	   ];
	
	$scope.sum = 0;
	$scope.calcSum = function($event, id) {
        var checkbox = $event.target;

       if (checkbox.checked) {
           $scope.sum += parseInt(checkbox.value);   
        } else {
           $scope.sum -= parseInt(checkbox.value);    
        }  
	};
	
	
	$scope.saveLifeComm= function(){
		//alert($scope.lifeComm.flatPct+''+$scope.lifeComm.flatAmt);
		
		var flatPct = document.getElementById('flatPct');
		var advCommPct = document.getElementById('advCommPct');
		if(!isNaN(flatPct.value) && flatPct.value<0 || !isNaN(flatPct.value) && flatPct.value>100 || !isNaN(advCommPct.value) && advCommPct.value<0 || !isNaN(advCommPct.value) && advCommPct.value>100){
			alert('Entered value must be in the range of 0 to 100. Please try again.');
			return false;
		}
		if($scope.lifeCommisionForm.$error.pattern){
			if(!$scope.specCharPattern.test(document.getElementById('commSplit').value)){
				alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
			}else{
					alert('Entered value does not appear to be a numeric. Please try again.');
			}
			return false;
		};
		if(document.getElementById('commSplit').value==''){
			$scope.lifeComm.commissionSplit = $scope.selCommissionSplit;
		}
		
		$scope.lifeComm.commissionSplit = parseFloat($scope.lifeComm.commissionSplit);
		$scope.lifeComm.flatAmount = parseFloat($scope.lifeComm.flatAmount);
		$scope.lifeComm.flatPercentage = parseFloat($scope.lifeComm.flatPercentage);
		$scope.lifeComm.advanceCommission = parseFloat($scope.lifeComm.advanceCommission);
		$scope.errorMsgComm = '';
		appService.fetchDataWithParams("mvc/saveCommission",$scope.lifeComm).then(function(data){
			if(data != null){
				if(data.errorMsg!=null){
					if(typeof(data.errorMsg)=='string'){
						$scope.errorMsgComm = data.errorMsg;
						return false;
					}else{
						$scope.createTbl = $scope.createErrorTable(data.errorMsg); 
						$scope.createTbl =$scope.createTbl.outerHTML;
					}
					var newWindow = window.open('','errorWindow',"width=600,height=300, top=80,scrollbars=1,resizable=1");
					newWindow.document.body.innerHTML = $scope.createTbl;
					newWindow.document.title = 'Fields Required';
				}
			}
			
		});
	};
	
	
	$scope.changeArrangement = function(){
		if($scope.lifeComm.arrangement!='Flat Amount'){
			$scope.lifeComm.flatAmount = 0;
		}
		if($scope.lifeComm.arrangement!='Flat %'){
			$scope.lifeComm.flatPercentage = 0;
		}
		
	};
	
	
}];