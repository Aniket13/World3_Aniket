var fieldGenerator = function($compile) {

	return {
		restrict : 'E',
		scope : {
			elementData : '=',
		},
		replace : true,

		link : function(scope, element, attrs) {

			var textbox = '<input ng-disabled="tab==4" type="text"'
					+ 'data-ng-model="elementData.value" class="pull-right">';
			var dropdown = '<select ng-change="" ng-disabled="tab==4" data-ng-model="planDtls.id"'
					+ 'class="width40pct pull-right" data-ng-options="item.description as item.description for item in elementData.allValues">'
					+ '<option value="">Select</option></select>';
			var checkbox = '<input type="checkbox" data-ng-model="s" class="pull-right"'
					+ 'ng-click="overRidePlan($event, field)" ng-checked="field.isOverRidden">';

			if (scope.elementData.fieldType == "dropdown") {
				element.html(dropdown);
				$compile(element.contents())(scope);
			} else if (scope.elementData.fieldType == "textbox") {
				element.html(textbox);
				$compile(element.contents())(scope);
			} else if (scope.elementData.fieldType == "checkbox") {
				element.html(checkbox);
				$compile(element.contents())(scope);
			}
		}

	};

};

