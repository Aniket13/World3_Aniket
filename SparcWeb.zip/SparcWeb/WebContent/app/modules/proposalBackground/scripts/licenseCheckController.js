var licenseCheckController = ['$scope','$localStorage','appService',function($scope,$localStorage,appService){
	
	$scope.getHeadTopLists = function (proposalIdVal, clientIdVal) { 
		var proposal = {
				proposalId : proposalIdVal,
				clientId: clientIdVal
		};
		appService.fetchDataWithParams("mvc/getHeaderDetails",proposal).then(function(data) {
			$scope.headerDetails = data;
			$scope.headTopLists=[ {name : 'Proposol ID', value : $scope.headerDetails.proposalId},
			                      {name : 'Client Name', value : $scope.headerDetails.clientName},
			                      {name : 'Proposal Status',value : $scope.headerDetails.proposalStatusVal}
			                    ];
			if($localStorage.versionNumber!=undefined && $localStorage.versionNumber!=''){
				$scope.headTopLists[3]={name : 'Version Number',value : $localStorage.versionIndexNumber};
				$scope.headTopLists[4]={name : 'Version Description',value :  $localStorage.versionDescription};
				$scope.headTopLists[5]={name : 'Version Status',value : $localStorage.versionStatus};
				
				if($localStorage.productName!=undefined && $localStorage.productName!=''){
					$scope.headTopLists[6]=	 {name : 'Product',value : $localStorage.productName};
					if($localStorage.planNumber!=undefined && $localStorage.planNumber!=''){
						$scope.headTopLists[7]={name : 'Plan Number',value : $localStorage.planNumber};
						$scope.headTopLists[8]={name : 'Plan Description',value :  $localStorage.planDescription};
					}
				}
				
			}
		});
	};
	$scope.getHeadTopLists($localStorage.proposalIdAttr,$localStorage.clientIdAttr);
	
	$scope.validateFn= function(){
		return true;
	};
}];
