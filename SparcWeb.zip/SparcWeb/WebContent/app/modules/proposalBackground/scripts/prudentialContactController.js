var prudentialContactsController = ['$scope','appService','$localStorage',
                                    function($scope,appService,$localStorage) {
	

	$scope.getHeadTopLists = function (proposalIdVal, clientIdVal) { 
		var proposal = {
				proposalId : proposalIdVal,
				clientId: clientIdVal
		};
		appService.fetchDataWithParams("mvc/getHeaderDetails",proposal).then(function(data) {
			$scope.headerDetails = data;
			$scope.headTopLists=[ {name : 'Proposol ID', value : $scope.headerDetails.proposalId},
			                      {name : 'Client Name', value : $scope.headerDetails.clientName},
			                      {name : 'Proposal Status',value : $scope.headerDetails.proposalStatusVal}
			                    ];
			if($localStorage.versionNumber!=undefined && $localStorage.versionNumber!=''){
				$scope.headTopLists[3]={name : 'Version Number',value : $localStorage.versionIndexNumber};
				$scope.headTopLists[4]={name : 'Version Description',value :  $localStorage.versionDescription};
				$scope.headTopLists[5]={name : 'Version Status',value : $localStorage.versionStatus};
				
				if($localStorage.productName!=undefined && $localStorage.productName!=''){
					$scope.headTopLists[6]=	 {name : 'Product',value : $localStorage.productName};
					if($localStorage.planNumber!=undefined && $localStorage.planNumber!=''){
						$scope.headTopLists[7]={name : 'Plan Number',value : $localStorage.planNumber};
						$scope.headTopLists[8]={name : 'Plan Description',value :  $localStorage.planDescription};
					}
				}
				
			}
		});
	};
	$scope.getHeadTopLists($localStorage.proposalIdAttr,$localStorage.clientIdAttr);
	
	$scope.acctMgr = [
	                    { code: "a", name: "ABC" },
	                    { code: "b", name: "PQR" }
	                ];
	
	$scope.fnsaveRfp = function() {
		console.log($scope.contact);
	appService.fetchDataWithParams("mvc/addRfpContact",$scope.contact).then(function(data){
		
	});
	};
	
	
	
	
	
	
	/*$scope.fnonLoad = function() {
	appService.fetchData("mvc/getRfpValues").then(function(data){
		console.log(data);
		$scope.contact=data;
		
		console.log($scope.contact);
	});
	};
	$scope.fnonLoad();
	
	*/
	
	$scope.fnonLoad = function() {
		appService.fetchData("mvc/getRfpValues").then(function(data){
			$scope.contact=data;
			$scope.contact.salesRegion = $localStorage.selSalesRegion;
			$scope.salesRegionList = [$localStorage.selSalesRegion];
			$scope.contact.salesOffice = $localStorage.selSalesOffice;
			$scope.contact.salesOfficeList = [$localStorage.selSalesOffice];
			$scope.contact.proposalId = $localStorage.proposalIdAttr;
			$scope.contact.ldsmName=[];
			$scope.contact.ldsmAsstName=[];
			$scope.contact.lifeSplName=[];
			$scope.contact.lifeSplAsstName=[];
			$scope.contact.underwriterName=[];
			$scope.contact.rateCalcTechName=[];
			$scope.contact.acctManagerName=[];
			$scope.contact.midMktAcctMgrName=[];
			$scope.contact.regAdminDirName=[];
			$scope.contact.acctExeName=[];
		});
		
		var json = {
				lookupType : "",
				lookupCategory : "'LDSM','LDSMASSIST','LIFE SPECIALIST','LIFE SPECIALIST ASSISTANT','UNDERWRITER','RATECALC TECHNICIAN','ACCOUNT MANAGER','MID-MARKET ACCOUNT MANAGER','REGIONAL ADMIN DIRECTOR','ACCOUNT EXECUTIVE'",
				code : "",
				description : ""
		};
		appService.fetchDataWithParams("mvc/getLookupDetails", json).then(function(data) {
			console.log(data);
			var i = 0, j = 0; k=0; l=0;m=0;n=0;o=0;p=0;q=0;r=0;
			angular.forEach(data,function(listObj){
				if(listObj.lookupCategory == 'LDSM'){
					$scope.contact.ldsmName[i]=listObj;
					i++;
				} else if(listObj.lookupCategory == 'LDSMASSIST'){
					$scope.contact.ldsmAsstName[j]=listObj;
					j++;
				} else if(listObj.lookupCategory == 'LIFE SPECIALIST'){
					$scope.contact.lifeSplName[k]=listObj;
					k++;
				} else if(listObj.lookupCategory == 'LIFE SPECIALIST ASSISTANT'){
					$scope.contact.lifeSplAsstName[l]=listObj;
					l++;
				} else if(listObj.lookupCategory == 'UNDERWRITER'){
					$scope.contact.underwriterName[m]=listObj;
					m++;
				} else if(listObj.lookupCategory == 'RATECALC TECHNICIAN'){
					$scope.contact.rateCalcTechName[n]=listObj;
					n++;
				} else if(listObj.lookupCategory == 'ACCOUNT MANAGER'){
					$scope.contact.acctManagerName[o]=listObj;
					o++;
				} else if(listObj.lookupCategory == 'MID-MARKET ACCOUNT MANAGER'){
					$scope.contact.midMktAcctMgrName[p]=listObj;
					p++;
				} else if(listObj.lookupCategory == 'REGIONAL ADMIN DIRECTOR'){
					$scope.contact.regAdminDirName[q]=listObj;
					q++;
				} else if(listObj.lookupCategory == 'ACCOUNT EXECUTIVE'){
					$scope.contact.acctExeName[r]=listObj;
					r++;
				}  
			});
		});
	};
	$scope.fnonLoad();
		
	
	$scope.validateFn= function(){
		$scope.prudentialContactForm.$submitted=true;
		if ($scope.prudentialContactForm.$valid) {
			return true;	
		}
	};
	
}];
