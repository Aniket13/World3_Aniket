var basicInformationController = ['$scope','appService','selectedClientFactory','$localStorage','$rootScope',
                                  function($scope,appService,selectedClientFactory,$localStorage,$rootScope){
	$scope.info={};
	$scope.info.contStateVal = "";
	$scope.sic = "";
	$scope.stateList = [];
	$scope.salesOfficeList = [];
	$scope.info.comments='';
	$scope.info.dtReqClient= new Date();

	$scope.getStatesAndSalesOfficeList = function() {
		var json = {
				lookupType : "",
				lookupCategory : "'BASICINFORMSTATES'",
				code : "",
				description : ""
		};
		appService.fetchDataWithParams("mvc/getLookupDetails", json).then(function(data) {
			console.log(data);
			angular.forEach(data,function(listObj){
				$scope.stateList.push(listObj);
				//$scope.salesOfficeList[j] = listObj;
			});
		});
	};
	
	//calling the function getStatesAndSalesOfficeList() on load
	$scope.getStatesAndSalesOfficeList();
	
	$scope.selectSalesOffice = function () {
		var proposal = {
				proposalId : $scope.info.proposalId
		};
		
		appService.fetchDataWithParams("mvc/getProposalVersionsCount", proposal).then(function(data){
			if(data>0 && $scope.oldEffDate!=$scope.propEffectiveDate){
				if(confirm('Changing Proposal Effective date will cause errors on existing versions if they are installed. Please Clone a new version or update the plan effective date on existing version before selling.')){
				}else{
					$scope.propEffectiveDate = $scope.oldEffDate;
				}
			}
		});
		
		if(document.getElementById('propEffectiveDate').value==''){
			$scope.salesOfficeList = [];
		}else {
			if($scope.info.salesOffVal=='' || $scope.info.salesOffVal==null){
				$scope.salesOfficeList = $scope.info.salesOffice;
				$scope.info.salesOffVal =$scope.info.salesOffice[0].salesOfficeId;
			}
		}
		$scope.dateFocus=true;
	};
	$scope.oldEffDate='';
	$scope.dateFocus=true;
	$scope.setOldEffDate = function () {
		if($scope.dateFocus){
			$scope.oldEffDate=$scope.propEffectiveDate;
			$scope.dateFocus=true;
		}
	};
	$scope.openEffDatePop = function () {
		$scope.oldEffDate=$scope.propEffectiveDate;
		$scope.dateFocus=false;
	};
	
	
	$scope.createNewProposal = function () { 
		$localStorage.proposalIdAttr = '';
		$localStorage.pruContactIdAttr = '';
		var client = {
				clientId : selectedClientFactory.getSelectedClient()[0].clientId
		};
		appService.fetchDataWithParams("mvc/createNewProposal",client).then(function(data){
			console.log(data);
			$scope.info = data;
			if($scope.info.multiNational==null){
				$scope.info.multiNational='N';
			}
			$rootScope.$broadcast('proposalIdCreated');
			if($scope.info.effDate=='' || $scope.info.effDate==undefined){
				$scope.salesOfficeList = [];
			}else{
				$scope.propEffectiveDate = new Date($scope.info.effDate);
				$scope.salesOfficeList = $scope.info.salesOffice;
				$scope.info.salesOffVal =$scope.info.salesOffice[0].salesOfficeId;
			}
			if($scope.info.dtReqClient=='' || $scope.info.dtReqClient==undefined){
				$scope.propToClient_req= new Date();
			}else{
				$scope.propToClient_req= new Date($scope.info.dtReqClient);
			}
			if($scope.info.dtRecClient=='' || $scope.info.dtRecClient==undefined){
				$scope.propToClient_fromClient= '';
			}else{
				$scope.propToClient_fromClient= new Date($scope.info.dtRecClient);
			}
			/*if($scope.info.dtSendToClient=='' || $scope.info.dtSendToClient==undefined){
				$scope.propToClient_toClient= '';
			}else{
				$scope.propToClient_toClient= new Date($scope.info.dtSendToClient);
			}*/
			if($scope.info.dtReqBroker=='' || $scope.info.dtReqBroker==undefined){
				$scope.propToBroker_dueDate= '';
			}else{
				$scope.propToBroker_dueDate= new Date($scope.info.dtReqBroker);
			}
			//setting attributes in session
			$localStorage.proposalIdAttr = $scope.info.proposalId;
			$localStorage.clientIdAttr = $scope.info.clientId;
			$localStorage.contractStateAttr = $scope.info.contStateVal;
			$localStorage.sicAttr = $scope.sic;
			
			$scope.headTopLists = [ {name : 'Proposol ID', value : $scope.info.proposalId},
			                      {name : 'Client Name', value :  $scope.info.clientName},
			                      {name : 'Proposal Status',value : $scope.info.proposalStatusVal}
			                      ];
			
		});
	};
	
	if ($localStorage.createProposal == true) {
		$localStorage.createProposal = false;
		$scope.createNewProposal();
	}
	
	$scope.getProposalDetails = function (proposalId) { 
		appService.fetchDataWithParams("mvc/getProposalDetails", proposalId).then(function(data){
			$scope.info = data;
			$scope.headTopLists = [ {name : 'Proposol ID', value : $scope.info.proposalId},
			                      {name : 'Client Name', value :  $scope.info.clientName},
			                      {name : 'Proposal Status',value : $scope.info.proposalStatusVal}
			                      ];
			$scope.propEffectiveDate = new Date(data.effDate);
			$scope.propToClient_fromClient=new Date(data.dtRecClient);
			$scope.propToClient_req=new Date(data.dtReqClient);
			if($scope.info.dtReqBroker!='' && $scope.info.dtReqBroker!=undefined){
				$scope.propToBroker_dueDate=new Date(data.dtReqBroker);
			}
			$scope.salesOfficeList = $scope.info.salesOffice;
			if($scope.info.multiNational==null){
				$scope.info.multiNational='N';
			}
			$scope.oldEffDate=$scope.propEffectiveDate;
			if($localStorage.versionNumber!=undefined && $localStorage.versionNumber!=''){
				$scope.headTopLists[3]={name : 'Version Number',value : $localStorage.versionIndexNumber};
				$scope.headTopLists[4]={name : 'Version Description',value :  $localStorage.versionDescription};
				$scope.headTopLists[5]={name : 'Version Status',value : $localStorage.versionStatus};
				
				if($localStorage.productName!=undefined && $localStorage.productName!=''){
					$scope.headTopLists[6]=	 {name : 'Product',value : $localStorage.productName};
					if($localStorage.planNumber!=undefined && $localStorage.planNumber!=''){
						$scope.headTopLists[7]={name : 'Plan Number',value : $localStorage.planNumber};
						$scope.headTopLists[8]={name : 'Plan Description',value :  $localStorage.planDescription};
					}
				}
				
			}
		});
	};
	if($localStorage.createProposal == false && $localStorage.proposalIdAttr){
		$scope.getProposalDetails($localStorage.proposalIdAttr);
	}
	
	$scope.validateComment= function(){
		if($scope.info.comments!=null || $scope.info.comments != undefined){
			if($scope.info.comments.length > 800){
			alert('Please enter only 800 characters.');
			$scope.info.comments=$scope.info.comments.substring(0,800);
			return false;
			}
		}
	};
	
	$scope.validateFn= function(){
		$localStorage.selSalesOffice = document.getElementById('salesOffice').options[document.getElementById('salesOffice').selectedIndex].text;
		angular.forEach($scope.info.salesOffice,function(value){
			if(value.salesOfficeId == $scope.info.salesOffVal){
				$localStorage.selSalesRegion = value.salesRegionValues.regName;
			}
		});
		$scope.info.effDate=document.getElementById('propEffectiveDate').value;
		$scope.info.dtRecClient=document.getElementById('propToClient_fromClient').value;
		$scope.info.dtReqClient=document.getElementById('propToClient_req').value;
		$scope.info.dtReqBroker=document.getElementById('propToBroker_dueDate').value;
		
		if($scope.propEffectiveDate==undefined){
			$scope.propEffectiveDate='';
			$scope.salesOfficeList = [];
		}
		if($scope.propToClient_fromClient==undefined){
			$scope.propToClient_fromClient='';
		}
		if($scope.propToClient_req==undefined){
			$scope.propToClient_req='';
		}
		if($scope.propToBroker_dueDate==undefined){
			$scope.propToBroker_dueDate='';
		}
		$scope.basicInfoForm.$submitted=true;
		if ($scope.basicInfoForm.$valid) {
			return true;	
		}
	};
}];
