var producerSearchController = ['$scope','$window', '$filter','producerSearchFactory', 'appService', '$localStorage',
        function($scope, $window, $filter, producerSearchFactory, appService,$localStorage){
	
	
	$scope.getHeadTopLists = function (proposalIdVal, clientIdVal) { 
		var proposal = {
				proposalId : proposalIdVal,
				clientId: clientIdVal
		};
		appService.fetchDataWithParams("mvc/getHeaderDetails",proposal).then(function(data) {
			$scope.headerDetails = data;
			$scope.headTopLists=[ {name : 'Proposol ID', value : $scope.headerDetails.proposalId},
			                      {name : 'Client Name', value : $scope.headerDetails.clientName},
			                      {name : 'Proposal Status',value : $scope.headerDetails.proposalStatusVal}
			                    ];
			
			if($localStorage.versionNumber!=undefined && $localStorage.versionNumber!=''){
				$scope.headTopLists[3]={name : 'Version Number',value : $localStorage.versionIndexNumber};
				$scope.headTopLists[4]={name : 'Version Description',value :  $localStorage.versionDescription};
				$scope.headTopLists[5]={name : 'Version Status',value : $localStorage.versionStatus};
				
				if($localStorage.productName!=undefined && $localStorage.productName!=''){
					$scope.headTopLists[6]=	 {name : 'Product',value : $localStorage.productName};
					if($localStorage.planNumber!=undefined && $localStorage.planNumber!=''){
						$scope.headTopLists[7]={name : 'Plan Number',value : $localStorage.planNumber};
						$scope.headTopLists[8]={name : 'Plan Description',value :  $localStorage.planDescription};
					}
				}
				
			}
		});
	};
	$scope.getHeadTopLists($localStorage.proposalIdAttr,$localStorage.clientIdAttr);
	
	//producerSearchFactory.getSelectedProducer();
	$scope.producers={
			proposalPlanID:$localStorage.proposalIdAttr,
			brokerID:2,
	};
	$scope.selectedProducers=[];
	appService.fetchData("mvc/getProducer").then(function(data){
		var i = 0;
		angular.forEach(data,function(listObj){	
			$scope.selectedProducers[i] = listObj;
			i = i + 1;
		});
		
		$scope.producers={
				proposalPlanID:$localStorage.proposalIdAttr,
				brokerID:data[0].brokerId,
		};
	});
	
	
	$scope.states = ["North Carolina", "New York"];
    $scope.hasIndividuals = false;
    
    $scope.searchIndividuals = function (filterTxn) {
    	/*hardcoded in service factory*/
    	$scope.individualList = producerSearchFactory.getAllProducers(filterTxn); 
    	if ($scope.individualList.length > 0) {
    		 $scope.hasIndividuals = true;
    	}
    };
    
    $scope.showalertmessage = function () {
    	var message = "The following producers has been selected:\n\n";
    	angular.forEach($scope.individualList, function(individualObj, arrayIndex){
    		var count = 0;
            if(individualObj.selectedProposal) {
            	count++;
            	producerSearchFactory.setSelectedProducer(individualObj);
            	message = message + (count) + "." + individualObj.firstName +  " " + individualObj.producerContractId + " " + individualObj.agencyCode + "\n";
            }
         });
    	message = message + "\n\n Commissions will be paid to the Individual unless the commission arrangement is Direct or None.\n\nContinue?\n\n";
    	$window.confirm(message);
    	//$window.location.reload();
    };
        
    /* method to verify if at least one checkbox is checked*/
    $scope.isChecked = function() {
    	if ($scope.hasIndividuals) {
    		var selected = $filter("filter")($scope.individualList , {selectedProposal:true} );
    		if (selected.length > 0) {
        		return true;
        	}
        	return false;
    	}
    };
    
    $scope.validateFn= function(){
    	console.log($scope.producers);
    	$localStorage.selBrokerId = $scope.producers.brokerID;
		return true;
	};
    
    
}];