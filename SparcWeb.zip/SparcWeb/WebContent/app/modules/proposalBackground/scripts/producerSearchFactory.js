var producerSearchFactory = ['$rootScope',
		function($rootScope) {

			$rootScope.selectedProducers =[];
			
			_setSelectedProducer = function(producer) {
				$rootScope.selectedProducers.push(producer);
			};
			_getSelectedProducer = function() {
				return $rootScope.selectedProducers;
			};
			_saveSelectedProducer = function() {
				return $rootScope.selectedProducers;
			};
			_deleteSelectedProducer = function() {
				return $rootScope.selectedProducers;
			};
			_getAllProducers = function(filterTxn) {
				//Query parameters
		    	if (filterTxn != null && filterTxn != undefined
		    			&& filterTxn.producer != null && filterTxn.producer != undefined) {
		    		var producer = filterTxn.producer;
		    		if (producer.contractNo != null && producer.contractNo != undefined) {
		    			console.log(producer.contractNo);
		    		}
		    		if (producer.city != null && producer.city != undefined) {
		    			console.log(producer.city);
		    		}
		    		if (producer.firstName != null && producer.firstName != undefined) {
		    			console.log(producer.firstName);
		    		}
		    		if (producer.lastName != null && producer.lastName != undefined) {
		    			console.log(producer.lastName);
		    		}
		    		if (producer.state != null && producer.state != undefined) {
		    			console.log(producer.state);
		    		}
		    	}
		    	 var individualList = [
		    	                       {
		    	                      	   lastName : 'ASDAS',
		    	                      	   firstName : 'ASEDA',
		    	                      	   middleName : 'ASD',
		    	                      	   producerContractId : 'ADABBD',
		    	                      	   agencyCode : 1234,
		    	                      	   ranking : 'New',
		    	                      	   type : 'individual',
		    	                      	   firmName :  'No Firm Affiliation',
		    	                      	   firmContractId : '',
		    	                      	   firmAgencyCode : '',
		    	                      	   status : 'A',
		    	                      	   reason : '00',
		    	                      	   eib : 'No'
		    	                         },
		    	                         {
		    	                      	   lastName : 'PODAS',
		    	                      	   firstName : 'PAEDA',
		    	                      	   middleName : 'PSD',
		    	                      	   producerContractId : 'DFABBD',
		    	                      	   agencyCode : 5678,
		    	                      	   ranking : 'New',
		    	                      	   type : 'individual',
		    	                      	   firmName :  'No Firm Affiliation',
		    	                      	   firmContractId : '',
		    	                      	   firmAgencyCode : '',
		    	                      	   status : 'A',
		    	                      	   reason : '00',
		    	                      	   eib : 'No'
		    	                         }
		    	                	  ];
		    	 return individualList;
		    	
			};
			
			return {
				getAllProducers : _getAllProducers,
				setSelectedProducer : _setSelectedProducer,
				getSelectedProducer : _getSelectedProducer,
				saveSelectedProducer : _saveSelectedProducer,
				deleteSelectedProducer : _deleteSelectedProducer
			};
} ];