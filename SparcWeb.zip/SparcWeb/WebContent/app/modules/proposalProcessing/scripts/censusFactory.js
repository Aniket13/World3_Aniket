var censusFactory = function(context) {
	var selectedTab = 2;
	var showTab=false;
	var cenId="";

	return {
		setSelectedTab : function(data) {
			selectedTab = data;
		},
		getSelectedTab : function() {
			return selectedTab;
		},
		setShowTab : function(data) {
			showTab = data;
		},
		getShowTab : function() {
			return showTab;
		},
		setCensusId : function(data) {
			cenId = data;
		},
		getCensusId : function() {
			return cenId;
		}
	};
};