var ratingEngineController = ['$scope','$compile','$window', function($scope,$compile,$window){
	$scope.validationMsgs = window.opener.validationMsgs;
	
	//$scope.validationMsgs=[{id:1, description:'Description'},{id:2, description:'Description'}];
	
	$scope.redirectBackToPage = function(){
		$window
		.open("#/plan", "New Window",
				"scrollbars=yes, left=50, top=20, height=650, width=1200");
		window.close();
	};
	
	$scope.saveBypass = function(){
		if($scope.selectedRatingError.errors.length==0){
			alert('You must select at least one PreCalc for bypassing.');
		}else if($scope.selectedRatingError.errors.length<$scope.validationMsgs.length){
			alert('Please select all errors for bypass or stop rating and fix the errors.');
		}
	};
	
	$scope.continueRating = function(){
		if($scope.selectedRatingError.errors.length<$scope.validationMsgs.length){
			alert('All rules must be either corrected or bypassed in order to Continue Rating.');
		}
	};
	
	
	$scope.selectedRatingError = {
			errors: []
		};

		$scope.toggleSelection = function toggleSelection(val) {
	  		  var idx =$scope.selectedRatingError.errors.indexOf(val);
	  		  // is currently selected
			  if (idx > -1) {
			    $scope.selectedRatingError.errors.splice(idx, 1);
			  }
			  // is newly selected
			  else {
				  $scope.selectedRatingError.errors.push(val);
			  }
			
		};
	
}];