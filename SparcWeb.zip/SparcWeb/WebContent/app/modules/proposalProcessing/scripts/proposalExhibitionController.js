var proposalExhibitionController = ['$scope','$rootScope','$compile','$window','appService','proposalRatingResultFactory','$localStorage', function($scope,$rootScope,$compile,$window,appService, proposalRatingResultFactory,$localStorage){
	$scope.validationMsgs = [];
	$scope.showBasicSummary= true;
	$scope.showVersionDetails = false;
	$scope.showProductDetails = false;
	$scope.showPlanDetails = false;
	$scope.showPlanRateExpression= false;
	$scope.wordflowAction='';
	$scope.selectedField=$localStorage.selectedField;
	$rootScope.showViewOriginalBtn=false;
	$rootScope.showViewOverrideBtn=true;
	$rootScope.showDownloadBtn=true;
	$scope.notRatedMsg=false;
	$rootScope.ratingEngineTxt='Rating Engine';
	$rootScope.ratingEngineBtnDis=false;
	$rootScope.showRatingSuccess=false;
	$rootScope.showRatingSuccessImg=false;
	
	
	$scope.proposalDetails={};
	$scope.basicInfoList=[];
	$scope.getProposalDetails= function(){
		var inputList=$localStorage.proposalIdAttr;
		//var inputList='2016224008';

		appService.fetchDataWithParams("mvc/getVersionPlanDetails",inputList).then(function(data){
			console.log(data);
			$scope.proposalDetails = data;
			angular.forEach($scope.proposalDetails.versionDetails,function(listVal,listKey){
				$scope.proposalDetails.versionDetails[listKey].versionIndex=listKey+1;
				angular.forEach(listVal.planList,function(val,key){
					listVal.planList[key].planIndex=key+1;
				});
			});
			if($localStorage.selectedField!=''){
				angular.forEach($scope.proposalDetails.versionDetails,function(listVal,listKey){
					if(listVal.versionNumber==$localStorage.selectedVersionRating){
						if($localStorage.selectedField==$localStorage.selectedVersionRating){
							$scope.versionSummary(listVal);
						}else if($localStorage.selectedField==$localStorage.selectedVersionRating+''+listVal.planList[0].productName){
							$scope.productDetails(listVal.versionNumber,listVal);
						} else{
							angular.forEach(listVal.planList,function(val,key){
								if(val.planNum==$localStorage.selectedPlanRating){
									$scope.planDetails(listVal.versionNumber,val.productName, val, listVal.versionIndex);
								}
							});
					
						}
					}
				});

			}
		});
		
		appService.fetchDataWithParams("mvc/getProposalDetails",inputList).then(function(data){
			$scope.basicInfoList=[
			                    {fieldKey:'Client Name',fieldVal:data.clientName},
			                    {fieldKey:'Proposal Description',fieldVal:data.description},
			                    {fieldKey:'Proposal Status',fieldVal:data.proposalStatusVal},
			                    {fieldKey:'Effective Date',fieldVal:data.effDate}
			                    ];
			appService.fetchData("mvc/getProducer").then(function(data){
				console.log('producer:'+data);
				$scope.basicInfoList.push({fieldKey:'Producer Name',fieldVal:data[0].producerName});
				$scope.basicInfoList.push({fieldKey:'Producer Contract#',fieldVal:data[0].producerAdbNo});
			
			});
			appService.fetchData("mvc/getRfpValues").then(function(data){
				if(data.ldsmNameVal!='' && data.ldsmNameVal!=null){
					$scope.basicInfoList.push({fieldKey:'LDSM Name',fieldVal:data.ldsmNameVal});
				}
				if(data.ldsmAsstVal!='' && data.ldsmAsstVal!=null){
					$scope.basicInfoList.push({fieldKey:'LDSM Assistant',fieldVal:data.ldsmAsstVal});
				}
				if(data.lifeSplVal!='' && data.lifeSplVal!=null){
					$scope.basicInfoList.push({fieldKey:'Life Specialist',fieldVal:data.lifeSplVal});
				}
				if(data.lifeSplAsstVal!='' && data.lifeSplAsstVal!=null){
					$scope.basicInfoList.push({fieldKey:'Life Specialist Assistant',fieldVal:data.lifeSplAsstVal});
				}
				if(data.uwVal!='' && data.uwVal!=null){
					$scope.basicInfoList.push({fieldKey:'Underwriter',fieldVal:data.uwVal});
				}
				if(data.rateCalcTechVal!='' && data.rateCalcTechVal!=null){
					$scope.basicInfoList.push({fieldKey:'RateCalc Technician',fieldVal:data.rateCalcTechVal});
				}
				if(data.acctManVal!='' && data.acctManVal!=null){
					$scope.basicInfoList.push({fieldKey:'Account Manager',fieldVal:data.acctManVal});
				}
				if(data.midMktAcctMgrVal!='' && data.midMktAcctMgrVal!=null){
					$scope.basicInfoList.push({fieldKey:'Mid-Market Account Manager',fieldVal:data.midMktAcctMgrVal});
				}
				if(data.regAdminDirVal!='' && data.regAdminDirVal!=null){
					$scope.basicInfoList.push({fieldKey:'Regional Admin Director',fieldVal:data.regAdminDirVal});
				}
				if(data.acctExeNameVal!='' && data.acctExeNameVal!=null){
					$scope.basicInfoList.push({fieldKey:'Account Executive',fieldVal:data.acctExeNameVal});
				}
				if(data.extAgentName!='' && data.extAgentName!=null){
					$scope.basicInfoList.push({fieldKey:'External Agent',fieldVal:data.extAgentName});
				}
			});	
		});
	};
	$scope.getProposalDetails();
	
	$scope.selectedVersionDetails='';
	$scope.selectedProductDetails='';
	$scope.selectedPlanDetails='';
	$scope.versionList=[];
		
	$scope.basicProposalSummary = function(val){
		$scope.showProductDetails = false;
		$scope.showPlanDetails = false;
		$scope.showVersionDetails = false;
		$scope.showBasicSummary= true;
		$scope.showPlanRateExpression= false;
		$localStorage.selectedField='';
		$scope.selectedField='';
		$localStorage.selectedVersionRating='';
		$localStorage.selectedPlanRating='';
		$scope.notRatedMsg=false;
	};
	
	$scope.versionSummary = function(val){
		$localStorage.selectedVersionRating = parseInt(val.versionNumber);
		$scope.selectedField=val.versionNumber;
		$localStorage.selectedField=val.versionNumber;
		$scope.selectedVersionDetails=val;
		$scope.showBasicSummary= false;
		$scope.showProductDetails = false;
		$scope.showPlanDetails = false;
		$scope.showVersionDetails = true;
		$scope.showPlanRateExpression= false;
		$scope.notRatedMsg=false;

	};
	
	$scope.productDetails = function(version,val){
		$scope.selectedField=version+''+val.planList[0].productName;
		$localStorage.selectedField=version+''+val.planList[0].productName;
		$localStorage.selectedVersionRating = parseInt(version);
		$scope.selectedProductDetails=val;
		$scope.showBasicSummary= false;
		$scope.showPlanDetails = false;
		$scope.showVersionDetails = false;
		$scope.showProductDetails = true;
		$scope.showPlanRateExpression= false;
		$scope.notRatedMsg=false;

	};
	
	$rootScope.ratingResultData={};
	$scope.planDetails = function(version,product, val, versinInd){
		
		$localStorage.selectedPlanRating = parseInt(val.planNum);
		$localStorage.selectedVersionRating = parseInt(version);
		$scope.selectedField=version+'P'+val.planNum;
		$localStorage.selectedField=version+'P'+val.planNum;
		$scope.selectedPlanDetails = val;
		$scope.selectedPlanDetails.versionNumber = version;
		$scope.selectedPlanDetails.productName = product;
		$scope.selectedPlanDetails.versionIndex = versinInd;
		$scope.showBasicSummary= false;
		$scope.showVersionDetails = false;
		$scope.showProductDetails = false;
		$scope.showPlanDetails = true;
		$scope.notRatedMsg=false;
		console.log("versionNumber on load : "+ $localStorage.selectedVersionRating);
		var plan = {
				planId : $localStorage.selectedPlanRating,
				versionNumber: $localStorage.selectedVersionRating
		};
		appService.fetchDataWithParams("mvc/loadRatingData",plan).then(function(data){
			console.log(data);
			if(data.planRated){
				$rootScope.ratingResultData=data;
				$scope.showPlanRateExpression= true;
				//proposalRatingResultFactory.setRatingResultData(data);
				if(data.savedOverrides && data.planReRatingPending){
					$rootScope.showViewOriginalBtn=false;
					$rootScope.showViewOverrideBtn=false;
					$rootScope.showDownloadBtn=false;
				}else{
					$rootScope.showViewOriginalBtn=false;
					$rootScope.showViewOverrideBtn=true;
					$rootScope.showDownloadBtn=true;
				}
			}else{
				$scope.notRatedMsg=true;
				$scope.showPlanRateExpression= false;
			}
			
			
		});
	};
	
	$scope.oldValue ='';
	$scope.setOldVal = function(val) {
		$scope.oldValue=val.overrideValue;
		console.log(val.overrideValue);
	};
	
	$scope.isNumeric = function(val) {
		if(!$scope.numericPattern.test(val.overrideValue) || val.overrideValue==''){
			val.overrideValue=$scope.oldValue;
		}
		console.log(val.overrideValue);
	};
	
	$scope.setOverride = function(val) {
		if(!val.overrideIndicator){
			val.overrideValue=0;
		}
	};
	
	
	$scope.saveOverrides = function() {
		console.log("versionNumber on saveOverrides:"+$localStorage.selectedVersionRating)
		var overridenList = {
				planId: $localStorage.selectedPlanRating,
				versionNumber: $localStorage.selectedVersionRating,
				overriddenValues :{}
		};
		angular.forEach($rootScope.ratingResultData.ratingModelOverideGrp,function(val,key){
			angular.forEach(val,function(listVal,listKey){
				if(listVal.overrideIndicator){
					var overrideVal=listVal.overrideValue;
					overridenList.overriddenValues[listVal.ruleID]=overrideVal.toString();
				}
			});
		});
		console.log(overridenList);
		appService.fetchDataWithParams("mvc/saveOverrides",overridenList).then(function(data){
			$rootScope.ratingResultData=data;
			$rootScope.showViewOriginalBtn=false;
			$rootScope.showViewOverrideBtn=false;
			$rootScope.showDownloadBtn=false;
			
		});
	};
	
	$scope.viewOriginalRates = function() {
		var overridenList = {
				planId : $localStorage.selectedPlanRating
		};
		
		appService.fetchDataWithParams("mvc/viewOriginalRates",overridenList).then(function(data){
			$rootScope.ratingResultData=data;
			$rootScope.showViewOriginalBtn=false;
			$rootScope.showViewOverrideBtn=true;
		});
	};
	
	$scope.viewOverrideRates = function() {
		var overridenList = {
				planId : $localStorage.selectedPlanRating
		};
		appService.fetchDataWithParams("mvc/viewOverrideRates",overridenList).then(function(data){
			$rootScope.ratingResultData=data;
			$rootScope.showViewOverrideBtn=false;
			$rootScope.showViewOriginalBtn=true;
		});
	};
	
	$scope.invokeRatingEngine = function() {
		var versionNumber = parseInt($localStorage.selectedVersionRating);
		//var versionNumber = 1;
		$rootScope.ratingEngineBtnDis=true;
		$rootScope.ratingEngineTxt='Rating in progress';
		appService.fetchDataWithParams("mvc/invokeRatingEngine",versionNumber).then(function(data){
			if(data.ratingSuccessful || data[0].ratingSuccessful){
				$rootScope.ratingEngineTxt='Rating Engine';
				$rootScope.ratingEngineBtnDis = false;
				$rootScope.showRatingSuccess = true;
			}
		});
	};
	
	$scope.refreshRating = function() {
		$scope.getProposalDetails();
	};
	
	$scope.goWorkflowAction = function() {
		if($scope.wordflowAction=='' || $scope.wordflowAction==undefined){
			alert('Please select workflow action.');
			return false;
		}
	};
	$scope.saveReasonPended = function() {
		
		if($scope.reasonPendedForm.$error.pattern){
			alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
			return false;
		}
		if($scope.reasonPended=='' || $scope.reasonPended==undefined){
			alert('Reason Pended cannot be Choose One. You must unpend the case first.');
			return false;
		}
		
	};
	
	
	$window.validationMsgs = [];
	/* $scope.ratingWindow = function() {
	        var w = $window.open('', '', 'directories=no,titlebar=no,toolbar=no,location=no,'
					+ 'status=no,menubar=no,scrollbars=yes,resizable=no,width=700,height=300');
	        w.document.write('<html><head><title>Prudential GI Application</title>');
	        w.document.write('<link rel="stylesheet" href="app/styles/main.css">');
	        w.document.write('</head><body ng-controller ="proposalExhibitionController">');
	        w.document.write('<b>This Version could not be rated due to following error(s):</b><button class="btn btn-default active marginleft5pct " type="button">Print</button>');
	        w.document.write('<table class="basicInfoTable marginTop15Px">');
	        w.document.write('<tr><th>Bypass</th><th>Id</th><th>Type</th><th>Message</th><th>Jump To</th></tr>');
	        w.document.write('<tr><td><input type="checkbox"></td><td>PRC103026</td><td>Basic Life</td><td> You can use it on a parent element to have it affect all children links</td><td><a href="#" >Fix Me</a></td></tr>');
	        w.document.write('</table>');
	        w.document.write('<div class="marginTop15Px">');
	        w.document.write('<button class="btn btn-default active " type="button">Check All</button>');
	        w.document.write('<button class="btn btn-default active " type="button">Save Bypass</button>');
	        w.document.write('</div>');
	        w.document.write('<hr/>');
	        w.document.write('<div class="marginTop5Px redColor">Clicking this button will ignore the above warnings and continue rating');
	        w.document.write('<button class="btn btn-default active marginleft10pct" type="button">Continue Rating</button></div>');
	        w.document.write('<div class="marginTop5Px redColor">Clicking this button will Stop Rating and allow you to return to it after fixing above error(s)');
	        w.document.write('<button class="btn btn-default active marginleft5pct " type="button">Stop Rating</button>');
	        w.document.write('</div>');
	        w.document.write('</div>');
	        w.document.write('</body></html>');
	        w.document.close();
	    };
	    */
	$scope.ratingWindow = function() {
		var ratingEngParams = {"duration":"","planId":"","proposalId":"","proposalVersion":"","roundingOccurs":"","typeOfCase":"PRU VALUE LDSM"};
		appService.fetchDataWithParams('mvc/Validations/planValidation',ratingEngParams).then(function(data) {
			var i = 0;
			angular.forEach(data.listOfValidationMsgs,function(listObj){
				$scope.validationMsgs[i]=listObj;
				i++;
			});
			$window.validationMsgs = $scope.validationMsgs;
			$window.open("#/ratingEngine", "Rating Engine", "left=50, top=20, height=300, width=700, addressbar=0, scrollbar=yes");
		});
	};

}];