var editCensusController = function($scope, $location, censusFactory, appService, $http) {
	$scope.showEditDtl = false;
	$scope.censusMember = {};
	$scope.censusMemberData = [];
	$scope.cenId = censusFactory.getCensusId();
	$scope.editCensusSave=false;
	$scope.errorMsg={};

	appService.fetchDataWithParams("mvc/getCensus", {
		censusId : $scope.cenId
	}).then(function(data) {
		$scope.censusMemberData = data;
	});

	appService.fetchDataWithParams("mvc/getCensusFieldValue", {
		censusId : $scope.cenId
	}).then(function(data) {

		$scope.fieldDefaultValues = data;

	});

	$scope.goToCensus = function() {
		$location.path("/census");
	};

	/*
	 * $scope.censusMemberData = [ { firstName : "a", lastName : "b", age : "23", govtID : "3827468GDVGG" }, { firstName : "a", lastName : "b", age : "23",
	 * govtID : "3827468GDVGG" }, { firstName : "a", lastName : "b", age : "23", govtID : "3827468GDVGG" } ];
	 */

	$scope.editMember = function(data) {
		$scope.errorMsg={};
		$scope.censusMember = data;
		
		if($scope.censusMember.birthDate!=null && $scope.censusMember.birthDate!=""){
			//document.getElementById('birthDate').value = $scope.censusMember.birthDate;
			$scope.birthDate = new Date($scope.censusMember.birthDate);
		}else{
			document.getElementById('birthDate').value='';
		}
		if($scope.censusMember.hireDate!=null && $scope.censusMember.hireDate!=""){
			//document.getElementById('hireDate').value = $scope.censusMember.hireDate;
			$scope.hireDate = new Date($scope.censusMember.hireDate);
		}else{
			document.getElementById('hireDate').value='';
		}
		
		$scope.editCensusSave = true;
	};
	$scope.saveCensusMember = function() {
		
		
		console.log($scope.censusMember);
		if($scope.censusMember.dentalPart!='B' && $scope.censusMember.dentalPart!='N' && $scope.censusMember.dentalPart!='D'){
			alert('Dental Participant must be B or D or N');
			return false;
		}
		if($scope.censusMember.dentalSpoucePart!='Y' && $scope.censusMember.dentalSpoucePart!='N'){
			alert('Dependent Dental Spouse Participant must be Y or N');
			return false;
		}
		
		if($scope.editCensusMemberForm.$error.pattern){
			alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
			return false;
		}
		if($scope.censusMember.dentalChildPart<0 || $scope.censusMember.dentalChildPart>5 || isNaN($scope.censusMember.dentalChildPart)){
			alert('Dependent Dental # of child Participants must be numeric value 0-5');
			return false;
		}
		$scope.censusMember.birthDate  = document.getElementById('birthDate').value;
		$scope.censusMember.hireDate  = document.getElementById('hireDate').value;
		appService.fetchDataWithParams("mvc/updateCensus", $scope.censusMember).then(function(data) {
			console.log(data);
			$scope.errorMsg={};
			angular.forEach(data.errorMsg.BLANK, function(value, key){
				$scope.errorMsg[value.screenCode]={screenCode:value.error, error:value.screenCode};

     		});
		});
	};

	$scope.currentPage = 0;
	$scope.pageSize = 10;
	$scope.numberOfPages = function() {
		return Math.ceil($scope.censusMemberData.length / $scope.pageSize);
	};

};
