var censusController = function($scope, $location, censusFactory, $rootScope,appService, $localStorage) {
	
	$rootScope.classLst=[];
	$scope.livesAllocation = [];
	$scope.livesAllocated = [];
	$scope.censusId='';
	$scope.newArea='';
	$scope.newAreaOther='';
	$scope.numberOfLives=0;
	$scope.numberOfLivesOther=0;
	$scope.livesErrorMessage='';
	$scope.livesAllocationLength=$scope.livesAllocation.length;
	$scope.tab = censusFactory.getSelectedTab();
	$scope.hideFlag = censusFactory.getShowTab();
	$scope.stateList = [];
	$scope.saveDisabled=false;
	$scope.selectedCensus="";
	$scope.caseLives='';
	
	
	$scope.getCensusDetail = function() {
		appService.fetchDataWithParams("mvc/getCensusDetail", $localStorage.clientIdAttr).then(function(data) {
			console.log(data);
			$scope.censusData = data;
			if($localStorage.selectedCensus!=''){
				angular.forEach(data, function(value, key){
					if($localStorage.selectedCensus==value.census_fl_Name){
						$scope.getCensusDetails(value);
					}
				});
			}
		});
	};
		
	$scope.getCensusStates = function() {
		var json = {
				lookupType : "",
				lookupCategory : "'CENSUSALLOCSTATE'",
				code : "",
				description : ""
		};
		appService.fetchDataWithParams("mvc/getLookupDetails", json).then(function(data) {
			console.log(data);
			var i = 0;
			angular.forEach(data,function(listObj){
				$scope.stateList[i]=listObj;
				i++;
			});
		});
	};
	//calling the function getCensusDetail() on load
	$scope.getCensusDetail();

	//calling the function getCensusStates() on load
	$scope.getCensusStates();
	
	var getClsObj=function(length, cenId){
		var strToNum = length+1;
		var val={
			censusClsId : strToNum.toString(),
			censusId : cenId,
			classDesc : "",
			exempt : false,
			mgmt : false,
			medicallyUnd : false,
			salaried : false,
			smoker : false,
			retire : false,
			grandFather : false,
			colBargain : false,
			fulTime : false,
		}
		return val;
	}

	
	$scope.headTopLists=[];
	$scope.headerDetails={};
	$scope.versionDetails={};
	$scope.getHeadTopLists = function (proposalIdVal, clientIdVal) { 
		var proposal = {
				proposalId : proposalIdVal,
				clientId: clientIdVal
		};
		appService.fetchDataWithParams("mvc/getHeaderDetails",proposal).then(function(data) {
			$scope.headerDetails = data;
		});
		
		
	};
	
	$scope.getHeadTopLists($localStorage.proposalIdAttr,$localStorage.clientIdAttr);
	
	$scope.getVersionDetails = function(proposalId, versionNumber) {
		var quotation = {
				proposalId : proposalId,
				versionNumber : versionNumber
		};
		
		if(proposalId==undefined || proposalId==''){
			$scope.headTopLists=[ {name : 'Proposol ID', value : '< no id assigned > ()'},
			                      {name : 'Client Name', value : $localStorage.clientNameAttr},
			                      {name : 'Proposal Status',value : '' }
			                    ];
		}else{
			appService.fetchDataWithParams("mvc/getVersionDetails",quotation).then(function(data){
				$scope.versionDetails = data;
				$scope.headTopLists=[ {name : 'Proposol ID', value : $scope.headerDetails.proposalId},
				                      {name : 'Client Name', value : $scope.headerDetails.clientName},
				                      {name : 'Proposal Status',value : $scope.headerDetails.proposalStatusVal},
				                      {name : 'Version Number',value :$localStorage.versionIndexNumber}, 
				                      {name : 'Version Description',value :  $localStorage.versionDescription},
				                      {name : 'Version Status',value : $localStorage.versionStatus}
				                    ];
				
				
			});
		}
	};
	
	$scope.getVersionDetails($localStorage.proposalIdAttr,$localStorage.versionNumber);
	
	
	$scope.newCensus = function () { 
		window.open('app/modules/proposalProcessing/templates/newCensusInfo.html', "", "scrollbars=yes, left=50, top=20, height=650, width=550");
		
	};

	$scope.name = "";
	$scope.censusDetail = {};
	$scope.selectedCensusDetails={};
	$scope.getCensusDetails = function(censusVal) {
		$scope.livesErrorMessage='';
		$scope.selectedCensus=censusVal.census_fl_Name;
		$localStorage.selectedCensus=$scope.selectedCensus;
		$scope.selectedCensusDetails = censusVal;
		angular.forEach(censusVal, function(value, key){
			if(key=="census_dt" || key=='receit_dt'){
				$scope.censusDetail[key]=new Date(value);
			}
			else{
				$scope.censusDetail[key]=value;
			}
			
		});
		$scope.censusDate=$scope.censusDetail.census_dt;
		$scope.receiptDate=$scope.censusDetail.receit_dt;
		$scope.caseLives = $scope.censusDetail.no_of_live;
		if($scope.censusDetail.sal_amt!=''){
			$scope.salaryInfo='No';
		}else{
			$scope.salaryInfo='Yes';
		}
		//$scope.censusDetail.census_dt=new Date('Wed May 25 14: 20:30 2016');
		//$scope.censusDetail2 = censusVal;
		//$scope.censusDetail3 = $scope.censusDetail2;
		$scope.hideFlag = true;
		censusFactory.setShowTab(true);
		censusFactory.setCensusId($scope.censusDetail.census_id);
		console.log($scope.censusDetail.census_id);
		appService.fetchDataWithParams("mvc/getCensusClass", {censusId:$scope.censusDetail.census_id}).then(
				function(data) {
					console.log(data);
					$rootScope.classLst=data;
					if($rootScope.classLst.length <= 0){
						var cls=getClsObj($rootScope.classLst.length,$scope.censusDetail.census_id);
						$rootScope.classLst.push(cls);		
					}
				
		});
		
		appService.fetchDataWithParams("mvc/getLivesAllocation", $scope.censusDetail.census_id).then(
				function(data) {
					console.log(data);
					$scope.censusId = $scope.censusDetail.census_id;
					$scope.livesAllocation = [];
					angular.forEach(data,function(listObj){
						$scope.livesAllocation.push(listObj);
					});
					$scope.livesAllocationLength=$scope.livesAllocation.length;
					$scope.livesAllocated = [];
					angular.forEach($scope.livesAllocation, function(value, key){
						if(value.cenState.length>=2){
							var stateCode = value.cenState.substring(0, 2);
							var stateFlag = true;
							angular.forEach($scope.livesAllocated, function(livesVal, livesKey){
								if(livesVal.allocatedState==stateCode){
									var numLives = parseInt(value.noOfLives);
									var allNumLives = parseInt(livesVal.allocatedNoOfLives);
									livesVal.allocatedNoOfLives=numLives+allNumLives;
									livesVal.allocPerc=(livesVal.allocatedNoOfLives*100/$scope.censusDetail.no_of_live).toFixed(2);
									stateFlag = false;
								}
							});
							if(stateFlag){
								var json ={
										allocatedState:stateCode,
									    allocatedNoOfLives:value.noOfLives,
									    allocPerc:(value.noOfLives*100/$scope.censusDetail.no_of_live).toFixed(2)
								};
								$scope.livesAllocation[key].allocPerc = parseFloat(json.allocPerc);
								$scope.livesAllocated.push(json);
							}
						}else{
							var json ={
								allocatedState:value.cenState,
							    allocatedNoOfLives:value.noOfLives,
							    allocPerc:(value.noOfLives*100/$scope.censusDetail.no_of_live).toFixed(2)
							};
							$scope.livesAllocation[key].allocPerc = parseFloat(json.allocPerc);
						    $scope.livesAllocated.push(json);
						}
					});
					
		});
		
	};
	
	$scope.salOptionChange = function() {
		$scope.censusDetail.sal_amt=0;
	};
	$scope.goToEditCensus = function() {
		$location.path("/editCensus");
	};
	$scope.setTab = function(tabVal) {
		$scope.tab = tabVal;
		censusFactory.setSelectedTab(tabVal);
		if(tabVal==4){
			$scope.saveDisabled=true;
		}else{
			$scope.saveDisabled=false;
		}
	};

	$scope.addCls = function() {
		$rootScope.classLst.push(getClsObj($rootScope.classLst.length,$scope.censusDetail.census_id));
	};
	
	$scope.saveCensusDtl = function() {
		if($scope.tab==2){
			if($scope.censusDetail.notes.length>100){
				alert('Please enter only 100 characters.');
				$scope.censusDetail.notes=$scope.censusDetail.notes.substring(0,100);
				return false;
			}
			if($scope.censusDetailsForm.censusDate.$invalid){
				alert("'"+document.getElementById('censusDate').value+"' is an invalid date. \n\Dates must be in the form:\n\nmm/dd/yyyy");
				return false;
			}
			if($scope.censusDetailsForm.receiptDate.$invalid){
				alert("'"+document.getElementById('receiptDate').value+"' is an invalid date. \n\Dates must be in the form:\n\nmm/dd/yyyy");
				return false;
			}
			if($scope.censusDetail.no_of_live!=$scope.caseLives){
				alert("Allocation of Lives does not match census lives.");
				return false;
			}
			if($scope.censusDetailsForm.$error.pattern){
				alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
				return false;
			}
			if($scope.censusDate==null || $scope.censusDate==""){
				document.getElementById('censusDate').value = $scope.selectedCensusDetails.census_dt;
				$scope.censusDate= new Date($scope.selectedCensusDetails.census_dt);
				
			}
			if($scope.receiptDate==null || $scope.receiptDate==""){
				document.getElementById('receiptDate').value = $scope.selectedCensusDetails.receit_dt;
				$scope.receiptDate= new Date($scope.selectedCensusDetails.receit_dt);
			}
			if(!$scope.numericPattern.test($scope.censusDetail.sal_amt) && $scope.censusDetail.sal_info_avia=='TRUE' || $scope.censusDetail.sal_amt=="" && $scope.censusDetail.sal_info_avia=='TRUE'){
				$scope.censusDetail.sal_amt = $scope.selectedCensusDetails.sal_amt;
			}
			if(!$scope.timePattern.test($scope.censusDetail.time_recv_dt) || $scope.censusDetail.time_recv_dt==""){
				$scope.censusDetail.time_recv_dt = $scope.selectedCensusDetails.time_recv_dt;
			}
			if($scope.censusDetail.created_by==""){
				$scope.censusDetail.created_by = $scope.selectedCensusDetails.created_by;
			}
			$scope.censusDetail.census_dt=document.getElementById('censusDate').value;
			$scope.censusDetail.receit_dt=document.getElementById('receiptDate').value;
			appService.fetchDataWithParams("mvc/updateCensusDetail",$scope.censusDetail).then(function(data) {
				$scope.getCensusDetail();
			});
		}
		if($scope.tab==3){
			console.log($rootScope.classLst);
			if($scope.censusClassesForm.$invalid){
				alert('You must input class description!');
				return false;
			}
			appService.fetchDataWithParams("mvc/addCensusClass",$rootScope.classLst).then(function(data) {});
		}
		if($scope.tab==4){
			console.log($scope.livesAllocation);
			var livesError = true;
			$scope.livesErrorMessage='';
			angular.forEach($scope.livesAllocation, function(value, key){
				if(livesError) {
					if(value.noOfLives<=0 || isNaN(value.noOfLives) || value.noOfLives % 1 != 0){
						livesError = false;
						$scope.livesErrorMessage="**Changes can not be saved. Number of lives must be whole number greater than zero. Please correct and re-save.";
					}
				}
			});
			
			if(livesError) {
				appService.fetchDataWithParams("mvc/addLivesAllocation",$scope.livesAllocation).then(function(data) {});
			}
		}
	};
	
	
	$scope.addNewArea = function(newArea, numberOfLives){
		if($scope.newArea==""){
				alert("Please select a State!");
				return false;
		};
		if($scope.newAreaOther=="" && $scope.newArea=="ZZ"){
			alert("Please enter a country name!");
			return false;
		};
		if(numberOfLives<=0 || isNaN(numberOfLives) || numberOfLives % 1 != 0){
			alert("Number of lives must be whole number greater than zero!");
			return false;
		};
		$scope.toalLivesCount= parseInt(numberOfLives);
		$scope.selectedArea = newArea;
		$scope.selectedAreaExist = false;
		angular.forEach($scope.livesAllocation, function(value, key){
			$scope.toalLivesCount = $scope.toalLivesCount + parseInt(value.noOfLives);
			if($scope.selectedArea==value.cenState){
				$scope.selectedAreaExist=true;
			}
		});
		
		if($scope.allocationLivesForm.$error.pattern && $scope.newArea=="ZZ"){
			alert('Sorry, but you may not use double quotes (\") in text fields. Please remove any and try again.');
			return false;
		}
		
		if(newArea!="" && numberOfLives!="" && numberOfLives!=0){
			if($scope.selectedAreaExist){
				$scope.livesErrorMessage='**This state/area is already allocated';
			}
			else{
				$scope.livesAllocation.push({
					'censusId':$scope.censusId,
					'cenState':newArea, 
					'noOfLives':numberOfLives, 
					'allocPerc':(numberOfLives*100/$scope.caseLives).toFixed(2)
				});
				$scope.saveDisabled=true;
				$scope.livesErrorMessage='';
				$scope.livesAllocated=[];
				angular.forEach($scope.livesAllocation, function(value, key){
					if(value.cenState.length>=2){
						var stateCode = value.cenState.substring(0, 2);
						var stateFlag = true;
						angular.forEach($scope.livesAllocated, function(livesVal, livesKey){
							if(livesVal.allocatedState==stateCode){
								var numLives = parseInt(value.noOfLives);
								var allNumLives = parseInt(livesVal.allocatedNoOfLives);
								livesVal.allocatedNoOfLives=numLives+allNumLives;
								livesVal.allocPerc=(livesVal.allocatedNoOfLives*100/$scope.censusDetail.no_of_live).toFixed(2);
								stateFlag = false;
							}
						});
						if(stateFlag){
							var json ={
									allocatedState:stateCode,
								    allocatedNoOfLives:value.noOfLives,
								    allocPerc:(value.noOfLives*100/$scope.censusDetail.no_of_live).toFixed(2)
							};
							$scope.livesAllocation[key].allocPerc = parseFloat(json.allocPerc);
							$scope.livesAllocated.push(json);
						}
					}else{
						var json ={
							allocatedState:value.cenState,
						    allocatedNoOfLives:value.noOfLives,
						    allocPerc:(value.noOfLives*100/$scope.censusDetail.no_of_live).toFixed(2)
						};
						$scope.livesAllocation[key].allocPerc = parseFloat(json.allocPerc);
					    $scope.livesAllocated.push(json);
					}
				});
			}
		
		}
		$scope.livesAllocationLength=$scope.livesAllocation.length;
	};
	
	$scope.calculatePercentage = function(){
		$scope.livesErrorMessage='';
		$scope.validCalc=true;
		var totNoOfLives=0;
		angular.forEach($scope.livesAllocation, function(value, key){
			totNoOfLives = totNoOfLives + parseInt(value.noOfLives);
			if(value.noOfLives<=0 || isNaN(value.noOfLives)  || value.noOfLives % 1 != 0){
				alert("Number of lives must be whole number greater than zero!");
				$scope.validCalc=false;
			};
		});
		
		if(totNoOfLives!=$scope.caseLives && $scope.validCalc==true){
			$scope.livesErrorMessage="**Total of state/area lives must match total number of census lives in order to calculate percentage. Please correct and re-save.";
		}
		

		if($scope.validCalc){
		$scope.livesAllocated=[];
		angular.forEach($scope.livesAllocation, function(value, key){
			if(value.cenState.length>=2){
				var stateCode = value.cenState.substring(0, 2);
				var stateFlag = true;
				angular.forEach($scope.livesAllocated, function(livesVal, livesKey){
					if(livesVal.allocatedState==stateCode){
						var numLives = parseInt(value.noOfLives);
						var allNumLives = parseInt(livesVal.allocatedNoOfLives);
						livesVal.allocatedNoOfLives=numLives+allNumLives;
						livesVal.allocPerc=(livesVal.allocatedNoOfLives*100/$scope.censusDetail.no_of_live).toFixed(2);
						stateFlag = false;
					}
				});
				if(stateFlag){
					var json ={
							allocatedState:stateCode,
						    allocatedNoOfLives:value.noOfLives,
						    allocPerc:(value.noOfLives*100/$scope.censusDetail.no_of_live).toFixed(2)
					};
					$scope.livesAllocation[key].allocPerc = parseFloat(json.allocPerc);
					$scope.livesAllocated.push(json);
				}
			}else{
				var json ={
					allocatedState:value.cenState,
				    allocatedNoOfLives:value.noOfLives,
				    allocPerc:(value.noOfLives*100/$scope.censusDetail.no_of_live).toFixed(2)
				};
				$scope.livesAllocation[key].allocPerc = parseFloat(json.allocPerc);
			    $scope.livesAllocated.push(json);
			}
		});
		$scope.saveDisabled=false;
		}
	};
	
	$scope.deleteAllocationLives = function(ind){
		appService.fetchDataWithParams("mvc/deleteLivesAllocation",$scope.livesAllocation[ind]).then(function(data) {});
		$scope.livesAllocation.splice(ind,1);     
		$scope.livesAllocationLength=$scope.livesAllocation.length;
	};

};
