var proposalRatingResultFactory = [ '$resource', 'context', '$rootScope',
		function($resource, context, $rootScope) {

			var ratingResultData = [];
			
			return {
				setRatingResultData : function(data) {
					ratingResultData = data;
					$rootScope.$broadcast('ratingResultData_Changed');
				},
				getRatingResultData : function() {
					return ratingResultData;
				}
			};
		} ];