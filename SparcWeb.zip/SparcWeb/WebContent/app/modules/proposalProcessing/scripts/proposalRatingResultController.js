var proposalRatingResultController = ['$scope','$rootScope','$compile','appService','proposalRatingResultFactory',
		function($scope,$rootScope, $compile,appService,proposalRatingResultFactory) {
			
			/*$scope.ratingResultData={};
			$rootScope.$on('ratingResultData_Changed', function(events, args) {
				$scope.ratingResultData=proposalRatingResultFactory.getRatingResultData();
			});
			
			$scope.saveOverrides = function(){
				console.log($scope.ratingResultData);
			};
*/

}];
