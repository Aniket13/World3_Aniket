var paginationElement = function(){
       
       return {
                  restrict: 'E',
                  scope: {
                	  prevPage: '@prev',
                       nextPage: '@next',
                       stepUrl: '@',
                       stepMsg: '@',
                       stepData: '=',
                       validateFn:'&'
                  },
                  controller: ['$scope','$location','appService', function($scope, $location, appService) {
                     $scope.nextClick=function(val){
                            appService.fetchDataWithParams($scope.stepUrl, $scope.stepData).then(function(data) {
                            	//data={'errorMsg':'<b>Error Message</b>'};
                				if(data != null){
                					if(data.errorMsg!=null){
                						//$scope.errorMsg=data.errorMsg;
                						if(typeof(data.errorMsg)=='string'){
                							$scope.createTbl = data.errorMsg;
                						}else{
                							$scope.createTbl = $scope.createErrorTable(data.errorMsg); 
                							$scope.createTbl =$scope.createTbl.outerHTML;
                						}
                						var newWindow = window.open('','Fields Required',"width=600,height=300, top=80,scrollbars=1,resizable=1");
                						newWindow.document.body.innerHTML = $scope.createTbl;
                						newWindow.document.title = 'Fields Required';
                						return false;
                					}
                				}
                            	if(data=="success"){
                           		 console.log("Data saved");
                           	 	}
                            	if(val!='save'){
                        	 		$location.path($scope.nextPage);
                        	 	}
                            });
                     };
                     
                     $scope.createErrorTable = function(errorMsg) {
                 		var tbl= document.createElement("table");
                 		tbl.style.fontSize = "12px";
                		tbl.style.fontFamily = "Arial";
                 		angular.forEach(errorMsg, function(value, key){
                 			if(key!='BLANK'){
                 				var tblCol = document.createElement("td");
                 			    var tblRow= document.createElement("tr");
                 			    tblCol.innerHTML='<b>'+key+'</b>';
                 			    tblRow.appendChild(tblCol);
                 			    tbl.appendChild(tblRow);
                 			}
                 			angular.forEach(value, function(value, key){
                 				var tblCol = document.createElement("td");
                 			    var tblRow= document.createElement("tr");
                 			    tblCol.innerHTML=value.error;
                 			    tblRow.appendChild(tblCol);
                 			    tbl.appendChild(tblRow);
                 			});
                 		});
                 		return tbl;
                 	};
                 	
                     $scope.prevClick=function(){
                         $location.path($scope.prevPage);
                     };
                    }],
                  template: '<div class="stepNav">' + 
                  			'<div class="col-sm-2"><a name="prevButton" id="prevButton" ng-show="prevPage" ng-click="prevClick()" class="">Previous Step <img src="app/images/prev.png" /></a></div>' + 
                  			'<div class="col-sm-7 text-center" >{{stepMsg}}</div>' + 
                  			'<div class="col-sm-3" ng-show="nextPage"><a name="nextButton" id="nextButton" ng-click="validateFn();nextClick()" class="nextStep"><img src="app/images/next.png"  /> Next Step <span ng-show="prevPage==\'prudentialContacts\'">(License Check)</span></a> </br></div>' + 
                  			'<div class="col-sm-3 pull-right"><a name="saveButton" id="saveButton" class=" saveTaskBtn" ><img src="app/images/saveTask.png"  /> Save to Task List</a></div>' + 
                  			'</div>'
                };

};

