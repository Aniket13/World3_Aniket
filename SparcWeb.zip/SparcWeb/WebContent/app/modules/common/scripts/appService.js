var appService = ['$resource','context', '$q', '$http', function($resource, context, $q, $http) {
	
	var findData=function(url, data){
		var getData;
		var myResource= $resource(context+url);
		
		if(data!=undefined){
			 return getData=new myResource(data);
		}else{
			 return getData=new myResource();
		}
		
	};
		
	this.fetchData = function(connector) {
		/**
		 * @name fetchData
		 * @description Global method to fetch/send data from/to DB
		 * @param {string}
		 *            connector: java request mapping url
		 * @returns {object} fetched data returned with promise
		 */
		document.getElementById('showLoader').style.display='block';
		var defered = $q.defer();
		var httpPromise = $http
				.post(connector)
				.success(function(data) {
					defered.resolve(data);
					document.getElementById('showLoader').style.display='none';
				})
				.error(function(data) {
							defered.resolve('ERROR: Unknown Error. Please contact the IT Service Desk.');
							document.getElementById('showLoader').style.display='none';
				});
		return defered.promise;
	};

	this.fetchDataWithParams = function(connector, paramaters) {
		/**
		 * @name fetchData
		 * @description Global method to fetch/send data from/to DB
		 * @param {string}
		 *            connector: java request mapping url
		 * @param paramaters :
		 *            parameters to be sent to server
		 * @returns {object} a promise with fetched data
		 */
		document.getElementById('showLoader').style.display='block';
		var defered = $q.defer();
		var httpPromise = $http
			.post(connector, paramaters)
			.success(function(data) {
				defered.resolve(data);
				document.getElementById('showLoader').style.display='none';
			})
			.error(function(data) {
				defered.resolve('ERROR: Unknown Error. Please contact the IT Service Desk.');
				document.getElementById('showLoader').style.display='none';
			});
		return defered.promise;
	};
}];