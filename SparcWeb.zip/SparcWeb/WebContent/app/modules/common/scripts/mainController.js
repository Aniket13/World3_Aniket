
var mainController = ['$scope', '$rootScope', 'context', '$localStorage', 'appService','$location','selectedClientFactory',
                      function($scope, $rootScope,context,$localStorage,appService,$location,selectedClientFactory) {

	$rootScope.stateNm = 'welcomePage';
	$rootScope.$on('$stateChangeSuccess', function(event, toState, toParams,
			fromState, fromParams) {
		// event.preventDefault();
		// transitionTo() promise will be rejected with
		// a 'transition prevented' error
		$scope.stateNm = toState.name;
	});
	$scope.disableLink = true;
	$rootScope.$on('proposalIdCreated', function(event, toState,
			toParams, fromState, fromParams) {
		// event.preventDefault();
		// transitionTo() promise will be rejected with
		// a 'transition prevented' error
		$scope.disableLink = false;
	});
	
	$scope.user = {};
	$scope.isHome=false;
	$scope.user.isValid = false;
	$scope.emailPattern=/^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
	$scope.phonePattern=/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
	$scope.numberPattern=/^[1-9]\d*$/;
	$scope.integerPattern=/^[0-9]\d*$/;
	$scope.numericPattern=/^([0-9])*(\.([0-9]{0,5})+)*$/;
	$scope.specCharPattern=/^[^\"]*$/;
	$scope.timePattern=/^([0][0-9]|[1][0-2]|[0-9]{1}):([0-5][0-9]):([0-5][0-9])(\s)(AM|PM)/;
	
	

	if($localStorage.actionNav==''){
		$rootScope.actionNav='Actions';
	}else{
		$rootScope.actionNav=$localStorage.actionNav;
	}
	if($localStorage.proposalIdAttr!=''){
		$scope.disableLink = false;
	}
	
	$scope.activeNav = function(val) {
		$localStorage.actionNav=val;
		$rootScope.actionNav=val;
		$localStorage.clientIdAttr='';
		$localStorage.sicCode = '';
		$localStorage.selectedCensus='';
		$scope.disableLink = true;
		$localStorage.enableCensus=false;
		$localStorage.proposalIdAttr='';
		$localStorage.selectedField='';
		$localStorage.versionNumber='';
		$localStorage.versionIndexNum='';
		$localStorage.versionDescription='';
		$localStorage.versionStatus='';
		$localStorage.productName='';
		$localStorage.planNumber='';
		$localStorage.planDescription='';
		$localStorage.selectedCensusId='';
	};
	
	$scope.goToNav = function() {
		if($rootScope.actionNav=='RFP'){
			$location.path('searchClient');
			$localStorage.clientIdAttr='';
			$localStorage.sicCode = '';
			$localStorage.selectedCensus='';
			$scope.disableLink = true;
			$localStorage.enableCensus=false;
			$localStorage.proposalIdAttr='';
			$localStorage.selectedField='';
			$localStorage.versionNumber='';
			$localStorage.versionIndexNum='';
			$localStorage.versionDescription='';
			$localStorage.versionStatus='';
			$localStorage.productName='';
			$localStorage.planNumber='';
			$localStorage.planDescription='';
			$localStorage.selectedCensusId='';
		}
	};
	
	$scope.logout= function() {
		//kill the session on logout
		appService.fetchData("mvc/killSession").then(function(data){
			console.log("session invalidated");
		});
		window.close();
		window.opener.location.href='#/login';
		$localStorage.loginUser='';
		
	};
	
	window.addEventListener("beforeunload", function (e) {
		  console.log('window close event');
		});
		
	$scope.changeState = function(url) {
		
		if (!$scope.disableLink || url=='selectedClient') {
			if(url=='plan'){
				if($localStorage.productName!=''){
					$location.path(url);
				}
			}else{
				$location.path(url);
			}
			
		}
		if($localStorage.enableCensus && url=='census'){
			$location.path(url);
		}
		
	
		//for rating demo
		if(url=='proposalExhibition'){
			$location.path(url);
		}
	};
	
	$scope.createErrorTable = function(errorMsg) {
		var tbl= document.createElement("table");
		tbl.style.fontSize = "12px";
		tbl.style.fontFamily = "Arial";
		angular.forEach(errorMsg, function(value, key){
			if(key!='BLANK'){
				var tblCol = document.createElement("td");
			    var tblRow= document.createElement("tr");
			    tblCol.innerHTML='<b>'+key+'</b>';
			    tblRow.appendChild(tblCol);
			    tbl.appendChild(tblRow);
			}
			angular.forEach(value, function(value, key){
				var tblCol = document.createElement("td");
			    var tblRow= document.createElement("tr");
			    tblCol.innerHTML=value.error;
			    tblRow.appendChild(tblCol);
			    tbl.appendChild(tblRow);
			});
		});
		return tbl;
	};
	
	$scope.goHome = function() {
		$location.path("\welcomeHome");
		selectedClientFactory.removeSelectedClient();
		$rootScope.actionNav='Actions';
		$localStorage.actionNav='';
		$localStorage.clientIdAttr='';
		$localStorage.sicCode = '';
		$localStorage.selectedCensus='';
		$scope.disableLink = true;
		$localStorage.enableCensus=false;
		$localStorage.proposalIdAttr='';
		$localStorage.selectedField='';
		$localStorage.versionNumber='';
		$localStorage.versionIndexNum='';
		$localStorage.versionDescription='';
		$localStorage.versionStatus='';
		$localStorage.productName='';
		$localStorage.planNumber='';
		$localStorage.planDescription='';
		$localStorage.selectedCensusId='';
	};
	
	
}];

