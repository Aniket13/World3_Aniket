var app = angular.module('sparc',['ngResource','ui.router','ui.bootstrap','ngStorage']);
	
app.constant('context', '/prudentialweb');

app.config(
		[ '$stateProvider', '$urlRouterProvider',
				function($stateProvider, $urlRouterProvider) {

					$urlRouterProvider.otherwise('/login');
					$stateProvider

					// HOME STATES AND NESTED VIEWS ========================================
					.state('login', {
						url : '/login',
						templateUrl : 'app/modules/login/templates/login.html',
						controller:'loginController'
					})
					.state('welcomePage', {
						url : '/welcomePage',
						templateUrl : 'app/modules/login/templates/welcome.html',
						controller:'loginController'
					})
					.state('roles', {
						url : '/roles',
						templateUrl : 'app/modules/login/templates/roles.html',
						controller:'rolesController'
					})
					.state('welcomeHome', {
						url : '/welcomeHome',
						templateUrl : 'app/modules/login/templates/welcomeHome.html',
						controller:'homeController'
					})
				
					.state('searchClient', {
						url : '/searchClient',
						templateUrl : 'app/modules/clients/templates/clientSearch.html',
						controller:'searchClientController'
					})
					.state('selectedClient', {
						url : '/selectedClient',
						templateUrl : 'app/modules/clients/templates/clientSelected.html',
						controller:'selectedClientController'
					})
					
					.state('basicInformation', {
						url : '/basicInformation',
						templateUrl : 'app/modules/proposalBackground/templates/basicInformation.html',
						controller:'basicInformationController'
					})
					.state('licenseCheck',
					{   url : '/licenseCheck',
						templateUrl : 'app/modules/proposalBackground/templates/licenseCheck.html',
						controller : 'licenseCheckController'
					})
				
					.state('prudentialContacts', {
						url : '/prudentialContacts',
						templateUrl : 'app/modules/proposalBackground/templates/prudentialContacts.html',
						controller:'prudentialContactsController'
					})
					
					.state('producerSearch', {
						url : '/producerSearch',
						views : {
							'' : {
					        	templateUrl: 'app/modules/proposalBackground/templates/producerSearch.html',
					        	controller:'producerSearchController'
					        },
				        	'personalProfile@producerSearch' : {
					        	templateUrl: 'app/modules/proposalBackground/templates/producerSearch-personalProfile.html',
					        	controller:'producerSearchController'
					        },
					        'fullADB@producerSearch' : {
					        	templateUrl: 'app/modules/proposalBackground/templates/producerSearch-fullADB.html',
					        	controller:'producerSearchController'
					        },
					        'individualSearch@producerSearch' : {
					        	templateUrl: 'app/modules/proposalBackground/templates/producerSearch-individualSearch.html',
					        	controller:'producerSearchController'
					        },
					        'firmSearch@producerSearch' : {
					        	templateUrl: 'app/modules/proposalBackground/templates/producerSearch-firmSearch.html',
					        	controller:'producerSearchController'
					        }
						}
					})
					
					
					.state('quickQuotes', {
						url : '/quickQuotes',
						templateUrl : 'app/modules/proposalDetails/templates/quickQuotes.html',
						controller:'quickQuotesController'
					})
				
					.state('proposalDetailsPlan', {
						url : '/plan',
						views: {
							'':{
								templateUrl : 'app/modules/proposalDetails/templates/proposalDetailsPlan.html',
								controller:'proposalDetailsPlanController'
								},
					        'planDetails@proposalDetailsPlan': { 
					        	templateUrl: "app/modules/proposalDetails/templates/planDetails.html",
					        	controller:'proposalDetailsPlanController'},
					        'planDetailsOverrides@proposalDetailsPlan': { 
						        templateUrl: "app/modules/proposalDetails/templates/planDetailsOverrides.html",
						        controller:'proposalDetailsPlanController'},
				        	'commissions@proposalDetailsPlan':{ 
				        		templateUrl: "app/modules/proposalDetails/templates/proposalDetailsPlanCommission.html",
					        	controller:'proposalDetailsPlanController'
					        	}
					      	}
					})
					
					.state('proposalExhibition',{
						url : '/proposalExhibition',
						views : {
							'' : {
								templateUrl : 'app/modules/proposalProcessing/templates/proposalExhibition.html',
								controller : 'proposalExhibitionController'
							},
							'ratingResult@proposalExhibition' : {
								templateUrl : 'app/modules/proposalProcessing/templates/proposalRatingResult.html',
								controller : 'proposalExhibitionController'
							}
						}
					})
					
					.state('ratingEngine', {
						url : '/ratingEngine',
						templateUrl : 'app/modules/proposalProcessing/templates/ratingEngine.html',
						controller:'ratingEngineController'
					})
					
					.state('census', {
						url : '/census',
						templateUrl : 'app/modules/proposalProcessing/templates/census.html',
						controller:'censusController'
					})
					.state('editCensus', {
						url : '/editCensus',
						templateUrl : 'app/modules/proposalProcessing/templates/editCensus.html',
						controller:'editCensusController'
					});
				} ]);


/** Controllers **/
app.controller('loginController', loginController);
app.controller('rolesController', rolesController);
app.controller('mainController', mainController);
app.controller('searchClientController',searchClientController);
app.controller('selectedClientController',selectedClientController);
app.controller('prudentialContactsController',prudentialContactsController);
app.controller('basicInformationController',basicInformationController);
app.controller('licenseCheckController', licenseCheckController);
app.controller('producerSearchController',producerSearchController);
app.controller('quickQuotesController',quickQuotesController);
app.controller('proposalDetailsPlanController',proposalDetailsPlanController);
app.controller('proposalDetailsPlanCommissionController',proposalDetailsPlanCommissionController);
app.controller('proposalExhibitionController',proposalExhibitionController);
app.controller('ratingEngineController',ratingEngineController);
app.controller('planlDetailsController',planlDetailsController);
app.controller('censusController',censusController);
app.controller('editCensusController',editCensusController);
app.controller('proposalRatingResultController',proposalRatingResultController);
app.controller('homeController',homeController);


/** Services **/
app.service('appService',appService);

/** factories **/
app.factory('planDetailsFactory',planDetailsFactory);
app.factory('producerSearchFactory',producerSearchFactory);
app.factory('commonFactory',commonFactory);
app.factory('selectedClientFactory',selectedClientFactory);
app.factory('censusFactory',censusFactory);
app.factory('proposalRatingResultFactory',proposalRatingResultFactory);

/** Directives **/
app.directive('paginationElement',paginationElement);  
app.directive('headTopElement',headTopElement);  

app.filter('startFrom',startFrom);
