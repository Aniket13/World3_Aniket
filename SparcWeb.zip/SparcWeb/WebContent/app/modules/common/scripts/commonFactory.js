var commonFactory = [ '$resource', 'context', '$rootScope',
		function($resource, context, $rootScope) {
	
	return 0;
} ];