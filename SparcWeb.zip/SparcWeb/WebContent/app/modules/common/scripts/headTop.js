var headTopElement = function(){
       return {
                  restrict: 'E',
                  scope: {
                	  headTopList: '='
                  },
                  template: '<div class="headTop"><ul><li ng-repeat="item in headTopList" class="col-md-4 col-sm-6" ng-class="{clearLeft:{{$index}}==7}"><div class="col-md-5 col-xs-5 headLabel">{{item.name}}</div> <div class="col-md-7  col-xs-7">{{item.value}}</div></li></ul></div>'
                };

};

