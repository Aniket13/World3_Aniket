package com.sample;

import java.util.ArrayList;
import java.util.List;

public class PojoDRLListIteration {

 private List<String> listOfString;

 public List<String> getListOfString() {
  return listOfString;
 }

 public void setListOfString(List<String> listOfString) {
  this.listOfString = listOfString;
 }

 public void addString(String value) {
  if (listOfString == null) {
   listOfString = new ArrayList<String>();
  }
  listOfString.add(value);
 }
}