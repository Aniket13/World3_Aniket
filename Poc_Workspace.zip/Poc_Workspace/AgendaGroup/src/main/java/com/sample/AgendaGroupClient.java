package com.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

public class AgendaGroupClient {

	public static void main(String args[]) throws Exception {
		//calling DRL to DT
		KnowledgeBase kbase = readKnowledgeBase();
		StatefulKnowledgeSession knowledgeSession = kbase
				.newStatefulKnowledgeSession();
		try {
			LoanAmount loanAmount = new LoanAmount();
			loanAmount.setBankBalance(10000);
			loanAmount.setMonthlyInstallment(18000);
			loanAmount.setAccountId("ACC013867");
			
			knowledgeSession.insert(loanAmount);

			knowledgeSession.getAgenda().getAgendaGroup("Inti1").setFocus();
			
			knowledgeSession.fireAllRules();
			

		} finally {

			knowledgeSession.dispose();
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		
		
		kbuilder.add(ResourceFactory.newClassPathResource("AgendaGroup.drl"),
				ResourceType.DRL);
		
		kbuilder.add(ResourceFactory.newClassPathResource("AgendaGroupD1.xls"),
				ResourceType.DTABLE);
		

		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}

		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}
	

	
	
}