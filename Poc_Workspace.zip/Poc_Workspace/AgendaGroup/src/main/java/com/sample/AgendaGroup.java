package com.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;

public class AgendaGroup {

	public static void main(String args[]) throws Exception {
//calling DT to DT
		KnowledgeBase kbase = readKnowledgeBase();
		StatefulKnowledgeSession knowledgeSession = kbase
				.newStatefulKnowledgeSession();
		try {
			LoanAmount loanAmount = new LoanAmount();
			loanAmount.setBankBalance(10000);
			loanAmount.setMonthlyInstallment(18000);
			loanAmount.setAccountId("ACC013867");

			System.out.println("befor loading excel");
			String dtpath = "D:\\Poc_Workspace\\AgendaGroup\\src\\main\\rules\\AgendagroupD.xls";
			testSpreadsheet(dtpath);
			System.out.println("after loading excel");
			knowledgeSession.insert(loanAmount);
		/*	knowledgeSession.getAgenda().getAgendaGroup("Thanks")
			.setFocus();*/
			knowledgeSession.getAgenda().getAgendaGroup("Thanks")
			.setFocus();
			knowledgeSession.getAgenda().getAgendaGroup("Check Balance")
					.setFocus();
			knowledgeSession.fireAllRules();
		} finally {
			knowledgeSession.dispose();
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();

		DecisionTableConfiguration config = KnowledgeBuilderFactory
				.newDecisionTableConfiguration();
		config.setInputType(DecisionTableInputType.XLS);
		kbuilder.add(ResourceFactory.newClassPathResource("AgendagroupD.xls"),
				ResourceType.DTABLE, config);
		kbuilder.add(ResourceFactory.newClassPathResource("AgendagroupD1.xls"),
				ResourceType.DTABLE, config);
		

		// kbuilder.add(ResourceFactory.newClassPathResource("AgendaGroup1.drl"),
		// ResourceType.DRL);
		// kbuilder.add(ResourceFactory.newClassPathResource("AgendaGroup2.drl"),
		// ResourceType.DRL);

		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}

		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

	private static void testSpreadsheet(String dtpath) {
		File dtf = new File(dtpath);
		InputStream is;
		try {
			is = new FileInputStream(dtf);
			SpreadsheetCompiler ssComp = new SpreadsheetCompiler();
			String s = ssComp.compile(is, InputType.XLS);
			System.out.println("=== Begin generated DRL ===");
			System.out.println(s);
			System.out.println("=== End generated DRL ===");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}