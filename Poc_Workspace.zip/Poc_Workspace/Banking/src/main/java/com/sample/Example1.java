package com.sample;

public class Example1 {
	public static void main(String[] args) throws Exception {
		new RuleRunner().runRules(new String[] { "Example1.drl" },
				new Object[0]);
	}
}