package com.sample;

public class Customer {

	public String CustId;
	public String CustType;

	public String getCustId() {
		return CustId;
	}

	public String getCustType() {
		return CustType;
	}

	public void setCustType(String custType) {
		CustType = custType;
	}

	public void setCustId(String custId) {
		CustId = custId;
	}

	
}
