package com.sample;

import java.util.StringTokenizer;

public class Token {

	public static void main(String args[])
	{
		StringTokenizer st =new StringTokenizer("hello abc","");
		while(st.hasMoreTokens())
		{
			String a=st.nextToken();
			StringBuffer sb=new StringBuffer(a);
	
			System.out.println(sb.reverse());
		}
	}
}
