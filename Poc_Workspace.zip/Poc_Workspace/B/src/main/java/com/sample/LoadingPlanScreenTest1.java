package com.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;

/**
 * This is a sample class to launch a decision table.
 */
public class LoadingPlanScreenTest1 {

	public static final void main(String[] args) {
		try {
			// load up the knowledge base
			KnowledgeBase kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();
			KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory
					.newFileLogger(ksession, "test");
			// go !
			System.out.println("befor loading excel");
			String dtpath = "D:\\Poc_Workspace\\B\\src\\main\\rules\\PlanLoadScreen.xls";
			testSpreadsheet(dtpath);
			System.out.println("after loading excel");
			PlanOnloadData p = new PlanOnloadData();
			p.setProduct_Name("BL");
			ksession.insert(p);
			ksession.fireAllRules();
			System.out.println(p.getContract_State_SetValue());
			System.out.println(p.getAgeBanded_Rating_SetValue());
			System.out.println(p.getAgeBanded_Rating_DefaultValue());
			System.out.println(p.getGurantee_Issue_Limit_SetValue());
			System.out.println(p.getEarning_Defination_SetValue());
			System.out.println(p.getInclude_Bonus_In_Earning_Defination_SetValue());
System.out.println(p);
			logger.close();
			ksession.dispose();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		DecisionTableConfiguration config = KnowledgeBuilderFactory
				.newDecisionTableConfiguration();
		config.setInputType(DecisionTableInputType.XLS);
		kbuilder.add(ResourceFactory.newClassPathResource("PlanLoadScreen.xls"),
				ResourceType.DTABLE, config);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

	private static void testSpreadsheet(String dtpath) {
		File dtf = new File(dtpath);
		InputStream is;
		try {
			is = new FileInputStream(dtf);
			SpreadsheetCompiler ssComp = new SpreadsheetCompiler();
			String s = ssComp.compile(is, InputType.XLS);
			System.out.println("=== Begin generated DRL ===");
			System.out.println(s);
			System.out.println("=== End generated DRL ===");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
