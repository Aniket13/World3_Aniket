package com.sample;

public class RangePojoClass {

	private double PlanEstAnnualPremium;
	private double Commission_Date_Value;
	private double value;
	private String rule;

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public double getPlanEstAnnualPremium() {
		return PlanEstAnnualPremium;
	}

	public void setPlanEstAnnualPremium(double planEstAnnualPremium) {
		PlanEstAnnualPremium = planEstAnnualPremium;
	}

	public double getCommission_Date_Value() {
		return Commission_Date_Value;
	}

	public void setCommission_Date_Value(double commission_Date_Value) {
		Commission_Date_Value = commission_Date_Value;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

}
