package com.sample;

public class PlanDecision {
	private String Contract_State;
	private String Effective_Date;
	private String Plan_Description;
	private String Type_OF_Case;
	private String Pru_Value_Exceptions;
	private String Field_Level_Exceptions;
	private String Contribution_Arrangement;
	private String Minimum_Participation_Percentage;
	private String Volatility_Caveat_Percentage;
	private String Composite_Rating;
	private String AgeBanded_Rating;
	private String Rate_Guarantee;
	private String Rate_Expression;
	private String Amount_Of_Insurance;
	private String Maximum_Dollar_Amount;
	private String Minimum_Dollar_Amount;
	private String Multiple_Of_Annual_Earning;
	private String Rounding_Rule;
	private String Age_Reduction_Schedule;
	private String Disability_Provision;
	private String Duration;
	private String Volume_Amounts;
	private String Gurantee_Issue_Limit;
	private String Dollar_Amount;
	private String Living_Benifit_Option;
	private String LBO_Maximum;
	private String LBO_Percentage;
	private String LBO_LifeExpectancy;
	private String Coverage_Terminates_At_Retirement;
	private String Travel_Assistance;
	private String Earning_Defination;
	private String Include_Bonus_In_Earning_Defination;
	private String Include_Commision_In_Earning_Defination;
	private String Include_OvertimeIn_Earning_Defination;
	
	
	
	private boolean Contract_State_Flag;
	private boolean Effective_Date_Flag;
	private boolean Plan_Description_Flag;
	private boolean Type_OF_Case_Flag;
	private boolean Pru_Value_Exceptions_Flag;
	private boolean Field_Level_Exceptions_Flag;
	private boolean Contribution_Arrangement_Flag;
	private boolean Minimum_Participation_Percentage_Flag;
	private boolean Volatility_Caveat_Percentage_Flag;
	private boolean Composite_Rating_Flag;
	private boolean AgeBanded_Rating_Flag;
	private boolean Rate_Guarantee_Flag;
	private boolean Rate_Expression_Flag;
	private boolean Amount_Of_Insurance_Flag;
	private boolean Maximum_Dollar_Amount_Flag;
	private boolean Minimum_Dollar_Amount_Flag;
	private boolean Multiple_Of_Annual_Earning_Flag;
	private boolean Rounding_Rule_Flag;
	private boolean Age_Reduction_Schedule_Flag;
	private boolean Disability_Provision_Flag;
	private boolean Duration_Flag;
	private boolean Volume_Amounts_Flag;
	private boolean Gurantee_Issue_Limit_Flag;
	private boolean Dollar_Amount_Flag;
	private boolean Living_Benifit_Option_Flag;
	private boolean LBO_Maximum_Flag;
	private boolean LBO_Percentage_Flag;
	private boolean LBO_LifeExpectancy_Flag;
	private boolean Coverage_Terminates_At_Retirement_Flag;
	private boolean Travel_Assistance_Flag;
	private boolean Earning_Defination_Flag;
	private boolean Include_Bonus_In_Earning_Defination_Flag;
	private boolean Include_Commision_In_Earning_Defination_Flag;
	private boolean Include_OvertimeIn_Earning_Defination_Flag;
	
	public String getContract_State() {
		return Contract_State;
	}
	public void setContract_State(String contract_State) {
		Contract_State = contract_State;
	}
	public String getEffective_Date() {
		return Effective_Date;
	}
	public void setEffective_Date(String effective_Date) {
		Effective_Date = effective_Date;
	}
	public String getPlan_Description() {
		return Plan_Description;
	}
	public void setPlan_Description(String plan_Description) {
		Plan_Description = plan_Description;
	}
	public String getType_OF_Case() {
		return Type_OF_Case;
	}
	public void setType_OF_Case(String type_OF_Case) {
		Type_OF_Case = type_OF_Case;
	}
	public String getPru_Value_Exceptions() {
		return Pru_Value_Exceptions;
	}
	public void setPru_Value_Exceptions(String pru_Value_Exceptions) {
		Pru_Value_Exceptions = pru_Value_Exceptions;
	}
	public String getField_Level_Exceptions() {
		return Field_Level_Exceptions;
	}
	public void setField_Level_Exceptions(String field_Level_Exceptions) {
		Field_Level_Exceptions = field_Level_Exceptions;
	}
	public String getContribution_Arrangement() {
		return Contribution_Arrangement;
	}
	public void setContribution_Arrangement(String contribution_Arrangement) {
		Contribution_Arrangement = contribution_Arrangement;
	}
	public String getMinimum_Participation_Percentage() {
		return Minimum_Participation_Percentage;
	}
	public void setMinimum_Participation_Percentage(
			String minimum_Participation_Percentage) {
		Minimum_Participation_Percentage = minimum_Participation_Percentage;
	}
	public String getVolatility_Caveat_Percentage() {
		return Volatility_Caveat_Percentage;
	}
	public void setVolatility_Caveat_Percentage(String volatility_Caveat_Percentage) {
		Volatility_Caveat_Percentage = volatility_Caveat_Percentage;
	}
	public String getComposite_Rating() {
		return Composite_Rating;
	}
	public void setComposite_Rating(String composite_Rating) {
		Composite_Rating = composite_Rating;
	}
	public String getAgeBanded_Rating() {
		return AgeBanded_Rating;
	}
	public void setAgeBanded_Rating(String ageBanded_Rating) {
		AgeBanded_Rating = ageBanded_Rating;
	}
	public String getRate_Guarantee() {
		return Rate_Guarantee;
	}
	public void setRate_Guarantee(String rate_Guarantee) {
		Rate_Guarantee = rate_Guarantee;
	}
	public String getRate_Expression() {
		return Rate_Expression;
	}
	public void setRate_Expression(String rate_Expression) {
		Rate_Expression = rate_Expression;
	}
	public String getAmount_Of_Insurance() {
		return Amount_Of_Insurance;
	}
	public void setAmount_Of_Insurance(String amount_Of_Insurance) {
		Amount_Of_Insurance = amount_Of_Insurance;
	}
	public String getMaximum_Dollar_Amount() {
		return Maximum_Dollar_Amount;
	}
	public void setMaximum_Dollar_Amount(String maximum_Dollar_Amount) {
		Maximum_Dollar_Amount = maximum_Dollar_Amount;
	}
	public String getMinimum_Dollar_Amount() {
		return Minimum_Dollar_Amount;
	}
	public void setMinimum_Dollar_Amount(String minimum_Dollar_Amount) {
		Minimum_Dollar_Amount = minimum_Dollar_Amount;
	}
	public String getMultiple_Of_Annual_Earning() {
		return Multiple_Of_Annual_Earning;
	}
	public void setMultiple_Of_Annual_Earning(String multiple_Of_Annual_Earning) {
		Multiple_Of_Annual_Earning = multiple_Of_Annual_Earning;
	}
	public String getRounding_Rule() {
		return Rounding_Rule;
	}
	public void setRounding_Rule(String rounding_Rule) {
		Rounding_Rule = rounding_Rule;
	}
	public String getAge_Reduction_Schedule() {
		return Age_Reduction_Schedule;
	}
	public void setAge_Reduction_Schedule(String age_Reduction_Schedule) {
		Age_Reduction_Schedule = age_Reduction_Schedule;
	}
	public String getDisability_Provision() {
		return Disability_Provision;
	}
	public void setDisability_Provision(String disability_Provision) {
		Disability_Provision = disability_Provision;
	}
	public String getDuration() {
		return Duration;
	}
	public void setDuration(String duration) {
		Duration = duration;
	}
	public String getVolume_Amounts() {
		return Volume_Amounts;
	}
	public void setVolume_Amounts(String volume_Amounts) {
		Volume_Amounts = volume_Amounts;
	}
	public String getGurantee_Issue_Limit() {
		return Gurantee_Issue_Limit;
	}
	public void setGurantee_Issue_Limit(String gurantee_Issue_Limit) {
		Gurantee_Issue_Limit = gurantee_Issue_Limit;
	}
	public String getDollar_Amount() {
		return Dollar_Amount;
	}
	public void setDollar_Amount(String dollar_Amount) {
		Dollar_Amount = dollar_Amount;
	}
	public String getLiving_Benifit_Option() {
		return Living_Benifit_Option;
	}
	public void setLiving_Benifit_Option(String living_Benifit_Option) {
		Living_Benifit_Option = living_Benifit_Option;
	}
	public String getLBO_Maximum() {
		return LBO_Maximum;
	}
	public void setLBO_Maximum(String lBO_Maximum) {
		LBO_Maximum = lBO_Maximum;
	}
	public String getLBO_Percentage() {
		return LBO_Percentage;
	}
	public void setLBO_Percentage(String lBO_Percentage) {
		LBO_Percentage = lBO_Percentage;
	}
	public String getLBO_LifeExpectancy() {
		return LBO_LifeExpectancy;
	}
	public void setLBO_LifeExpectancy(String lBO_LifeExpectancy) {
		LBO_LifeExpectancy = lBO_LifeExpectancy;
	}
	public String getCoverage_Terminates_At_Retirement() {
		return Coverage_Terminates_At_Retirement;
	}
	public void setCoverage_Terminates_At_Retirement(
			String coverage_Terminates_At_Retirement) {
		Coverage_Terminates_At_Retirement = coverage_Terminates_At_Retirement;
	}
	public String getTravel_Assistance() {
		return Travel_Assistance;
	}
	public void setTravel_Assistance(String travel_Assistance) {
		Travel_Assistance = travel_Assistance;
	}
	public String getEarning_Defination() {
		return Earning_Defination;
	}
	public void setEarning_Defination(String earning_Defination) {
		Earning_Defination = earning_Defination;
	}
	public String getInclude_Bonus_In_Earning_Defination() {
		return Include_Bonus_In_Earning_Defination;
	}
	public void setInclude_Bonus_In_Earning_Defination(
			String include_Bonus_In_Earning_Defination) {
		Include_Bonus_In_Earning_Defination = include_Bonus_In_Earning_Defination;
	}
	public String getInclude_Commision_In_Earning_Defination() {
		return Include_Commision_In_Earning_Defination;
	}
	public void setInclude_Commision_In_Earning_Defination(
			String include_Commision_In_Earning_Defination) {
		Include_Commision_In_Earning_Defination = include_Commision_In_Earning_Defination;
	}
	public String getInclude_OvertimeIn_Earning_Defination() {
		return Include_OvertimeIn_Earning_Defination;
	}
	public void setInclude_OvertimeIn_Earning_Defination(
			String include_OvertimeIn_Earning_Defination) {
		Include_OvertimeIn_Earning_Defination = include_OvertimeIn_Earning_Defination;
	}
	public boolean isContract_State_Flag() {
		return Contract_State_Flag;
	}
	public void setContract_State_Flag(boolean contract_State_Flag) {
		Contract_State_Flag = contract_State_Flag;
	}
	public boolean isEffective_Date_Flag() {
		return Effective_Date_Flag;
	}
	public void setEffective_Date_Flag(boolean effective_Date_Flag) {
		Effective_Date_Flag = effective_Date_Flag;
	}
	public boolean isPlan_Description_Flag() {
		return Plan_Description_Flag;
	}
	public void setPlan_Description_Flag(boolean plan_Description_Flag) {
		Plan_Description_Flag = plan_Description_Flag;
	}
	public boolean isType_OF_Case_Flag() {
		return Type_OF_Case_Flag;
	}
	public void setType_OF_Case_Flag(boolean type_OF_Case_Flag) {
		Type_OF_Case_Flag = type_OF_Case_Flag;
	}
	public boolean isPru_Value_Exceptions_Flag() {
		return Pru_Value_Exceptions_Flag;
	}
	public void setPru_Value_Exceptions_Flag(boolean pru_Value_Exceptions_Flag) {
		Pru_Value_Exceptions_Flag = pru_Value_Exceptions_Flag;
	}
	public boolean isField_Level_Exceptions_Flag() {
		return Field_Level_Exceptions_Flag;
	}
	public void setField_Level_Exceptions_Flag(boolean field_Level_Exceptions_Flag) {
		Field_Level_Exceptions_Flag = field_Level_Exceptions_Flag;
	}
	public boolean isContribution_Arrangement_Flag() {
		return Contribution_Arrangement_Flag;
	}
	public void setContribution_Arrangement_Flag(
			boolean contribution_Arrangement_Flag) {
		Contribution_Arrangement_Flag = contribution_Arrangement_Flag;
	}
	public boolean isMinimum_Participation_Percentage_Flag() {
		return Minimum_Participation_Percentage_Flag;
	}
	public void setMinimum_Participation_Percentage_Flag(
			boolean minimum_Participation_Percentage_Flag) {
		Minimum_Participation_Percentage_Flag = minimum_Participation_Percentage_Flag;
	}
	public boolean isVolatility_Caveat_Percentage_Flag() {
		return Volatility_Caveat_Percentage_Flag;
	}
	public void setVolatility_Caveat_Percentage_Flag(
			boolean volatility_Caveat_Percentage_Flag) {
		Volatility_Caveat_Percentage_Flag = volatility_Caveat_Percentage_Flag;
	}
	public boolean isComposite_Rating_Flag() {
		return Composite_Rating_Flag;
	}
	public void setComposite_Rating_Flag(boolean composite_Rating_Flag) {
		Composite_Rating_Flag = composite_Rating_Flag;
	}
	public boolean isAgeBanded_Rating_Flag() {
		return AgeBanded_Rating_Flag;
	}
	public void setAgeBanded_Rating_Flag(boolean ageBanded_Rating_Flag) {
		AgeBanded_Rating_Flag = ageBanded_Rating_Flag;
	}
	public boolean isRate_Guarantee_Flag() {
		return Rate_Guarantee_Flag;
	}
	public void setRate_Guarantee_Flag(boolean rate_Guarantee_Flag) {
		Rate_Guarantee_Flag = rate_Guarantee_Flag;
	}
	public boolean isRate_Expression_Flag() {
		return Rate_Expression_Flag;
	}
	public void setRate_Expression_Flag(boolean rate_Expression_Flag) {
		Rate_Expression_Flag = rate_Expression_Flag;
	}
	public boolean isAmount_Of_Insurance_Flag() {
		return Amount_Of_Insurance_Flag;
	}
	public void setAmount_Of_Insurance_Flag(boolean amount_Of_Insurance_Flag) {
		Amount_Of_Insurance_Flag = amount_Of_Insurance_Flag;
	}
	public boolean isMaximum_Dollar_Amount_Flag() {
		return Maximum_Dollar_Amount_Flag;
	}
	public void setMaximum_Dollar_Amount_Flag(boolean maximum_Dollar_Amount_Flag) {
		Maximum_Dollar_Amount_Flag = maximum_Dollar_Amount_Flag;
	}
	public boolean isMinimum_Dollar_Amount_Flag() {
		return Minimum_Dollar_Amount_Flag;
	}
	public void setMinimum_Dollar_Amount_Flag(boolean minimum_Dollar_Amount_Flag) {
		Minimum_Dollar_Amount_Flag = minimum_Dollar_Amount_Flag;
	}
	public boolean isMultiple_Of_Annual_Earning_Flag() {
		return Multiple_Of_Annual_Earning_Flag;
	}
	public void setMultiple_Of_Annual_Earning_Flag(
			boolean multiple_Of_Annual_Earning_Flag) {
		Multiple_Of_Annual_Earning_Flag = multiple_Of_Annual_Earning_Flag;
	}
	public boolean isRounding_Rule_Flag() {
		return Rounding_Rule_Flag;
	}
	public void setRounding_Rule_Flag(boolean rounding_Rule_Flag) {
		Rounding_Rule_Flag = rounding_Rule_Flag;
	}
	public boolean isAge_Reduction_Schedule_Flag() {
		return Age_Reduction_Schedule_Flag;
	}
	public void setAge_Reduction_Schedule_Flag(boolean age_Reduction_Schedule_Flag) {
		Age_Reduction_Schedule_Flag = age_Reduction_Schedule_Flag;
	}
	public boolean isDisability_Provision_Flag() {
		return Disability_Provision_Flag;
	}
	public void setDisability_Provision_Flag(boolean disability_Provision_Flag) {
		Disability_Provision_Flag = disability_Provision_Flag;
	}
	public boolean isDuration_Flag() {
		return Duration_Flag;
	}
	public void setDuration_Flag(boolean duration_Flag) {
		Duration_Flag = duration_Flag;
	}
	public boolean isVolume_Amounts_Flag() {
		return Volume_Amounts_Flag;
	}
	public void setVolume_Amounts_Flag(boolean volume_Amounts_Flag) {
		Volume_Amounts_Flag = volume_Amounts_Flag;
	}
	public boolean isGurantee_Issue_Limit_Flag() {
		return Gurantee_Issue_Limit_Flag;
	}
	public void setGurantee_Issue_Limit_Flag(boolean gurantee_Issue_Limit_Flag) {
		Gurantee_Issue_Limit_Flag = gurantee_Issue_Limit_Flag;
	}
	public boolean isDollar_Amount_Flag() {
		return Dollar_Amount_Flag;
	}
	public void setDollar_Amount_Flag(boolean dollar_Amount_Flag) {
		Dollar_Amount_Flag = dollar_Amount_Flag;
	}
	public boolean isLiving_Benifit_Option_Flag() {
		return Living_Benifit_Option_Flag;
	}
	public void setLiving_Benifit_Option_Flag(boolean living_Benifit_Option_Flag) {
		Living_Benifit_Option_Flag = living_Benifit_Option_Flag;
	}
	public boolean isLBO_Maximum_Flag() {
		return LBO_Maximum_Flag;
	}
	public void setLBO_Maximum_Flag(boolean lBO_Maximum_Flag) {
		LBO_Maximum_Flag = lBO_Maximum_Flag;
	}
	public boolean isLBO_Percentage_Flag() {
		return LBO_Percentage_Flag;
	}
	public void setLBO_Percentage_Flag(boolean lBO_Percentage_Flag) {
		LBO_Percentage_Flag = lBO_Percentage_Flag;
	}
	public boolean isLBO_LifeExpectancy_Flag() {
		return LBO_LifeExpectancy_Flag;
	}
	public void setLBO_LifeExpectancy_Flag(boolean lBO_LifeExpectancy_Flag) {
		LBO_LifeExpectancy_Flag = lBO_LifeExpectancy_Flag;
	}
	public boolean isCoverage_Terminates_At_Retirement_Flag() {
		return Coverage_Terminates_At_Retirement_Flag;
	}
	public void setCoverage_Terminates_At_Retirement_Flag(
			boolean coverage_Terminates_At_Retirement_Flag) {
		Coverage_Terminates_At_Retirement_Flag = coverage_Terminates_At_Retirement_Flag;
	}
	public boolean isTravel_Assistance_Flag() {
		return Travel_Assistance_Flag;
	}
	public void setTravel_Assistance_Flag(boolean travel_Assistance_Flag) {
		Travel_Assistance_Flag = travel_Assistance_Flag;
	}
	public boolean isEarning_Defination_Flag() {
		return Earning_Defination_Flag;
	}
	public void setEarning_Defination_Flag(boolean earning_Defination_Flag) {
		Earning_Defination_Flag = earning_Defination_Flag;
	}
	public boolean isInclude_Bonus_In_Earning_Defination_Flag() {
		return Include_Bonus_In_Earning_Defination_Flag;
	}
	public void setInclude_Bonus_In_Earning_Defination_Flag(
			boolean include_Bonus_In_Earning_Defination_Flag) {
		Include_Bonus_In_Earning_Defination_Flag = include_Bonus_In_Earning_Defination_Flag;
	}
	public boolean isInclude_Commision_In_Earning_Defination_Flag() {
		return Include_Commision_In_Earning_Defination_Flag;
	}
	public void setInclude_Commision_In_Earning_Defination_Flag(
			boolean include_Commision_In_Earning_Defination_Flag) {
		Include_Commision_In_Earning_Defination_Flag = include_Commision_In_Earning_Defination_Flag;
	}
	public boolean isInclude_OvertimeIn_Earning_Defination_Flag() {
		return Include_OvertimeIn_Earning_Defination_Flag;
	}
	public void setInclude_OvertimeIn_Earning_Defination_Flag(
			boolean include_OvertimeIn_Earning_Defination_Flag) {
		Include_OvertimeIn_Earning_Defination_Flag = include_OvertimeIn_Earning_Defination_Flag;
	}
	
	/*  
	 Set Values
	 */
	
	String Composite_Rating_DefaultValue;
	public String getComposite_Rating_DefaultValue() {
		return Composite_Rating_DefaultValue;
	}
	public void setComposite_Rating_DefaultValue(
			String composite_Rating_DefaultValue) {
		Composite_Rating_DefaultValue = composite_Rating_DefaultValue;
	}
	public String getAgeBanded_Rating_DefaultValue() {
		return AgeBanded_Rating_DefaultValue;
	}
	public void setAgeBanded_Rating_DefaultValue(
			String ageBanded_Rating_DefaultValue) {
		AgeBanded_Rating_DefaultValue = ageBanded_Rating_DefaultValue;
	}
	public String getContract_State_DefaultValue() {
		return Contract_State_DefaultValue;
	}
	public void setContract_State_DefaultValue(String contract_State_DefaultValue) {
		Contract_State_DefaultValue = contract_State_DefaultValue;
	}
	public String getEffective_Date_DefaultValue() {
		return Effective_Date_DefaultValue;
	}
	public void setEffective_Date_DefaultValue(String effective_Date_DefaultValue) {
		Effective_Date_DefaultValue = effective_Date_DefaultValue;
	}
	public String getType_OF_Case_DefaultValue() {
		return Type_OF_Case_DefaultValue;
	}
	public void setType_OF_Case_DefaultValue(String type_OF_Case_DefaultValue) {
		Type_OF_Case_DefaultValue = type_OF_Case_DefaultValue;
	}

	String AgeBanded_Rating_DefaultValue;
	String Contract_State_DefaultValue;
	String Effective_Date_DefaultValue;

	String Type_OF_Case_DefaultValue;
	
}
