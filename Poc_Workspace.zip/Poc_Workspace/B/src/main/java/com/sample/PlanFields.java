package com.sample;

public class PlanFields {
	
	String Contract_State;
	String Effective_Date;
	String Plan_Description;
	String Type_OF_Case;
	String Pru_Value_Exceptions;
	String Field_Level_Exceptions;
	String Contribution_Arrangement;
	String Minimum_Participation_Percentage;
	String Volatility_Caveat_Percentage;
	String Composite_Rating;
	String AgeBanded_Rating;
	String Rate_Guarantee;
	String Rate_Expression;
	String Amount_Of_Insurance;
	String Maximum_Dollar_Amount;
	String Minimum_Dollar_Amount;
	String Multiple_Of_Annual_Earning;
	String Rounding_Rule;
	String Age_Reduction_Schedule;
	String Disability_Provision;
	String Duration;
	String Volume_Amounts;
	String Gurantee_Issue_Limit;
	String Dollar_Amount;
	String Living_Benifit_Option;
	String LBO_Maximum;
	String LBO_Percentage;
	String LBO_LifeExpectancy;
	String Coverage_Terminates_At_Retirement;
	String Travel_Assistance;
	String Earning_Defination;
	String Include_Bonus_In_Earning_Defination;
	String Include_Commision_In_Earning_Defination;
	String Include_OvertimeIn_Earning_Defination;
	public String getContract_State() {
		return Contract_State;
	}
	public void setContract_State(String contract_State) {
		Contract_State = contract_State;
	}
	public String getEffective_Date() {
		return Effective_Date;
	}
	public void setEffective_Date(String effective_Date) {
		Effective_Date = effective_Date;
	}
	public String getPlan_Description() {
		return Plan_Description;
	}
	public void setPlan_Description(String plan_Description) {
		Plan_Description = plan_Description;
	}
	public String getType_OF_Case() {
		return Type_OF_Case;
	}
	public void setType_OF_Case(String type_OF_Case) {
		Type_OF_Case = type_OF_Case;
	}
	public String getPru_Value_Exceptions() {
		return Pru_Value_Exceptions;
	}
	public void setPru_Value_Exceptions(String pru_Value_Exceptions) {
		Pru_Value_Exceptions = pru_Value_Exceptions;
	}
	public String getField_Level_Exceptions() {
		return Field_Level_Exceptions;
	}
	public void setField_Level_Exceptions(String field_Level_Exceptions) {
		Field_Level_Exceptions = field_Level_Exceptions;
	}
	public String getContribution_Arrangement() {
		return Contribution_Arrangement;
	}
	public void setContribution_Arrangement(String contribution_Arrangement) {
		Contribution_Arrangement = contribution_Arrangement;
	}
	public String getMinimum_Participation_Percentage() {
		return Minimum_Participation_Percentage;
	}
	public void setMinimum_Participation_Percentage(
			String minimum_Participation_Percentage) {
		Minimum_Participation_Percentage = minimum_Participation_Percentage;
	}
	public String getVolatility_Caveat_Percentage() {
		return Volatility_Caveat_Percentage;
	}
	public void setVolatility_Caveat_Percentage(String volatility_Caveat_Percentage) {
		Volatility_Caveat_Percentage = volatility_Caveat_Percentage;
	}
	public String getComposite_Rating() {
		return Composite_Rating;
	}
	public void setComposite_Rating(String composite_Rating) {
		Composite_Rating = composite_Rating;
	}
	public String getAgeBanded_Rating() {
		return AgeBanded_Rating;
	}
	public void setAgeBanded_Rating(String ageBanded_Rating) {
		AgeBanded_Rating = ageBanded_Rating;
	}
	public String getRate_Guarantee() {
		return Rate_Guarantee;
	}
	public void setRate_Guarantee(String rate_Guarantee) {
		Rate_Guarantee = rate_Guarantee;
	}
	public String getRate_Expression() {
		return Rate_Expression;
	}
	public void setRate_Expression(String rate_Expression) {
		Rate_Expression = rate_Expression;
	}
	public String getAmount_Of_Insurance() {
		return Amount_Of_Insurance;
	}
	public void setAmount_Of_Insurance(String amount_Of_Insurance) {
		Amount_Of_Insurance = amount_Of_Insurance;
	}
	public String getMaximum_Dollar_Amount() {
		return Maximum_Dollar_Amount;
	}
	public void setMaximum_Dollar_Amount(String maximum_Dollar_Amount) {
		Maximum_Dollar_Amount = maximum_Dollar_Amount;
	}
	public String getMinimum_Dollar_Amount() {
		return Minimum_Dollar_Amount;
	}
	public void setMinimum_Dollar_Amount(String minimum_Dollar_Amount) {
		Minimum_Dollar_Amount = minimum_Dollar_Amount;
	}
	public String getMultiple_Of_Annual_Earning() {
		return Multiple_Of_Annual_Earning;
	}
	public void setMultiple_Of_Annual_Earning(String multiple_Of_Annual_Earning) {
		Multiple_Of_Annual_Earning = multiple_Of_Annual_Earning;
	}
	public String getRounding_Rule() {
		return Rounding_Rule;
	}
	public void setRounding_Rule(String rounding_Rule) {
		Rounding_Rule = rounding_Rule;
	}
	public String getAge_Reduction_Schedule() {
		return Age_Reduction_Schedule;
	}
	public void setAge_Reduction_Schedule(String age_Reduction_Schedule) {
		Age_Reduction_Schedule = age_Reduction_Schedule;
	}
	public String getDisability_Provision() {
		return Disability_Provision;
	}
	public void setDisability_Provision(String disability_Provision) {
		Disability_Provision = disability_Provision;
	}
	public String getDuration() {
		return Duration;
	}
	public void setDuration(String duration) {
		Duration = duration;
	}
	public String getVolume_Amounts() {
		return Volume_Amounts;
	}
	public void setVolume_Amounts(String volume_Amounts) {
		Volume_Amounts = volume_Amounts;
	}
	public String getGurantee_Issue_Limit() {
		return Gurantee_Issue_Limit;
	}
	public void setGurantee_Issue_Limit(String gurantee_Issue_Limit) {
		Gurantee_Issue_Limit = gurantee_Issue_Limit;
	}
	public String getDollar_Amount() {
		return Dollar_Amount;
	}
	public void setDollar_Amount(String dollar_Amount) {
		Dollar_Amount = dollar_Amount;
	}
	public String getLiving_Benifit_Option() {
		return Living_Benifit_Option;
	}
	public void setLiving_Benifit_Option(String living_Benifit_Option) {
		Living_Benifit_Option = living_Benifit_Option;
	}
	public String getLBO_Maximum() {
		return LBO_Maximum;
	}
	public void setLBO_Maximum(String lBO_Maximum) {
		LBO_Maximum = lBO_Maximum;
	}
	public String getLBO_Percentage() {
		return LBO_Percentage;
	}
	public void setLBO_Percentage(String lBO_Percentage) {
		LBO_Percentage = lBO_Percentage;
	}
	public String getLBO_LifeExpectancy() {
		return LBO_LifeExpectancy;
	}
	public void setLBO_LifeExpectancy(String lBO_LifeExpectancy) {
		LBO_LifeExpectancy = lBO_LifeExpectancy;
	}
	public String getCoverage_Terminates_At_Retirement() {
		return Coverage_Terminates_At_Retirement;
	}
	public void setCoverage_Terminates_At_Retirement(
			String coverage_Terminates_At_Retirement) {
		Coverage_Terminates_At_Retirement = coverage_Terminates_At_Retirement;
	}
	public String getTravel_Assistance() {
		return Travel_Assistance;
	}
	public void setTravel_Assistance(String travel_Assistance) {
		Travel_Assistance = travel_Assistance;
	}
	public String getEarning_Defination() {
		return Earning_Defination;
	}
	public void setEarning_Defination(String earning_Defination) {
		Earning_Defination = earning_Defination;
	}
	public String getInclude_Bonus_In_Earning_Defination() {
		return Include_Bonus_In_Earning_Defination;
	}
	public void setInclude_Bonus_In_Earning_Defination(
			String include_Bonus_In_Earning_Defination) {
		Include_Bonus_In_Earning_Defination = include_Bonus_In_Earning_Defination;
	}
	public String getInclude_Commision_In_Earning_Defination() {
		return Include_Commision_In_Earning_Defination;
	}
	public void setInclude_Commision_In_Earning_Defination(
			String include_Commision_In_Earning_Defination) {
		Include_Commision_In_Earning_Defination = include_Commision_In_Earning_Defination;
	}
	public String getInclude_OvertimeIn_Earning_Defination() {
		return Include_OvertimeIn_Earning_Defination;
	}
	public void setInclude_OvertimeIn_Earning_Defination(
			String include_OvertimeIn_Earning_Defination) {
		Include_OvertimeIn_Earning_Defination = include_OvertimeIn_Earning_Defination;
	}



}
