package com.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;
import org.drools.io.ResourceFactory;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;

/**
 * This is a sample class to launch a decision table.
 */
public class DecisionTableTest {

	public static final void main(String[] args) {
		try {
			// load up the knowledge base
			KnowledgeBase kbase = readKnowledgeBase();
			StatefulKnowledgeSession ksession = kbase
					.newStatefulKnowledgeSession();
			KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory
					.newFileLogger(ksession, "test");
			// go !
			System.out.println("befor loading excel");
			String dtpath = "D:\\Poc_Workspace\\B\\src\\main\\rules\\Plan.XLS";
			testSpreadsheet(dtpath);
			System.out.println("after loading excel");
			Plan p1 = new Plan();

			p1.setProduct_Name("BL");
			/*p1.setContract_State("AL");
			p1.setPlan_Description("Plan1");
			p1.setContribution_Arrangement("Contributory");
			p1.setComposite_Rating("Yes");
			p1.setAgeBanded_Rating("Yes");
			p1.setRate_Expression("Per $100 of Covered Payroll");
			p1.setAge_Reduction_Schedule("35% @ 65");
			p1.setDisability_Provision("Dis A");
			p1.setDuration("Age 65");
			p1.setVolume_Amounts("System calculated volume");
			p1.setGurantee_Issue_Limit("Dollar");
			p1.setLiving_Benifit_Option("No");
			p1.setLBO_LifeExpectancy("");
			p1.setCoverage_Terminates_At_Retirement("Yes");*/

			ksession.insert(p1);
			ksession.fireAllRules();
			logger.close();
			System.out.println(p1.getRule());
			System.out.println(p1.getContract_State());
			//System.out.println(p1.getComposite_Rating_Flag());
			/*StringTokenizer st=new StringTokenizer(p1.getContract_State_Flag(),"|");
			while(st.hasMoreElements())
			{
				
					System.out.println(st.nextToken());
					
			
			}*/
			ksession.dispose();

		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	private static KnowledgeBase readKnowledgeBase() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		DecisionTableConfiguration config = KnowledgeBuilderFactory
				.newDecisionTableConfiguration();
		config.setInputType(DecisionTableInputType.XLS);
		kbuilder.add(ResourceFactory.newClassPathResource("Plan.XLS"),
				ResourceType.DTABLE, config);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kbase;
	}

	private static void testSpreadsheet(String dtpath) {
		File dtf = new File(dtpath);
		InputStream is;
		try {
			is = new FileInputStream(dtf);
			SpreadsheetCompiler ssComp = new SpreadsheetCompiler();
			String s = ssComp.compile(is, InputType.XLS);
			System.out.println("=== Begin generated DRL ===");
			System.out.println(s);
			System.out.println("=== End generated DRL ===");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
