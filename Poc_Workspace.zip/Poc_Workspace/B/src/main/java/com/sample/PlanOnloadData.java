package com.sample;

public class PlanOnloadData {

	private String Product_Name;
	public String getProduct_Name() {
		return Product_Name;
	}
	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}
	String Contract_State_SetValue;
	String Effective_Date_SetValue;
	String Plan_Description_SetValue;
	String Type_OF_Case_SetValue;
	String Pru_Value_Exceptions_SetValue;
	String Field_Level_Exceptions_SetValue;
	String Contribution_Arrangement_SetValue;
	String Minimum_Participation_Percentage_SetValue;
	String Volatility_Caveat_Percentage_SetValue;
	String Composite_Rating_SetValue;
	String AgeBanded_Rating_SetValue;
	String Rate_Guarantee_SetValue;
	String Rate_Expression_SetValue;
	String Amount_Of_Insurance_SetValue;
	String Maximum_Dollar_Amount_SetValue;
	String Minimum_Dollar_Amount_SetValue;
	String Multiple_Of_Annual_Earning_SetValue;
	String Rounding_Rule_SetValue;
	String Age_Reduction_Schedule_SetValue;
	String Disability_Provision_SetValue;
	String Duration_SetValue;
	String Volume_Amounts_SetValue;
	String Gurantee_Issue_Limit_SetValue;
	String Dollar_Amount_SetValue;
	String Living_Benifit_Option_SetValue;
	String LBO_Maximum_SetValue;
	String LBO_Percentage_SetValue;
	String LBO_LifeExpectancy_SetValue;
	String Coverage_Terminates_At_Retirement_SetValue;
	String Travel_Assistance_SetValue;
	String Earning_Defination_SetValue;
	String Include_Bonus_In_Earning_Defination_SetValue;
	String Include_Commision_In_Earning_Defination_SetValue;
	String Include_OvertimeIn_Earning_Defination_SetValue;
	
	String Contract_State_DefaultValue;
	String Effective_Date_DefaultValue;
	String Plan_Description_DefaultValue;
	String Type_OF_Case_DefaultValue;
	String Pru_Value_Exceptions_DefaultValue;
	String Field_Level_Exceptions_DefaultValue;
	String Contribution_Arrangement_DefaultValue;
	String Minimum_Participation_Percentage_DefaultValue;
	String Volatility_Caveat_Percentage_DefaultValue;
	String Composite_Rating_DefaultValue;
	String AgeBanded_Rating_DefaultValue;
	String Rate_Guarantee_DefaultValue;
	String Rate_Expression_DefaultValue;
	String Amount_Of_Insurance_DefaultValue;
	String Maximum_Dollar_Amount_DefaultValue;
	String Minimum_Dollar_Amount_DefaultValue;
	String Multiple_Of_Annual_Earning_DefaultValue;
	String Rounding_Rule_DefaultValue;
	String Age_Reduction_Schedule_DefaultValue;
	String Disability_Provision_DefaultValue;
	String Duration_DefaultValue;
	String Volume_Amounts_DefaultValue;
	String Gurantee_Issue_Limit_DefaultValue;
	String Dollar_Amount_DefaultValue;
	String Living_Benifit_Option_DefaultValue;
	String LBO_Maximum_DefaultValue;
	String LBO_Percentage_DefaultValue;
	String LBO_LifeExpectancy_DefaultValue;
	String Coverage_Terminates_At_Retirement_DefaultValue;
	String Travel_Assistance_DefaultValue;
	String Earning_Defination_DefaultValue;
	String Include_Bonus_In_Earning_Defination_DefaultValue;
	String Include_Commision_In_Earning_Defination_DefaultValue;
	String Include_OvertimeIn_Earning_Defination_DefaultValue;
	
	public String getContract_State_SetValue() {
		return Contract_State_SetValue;
	}
	public void setContract_State_SetValue(String contract_State_SetValue) {
		Contract_State_SetValue = contract_State_SetValue;
	}
	public String getEffective_Date_SetValue() {
		return Effective_Date_SetValue;
	}
	public void setEffective_Date_SetValue(String effective_Date_SetValue) {
		Effective_Date_SetValue = effective_Date_SetValue;
	}
	public String getPlan_Description_SetValue() {
		return Plan_Description_SetValue;
	}
	public void setPlan_Description_SetValue(String plan_Description_SetValue) {
		Plan_Description_SetValue = plan_Description_SetValue;
	}
	public String getType_OF_Case_SetValue() {
		return Type_OF_Case_SetValue;
	}
	public void setType_OF_Case_SetValue(String type_OF_Case_SetValue) {
		Type_OF_Case_SetValue = type_OF_Case_SetValue;
	}
	public String getPru_Value_Exceptions_SetValue() {
		return Pru_Value_Exceptions_SetValue;
	}
	public void setPru_Value_Exceptions_SetValue(
			String pru_Value_Exceptions_SetValue) {
		Pru_Value_Exceptions_SetValue = pru_Value_Exceptions_SetValue;
	}
	public String getField_Level_Exceptions_SetValue() {
		return Field_Level_Exceptions_SetValue;
	}
	public void setField_Level_Exceptions_SetValue(
			String field_Level_Exceptions_SetValue) {
		Field_Level_Exceptions_SetValue = field_Level_Exceptions_SetValue;
	}
	public String getContribution_Arrangement_SetValue() {
		return Contribution_Arrangement_SetValue;
	}
	public void setContribution_Arrangement_SetValue(
			String contribution_Arrangement_SetValue) {
		Contribution_Arrangement_SetValue = contribution_Arrangement_SetValue;
	}
	public String getMinimum_Participation_Percentage_SetValue() {
		return Minimum_Participation_Percentage_SetValue;
	}
	public void setMinimum_Participation_Percentage_SetValue(
			String minimum_Participation_Percentage_SetValue) {
		Minimum_Participation_Percentage_SetValue = minimum_Participation_Percentage_SetValue;
	}
	public String getVolatility_Caveat_Percentage_SetValue() {
		return Volatility_Caveat_Percentage_SetValue;
	}
	public void setVolatility_Caveat_Percentage_SetValue(
			String volatility_Caveat_Percentage_SetValue) {
		Volatility_Caveat_Percentage_SetValue = volatility_Caveat_Percentage_SetValue;
	}
	public String getComposite_Rating_SetValue() {
		return Composite_Rating_SetValue;
	}
	public void setComposite_Rating_SetValue(String composite_Rating_SetValue) {
		Composite_Rating_SetValue = composite_Rating_SetValue;
	}
	public String getAgeBanded_Rating_SetValue() {
		return AgeBanded_Rating_SetValue;
	}
	public void setAgeBanded_Rating_SetValue(String ageBanded_Rating_SetValue) {
		AgeBanded_Rating_SetValue = ageBanded_Rating_SetValue;
	}
	public String getRate_Guarantee_SetValue() {
		return Rate_Guarantee_SetValue;
	}
	public void setRate_Guarantee_SetValue(String rate_Guarantee_SetValue) {
		Rate_Guarantee_SetValue = rate_Guarantee_SetValue;
	}
	public String getRate_Expression_SetValue() {
		return Rate_Expression_SetValue;
	}
	public void setRate_Expression_SetValue(String rate_Expression_SetValue) {
		Rate_Expression_SetValue = rate_Expression_SetValue;
	}
	public String getAmount_Of_Insurance_SetValue() {
		return Amount_Of_Insurance_SetValue;
	}
	public void setAmount_Of_Insurance_SetValue(String amount_Of_Insurance_SetValue) {
		Amount_Of_Insurance_SetValue = amount_Of_Insurance_SetValue;
	}
	public String getMaximum_Dollar_Amount_SetValue() {
		return Maximum_Dollar_Amount_SetValue;
	}
	public void setMaximum_Dollar_Amount_SetValue(
			String maximum_Dollar_Amount_SetValue) {
		Maximum_Dollar_Amount_SetValue = maximum_Dollar_Amount_SetValue;
	}
	public String getMinimum_Dollar_Amount_SetValue() {
		return Minimum_Dollar_Amount_SetValue;
	}
	public void setMinimum_Dollar_Amount_SetValue(
			String minimum_Dollar_Amount_SetValue) {
		Minimum_Dollar_Amount_SetValue = minimum_Dollar_Amount_SetValue;
	}
	public String getMultiple_Of_Annual_Earning_SetValue() {
		return Multiple_Of_Annual_Earning_SetValue;
	}
	public void setMultiple_Of_Annual_Earning_SetValue(
			String multiple_Of_Annual_Earning_SetValue) {
		Multiple_Of_Annual_Earning_SetValue = multiple_Of_Annual_Earning_SetValue;
	}
	public String getRounding_Rule_SetValue() {
		return Rounding_Rule_SetValue;
	}
	public void setRounding_Rule_SetValue(String rounding_Rule_SetValue) {
		Rounding_Rule_SetValue = rounding_Rule_SetValue;
	}
	public String getAge_Reduction_Schedule_SetValue() {
		return Age_Reduction_Schedule_SetValue;
	}
	public void setAge_Reduction_Schedule_SetValue(
			String age_Reduction_Schedule_SetValue) {
		Age_Reduction_Schedule_SetValue = age_Reduction_Schedule_SetValue;
	}
	public String getDisability_Provision_SetValue() {
		return Disability_Provision_SetValue;
	}
	public void setDisability_Provision_SetValue(
			String disability_Provision_SetValue) {
		Disability_Provision_SetValue = disability_Provision_SetValue;
	}
	public String getDuration_SetValue() {
		return Duration_SetValue;
	}
	public void setDuration_SetValue(String duration_SetValue) {
		Duration_SetValue = duration_SetValue;
	}
	public String getVolume_Amounts_SetValue() {
		return Volume_Amounts_SetValue;
	}
	public void setVolume_Amounts_SetValue(String volume_Amounts_SetValue) {
		Volume_Amounts_SetValue = volume_Amounts_SetValue;
	}
	public String getGurantee_Issue_Limit_SetValue() {
		return Gurantee_Issue_Limit_SetValue;
	}
	public void setGurantee_Issue_Limit_SetValue(
			String gurantee_Issue_Limit_SetValue) {
		Gurantee_Issue_Limit_SetValue = gurantee_Issue_Limit_SetValue;
	}
	public String getDollar_Amount_SetValue() {
		return Dollar_Amount_SetValue;
	}
	public void setDollar_Amount_SetValue(String dollar_Amount_SetValue) {
		Dollar_Amount_SetValue = dollar_Amount_SetValue;
	}
	public String getLiving_Benifit_Option_SetValue() {
		return Living_Benifit_Option_SetValue;
	}
	public void setLiving_Benifit_Option_SetValue(
			String living_Benifit_Option_SetValue) {
		Living_Benifit_Option_SetValue = living_Benifit_Option_SetValue;
	}
	public String getLBO_Maximum_SetValue() {
		return LBO_Maximum_SetValue;
	}
	public void setLBO_Maximum_SetValue(String lBO_Maximum_SetValue) {
		LBO_Maximum_SetValue = lBO_Maximum_SetValue;
	}
	public String getLBO_Percentage_SetValue() {
		return LBO_Percentage_SetValue;
	}
	public void setLBO_Percentage_SetValue(String lBO_Percentage_SetValue) {
		LBO_Percentage_SetValue = lBO_Percentage_SetValue;
	}
	public String getLBO_LifeExpectancy_SetValue() {
		return LBO_LifeExpectancy_SetValue;
	}
	public void setLBO_LifeExpectancy_SetValue(String lBO_LifeExpectancy_SetValue) {
		LBO_LifeExpectancy_SetValue = lBO_LifeExpectancy_SetValue;
	}
	public String getCoverage_Terminates_At_Retirement_SetValue() {
		return Coverage_Terminates_At_Retirement_SetValue;
	}
	public void setCoverage_Terminates_At_Retirement_SetValue(
			String coverage_Terminates_At_Retirement_SetValue) {
		Coverage_Terminates_At_Retirement_SetValue = coverage_Terminates_At_Retirement_SetValue;
	}
	public String getTravel_Assistance_SetValue() {
		return Travel_Assistance_SetValue;
	}
	public void setTravel_Assistance_SetValue(String travel_Assistance_SetValue) {
		Travel_Assistance_SetValue = travel_Assistance_SetValue;
	}
	public String getEarning_Defination_SetValue() {
		return Earning_Defination_SetValue;
	}
	public void setEarning_Defination_SetValue(String earning_Defination_SetValue) {
		Earning_Defination_SetValue = earning_Defination_SetValue;
	}
	public String getInclude_Bonus_In_Earning_Defination_SetValue() {
		return Include_Bonus_In_Earning_Defination_SetValue;
	}
	public void setInclude_Bonus_In_Earning_Defination_SetValue(
			String include_Bonus_In_Earning_Defination_SetValue) {
		Include_Bonus_In_Earning_Defination_SetValue = include_Bonus_In_Earning_Defination_SetValue;
	}
	public String getInclude_Commision_In_Earning_Defination_SetValue() {
		return Include_Commision_In_Earning_Defination_SetValue;
	}
	public void setInclude_Commision_In_Earning_Defination_SetValue(
			String include_Commision_In_Earning_Defination_SetValue) {
		Include_Commision_In_Earning_Defination_SetValue = include_Commision_In_Earning_Defination_SetValue;
	}
	public String getInclude_OvertimeIn_Earning_Defination_SetValue() {
		return Include_OvertimeIn_Earning_Defination_SetValue;
	}
	public void setInclude_OvertimeIn_Earning_Defination_SetValue(
			String include_OvertimeIn_Earning_Defination_SetValue) {
		Include_OvertimeIn_Earning_Defination_SetValue = include_OvertimeIn_Earning_Defination_SetValue;
	}
	public String getContract_State_DefaultValue() {
		return Contract_State_DefaultValue;
	}
	public void setContract_State_DefaultValue(String contract_State_DefaultValue) {
		Contract_State_DefaultValue = contract_State_DefaultValue;
	}
	public String getEffective_Date_DefaultValue() {
		return Effective_Date_DefaultValue;
	}
	public void setEffective_Date_DefaultValue(String effective_Date_DefaultValue) {
		Effective_Date_DefaultValue = effective_Date_DefaultValue;
	}
	public String getPlan_Description_DefaultValue() {
		return Plan_Description_DefaultValue;
	}
	public void setPlan_Description_DefaultValue(
			String plan_Description_DefaultValue) {
		Plan_Description_DefaultValue = plan_Description_DefaultValue;
	}
	public String getType_OF_Case_DefaultValue() {
		return Type_OF_Case_DefaultValue;
	}
	public void setType_OF_Case_DefaultValue(String type_OF_Case_DefaultValue) {
		Type_OF_Case_DefaultValue = type_OF_Case_DefaultValue;
	}
	public String getPru_Value_Exceptions_DefaultValue() {
		return Pru_Value_Exceptions_DefaultValue;
	}
	public void setPru_Value_Exceptions_DefaultValue(
			String pru_Value_Exceptions_DefaultValue) {
		Pru_Value_Exceptions_DefaultValue = pru_Value_Exceptions_DefaultValue;
	}
	public String getField_Level_Exceptions_DefaultValue() {
		return Field_Level_Exceptions_DefaultValue;
	}
	public void setField_Level_Exceptions_DefaultValue(
			String field_Level_Exceptions_DefaultValue) {
		Field_Level_Exceptions_DefaultValue = field_Level_Exceptions_DefaultValue;
	}
	public String getContribution_Arrangement_DefaultValue() {
		return Contribution_Arrangement_DefaultValue;
	}
	public void setContribution_Arrangement_DefaultValue(
			String contribution_Arrangement_DefaultValue) {
		Contribution_Arrangement_DefaultValue = contribution_Arrangement_DefaultValue;
	}
	public String getMinimum_Participation_Percentage_DefaultValue() {
		return Minimum_Participation_Percentage_DefaultValue;
	}
	public void setMinimum_Participation_Percentage_DefaultValue(
			String minimum_Participation_Percentage_DefaultValue) {
		Minimum_Participation_Percentage_DefaultValue = minimum_Participation_Percentage_DefaultValue;
	}
	public String getVolatility_Caveat_Percentage_DefaultValue() {
		return Volatility_Caveat_Percentage_DefaultValue;
	}
	public void setVolatility_Caveat_Percentage_DefaultValue(
			String volatility_Caveat_Percentage_DefaultValue) {
		Volatility_Caveat_Percentage_DefaultValue = volatility_Caveat_Percentage_DefaultValue;
	}
	public String getComposite_Rating_DefaultValue() {
		return Composite_Rating_DefaultValue;
	}
	public void setComposite_Rating_DefaultValue(
			String composite_Rating_DefaultValue) {
		Composite_Rating_DefaultValue = composite_Rating_DefaultValue;
	}
	public String getAgeBanded_Rating_DefaultValue() {
		return AgeBanded_Rating_DefaultValue;
	}
	public void setAgeBanded_Rating_DefaultValue(
			String ageBanded_Rating_DefaultValue) {
		AgeBanded_Rating_DefaultValue = ageBanded_Rating_DefaultValue;
	}
	public String getRate_Guarantee_DefaultValue() {
		return Rate_Guarantee_DefaultValue;
	}
	public void setRate_Guarantee_DefaultValue(String rate_Guarantee_DefaultValue) {
		Rate_Guarantee_DefaultValue = rate_Guarantee_DefaultValue;
	}
	public String getRate_Expression_DefaultValue() {
		return Rate_Expression_DefaultValue;
	}
	public void setRate_Expression_DefaultValue(String rate_Expression_DefaultValue) {
		Rate_Expression_DefaultValue = rate_Expression_DefaultValue;
	}
	public String getAmount_Of_Insurance_DefaultValue() {
		return Amount_Of_Insurance_DefaultValue;
	}
	public void setAmount_Of_Insurance_DefaultValue(
			String amount_Of_Insurance_DefaultValue) {
		Amount_Of_Insurance_DefaultValue = amount_Of_Insurance_DefaultValue;
	}
	public String getMaximum_Dollar_Amount_DefaultValue() {
		return Maximum_Dollar_Amount_DefaultValue;
	}
	public void setMaximum_Dollar_Amount_DefaultValue(
			String maximum_Dollar_Amount_DefaultValue) {
		Maximum_Dollar_Amount_DefaultValue = maximum_Dollar_Amount_DefaultValue;
	}
	public String getMinimum_Dollar_Amount_DefaultValue() {
		return Minimum_Dollar_Amount_DefaultValue;
	}
	public void setMinimum_Dollar_Amount_DefaultValue(
			String minimum_Dollar_Amount_DefaultValue) {
		Minimum_Dollar_Amount_DefaultValue = minimum_Dollar_Amount_DefaultValue;
	}
	public String getMultiple_Of_Annual_Earning_DefaultValue() {
		return Multiple_Of_Annual_Earning_DefaultValue;
	}
	public void setMultiple_Of_Annual_Earning_DefaultValue(
			String multiple_Of_Annual_Earning_DefaultValue) {
		Multiple_Of_Annual_Earning_DefaultValue = multiple_Of_Annual_Earning_DefaultValue;
	}
	public String getRounding_Rule_DefaultValue() {
		return Rounding_Rule_DefaultValue;
	}
	public void setRounding_Rule_DefaultValue(String rounding_Rule_DefaultValue) {
		Rounding_Rule_DefaultValue = rounding_Rule_DefaultValue;
	}
	public String getAge_Reduction_Schedule_DefaultValue() {
		return Age_Reduction_Schedule_DefaultValue;
	}
	public void setAge_Reduction_Schedule_DefaultValue(
			String age_Reduction_Schedule_DefaultValue) {
		Age_Reduction_Schedule_DefaultValue = age_Reduction_Schedule_DefaultValue;
	}
	public String getDisability_Provision_DefaultValue() {
		return Disability_Provision_DefaultValue;
	}
	public void setDisability_Provision_DefaultValue(
			String disability_Provision_DefaultValue) {
		Disability_Provision_DefaultValue = disability_Provision_DefaultValue;
	}
	public String getDuration_DefaultValue() {
		return Duration_DefaultValue;
	}
	public void setDuration_DefaultValue(String duration_DefaultValue) {
		Duration_DefaultValue = duration_DefaultValue;
	}
	public String getVolume_Amounts_DefaultValue() {
		return Volume_Amounts_DefaultValue;
	}
	public void setVolume_Amounts_DefaultValue(String volume_Amounts_DefaultValue) {
		Volume_Amounts_DefaultValue = volume_Amounts_DefaultValue;
	}
	public String getGurantee_Issue_Limit_DefaultValue() {
		return Gurantee_Issue_Limit_DefaultValue;
	}
	public void setGurantee_Issue_Limit_DefaultValue(
			String gurantee_Issue_Limit_DefaultValue) {
		Gurantee_Issue_Limit_DefaultValue = gurantee_Issue_Limit_DefaultValue;
	}
	public String getDollar_Amount_DefaultValue() {
		return Dollar_Amount_DefaultValue;
	}
	public void setDollar_Amount_DefaultValue(String dollar_Amount_DefaultValue) {
		Dollar_Amount_DefaultValue = dollar_Amount_DefaultValue;
	}
	public String getLiving_Benifit_Option_DefaultValue() {
		return Living_Benifit_Option_DefaultValue;
	}
	public void setLiving_Benifit_Option_DefaultValue(
			String living_Benifit_Option_DefaultValue) {
		Living_Benifit_Option_DefaultValue = living_Benifit_Option_DefaultValue;
	}
	public String getLBO_Maximum_DefaultValue() {
		return LBO_Maximum_DefaultValue;
	}
	public void setLBO_Maximum_DefaultValue(String lBO_Maximum_DefaultValue) {
		LBO_Maximum_DefaultValue = lBO_Maximum_DefaultValue;
	}
	public String getLBO_Percentage_DefaultValue() {
		return LBO_Percentage_DefaultValue;
	}
	public void setLBO_Percentage_DefaultValue(String lBO_Percentage_DefaultValue) {
		LBO_Percentage_DefaultValue = lBO_Percentage_DefaultValue;
	}
	public String getLBO_LifeExpectancy_DefaultValue() {
		return LBO_LifeExpectancy_DefaultValue;
	}
	public void setLBO_LifeExpectancy_DefaultValue(
			String lBO_LifeExpectancy_DefaultValue) {
		LBO_LifeExpectancy_DefaultValue = lBO_LifeExpectancy_DefaultValue;
	}
	public String getCoverage_Terminates_At_Retirement_DefaultValue() {
		return Coverage_Terminates_At_Retirement_DefaultValue;
	}
	public void setCoverage_Terminates_At_Retirement_DefaultValue(
			String coverage_Terminates_At_Retirement_DefaultValue) {
		Coverage_Terminates_At_Retirement_DefaultValue = coverage_Terminates_At_Retirement_DefaultValue;
	}
	public String getTravel_Assistance_DefaultValue() {
		return Travel_Assistance_DefaultValue;
	}
	public void setTravel_Assistance_DefaultValue(
			String travel_Assistance_DefaultValue) {
		Travel_Assistance_DefaultValue = travel_Assistance_DefaultValue;
	}
	public String getEarning_Defination_DefaultValue() {
		return Earning_Defination_DefaultValue;
	}
	public void setEarning_Defination_DefaultValue(
			String earning_Defination_DefaultValue) {
		Earning_Defination_DefaultValue = earning_Defination_DefaultValue;
	}
	public String getInclude_Bonus_In_Earning_Defination_DefaultValue() {
		return Include_Bonus_In_Earning_Defination_DefaultValue;
	}
	public void setInclude_Bonus_In_Earning_Defination_DefaultValue(
			String include_Bonus_In_Earning_Defination_DefaultValue) {
		Include_Bonus_In_Earning_Defination_DefaultValue = include_Bonus_In_Earning_Defination_DefaultValue;
	}
	public String getInclude_Commision_In_Earning_Defination_DefaultValue() {
		return Include_Commision_In_Earning_Defination_DefaultValue;
	}
	public void setInclude_Commision_In_Earning_Defination_DefaultValue(
			String include_Commision_In_Earning_Defination_DefaultValue) {
		Include_Commision_In_Earning_Defination_DefaultValue = include_Commision_In_Earning_Defination_DefaultValue;
	}
	public String getInclude_OvertimeIn_Earning_Defination_DefaultValue() {
		return Include_OvertimeIn_Earning_Defination_DefaultValue;
	}
	public void setInclude_OvertimeIn_Earning_Defination_DefaultValue(
			String include_OvertimeIn_Earning_Defination_DefaultValue) {
		Include_OvertimeIn_Earning_Defination_DefaultValue = include_OvertimeIn_Earning_Defination_DefaultValue;
	}

}
